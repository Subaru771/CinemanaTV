# Cee TV 1.2.2

Updates the existing Cee TV app (`app.cinemanatv.cee`, version code 11). Android 8+, with the TV layout retained in landscape. The manifest already supports ordinary Android launchers and does not require Leanback/touch hardware.

## Touch testing

TV Material surfaces previously handled D-pad and accessibility activation, with no pointer click handler. A shared touch bridge now adds single taps and long presses while retaining the existing remote/focus semantics. It applies to navigation, posters, episode cards, buttons, player menus and startup notices. Scrolling cancels a tap; long press does not also activate the normal click. Touch requests focus before activation so TV focus callbacks can track the selected control.

There are visible Back controls in Details and the native player, a Close action in player menus, a larger timeline hit area, and drag-to-seek that previews while dragging and commits one seek on release. Player transport controls scroll horizontally on narrow landscape displays. This is touch support for testing the TV app, not a separate portrait phone interface.

## Quality reliability

Source declarations with reordered keys, quoted keys, extra fields and escaped query characters can now retain their labels. Commented JavaScript sources are ignored. Successful source results remain briefly reusable by the download chooser after a player prefetch is consumed. Successful HLS metadata is briefly cached, and transient lookup failures can retry.

Viewing/downloads use shared quality discovery: published HLS resolutions first, then Media3 track inspection for adaptive streams without a readable list (including DASH). Provider choices remain visible when native playback first reports only one track. Decoder metadata supplements the complete inventory rather than replacing it. Discovery runs across up to three supplied adaptive streams in parallel and publishes choices as each responds; one slow or failed stream does not hide another stream's resolutions. Numbered HLS options display as resolutions in the player instead of being labelled as servers. Playback and downloads retain each option's originating master so separate audio/subtitle tracks are preserved. Download base choices remain visible while additional qualities load, and a Retry requests fresh source/metadata. The player exposes a quality retry action without stopping playback. A fixed-resolution file is labelled as such; no resolution is invented for an unknown MP4.

The current website also declares direct MP4 files using `masterUrl` on `*.downet.net`. These now produce an Original file choice rather than being rejected as an unsupported HLS route. A direct MP4 has one encoded resolution; extra encodes are never invented. Media-server access itself still depends on the viewer's network.

See [the reference APK findings](REFERENCE-APK-FINDINGS.md) for the native CEE API difference and the live verification limits.

## Episode order and resume

Episode batches and playback queues normalize season/episode numbers chronologically. Parsing handles both Arabic digit sets, compound Arabic season ordinals, explicit episode attributes and episode labels instead of accidentally using a title's year. Explicitly selected episodes retain their identity when a queue is sorted.

Resume chooses the most recently watched unfinished episode, rather than the highest-numbered episode with saved progress. A Start from beginning action is available when resuming a series. Provider pagination still determines which episodes have been loaded; additional pages remain available through Load more episodes.

## Build and validation

JDK 17, Android SDK 35. Run `bash gradlew testDebugUnitTest assembleRelease`. Native Compose/Robolectric classes run in isolated JVMs; phone/TV screen configurations have separate test classes to avoid leaked renderer/clock state. Optional live provider tests require `CEE_LIVE_TEST=1` and are reported separately.

Pointer tests inject real taps, long presses, swipes and timeline drags, including phone landscape and chronological series controls. Existing D-pad tests remain. Live source resolution choices were compared between viewing/download paths. Physical phone/TV playback has not been tested here. Provider availability, supported media and genuine VK's official controls remain separate constraints.

The APK uses the same configured signing key as earlier Cee TV releases, preserving the existing app's local data on an ordinary update. Update feed, Telegram actions, native playback settings and local library/download features are retained.
