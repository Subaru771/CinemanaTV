package app.cinemanatv.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.gson.Gson
import com.google.gson.JsonElement
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import retrofit2.HttpException
import java.io.File

/** Small time-limited in-memory detail cache; never used for expiring stream URLs. */
private class DetailCache<T>(private val limit: Int = 40) {
    private data class Value<V>(val data: V, val expires: Long)
    private val values = object : LinkedHashMap<String, Value<T>>(limit, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Value<T>>?): Boolean = size > limit
    }
    @Synchronized fun get(key: String): T? {
        val entry = values[key] ?: return null
        if (entry.expires <= System.currentTimeMillis()) { values.remove(key); return null }
        return entry.data
    }
    @Synchronized fun put(key: String, data: T) {
        values[key] = Value(data, System.currentTimeMillis() + 5 * 60_000L)
    }
}

class Repository(
    private val api: CinemanaApi,
    /** Where the last catalog is kept so the next launch can paint instantly. */
    private val homeDir: File? = null,
) {
    private val gson = Gson()
    private val infoCache = DetailCache<Video>()
    private val episodeCache = DetailCache<List<Video>>()
    private val relatedCache = DetailCache<List<Video>>()
    // ---- Stale-while-revalidate catalog: paint last session's rows immediately, refresh behind them ----
    private fun homeFile(kind: Int?): File? = homeDir?.let { File(it, "home_${kind ?: 0}.json") }

    /** Last successfully loaded catalog for this tab, or null. Safe to call from any dispatcher. */
    suspend fun cachedHome(kind: Int?): HomeData? = withContext(Dispatchers.IO) {
        try {
            val file = homeFile(kind)?.takeIf { it.isFile && it.length() > 2L } ?: return@withContext null
            val data = gson.fromJson(file.readText(), HomeData::class.java)
            data?.takeIf { it.rows.isNotEmpty() && it.rows.all { row -> row.items.isNotEmpty() } }
        } catch (c: CancellationException) { throw c }
          catch (_: Throwable) { null } // corrupt or from an older schema: just ignore it
    }

    private suspend fun saveHome(kind: Int?, data: HomeData) = withContext(Dispatchers.IO) {
        try {
            val target = homeFile(kind) ?: return@withContext
            target.parentFile?.mkdirs()
            val tmp = File(target.parentFile, target.name + ".tmp")
            tmp.writeText(gson.toJson(data))
            if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
        } catch (c: CancellationException) { throw c }
          catch (_: Throwable) { /* cache is best-effort */ }
    }

    /** Catalog rows differ per account (Continue Watching), so drop them on sign-in / sign-out. */
    fun clearHomeCache() {
        homeDir?.listFiles()?.forEach { it.delete() }
    }

    // ---- Short-lived stream prefetch (Detail screen dwell, next episode) ----
    private class Prefetched(val at: Long, val sources: PlaySources)
    private val prefetchLock = Any()
    private val prefetched = LinkedHashMap<String, Prefetched>()

    suspend fun automaticAlternative(original: Video): Video? {
        val alternative = CeeAlternativeSource.automaticMatch(original) ?: return null
        val result = CeeAlternativeSource.resolve(alternative.id)
        if (result.qualities.isEmpty()) return null
        synchronized(prefetchLock) {
            prefetched[alternative.id] = Prefetched(System.currentTimeMillis(), result)
            while (prefetched.size > 4) prefetched.remove(prefetched.keys.first())
        }
        return alternative
    }

    /** Resolve stream URLs ahead of the Play press. Entries are single-use and expire quickly. */
    suspend fun prefetchSources(id: String) {
        val now = System.currentTimeMillis()
        val existing = synchronized(prefetchLock) { prefetched[id] }
        if (existing != null && now - existing.at < 60_000L) return
        try {
            val result = withTimeoutOrNull(8_000L) { loadSources(id) } ?: return
            if (result.qualities.isEmpty()) return
            synchronized(prefetchLock) {
                prefetched[id] = Prefetched(System.currentTimeMillis(), result)
                while (prefetched.size > 4) prefetched.remove(prefetched.keys.first())
            }
        } catch (c: CancellationException) { throw c }
          catch (_: Exception) { /* purely an optimisation; the player will fetch normally */ }
    }

    /** Allows byte preloading without consuming the one-shot stream URL warmup. */
    fun peekPrefetched(id: String, maxAgeMs: Long = 150_000L): PlaySources? {
        val entry = synchronized(prefetchLock) { prefetched[id] } ?: return null
        return entry.sources.takeIf { System.currentTimeMillis() - entry.at in 0..maxAgeMs }
    }

    /** Consumes a prefetched result if it is still fresh. Retries always fetch new URLs. */
    fun takePrefetched(id: String, maxAgeMs: Long = 150_000L): PlaySources? {
        val entry = synchronized(prefetchLock) { prefetched.remove(id) } ?: return null
        return entry.sources.takeIf { System.currentTimeMillis() - entry.at <= maxAgeMs }
    }

    /** null = the request failed (network/HTTP), empty = the server answered with nothing recognisable. */
    private suspend fun listOrNull(block: suspend () -> JsonElement): List<Video>? = try {
        val payload = block()
        withContext(Dispatchers.Default) { Payloads.videos(payload) }
    } catch (c: CancellationException) { throw c }
      catch (_: Exception) { null }

    private suspend fun list(block: suspend () -> JsonElement): List<Video> = listOrNull(block).orEmpty()

    private suspend fun browse(kind: Int, sort: String, page: Int = 0) =
        listOrNull { api.videos(kind.toString(), "0", "0", sort, "20", "-", page.toString()) }

    suspend fun loadHome(kind: Int?): HomeData = coroutineScope {
        val kinds = kind?.let { listOf(it) } ?: listOf(1, 2)
        val single = kind != null
        fun name(k: Int) = if (k == 1) "Movies" else "Series"
        val banner = async { withTimeoutOrNull(4_000L) { listOrNull { api.banner() } } }

        // Home mixes both catalogs, so it stays light (2 requests each). A Movies or Series
        // tab loads three pages of each sort and derives the extra sections locally.
        class Fetch(val k: Int, val sort: String, val task: kotlinx.coroutines.Deferred<List<Video>?>)
        val fetches = kinds.flatMap { k ->
            val pages = if (single) listOf(0, 1, 2) else listOf(0)
            pages.flatMap { page -> listOf("views_desc", "desc").map { sort ->
                Fetch(k, sort, async { withTimeoutOrNull(9_000L) { browse(k, sort, page) } })
            } }
        }
        val loaded = fetches.map { Triple(it.k, it.sort, it.task.await()) }
        val bannerList = banner.await()
        if (loaded.all { it.third == null } && bannerList == null) {
            try { api.featured() }
            catch (c: CancellationException) { throw c }
            catch (e: Exception) { throw e }
            throw java.io.IOException("Catalog unreachable")
        }

        val contentRows = buildList {
            for (k in kinds) {
                val n = name(k)
                fun pool(sort: String) = loaded.filter { it.first == k && it.second == sort }
                    .flatMap { it.third.orEmpty() }.distinctBy { it.id }
                val trending = pool("views_desc")
                val fresh = pool("desc")
                val all = (trending + fresh).distinctBy { it.id }
                fun row(title: String, items: List<Video>, min: Int = 4) {
                    if (items.size >= min) add(ContentRow(title, items.take(30)))
                }
                row("Trending $n", trending, 1)
                row("New $n", fresh, 1)
                row("Top Rated $n", all.filter { (SearchFiltering.stars(it.stars) ?: 0.0) >= 6.5 }
                    .sortedByDescending { SearchFiltering.stars(it.stars) ?: 0.0 })
                if (single) {
                    row("Classic $n", all.filter { (SearchFiltering.year(it.year) ?: 9999) < 2005 }
                        .sortedByDescending { SearchFiltering.stars(it.stars) ?: 0.0 })
                    row("Latest Releases", all.filter { (SearchFiltering.year(it.year) ?: 0) >= 2024 }
                        .sortedByDescending { SearchFiltering.year(it.year) ?: 0 })
                    // Genre sections come from the tags on the titles we actually received.
                    val byGenre = all.flatMap { v -> v.genres.map { it to v } }
                        .filter { (g, _) -> g.length in 3..24 }
                        .groupBy({ it.first.lowercase() }, { it.second })
                    byGenre.entries.filter { it.value.size >= 6 }
                        .sortedByDescending { it.value.size }.take(6)
                        .forEach { (g, items) ->
                            val label = g.replaceFirstChar { c -> c.uppercase() }
                            row("$label $n", items.distinctBy { it.id })
                        }
                }
            }
        }
        val hero = bannerList.orEmpty().let { raw ->
            val matching = if (kind == null) raw else raw.filter { it.kind == kind.toString() }
            matching.ifEmpty { contentRows.firstOrNull()?.items?.take(6).orEmpty() }
        }
        HomeData(hero, contentRows).also { saveHome(kind, it) }
    }

    suspend fun search(q: String): List<Video> = coroutineScope {
        val encoded = encodeQuery(q)
        val films = async { listOrNull { api.search(encoded, "1") } }
        val series = async { listOrNull { api.search(encoded, "2") } }
        val f = films.await(); val t = series.await()
        if (f == null && t == null) throw java.io.IOException("Search unreachable")
        // Search endpoints are explicitly scoped by content type. Use that
        // authoritative type even if an item's kind field is absent/incorrect.
        (f.orEmpty().map { it.copy(kind = "1") } +
            t.orEmpty().map { it.copy(kind = "2") })
            .distinctBy { it.id }
    }

    suspend fun info(v: Video): Video {
        if (CeeAlternativeSource.owns(v.id)) return v
        infoCache.get(v.id)?.let { return it }
        return try {
            withContext(Dispatchers.Default) { Payloads.detail(api.info(v.id), v) }.also { infoCache.put(v.id, it) }
        } catch (c: CancellationException) { throw c }
          catch (_: Exception) { v }
    }

    /** Like [info] but returns null when the lookup FAILED, so a filter can tell "unknown" from "checked". */
    suspend fun infoOrNull(v: Video, refresh: Boolean = false): Video? {
        if (CeeAlternativeSource.owns(v.id)) return v
        if (!refresh) infoCache.get(v.id)?.let { return it }
        return try {
            withContext(Dispatchers.Default) { Payloads.detail(api.info(v.id), v) }.also { infoCache.put(v.id, it) }
        } catch (c: CancellationException) { throw c }
          catch (_: Exception) { null }
    }

    suspend fun episodes(id: String): List<Video> {
        if (CeeAlternativeSource.owns(id)) return emptyList()
        episodeCache.get(id)?.let { return it }
        return list { api.episodes(id) }
            .sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber }))
            .also { if (it.isNotEmpty()) episodeCache.put(id, it) }
    }
    suspend fun related(id: String): List<Video> {
        if (CeeAlternativeSource.owns(id)) return emptyList()
        relatedCache.get(id)?.let { return it }
        return list { api.related(id) }.also { if (it.isNotEmpty()) relatedCache.put(id, it) }
    }

    /** Resolve playable URLs without ever waiting on the optional subtitle endpoint. */
    suspend fun loadSources(id: String): PlaySources {
        if (CeeAlternativeSource.owns(id)) return CeeAlternativeSource.resolve(id)
        var primaryFailure: Exception? = null
        val direct = try { withContext(Dispatchers.Default) { Payloads.sources(api.files(id)) } }
            catch (c: CancellationException) { throw c }
            catch (e: Exception) { primaryFailure = e; emptyList() }
        val files = if (direct.isNotEmpty()) direct else try {
            val fallback = withContext(Dispatchers.Default) { Payloads.sources(api.info(id)) }
            if (fallback.isEmpty() && primaryFailure != null) throw primaryFailure
            fallback
        } catch (c: CancellationException) { throw c }
          catch (e: Exception) { throw primaryFailure ?: e }
        return PlaySources(files, emptyList())
    }

    /** Subtitles are independent; a slow endpoint never delays or cancels playback. */
    suspend fun loadSubtitles(id: String): List<SubtitleOption> =
        if (CeeAlternativeSource.owns(id)) emptyList()
        else withContext(Dispatchers.Default) { Payloads.subtitles(api.subtitles(id)) }

    /** Test both of the paths needed for playback, without bypassing ISP authorization.
     * A healthy catalog alone does not prove the CDN/media host is reachable.
     */
    suspend fun networkReport(context: Context, recentVideoId: String?): String {
        val connection = app.cinemanatv.util.NetworkResilience.link(context)
        if (!connection.connected) return "No active connection. Connect Wi-Fi or Ethernet and retry."
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        val header = "Network: ${connection.type} · Android internet check: ${if (validated) "passed" else "not confirmed"}"
        if (recentVideoId != null && CeeAlternativeSource.owns(recentVideoId)) {
            return try {
                val sources = withTimeoutOrNull(25_000L) { loadSources(recentVideoId) }
                    ?: return "$header\nCEE: stream lookup timed out."
                val sample = sources.qualities.minByOrNull { it.height }
                    ?: return "$header\nCEE: no supported streams returned."
                "$header\nSource: CEE alternative\n${MediaRouteProbe.check(sample.url)}"
            } catch (c: CancellationException) { throw c }
              catch (e: Exception) { "$header\nCEE: ${e.message ?: e.javaClass.simpleName}" }
        }
        val catalog = try {
            val reachable = withTimeoutOrNull(9_000L) { api.featuredFresh(); true }
            if (reachable == null) return "$header\nCatalog: timed out.\nA stream test requires a reachable catalog."
            "Catalog: connected to the live Shabakaty server."
        } catch (c: CancellationException) { throw c }
          catch (e: retrofit2.HttpException) {
            val code = e.code()
            return "$header\nCatalog: ${NetworkProbeLogic.response(code, null).replace("Media server", "Catalog server")}\nThe ISP or account may not be enabled for Cinemana."
          } catch (e: Exception) {
            return "$header\nCatalog: ${NetworkProbeLogic.failure(e.javaClass.simpleName)}\nNo change of video quality can resolve a catalog routing problem."
          }
        val id = recentVideoId?.takeIf(String::isNotBlank)
        if (id == null) return "$header\n$catalog\nMedia: no movie sample is available. Open Home, then run this check again."
        val sources = try {
            withTimeoutOrNull(10_000L) { loadSources(id) }
                ?: return "$header\n$catalog\nMedia: stream lookup timed out."
        } catch (c: CancellationException) { throw c }
          catch (e: retrofit2.HttpException) {
            return "$header\n$catalog\nMedia links: ${NetworkProbeLogic.response(e.code(), null)}"
          } catch (e: Exception) {
            return "$header\n$catalog\nMedia links: ${NetworkProbeLogic.failure(e.javaClass.simpleName)}"
          }
        val sample = sources.qualities.minByOrNull { if (it.height > 0) it.height else 100000 }
            ?: return "$header\n$catalog\nMedia: the provider did not return playable links for this title."
        return "$header\n$catalog\n${MediaRouteProbe.check(sample.url)}"
    }

    /** More diagnostic information than a generic 'check your internet' message. */
    suspend fun probe(): String = try {
        val payload = api.featured()
        val count = Payloads.videos(payload).size
        if (count > 0) "Catalog reachable: $count recognized titles"
        else "Catalog responded, but no recognizable titles were found. Response type: " +
            when { payload.isJsonArray -> "array"; payload.isJsonObject -> "object (${payload.asJsonObject.keySet().take(8).joinToString()})"; else -> "other" }
    } catch (c: CancellationException) { throw c }
      catch (e: HttpException) { "Catalog HTTP ${e.code()} — ${if (e.code() == 403) "access restricted or authorization needed" else "request refused"}" }
      catch (e: Exception) { "Catalog unavailable: ${e.javaClass.simpleName}" }
}
