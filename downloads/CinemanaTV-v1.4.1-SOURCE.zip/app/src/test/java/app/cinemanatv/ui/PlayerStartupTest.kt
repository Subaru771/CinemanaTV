package app.cinemanatv.ui

import android.app.Application
import android.os.Looper
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import app.cinemanatv.Services
import app.cinemanatv.data.AuthRepository
import app.cinemanatv.data.CinemanaApi
import app.cinemanatv.data.Prefs
import app.cinemanatv.data.Repository
import app.cinemanatv.data.Video
import app.cinemanatv.data.QualityOption
import com.google.gson.JsonArray
import org.junit.Test
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import app.cinemanatv.util.CrashReports
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.lang.reflect.Proxy
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
@LooperMode(LooperMode.Mode.PAUSED)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PlayerStartupTest {
    @Test fun playerConstructionFailureShowsAnErrorInsteadOfCrashing() {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        val activity = controller.get()
        Services.prefs = Prefs(activity)
        var errorScreenAttached = false
        activity.setContent {
            CinemanaTheme {
                CompositionLocalProvider(LocalPlayerEngineFactory provides { throw IllegalStateException("simulated startup failure") }) {
                    PlayerScreen(listOf(Video(nb = "failure-test")), 0, onExit = {},
                        onRegisterBack = { errorScreenAttached = it != null })
                }
            }
        }
        val decor = activity.window.decorView
        decor.measure(View.MeasureSpec.makeMeasureSpec(1280, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(720, View.MeasureSpec.EXACTLY))
        decor.layout(0, 0, 1280, 720)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1))
        assertTrue(errorScreenAttached)
        assertFalse(activity.isFinishing)
        assertTrue(CrashReports.last(activity)!!.contains("simulated startup failure"))
        controller.pause().stop().destroy()
    }

    @Test fun openingAProgressiveStreamDoesNotThrowDuringPreparation() {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        val engine = CinemaPlaybackEngine(controller.get())
        try {
            engine.open("stream-test", QualityOption(480, "https://media.invalid/test.mp4"),
                emptyList(), 0L, false, 480)
            assertEquals(1, engine.player.mediaItemCount)
        } finally {
            engine.close()
            controller.pause().stop().destroy()
        }
    }

    @Test fun openingTheNativePlayerSurvivesAnUnavailableSource() {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        val activity = controller.get()
        Services.prefs = Prefs(activity)
        Services.auth = AuthRepository(Services.prefs)
        val api = Proxy.newProxyInstance(CinemanaApi::class.java.classLoader,
            arrayOf(CinemanaApi::class.java)) { _, _, _ -> JsonArray() } as CinemanaApi
        Services.repo = Repository(api)
        var playerScreenAttached = false
        activity.setContent {
            CinemanaTheme {
                PlayerScreen(listOf(Video(nb = "startup-test", enTitle = "Startup test", kind = "1")),
                    0, onExit = {}, onRegisterBack = { playerScreenAttached = it != null })
            }
        }
        val decor = activity.window.decorView
        decor.measure(View.MeasureSpec.makeMeasureSpec(1280, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(720, View.MeasureSpec.EXACTLY))
        decor.layout(0, 0, 1280, 720)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(2))
        assertTrue("The player screen must actually be composed", playerScreenAttached)
        controller.pause().stop().destroy()
    }
}
