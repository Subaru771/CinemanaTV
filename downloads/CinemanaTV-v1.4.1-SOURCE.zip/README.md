# Cinemana TV v1.4.1 — Player startup recovery and diagnostics

Version **1.4.1**, versionCode **123** guards player construction and stream
preparation so synchronous initialization exceptions become an error screen.
**Error details** and **Settings > Diagnostics > Last player error** show the
recorded exception. Uncaught Java errors leave a report shown on the next launch;
reports remain private to the app unless the user shares them. Stream URLs and
HTTP authentication headers are redacted.

The reported real-device Play crash has not yet been reproduced. Android-level
Robolectric tests exercise player-screen composition, progressive-source
preparation, and a simulated player-construction failure on API 28; they do not verify the user's hardware codecs. Automatic
alternative fallback is retained. Install over the 1.4 test APK without uninstalling
when using the APK signed in this environment.

---

# Cinemana TV v1.4 — Automatic alternative fallback

Version **1.4**, versionCode **122**. When original playback fails, the player
tries the alternative source automatically once. It switches only on a unique
exact title/release-year match; episodes also require exact season/episode
coordinates and series year. Ambiguous or missing matches keep manual selection
available. Alternative titles keep their own progress and metadata.

See [ALTERNATIVE-SOURCE.md](ALTERNATIVE-SOURCE.md) for details and limits.

---

# Cinemana TV v1.3 — Optional native alternative source

Version **1.3**, versionCode **121**, adds explicit alternative-title selection
and playback in the existing Media3 player. Open **Find alternative source** on a
title/error screen or **Settings > Diagnostics > Browse alternative source**.
See [ALTERNATIVE-SOURCE.md](ALTERNATIVE-SOURCE.md) for operation, validation,
provider limits, and signing requirements. This is not a guarantee of access on
every network. The earlier v1.2 notes below are historical.

---

# Cinemana TV v1.2 — Public release

**Version shown in Android app details:** `1.2`  
**Android versionCode:** `120` (increased from 60 to support upgrades)  
**Application ID:** `app.cinemanatv` (unchanged)

This public release incorporates the v1.6.5 development source. The historical v1.5.x/v1.6.x records below describe internal iterations, not the release name displayed to users.

Build with `MAKE-APK.cmd` (Windows) or GitHub Actions. The output is called `CinemanaTV-v1.2.apk`.

The update prompt is driven by the remotely published manifest's `versionName`. Set it to `1.2` with `versionCode` `120` for this public release. The remote update requires a versionCode greater than the installed app's to trigger.

Signing note: upgrades require the exact same signing certificate. The builder is locally debug-signed unless otherwise configured.

---

## Earlier development notes

# Cinemana TV v1.6.0 — Faster browsing without badges

Poster/episode badge overlays and automatic browsing marker checks are removed. The app no longer performs marker discovery merely because a card is visible. Published scene skipping still runs during playback, and mature-skip search checking runs only when explicitly selected.

Performance changes: no artificial 650 ms startup floor, background JSON parsing, smaller episode artwork decoding, and remembered search rankings. This release is optimized/minified and not debuggable. A speed multiplier is not certified; actual TV timing needs on-device measurement.

Version **1.6.0**, code **55**, existing local test signing key. See BUILD-STATUS-v1.6.0.md for actual build/test checks.

---


### Startup Telegram invitation (v1.6.5)

The TV Telegram popup no longer draws a bright white focus highlighter; remote focus is indicated by a subtle red border/dark shade instead.

The launch card is now language-specific: **Settings > Interface language** selects
English or Arabic for the *entire* Telegram invitation. The dialog has remote/D-pad
focus, Join / Not Now / Close, and **Don't show this again**. This preference is
local to the TV and does not affect independent new-version notifications.

Visual concepts (not screenshots of the compiled app):
`previews/Telegram-TV-English-CONCEPT.png` and
`previews/Telegram-TV-Arabic-CONCEPT.png`.


## Historical notes

# Cinemana TV v1.5.9 — General published-marker discovery

All movie and series episode titles are eligible for lookup. No Game of Thrones whitelist remains. The app uses existing published timestamps only: no video analysis, frame upload, AI service or analysis billing.

- Movies: existing CleanStream/MovieHaven data, then VideoSkip discovery if no usable mature ranges were found.
- Episodes: search VideoSkip using the parent series title, verify exact series IMDb ID, then select exact season/episode. Preserve parent identity in playback queues.
- Similar titles cannot substitute for IMDb identity. No cross-episode or cross-file timestamp mixing. Files whose ranges exceed the playback runtime are rejected.
- Source requests are bounded and pages cached briefly to avoid repeated browsing traffic.
- A title without published matching markers cannot be automatically skipped. This generalizes lookup eligibility, not guaranteed coverage. Community timestamps can be incomplete or mistimed for Cinemana’s cut.

Enable **Settings → Mature content → Skip mature scenes**. Version **1.5.9**, code **54**, same local debug signing key as earlier builds in this chat. See BUILD-STATUS-v1.5.9.md for actual checks.

Sources: https://github.com/ameen-roayan/stremio-cleanstream and https://videoskip.herokuapp.com/exchange/ . Published author/source details remain on VideoSkip’s pages.

---

## Historical release notes

# Cinemana TV v1.5.8 — Game of Thrones episode markers

Game of Thrones episodes now use VideoSkip community files selected by series IMDb ID, season and episode. Existing movie sources continue separately. Turn on **Settings → Mature content → Skip mature scenes**.

The player displays **Episode skip active · community timing; cut unverified** when it has accepted episode timestamps. Public episode support in this release is limited to Game of Thrones and episodes with published files. Source files may have missing scenes or timing differences from Cinemana. No video scanning occurs. Timestamp bounds are checked, but fitting within the runtime does not verify the edition.

Source: https://videoskip.herokuapp.com/exchange/series/225/ . Author attribution and original skip files remain available there. Timestamps are fetched on demand, not embedded as invented scene timings.

Series identity is preserved in episode queues. File lookup verifies series/episode, ignores unrelated categories and audio-only mute instructions, and rejects files whose mature ranges do not fit playback. Latest eligible published files are considered individually; timestamps from different files/episodes are never combined.

Version **1.5.8**, code **53**. See BUILD-STATUS-v1.5.8.md for actual verification. Debug APK uses the same local signing key as the previous 1.5.7 build from this chat.

---

# Cinemana TV v1.5.7 — Mature-marker loading repair

This is a native Android TV app. Enable **Settings → Mature content → Skip marked scenes**.

- Movie cards with empty/zero parent IDs now receive marker lookups instead of being treated as episodes.
- Partial title-detail responses preserve the IMDb ID and existing card data.
- Mature markers load independently of intro/credit services.
- Failed requests and missing IMDb details retry during playback; visible cards also retry unknown lookups.
- The player shows whether skipping is active, timestamps are absent, the cut does not match, or a lookup is failing.
- Existing history, settings, downloads, app ID and saved scene ranges are preserved.

Only published or previously saved timestamps can be skipped. Community data may be incomplete or inaccurate. Public mature-marker lookup currently supports movies; episodes need existing local markers. A `✓ SKIP` badge means timestamps are published, not that every scene is covered or that the playing cut matches.

Version name `1.5.7`, version code `52`. See `BUILD-STATUS-v1.5.7.md` for actual verification and `MATURE-SKIP-TESTING.md` for TV checks. APKs built with this project use the local debug key; an existing install signed with a different key cannot be updated in place.

Build with JDK 17+, Android SDK 35, and Gradle dependencies available:

```sh
bash gradlew --no-daemon testDebugUnitTest assembleRelease
```

On Windows, run `RUN-FULL-TEST.cmd`. Configure optional sign-in as described below.

---

## Historical v1.5.6 notes

# Cinemana TV v1.5.6 — Mature-skip badges and search filter

This release builds on the v1.5.5 focus/navigation fixes and adds live mature-skip marker badges and a Search filter without altering playback or saved content.

## New in v1.5.6

- Every poster card (including Home, Search, Library, Downloads, History, related content) now has a compact **✓ SKIP / NO MARKERS / CHECKING / SKIP ?** status badge. Episode cards and detail headers also show marker status.
- Search → Filters → Mature skip supports **Any status**, **Has mature skip**, **No markers found**, **Unknown / unchecked**. Filtering happens locally against available results; selecting it checks the returned list progressively (limited to three concurrent requests).
- Only titles with valid published nudity/sexual-scene timestamps from MovieHavenDB/CleanStream (or saved local scene ranges) can show **✓ SKIP**. The player must still verify the actual playback runtime/cut; the badge does **not** guarantee the video is safe or that its scenes will be skipped.
- **NO MARKERS** means both public sources were checked without verified matching entries. Timeouts, unreachable sources, unknown IDs and series with no episode-specific support remain **SKIP ?** rather than becoming false negatives.
- Existing mature-scene playback engine, settings, history, and downloads are unchanged.
 The earlier merge combines the strongest parts of **v1.5.0** (faster home, remote-first player, exact seek and skip/undo UI) and **v1.4.10** (conservative treatment of post-credits story scenes and lower-overhead marker polling).

## Build and installation

- On Windows with JDK 17+, Android SDK 35 and internet access for Gradle, run `RUN-FULL-TEST.cmd` to run regression tests and build a test-signed release APK. Use `BUILD-APK.cmd` to build without unit tests, or `BUILD-DEBUG-APK.cmd` for a debugging build.
- Output from `RUN-FULL-TEST.cmd`: `output/CinemanaTV-v1.5.6-test.apk`.
- `versionName = 1.5.6`, `versionCode = 51`; the app ID, storage, history, downloads and settings are unchanged.
- The APK signing key may not match an older install. Back up app data before removing older versions.
- Automatic mature scene skipping is only available with accurate saved or externally supplied ranges; no real-time video AI is used.

## Sign-in configuration
Sign-in needs your OAuth values. Put them in `local.properties` (not committed):

```
cinemana.clientId=YOUR_CLIENT_ID
cinemana.scope=YOUR_SCOPE
```

or set the environment variables `CINEMANA_CLIENTID` and `CINEMANA_SCOPE`
(for GitHub Actions, add them as repository secrets).

## Mature scene skipping: troubleshooting
Published movie markers require an IMDb ID. A declared source runtime must match playback within five seconds; legacy entries without a runtime are checked against the actual stream boundaries. The player status explains unavailable lookups.

## Earlier project notes

# CinemanaTV v1.4.7 — Search & TV Focus Fixes

**Android TV / Google TV full source**. No accounts or sign-in required.

Changes:
- Search removed from the navigation tabs and moved to a separate fixed header action.
- Settings sidebar responds to **D-pad focus without pressing OK**; a visible ring and category marker indicate selection.
- Search now **prioritizes exact titles** and hides low-relevance matches under a **Show related results** action.
- Settings controls and search remain remote accessible and retain the v1.4.6 two-pane design.
- Mature content options: **Off**, **Skip marked scenes**, or **Hide mature titles**.
- External player handoff is disabled in Skip Scenes mode because it cannot enforce local markers.
- Skip mature scenes uses available community and previously saved scene ranges automatically; the manual timestamp editor has been removed. Public movie scene-marker sources are supported when matching timestamps are available. Unmarked scenes are not automatically skipped.
- Hide titles uses provider age certificates and adult tags. It may miss incorrectly labeled titles; it is not a certified child-protection solution.
- Existing downloads, watch history, player and saved data formats remain intact.

## Build

On Windows with Android SDK, a network connection for Gradle dependencies, and Java 17+:

1. Extract the ZIP.
2. Double-click `RUN-V1.4.7-FULL-TEST.cmd`.
3. The script runs Android unit tests and builds a test APK. If successful the output is `output/CinemanaTV-v1.4.7-test.apk`.
4. If it fails, send `output/CinemanaTV-v1.4.7-BUILD.log`.

APK **not included**. Builds use the local debug signing key even for the optimized test APK, so keep app data and signing compatibility in mind.

## TV test priorities

1. Settings → Mature Content, then press remote **Down** to Playback and Subtitles: the right-hand panel and highlighted sidebar row should change **without OK**.
2. Search for `the mentalist`: the exact title should come first, with irrelevant results behind **Show related results**.
3. Set **Skip marked scenes**: on an unmarked title the player must show **Scene skipping unavailable · no timestamps** (it must not falsely claim the video is safe).
4. On a movie with published markers, seek just before a known marker and verify it skips past its end; test Undo. The old manual editor is no longer present.
5. Verify Hide Titles, downloads and app data remain intact. Check Back and DPAD navigation and setting persistence across restarts.

## Limitations

This environment does not have a complete Android Gradle build toolchain, so Android compilation and actual TV playback are not certified. Pure Kotlin scene-range logic can be verified independently. Historical test results in `docs/archive` refer to earlier versions.


## Community scene and chapter markers (experimental)

Cinemana can consult **SkipDB** for verified intro, recap, outro and preview
markers, with **IntroDB** as a fallback. Enable the community marker option
in Player settings first. The player only shows a skip button within a
matching range: it never jumps an arbitrary fixed number of seconds.

**Mature-scene skipping** is independent of intro markers. It requires
explicit, time-coded nudity/sexual-scene ranges from the content provider,
your saved local ranges (Android TV), or a compatible MovieHavenDB movie entry.
MovieHavenDB has very limited coverage; most series have no public verified
mature-scene markers. **No frame scanning occurs and no filtering is guaranteed.**
All movie and series titles remain visible. Different cuts may have different
scene positions; mismatched/unknown timestamps are not automatically applied.

External requests send IMDb ID, season/episode and (for SkipDB) runtime, but
not video frames or private watch history. Skipping is on-device and light on
CPU/battery. Sources: [SkipDB](https://skipdb.tv/) (ODbL 1.0, attribution
+ reciprocal data requirements), [IntroDB](https://introdb.app/) (API terms),
and [MovieHavenDB](https://github.com/arman-kh/MovieHavenDB) (CC BY 4.0).
Review each source's terms and permitted use before public redistribution.
