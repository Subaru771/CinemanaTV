package app.cinemanatv.ui

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import app.cinemanatv.Services
import app.cinemanatv.data.*
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@OptIn(ExperimentalTestApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w1280dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class TvInteractionTest {
    @get:Rule val compose=createComposeRule()
    private val movie=Video(nb="cee_123",enTitle="Example",kind="1",providerPageId="123")
    private fun SemanticsNodeInteraction.remoteClick():SemanticsNodeInteraction =
        performSemanticsAction(SemanticsActions.RequestFocus){it()}.assertIsFocused()
            .performKeyInput{pressKey(Key.DirectionCenter)}
    private fun prefs(){Services.prefs=Prefs(RuntimeEnvironment.getApplication())}

    @Test fun failedDownloadLookupCanRetryAndShowsTheActualQualityChoices() {
        prefs()
        val attempts=java.util.concurrent.atomic.AtomicInteger()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String):PlaySources {
            val attempt=attempts.incrementAndGet()
            if(attempt==1)throw java.io.IOException("temporary failure")
            return PlaySources(listOf(QualityOption(1080,"https://media.invalid/1080.mp4"),QualityOption(720,"https://media.invalid/720.mp4")),emptyList())
        }})
        var dismissed=false
        compose.setContent { CinemanaTheme {DownloadOptionsDialog(movie){dismissed=true}} }
        compose.waitUntil(10_000){attempts.get()>=1}
        compose.onNodeWithText("Retry").assertExists().remoteClick()
        compose.waitUntil(10_000){attempts.get()>=2}
        compose.onNodeWithText("1080p").assertIsDisplayed()
        compose.onNodeWithText("720p").assertIsDisplayed()
        compose.onNodeWithText("Close").performScrollTo().remoteClick()
        assertTrue(dismissed)
    }

    @Test fun qualityControlOpensWithTheRemoteWhileTheStreamIsLoading() {
        prefs()
        val pending=kotlinx.coroutines.CompletableDeferred<PlaySources>()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=pending.await()})
        compose.setContent {CinemanaTheme{PlayerScreen(listOf(movie),0,onExit={},onRegisterBack={})}}
        compose.onNodeWithText("Quality · Auto").assertIsDisplayed().remoteClick()
        compose.onNodeWithText("Video quality").assertIsDisplayed()
        compose.onNode(hasText("Auto") and hasClickAction()).assertIsDisplayed()
        compose.onNodeWithText("720p").assertDoesNotExist()
    }

    @Test fun homeCategoryShortcutOpensItsActualCollection() {
        prefs()
        val section=CatalogSection("international","International movies",1,7,96)
        val data=HomeData(listOf(movie),listOf(ContentRow("International movies",listOf(movie),section)))
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val vm=AppViewModel();vm.homeCache[0]=data;vm.markHomeFresh(0)
        compose.setContent{CinemanaTheme{MainShell(vm)}}
        compose.onNode(hasText("International movies") and hasClickAction()).performScrollTo().remoteClick()
        compose.runOnIdle {assertTrue(vm.stack.last() is Screen.Collection)}
    }

    @Test fun detailPlayAndListActionsRemainReachableWithTheRemote() {
        prefs()
        Services.repo=Repository(StubCeeCatalog())
        var played=false
        compose.setContent{CinemanaTheme{DetailScreen(movie,onPlay={_,_->played=true},onOpen={})}}
        compose.onNodeWithText("Play").remoteClick()
        compose.runOnIdle{assertTrue(played)}
        compose.onNodeWithText("Add to My List",substring=true).performScrollTo().remoteClick()
        compose.runOnIdle{assertTrue(Services.prefs.isWatchlisted(movie.id))}
    }
}
