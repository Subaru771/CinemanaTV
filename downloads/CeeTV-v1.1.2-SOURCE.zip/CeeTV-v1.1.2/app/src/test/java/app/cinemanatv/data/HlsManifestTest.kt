package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class HlsManifestTest {
    private val url="https://media.example/master.m3u8?token=private"
    private val master="""#EXTM3U
#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",URI="audio.m3u8"
#EXT-X-STREAM-INF:BANDWIDTH=4000000,RESOLUTION=1920x1080,AUDIO="audio"
1080/index.m3u8
#EXT-X-STREAM-INF:RESOLUTION=1280x720,BANDWIDTH=2000000
720/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=3000000,RESOLUTION=1280x720
720-backup/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=1000000,RESOLUTION=854x480
/480/index.m3u8
"""
    @Test fun parsesActualRenditionsAndResolvesRelativePathsWithoutCopyingMasterTokens() {
        val variants=HlsManifest.variants(url,master)
        assertEquals(listOf(1080,720,480),variants.map{it.height})
        assertEquals("https://media.example/1080/index.m3u8",variants.first().url)
        assertEquals("https://media.example/480/index.m3u8",variants.last().url)
    }
    @Test fun rejectsHtmlMissingResolutionAndUnsafeVariantAddresses() {
        assertTrue(HlsManifest.variants(url,"<html>Server error</html>").isEmpty())
        val bad="#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=5000\naudio.m3u8\n#EXT-X-STREAM-INF:RESOLUTION=1920x1080\nhttp://media.example/x.m3u8\n"
        assertTrue(HlsManifest.variants(url,bad).isEmpty())
    }
    @Test fun successfulMasterWithDeniedChildDoesNotCountAsPlayable() {
        assertFalse(HlsManifest.readable(url,{ if(it==url)master else throw IOException("HTTP 403") },{true}))
    }
    @Test fun successfulPlaylistsWithDeniedSegmentDoNotCountAsPlayable() {
        assertFalse(HlsManifest.readable(url,{ if(it==url)master else "#EXTM3U\n#EXTINF:4,\nsegment.ts" },{false}))
    }
    @Test fun followsSmallestRenditionThroughActualVideoData() {
        val segments=mutableListOf<String>()
        assertTrue(HlsManifest.readable(url,{ if(it==url)master else "#EXTM3U\n#EXTINF:4,\nsegment.ts" },{segments.add(it);true}))
        assertEquals(listOf("https://media.example/480/segment.ts"),segments)
    }
    @Test fun mediaPlaylistDoesNotNeedAnInventedMasterOrResolution() {
        assertTrue(HlsManifest.readable(url,{"#EXTM3U\n#EXTINF:4,\nsegment.ts"},{it=="https://media.example/segment.ts"}))
        assertTrue(HlsManifest.variants(url,"#EXTM3U\n#EXTINF:4,\nsegment.ts").isEmpty())
    }
    @Test fun downloadChoicesKeepTheMasterAndItsSeparateAudioInsteadOfUsingVideoOnlyChildren() = kotlinx.coroutines.runBlocking {
        val source=QualityOption(0,url,"Auto","application/x-mpegURL")
        val choices=HlsManifest.downloadOptions(listOf(source)){listOf(1080,720)}
        assertEquals(listOf(0,1080,720),choices.map{it.height})
        assertTrue(choices.all{it.url==url && it.adaptive})
    }
    @Test fun masterWithoutResolutionStillRequiresAReadableChildPlaylist() {
        val manifest="#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000000\nchild.m3u8"
        assertFalse(HlsManifest.readable(url,{if(it==url)manifest else throw IOException("HTTP 403")},{true}))
    }
    @Test fun longMoviePlaylistsRemainUsableWithoutReadingTheWholeResponse() {
        val body="#EXTM3U\n"+(1..10_000).joinToString("") { "#EXTINF:4,\nsegment-$it.ts?token="+"x".repeat(160)+"\n" }
        val source=okio.Buffer().writeUtf8(body)
        val text=HlsManifest.playlistPrefix(source)
        assertTrue(source.size>1_000_000)
        assertTrue(text.length<=65_536)
        val last=text.lineSequence().last()
        assertTrue(last.startsWith("#") || last.endsWith("x".repeat(160)))
        assertTrue(HlsManifest.readable(url,{text},{it.contains("segment-1.ts?")}))
    }
}
