package app.cinemanatv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.BufferedSource
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Reads source-declared HLS renditions. Keep the master URL so alternate audio is retained. */
object HlsManifest {
    internal data class Variant(val height: Int, val url: String)
    private val http by lazy { OkHttpClient.Builder().followRedirects(false)
        .callTimeout(6, TimeUnit.SECONDS).connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS).build() }

    internal fun variants(master: String, text: String): List<Variant> {
        if (!text.trimStart().startsWith("#EXTM3U")) return emptyList()
        val base = master.toHttpUrlOrNull() ?: return emptyList()
        var height: Int? = null
        return buildList {
            text.lineSequence().take(8000).forEach { raw ->
                val line = raw.trim()
                if (line.startsWith("#EXT-X-STREAM-INF:")) {
                    height = Regex("""(?:[:,])\s*RESOLUTION\s*=\s*[0-9]+x([0-9]+)(?:,|$)""",
                        RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)?.toIntOrNull()
                        ?.takeIf { it in 144..8640 }
                } else if (line.isNotBlank() && !line.startsWith("#")) {
                    val target = base.resolve(line)
                    if (height != null && target != null && safe(target)) add(Variant(height!!, target.toString()))
                    height = null
                }
            }
        }.distinctBy { it.height }.sortedByDescending { it.height }
    }

    private fun safe(url: HttpUrl) = url.scheme == "https" && url.username.isEmpty() && url.password.isEmpty()

    /** Movie playlists may be megabytes long. Only headers and the first segment are needed here. */
    internal fun playlistPrefix(source: BufferedSource): String {
        val truncated=source.request(65_537L)
        val text=source.readUtf8(minOf(source.buffer.size,65_536L))
        return (if(truncated)text.substringBeforeLast('\n', "") else text)
            .takeIf{it.trimStart().startsWith("#EXTM3U")}
            ?: throw IOException("The provider did not return a playlist.")
    }

    private fun read(url: String): String {
        val parsed = url.toHttpUrlOrNull()?.takeIf(::safe) ?: throw IOException("Invalid playlist address.")
        return http.newCall(Request.Builder().url(parsed).header("User-Agent", userAgent()).build()).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Playlist HTTP ${response.code}.")
            val source = response.body?.source() ?: throw IOException("Empty playlist.")
            playlistPrefix(source)
        }
    }

    /** Check the media playlist and a small segment range, not only a successful master. */
    internal fun readable(address: String, playlist: (String) -> String = ::read,
                          segment: (String) -> Boolean = ::segmentReadable): Boolean { return try {
        var url = address
        var text = playlist(url)
        if (text.lineSequence().any { it.startsWith("#EXT-X-STREAM-INF:") }) {
            val known = variants(url, text)
            val child = known.lastOrNull()?.url ?: text.lineSequence().map(String::trim)
                .firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
                ?.let { url.toHttpUrlOrNull()?.resolve(it)?.takeIf(::safe)?.toString() }
                ?: return false
            url = child
            text = playlist(url)
        }
        // Nested masters and response pages are not segment data.
        if(text.contains("#EXT-X-STREAM-INF:")) return false
        if (!text.trimStart().startsWith("#EXTM3U")) false else {
            val first = text.lineSequence().map(String::trim).firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
            val target = first?.let { url.toHttpUrlOrNull()?.resolve(it) }
            target != null && safe(target) && segment(target.toString())
        }
    } catch (_: IOException) { false }
    }

    private fun segmentReadable(address: String): Boolean {
        val url = address.toHttpUrlOrNull()?.takeIf(::safe) ?: return false
        return http.newCall(Request.Builder().url(url).header("User-Agent", userAgent())
            .header("Range", "bytes=0-511").header("Accept-Encoding", "identity").build()).execute().use { response ->
            if (!response.isSuccessful || response.header("Content-Type").orEmpty().contains("text/html", true)) return@use false
            val source = response.body?.source() ?: return@use false
            if (!source.request(16)) return@use false
            val prefix = source.readByteArray(16)
            String(prefix, Charsets.UTF_8).trimStart().let{!it.startsWith("<") && !it.startsWith("#EXTM3U")}
        }
    }

    suspend fun heights(option: QualityOption): List<Int> = withContext(Dispatchers.IO) {
        if (!option.adaptive || option.mimeType.equals("application/dash+xml",true) || option.url.substringBefore('?').endsWith(".mpd", true)) return@withContext emptyList()
        try { variants(option.url, read(option.url)).map { it.height } }
        catch (c: kotlinx.coroutines.CancellationException) { throw c }
        catch (_: IOException) { emptyList() }
    }

    suspend fun downloadOptions(options: List<QualityOption>,
                                findHeights: suspend (QualityOption)->List<Int> = ::heights): List<QualityOption> = withContext(Dispatchers.IO) {
        // A single successful master is enough; do not probe every mirror before showing the dialog.
        val first = options.firstOrNull { it.adaptive && it.height == 0 } ?: return@withContext options
        val heights = findHeights(first)
        options + heights.map { first.copy(height = it, name = "${it}p") }
    }
}
