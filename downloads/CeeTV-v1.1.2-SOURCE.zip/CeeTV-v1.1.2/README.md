# Cee TV 1.1.2

Standalone CEE-backed Android TV app, package `app.cinemanatv.cee`, version code 8, Android 8+. This is an update to the separate Cee TV app. The original Cinemana TV app is unaffected.

## Changes

- Partial catalogue loading: a failed Movies or Series page no longer cancels successful category rows. A category-only response can populate the featured area.
- HLS delivery checks: native source lookup checks a media playlist and a small segment request, rather than accepting a master alone. Unreadable HLS routes advance to another declared source/server. This is a reachability sample, not a guarantee for every segment, DRM, or decoder.
- Playback recovery: permanent refusals can advance through the existing source alternatives. Stalled-stream refresh excludes the failed URL instead of fetching it again unchanged. Refresh/retry limits remain bounded.
- Quality: declared HLS resolutions can appear before decoder preparation; once tracks load, decoder-supported Media3 renditions take precedence. Manual selection keeps the exact video override; Auto restores adaptive selection. DASH continues to enumerate native tracks after preparation.
- Downloads: original MP4 files without a declared resolution remain available as "Original file"; no resolution is invented. HLS masters expose their declared heights in the download chooser while preserving the master and alternate audio. Preparation chooses a supported rendition up to the selected height. Lookup failures can be retried inside the dialog. Failed queue entries reopen download choices directly; network/storage/link explanations are visible.
- UI: featured artwork, category shortcuts, readable first-row layout at 720p, larger posters, consistent grids, true resume-progress bars, clear selected navigation, proper search icon, and separate detail action rows. New download status messages are localized in Arabic.

Only source-provided streams, resolutions, metadata and subtitles are shown. Genuine VK embeds retain the official player and its controls; native quality/offline features do not apply to that embedded player. Provider refusals, dead links and network restrictions cannot be guaranteed fixed by an APK.

## Build and validation

Use JDK 17 and Android SDK 35. `bash gradlew testDebugUnitTest assembleRelease` builds the signed sideload release with the configured local key. `CEE_LIVE_TEST=1` enables optional live-provider checks; failures are recorded separately from deterministic tests. UI integration tests exercise the actual Compose screens under Robolectric. No physical TV or sustained playback test was performed in this workspace.

The passive update feed is `https://raw.githubusercontent.com/Subaru771/CinemanaTV/main/downloads/CeeTV-updates.json`. Installation of an update remains a system/user action. Telegram access and startup preferences are retained.
