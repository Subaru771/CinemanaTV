@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package app.cinemanatv.util

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Tracks
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.offline.DownloadHelper
import app.cinemanatv.data.HlsManifest
import app.cinemanatv.data.QualityOption
import app.cinemanatv.data.userAgent
import kotlinx.coroutines.*
import java.io.IOException
import kotlin.coroutines.resume

/** Shared resolution discovery for viewing/downloads. Successful metadata is briefly reusable. */
object QualityDiscovery {
    private val cache=LinkedHashMap<String,Pair<Long,List<Int>>>()
    internal fun trackHeights(tracks:Tracks):List<Int> = tracks.groups.filter{it.type==C.TRACK_TYPE_VIDEO}.flatMap { group ->
        (0 until group.length).filter{group.isTrackSupported(it)}.map{group.getTrackFormat(it).height}.filter{it>0}
    }.distinct().sortedDescending()

    suspend fun heights(context:Context,option:QualityOption,refresh:Boolean=false):List<Int> {
        if(!option.adaptive)return listOfNotNull(option.height.takeIf{it>0})
        if(!refresh)synchronized(cache){cache[option.url]?.takeIf{System.currentTimeMillis()-it.first in 0..30_000}}?.let{return it.second}
        val parsed=HlsManifest.heights(option,refresh)
        val result=parsed.ifEmpty { scan(context.applicationContext,option) }
        if(result.isNotEmpty())synchronized(cache){cache[option.url]=System.currentTimeMillis() to result;while(cache.size>24)cache.remove(cache.keys.first())}
        return result
    }

    private suspend fun scan(context:Context,option:QualityOption):List<Int> = try { withTimeoutOrNull(10_000) {
        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine<List<Int>> { continuation ->
                val item=MediaItem.Builder().setUri(option.url).setMimeType(option.mimeType).build()
                val helper=DownloadHelper.Factory().setRenderersFactory(DefaultRenderersFactory(context))
                    .setDataSourceFactory(DefaultHttpDataSource.Factory().setUserAgent(userAgent()).setConnectTimeoutMs(6000).setReadTimeoutMs(6000)).create(item)
                fun release(){if(Looper.myLooper()==Looper.getMainLooper())helper.release() else Handler(Looper.getMainLooper()).post{helper.release()}}
                continuation.invokeOnCancellation{release()}
                try {
                    helper.prepare(object:DownloadHelper.Callback {
                        override fun onPrepared(prepared:DownloadHelper,tracksInfoAvailable:Boolean) {
                            val result=runCatching{if(tracksInfoAvailable)(0 until prepared.periodCount).flatMap{trackHeights(prepared.getTracks(it))}.distinct().sortedDescending() else emptyList()}.getOrDefault(emptyList())
                            release();if(continuation.isActive)continuation.resume(result)
                        }
                        override fun onPrepareError(prepared:DownloadHelper,error:IOException){release();if(continuation.isActive)continuation.resume(emptyList())}
                    })
                }catch(error:Exception){release();if(continuation.isActive)continuation.resume(emptyList())}
            }
        }
    } ?: emptyList()
    }catch(cancel:CancellationException){throw cancel}catch(_:Exception){emptyList()}catch(_:LinkageError){emptyList()}

    suspend fun downloads(context:Context,options:List<QualityOption>,refresh:Boolean=false):List<QualityOption> {
        for(option in options.filter{it.adaptive && it.height==0}.take(3)) {
            val sizes=heights(context,option,refresh)
            if(sizes.isNotEmpty())return numberedDownloadOptions(options+sizes.map{option.copy(height=it,name="${it}p")})
        }
        return numberedDownloadOptions(options)
    }
}
