package app.cinemanatv.util

import app.cinemanatv.data.QualityOption

/** Keep actual resolutions, adaptive masters, and original MP4 files without a declared height. */
fun numberedDownloadOptions(options: List<QualityOption>): List<QualityOption> =
    options.asSequence()
        .filter { (it.height > 0 || it.adaptive || it.mimeType.equals("video/mp4",true) || it.url.substringBefore('?').endsWith(".mp4",true)) &&
            (it.url.startsWith("https://") || it.url.startsWith("http://")) }
        .sortedByDescending { it.height }
        .distinctBy { if (it.height > 0) "height:${it.height}" else "source:${it.url}" }
        .toList()

fun downloadQualityLabel(choice: QualityOption): String =
    if (choice.height > 0) "${choice.height}p" else if(choice.adaptive) "Auto (offline)" else "Original file"
