package app.cinemanatv.util

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** User-initiated, device-local diagnostics. Tokens, full media paths and headers are excluded. */
object PlaybackReport {
    fun redact(value:String):String {
        val headers=Regex("(?im)(?:authorization|cookie|set-cookie)\\s*[:=][^\\r\\n]*").replace(value,"[private header removed]")
        return Regex("https?://[^\\s<>\"']+").replace(headers) { match ->
            match.value.toHttpUrlOrNull()?.let{"${it.scheme}://${it.host}/…"} ?: "[media address]"
        }
    }

    fun build(version:String,device:String,title:String,id:String,network:String,sourceUrl:String?,error:String):String =
        listOf("Cee TV $version",redact(device),"Title: "+redact(title),"Title ID: "+redact(id),
            "Network: "+redact(network),"Media host: "+(sourceUrl?.toHttpUrlOrNull()?.host ?: "not resolved"),
            "Error: "+redact(error).take(1200)).joinToString("\n")
}
