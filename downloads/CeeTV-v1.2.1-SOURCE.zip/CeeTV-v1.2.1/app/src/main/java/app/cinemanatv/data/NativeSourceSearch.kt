package app.cinemanatv.data

import kotlinx.coroutines.ensureActive
import java.io.IOException
import kotlin.coroutines.coroutineContext

/** Prefer a checked server, while retaining declared native candidates if a sample was inconclusive. */
internal class NativeSourceSearch {
    var fallback: PlaySources?=null
        private set

    fun remember(qualities: List<QualityOption>) {
        if(fallback==null && qualities.isNotEmpty())fallback=PlaySources(qualities,emptyList())
    }

    suspend fun find(servers: Int, attempt: suspend (Int)->PlaySources): PlaySources {
        var first: IOException?=null
        for(server in 0 until servers) {
            coroutineContext.ensureActive()
            try { return attempt(server) }
            catch(error: IOException) { if(first==null)first=error }
        }
        return fallback ?: throw (first ?: IOException("No source was returned."))
    }
}
