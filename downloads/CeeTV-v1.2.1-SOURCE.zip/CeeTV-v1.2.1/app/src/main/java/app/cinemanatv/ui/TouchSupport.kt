package app.cinemanatv.ui

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.*
import androidx.tv.material3.Surface as TvSurface

/** TV Material handles D-pad/semantics; add real pointer gestures without another focus target. */
internal fun Modifier.touchClick(enabled:Boolean=true,onLongClick:(()->Unit)?=null,onClick:()->Unit):Modifier = composed {
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)
    val focus=remember{FocusRequester()}
    this.focusRequester(focus).pointerInput(enabled,onLongClick!=null) {
        if(enabled)detectTapGestures(
            onTap={runCatching{focus.requestFocus()};click()},
            onLongPress=if(onLongClick!=null)({runCatching{focus.requestFocus()};longClick?.invoke()}) else null
        )
    }
}

@Composable
internal fun TouchSurface(
    onClick:()->Unit,modifier:Modifier=Modifier,onLongClick:(()->Unit)?=null,enabled:Boolean=true,
    tonalElevation:Dp=0.dp,shape:ClickableSurfaceShape=ClickableSurfaceDefaults.shape(),
    colors:ClickableSurfaceColors=ClickableSurfaceDefaults.colors(),scale:ClickableSurfaceScale=ClickableSurfaceDefaults.scale(),
    border:ClickableSurfaceBorder=ClickableSurfaceDefaults.border(),glow:ClickableSurfaceGlow=ClickableSurfaceDefaults.glow(),
    interactionSource:MutableInteractionSource?=null,content:@Composable BoxScope.()->Unit,
) {
    TvSurface(onClick,modifier.touchClick(enabled,onLongClick,onClick),onLongClick,enabled,tonalElevation,
        shape,colors,scale,border,glow,interactionSource,content)
}
