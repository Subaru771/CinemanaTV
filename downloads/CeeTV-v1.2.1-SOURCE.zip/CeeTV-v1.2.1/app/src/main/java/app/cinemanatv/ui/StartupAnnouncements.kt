package app.cinemanatv.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Button
import androidx.tv.material3.Border
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.Text
import app.cinemanatv.R
import app.cinemanatv.Services
import app.cinemanatv.util.AvailableAppUpdate

private val tvCardShape = RoundedCornerShape(26.dp)
private val tvCardRed = Color(0xFFB5F36D)
private val tvWhite = Color(0xFFF9FAFD)

/** The Telegram invitation matches the selected TV interface language, showing
 * just ONE language at a time. The update dialog is independent and only appears
 * when a real newer version was found. All controls are D-pad accessible.
 */
@Composable
fun StartupAnnouncements(
    showTelegram: Boolean,
    update: AvailableAppUpdate?,
    onTelegram: () -> Unit,
    onUpdate: () -> Unit,
    onDismiss: () -> Unit,
    onSkip: () -> Unit,
) {
    if (!showTelegram && update == null) return
    if (showTelegram) {
        TelegramChannelDialog(onTelegram = onTelegram, onDismiss = onDismiss)
    } else if (update != null) {
        UpdateAvailableDialog(update = update, onUpdate = onUpdate, onDismiss = onDismiss, onSkip = onSkip)
    }
}

@Composable
private fun TelegramChannelDialog(onTelegram: () -> Unit, onDismiss: () -> Unit) {
    val copy = telegramCardCopy(LocalInterfaceLanguage.current)
    var neverShowAgain by remember { mutableStateOf(Services.prefs.hideTelegramInvitation) }
    val joinFocus = remember { FocusRequester() }
    LaunchedEffect(copy.title) {
        kotlinx.coroutines.delay(120L)
        runCatching { joinFocus.requestFocus() }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
        ),
    ) {
        Box(
            Modifier.fillMaxSize().background(Color(0xE6080E0C)),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.84f)
                    .widthIn(max = 900.dp)
                    .border(1.dp, Color(0xFF527B39), tvCardShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF15331B), Color(0xFF0B170F), Color(0xFF102519)),
                        ),
                        tvCardShape,
                    )
                    .padding(horizontal = 26.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    TvNoticeButton(
                        label = "×",
                        accessibilityLabel = copy.close,
                        onClick = onDismiss,
                        modifier = Modifier.size(46.dp),
                        compact = true,
                    )
                    Spacer(Modifier.weight(1f))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(R.drawable.cee_mark),
                            contentDescription = null,
                            modifier = Modifier.size(53.dp),
                        )
                        Text("Cee", fontSize = 27.sp,
                            fontWeight = FontWeight.Bold, color = tvWhite)
                    }
                    Spacer(Modifier.weight(1f))
                    Spacer(Modifier.width(46.dp))
                }
                Box(
                    Modifier.size(50.dp)
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFF41C2FB), Color(0xFF0276CB))),
                            RoundedCornerShape(14.dp),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("➤", color = tvWhite, fontSize = 30.sp,
                        fontWeight = FontWeight.Bold)
                }
                Text(copy.title, color = tvWhite, fontSize = 28.sp,
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(copy.description, color = Color(0xFFE4DFE5), fontSize = 17.sp,
                    lineHeight = 23.sp, textAlign = TextAlign.Center)
                Row(
                    modifier = Modifier.fillMaxWidth()
                        .border(1.dp, Color(0xFF375A2C), RoundedCornerShape(18.dp))
                        .background(Color(0x64240914), RoundedCornerShape(18.dp))
                        .padding(vertical = 9.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TelegramFeature("🔔", copy.updates, Modifier.weight(1f))
                    Box(Modifier.width(1.dp).height(70.dp).background(Color(0xFF466A36)))
                    TelegramFeature("☆", copy.features, Modifier.weight(1f))
                    Box(Modifier.width(1.dp).height(70.dp).background(Color(0xFF466A36)))
                    TelegramFeature("📣", copy.news, Modifier.weight(1f))
                }
                TvNoticeButton(
                    label = copy.join,
                    accessibilityLabel = copy.join,
                    modifier = Modifier.fillMaxWidth(0.87f).height(54.dp).focusRequester(joinFocus),
                    primary = true,
                    onClick = onTelegram,
                )
                TvNoticeButton(
                    label = copy.later,
                    accessibilityLabel = copy.later,
                    modifier = Modifier.fillMaxWidth(0.87f).height(49.dp),
                    onClick = onDismiss,
                )
                TvNoticeButton(
                    label = (if (neverShowAgain) "☑  " else "☐  ") + copy.neverShow,
                    accessibilityLabel = copy.neverShow,
                    modifier = Modifier.fillMaxWidth(0.83f).height(38.dp),
                    compact = true,
                    onClick = {
                        neverShowAgain = !neverShowAgain
                        // Save as soon as toggled: the Activity owns hardware Back
                        // and can dismiss the dialog without firing a button callback.
                        Services.prefs.hideTelegramInvitation = neverShowAgain
                    },
                )
            }
        }
    }
}

@Composable
private fun TelegramFeature(icon: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(icon, fontSize = 25.sp, color = Color(0xFFB5F36D),
            textAlign = TextAlign.Center)
        Text(label, fontSize = 14.sp, lineHeight = 18.sp,
            fontWeight = FontWeight.Medium, color = tvWhite,
            textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun TvNoticeButton(
    label: String,
    accessibilityLabel: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    compact: Boolean = false,
    onClick: () -> Unit,
) {
    // One focus layer only: use the TV Button's built-in border (rather than
    // Modifier.border, which stays offset when the focused Button transforms).
    val buttonShape = RoundedCornerShape(if (compact) 15.dp else 19.dp)
    Button(
        onClick = onClick,
        modifier = modifier.touchClick(onClick=onClick).semantics { contentDescription = accessibilityLabel },
        shape = ButtonDefaults.shape(shape = buttonShape),
        scale = ButtonDefaults.scale(focusedScale = 1f),
        border = ButtonDefaults.border(
            focusedBorder = Border(
                BorderStroke(1.5.dp, Color(0xFFB5F36D)), shape = buttonShape,
            ),
        ),
        colors = ButtonDefaults.colors(
            containerColor = if (primary) tvCardRed else Color(0xFF1C2E23),
            contentColor = if(primary) Color(0xFF10200C) else tvWhite,
            focusedContainerColor = if (primary) Color(0xFF9CDE55) else Color(0xFF2E4933),
            focusedContentColor = if(primary) Color(0xFF10200C) else tvWhite,
        ),
    ) {
        Box(
            modifier = if (compact) Modifier else Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            Text(label, fontSize = if (compact) 15.sp else 20.sp,
                fontWeight = if (primary) FontWeight.Bold else FontWeight.Medium,
                textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun UpdateAvailableDialog(
    update: AvailableAppUpdate,
    onUpdate: () -> Unit,
    onDismiss: () -> Unit,
    onSkip: () -> Unit,
) {
    val firstButton = remember { FocusRequester() }
    LaunchedEffect(update.versionCode) {
        kotlinx.coroutines.delay(120L)
        runCatching { firstButton.requestFocus() }
    }
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false,
        ),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(
                modifier = Modifier.widthIn(min = 450.dp, max = 600.dp)
                    .border(1.dp, Color(0xFF466A36), RoundedCornerShape(22.dp))
                    .background(Color(0xFF161B26), RoundedCornerShape(22.dp))
                    .padding(25.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp),
            ) {
                Text(t("Update available"), fontSize = 24.sp,
                    fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    if (LocalInterfaceLanguage.current == "ar")
                        "الإصدار ${update.versionName} متوفر الآن"
                    else "Version ${update.versionName} is available",
                    fontSize = 16.sp, color = C.Dim,
                )
                val notes = if (LocalInterfaceLanguage.current == "ar") update.notesArabic else update.notes
                if (notes.isNotEmpty()) Text(notes, fontSize = 14.sp, color = C.Dim)
                AppButton(t("Get update"), Modifier.focusRequester(firstButton),
                    primary = true, onClick = onUpdate)
                AppButton(if (LocalInterfaceLanguage.current == "ar") "ذكرني لاحقاً" else "Remind me later", onClick = onDismiss)
                AppButton(if (LocalInterfaceLanguage.current == "ar") "تخطي هذا الإصدار" else "Skip this version", onClick = onSkip)
            }
        }
    }
}
