package app.cinemanatv.data

/** Shared by the episode list and playback queue; unknown numbers never outrank episode one. */
fun chronologicalEpisodes(videos:List<Video>):List<Video> = videos.distinctBy{it.id}.sortedWith(
    compareBy<Video>({it.seasonNumber.takeIf{number->number>0} ?: Int.MAX_VALUE},
        {it.episodeNumber.takeIf{number->number>0} ?: Int.MAX_VALUE})
)

fun chronologicalPlaybackQueue(videos:List<Video>):List<Video> =
    if(videos.isNotEmpty() && videos.all{it.kind=="2" && it.episodeNumber>0} && videos.mapNotNull{it.rootSeries}.distinct().size<=1)
        chronologicalEpisodes(videos) else videos

fun resumeEpisodeIndex(videos:List<Video>,recentIds:List<String>,position:(String)->Long):Int {
    for(id in recentIds){val index=videos.indexOfFirst{it.id==id};if(index>=0 && position(id)>10_000)return index}
    return videos.indexOfFirst{position(it.id)>10_000}
}
