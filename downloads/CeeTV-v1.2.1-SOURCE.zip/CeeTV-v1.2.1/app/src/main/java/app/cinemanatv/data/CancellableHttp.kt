package app.cinemanatv.data

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resumeWithException

/** Cancellation covers the headers AND body read. Callers never receive an open response. */
internal object CancellableHttp {
    suspend fun <T> read(client: OkHttpClient, request: Request, consume: (Response)->T): T =
        suspendCancellableCoroutine { continuation ->
            val call=client.newCall(request)
            continuation.invokeOnCancellation { call.cancel() }
            call.enqueue(object: Callback {
                override fun onFailure(call: Call, error: IOException) {
                    if(continuation.isActive)continuation.resumeWithException(error)
                }
                override fun onResponse(call: Call, response: Response) {
                    val result=runCatching { response.use {
                        if(!continuation.isActive)throw IOException("Request cancelled.")
                        consume(it)
                    } }
                    if(continuation.isActive)continuation.resumeWith(result)
                }
            })
        }
}
