package app.cinemanatv.data

import com.google.gson.JsonParser
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** Read simple source declarations; never execute provider JavaScript. */
internal object DeclaredQualities {
    fun withoutComments(text:String):String {
        val out=StringBuilder();var i=0;var quote:Char?=null
        while(i<text.length) {
            val c=text[i]
            if(quote!=null){out.append(c);i++;if(c=='\\' && i<text.length){out.append(text[i++])}else if(c==quote)quote=null;continue}
            if(c=='\'' || c=='"' || c=='`'){quote=c;out.append(c);i++;continue}
            if(text.startsWith("//",i)){while(i<text.length && text[i]!='\n')i++;continue}
            if(text.startsWith("/*",i)){val end=text.indexOf("*/",i+2);i=if(end<0)text.length else end+2;out.append(' ');continue}
            out.append(c);i++
        }
        return out.toString()
    }

    fun parse(script:String):List<QualityOption> = Regex("""\{[^{}]{1,16384}\}""").findAll(script).take(400).mapNotNull { match ->
        runCatching {
            val json=JsonParser.parseString(match.value).asJsonObject
            val raw=json.get("file")?.takeIf{it.isJsonPrimitive && it.asJsonPrimitive.isString}?.asString ?: return@runCatching null
            val url=raw.toHttpUrlOrNull()?.takeIf(CeeAlternativeSource::allowedMedia) ?: return@runCatching null
            val label=json.get("label")?.takeIf{it.isJsonPrimitive}?.asString?.take(64).orEmpty()
            val height=Regex("[0-9]{3,4}").find(label)?.value?.toIntOrNull() ?: 0
            val type=json.get("type")?.takeIf{it.isJsonPrimitive}?.asString.orEmpty()
            val mime=when {
                url.host=="stream.cinemana.cc" || url.encodedPath.endsWith(".m3u8",true) || type.equals("hls",true)->"application/x-mpegURL"
                url.encodedPath.endsWith(".mpd",true) || type.equals("dash",true)->"application/dash+xml"
                else->null
            }
            QualityOption(height,url.toString(),if(label.isNotBlank())"CEE · $label" else if(height>0)"${height}p" else null,mime)
        }.getOrNull()
    }.distinctBy{it.url}.sortedByDescending{it.height}.toList()
}
