package app.cinemanatv.ui

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.runtime.CompositionLocalProvider
import app.cinemanatv.Services
import app.cinemanatv.data.*
import org.junit.Rule
import org.junit.After
import androidx.lifecycle.ViewModelStore
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@OptIn(ExperimentalTestApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w1280dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class TvInteractionTest {
    @get:Rule val compose=createComposeRule()
    private val movie=Video(nb="cee_123",enTitle="Example",kind="1",providerPageId="123")
    private fun SemanticsNodeInteraction.remoteClick():SemanticsNodeInteraction =
        performSemanticsAction(SemanticsActions.RequestFocus){it()}.assertIsFocused()
            .performKeyInput{pressKey(Key.DirectionCenter)}
    private val models=ViewModelStore()
    private var modelCount=0
    private fun model()=AppViewModel().also{models.put("test-model-${modelCount++}",it)}
    @After fun releaseModels(){models.clear()}
    private fun prefs(){
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cinemana_tv",0).edit().clear().commit()
        app.getSharedPreferences("cinemana_library",0).edit().clear().commit()
        Services.prefs=Prefs(app)
    }

    @Test fun failedDownloadLookupCanRetryAndShowsTheActualQualityChoices() {
        prefs()
        val attempts=java.util.concurrent.atomic.AtomicInteger()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String):PlaySources {
            val attempt=attempts.incrementAndGet()
            if(attempt==1)throw java.io.IOException("temporary failure")
            return PlaySources(listOf(QualityOption(1080,"https://media.invalid/1080.mp4"),QualityOption(720,"https://media.invalid/720.mp4")),emptyList())
        }})
        var dismissed=false
        compose.setContent { CinemanaTheme {DownloadOptionsDialog(movie){dismissed=true}} }
        compose.waitUntil(10_000){attempts.get()>=1}
        compose.onNodeWithText("Retry").assertExists().remoteClick()
        compose.waitUntil(10_000){attempts.get()>=2}
        compose.onNodeWithText("1080p").assertIsDisplayed()
        compose.onNodeWithText("720p").assertIsDisplayed()
        compose.onNodeWithText("Close").performScrollTo().remoteClick()
        assertTrue(dismissed)
    }

    @Test fun qualityControlOpensWithTheRemoteWhileTheStreamIsLoading() {
        prefs()
        val pending=kotlinx.coroutines.CompletableDeferred<PlaySources>()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=pending.await()})
        compose.setContent {CinemanaTheme{PlayerScreen(listOf(movie),0,onExit={},onRegisterBack={})}}
        compose.onNodeWithText("Quality · Auto").assertIsDisplayed().remoteClick()
        compose.onNodeWithText("Video quality").assertIsDisplayed()
        compose.onNode(hasText("Auto") and hasClickAction()).assertIsDisplayed()
        compose.onNodeWithText("720p").assertDoesNotExist()
    }

    @Test fun qualityMenuCanBeOpenedAfterEnginePreparationFails() {
        prefs()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=
            PlaySources(listOf(QualityOption(1080,"file:///cee-missing-fixture/movie.mp4")),emptyList())})
        compose.setContent{CinemanaTheme{CompositionLocalProvider(LocalPlayerEngineFactory provides {context ->
            object:CinemaPlaybackEngine(context){
                override fun open(id:String,quality:QualityOption,subtitles:List<SubtitleOption>,at:Long,play:Boolean,maxVideoHeight:Int){
                    throw IllegalStateException("Fixture decoder preparation failure")
                }
            }
        }){PlayerScreen(listOf(movie),0,onExit={},onRegisterBack={})}}}
        compose.onNodeWithText("Playback unavailable").assertIsDisplayed()
        compose.onNode(hasText("Video quality") and hasClickAction()).remoteClick()
        compose.onNode(hasText("Auto") and hasClickAction()).assertIsDisplayed()
        compose.onNode(hasText("1080p") and hasClickAction()).assertIsDisplayed()
    }

    @Test fun homeCategoryShortcutOpensItsActualCollection() {
        prefs()
        val section=CatalogSection("international","International movies",1,7,96)
        val data=HomeData(listOf(movie),listOf(ContentRow("International movies",listOf(movie),section)))
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val vm=model();vm.homeCache[0]=data;vm.markHomeFresh(0)
        compose.setContent{CinemanaTheme{MainShell(vm)}}
        compose.onNode(hasText("International movies") and hasClickAction()).performScrollTo().remoteClick()
        compose.runOnIdle {assertTrue(vm.stack.last() is Screen.Collection)}
    }

    @Test fun detailPlayAndListActionsRemainReachableWithTheRemote() {
        prefs()
        Services.repo=Repository(StubCeeCatalog())
        var played=false
        compose.setContent{CinemanaTheme{DetailScreen(movie,onPlay={_,_->played=true},onOpen={})}}
        compose.onNodeWithText("Play").remoteClick()
        compose.runOnIdle{assertTrue(played)}
        compose.onNodeWithText("Add to My List",substring=true).performScrollTo().remoteClick()
        compose.runOnIdle{assertTrue(Services.prefs.isWatchlisted(movie.id))}
    }

    @Test fun railFocusStaysPutAndMovesBetweenDestinationsWithTheDpad() {
        prefs()
        val data=HomeData(listOf(movie),listOf(ContentRow("Latest movies",listOf(movie))))
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val vm=model();vm.homeCache[0]=data;vm.markHomeFresh(0)
        compose.setContent{CinemanaTheme{MainShell(vm)}}
        compose.onNode(hasText("Series") and hasClickAction()).performSemanticsAction(SemanticsActions.RequestFocus){it()}
        compose.mainClock.advanceTimeBy(200)
        compose.onNode(hasText("Series") and hasClickAction()).assertIsFocused().performKeyInput{pressKey(Key.DirectionDown)}
        compose.onNode(hasText("Movies") and hasClickAction()).assertIsFocused()
    }

    @Test fun searchClosesBackToThePreviousLibraryDestination() {
        prefs()
        val data=HomeData(listOf(movie),listOf(ContentRow("Latest movies",listOf(movie))))
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val vm=model();vm.homeCache[0]=data;vm.markHomeFresh(0);vm.tab=5
        compose.setContent{CinemanaTheme{MainShell(vm)}}
        compose.onAllNodes(hasText("Search") and hasClickAction()).onFirst().remoteClick()
        compose.runOnIdle{assertEquals(3,vm.tab);assertEquals(5,vm.lastTab)}
        compose.onNode(hasText("Close") and hasClickAction()).remoteClick()
        compose.runOnIdle{assertEquals(5,vm.tab)}
    }

    @Test fun returningFromDetailsPreservesTheVisibleHomeScrollAndCard() {
        prefs()
        val videos=(1..12).map{movie.copy(nb="cee_$it",enTitle="Movie $it",providerPageId=it.toString())}
        val data=HomeData(videos.take(1),listOf(ContentRow("Latest movies",videos)))
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val vm=model();vm.homeCache[0]=data;vm.markHomeFresh(0)
        compose.setContent{CinemanaTheme{
            val screen=vm.stack.last()
            if(screen is Screen.Detail)DetailScreen(screen.video,onPlay={_,_->},onOpen={}) else MainShell(vm)
        }}
        compose.mainClock.advanceTimeBy(200)
        compose.runOnIdle{vm.colState(0).requestScrollToItem(0,20);vm.rowState(0,"Latest movies").requestScrollToItem(1,10)}
        compose.onNode(hasText("Movie 4") and hasClickAction()).performSemanticsAction(SemanticsActions.RequestFocus){it()}
        fun position()=listOf(vm.colState(0).firstVisibleItemIndex,vm.colState(0).firstVisibleItemScrollOffset,
            vm.rowState(0,"Latest movies").firstVisibleItemIndex,vm.rowState(0,"Latest movies").firstVisibleItemScrollOffset)
        var before=emptyList<Int>()
        compose.runOnIdle{before=position()}
        compose.onNode(hasText("Movie 4") and hasClickAction()).performKeyInput{pressKey(Key.DirectionCenter)}
        compose.onNodeWithText("Play").assertIsDisplayed()
        compose.runOnIdle{assertTrue(vm.pop())}
        compose.mainClock.advanceTimeBy(200)
        compose.waitUntil(5_000){compose.onNode(hasText("Movie 4") and hasClickAction()).fetchSemanticsNode().config[SemanticsProperties.Focused]}
        compose.onNode(hasText("Movie 4") and hasClickAction()).assertIsFocused()
        compose.runOnIdle{assertEquals(before,position())}
    }
}
