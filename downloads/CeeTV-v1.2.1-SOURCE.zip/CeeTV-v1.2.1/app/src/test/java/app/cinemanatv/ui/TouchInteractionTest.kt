package app.cinemanatv.ui

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.cinemanatv.Services
import app.cinemanatv.data.*
import kotlinx.coroutines.CompletableDeferred
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w1280dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class TouchInteractionTest {
    @get:Rule val compose=createComposeRule()
    private val movie=Video(nb="cee_1",kind="1",enTitle="Example",providerPageId="1")
    @Before fun setup(){
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cinemana_tv",0).edit().clear().commit();app.getSharedPreferences("cinemana_library",0).edit().clear().commit()
        Services.prefs=Prefs(app);Services.repo=Repository(StubCeeCatalog())
    }
    @Test fun oneRealTapActivatesAButtonExactlyOnce() {
        var count=0
        compose.setContent{CinemanaTheme{AppButton("Tap me"){count++}}}
        compose.onNodeWithText("Tap me").performTouchInput{click()}
        compose.runOnIdle{assertEquals(1,count)}
    }
    @Test fun posterTapAndLongPressAreDistinctActions() {
        var clicks=0;var holds=0
        compose.setContent{CinemanaTheme{PosterCard(movie,onLongClick={holds++},onClick={clicks++})}}
        compose.onNode(hasContentDescription("Example") and hasClickAction()).performTouchInput{click()}
        compose.runOnIdle{assertEquals(1,clicks)}
        compose.onNode(hasContentDescription("Example") and hasClickAction()).performTouchInput{longClick()}
        compose.runOnIdle{assertEquals(1,clicks);assertEquals(1,holds)}
    }
    @Test fun swipingAPosterRowDoesNotOpenAMovie() {
        var clicks=0
        compose.setContent{CinemanaTheme{LazyRow(Modifier.width(340.dp)){items((1..12).toList()){PosterCard(movie.copy(nb="cee_$it",enTitle="Movie $it"),onClick={clicks++})}}}}
        compose.onNode(hasContentDescription("Movie 2") and hasClickAction()).performTouchInput{swipeLeft()}
        compose.runOnIdle{assertEquals(0,clicks)}
    }
    @Test fun tappingThePlayerQualityButtonOpensTheMenu() {
        val pending=CompletableDeferred<PlaySources>()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=pending.await()})
        compose.setContent{CinemanaTheme{PlayerScreen(listOf(movie),0,onExit={},onRegisterBack={})}}
        compose.onNodeWithText("Quality · Auto").performTouchInput{click()}
        compose.onNodeWithText("Video quality").assertIsDisplayed()
        compose.onNodeWithText("Close").performTouchInput{click()}
        compose.onNodeWithText("Quality · Auto").assertIsDisplayed()
    }
    @Test fun timelineDragCommitsOneSeekAtRelease() {
        val jumps=mutableListOf<Float>()
        compose.setContent{CinemanaTheme{CinemaTimeline(0f,0f,true,true,FocusRequester(),{}, {_,_->}, {jumps.add(it)})}}
        compose.onNodeWithContentDescription("Playback timeline").performTouchInput{swipe(start=percentOffset(0.1f,0.5f),end=percentOffset(0.8f,0.5f))}
        compose.runOnIdle{assertEquals(1,jumps.size);assertEquals(0.8f,jumps.single(),0.06f)}
    }
    @Test fun seriesResumeAndStartUseChronologicalEpisodesWithRealTaps() {
        val episodes=(1..10).map{Video(nb="ep$it",kind="2",season="1",episodeNummer=it.toString(),enTitle="Episode $it")}
        Services.prefs.setResume("ep10",60_000);Services.prefs.touchRecent(episodes.last())
        Services.prefs.setResume("ep1",60_000);Services.prefs.touchRecent(episodes.first())
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun episodes(video:Video)=episodes.reversed()})
        var played:List<Video> = emptyList();var index=-1
        compose.setContent{CinemanaTheme{DetailScreen(movie.copy(kind="2",nb="cee_series_a"),onPlay={q,i->played=q;index=i},onOpen={})}}
        compose.onNodeWithText("Resume S1:E1").performTouchInput{click()}
        compose.runOnIdle{assertEquals((1..10).toList(),played.map{it.episodeNumber});assertEquals(0,index)}
        compose.onNodeWithText("Start from beginning").performScrollTo().performTouchInput{click()}
        compose.runOnIdle{assertEquals(0,index)}
    }
}
