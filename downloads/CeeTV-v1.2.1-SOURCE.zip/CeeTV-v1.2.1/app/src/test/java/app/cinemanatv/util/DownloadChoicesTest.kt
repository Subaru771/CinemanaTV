package app.cinemanatv.util

import app.cinemanatv.data.QualityOption
import org.junit.Assert.assertEquals
import org.junit.Test

class DownloadChoicesTest {
    @Test fun ordersNumericalResolutionsHighestFirst() {
        val options = listOf(
            QualityOption(480, "https://example.org/480.mp4"),
            QualityOption(2160, "https://example.org/4k.mp4"),
            QualityOption(720, "https://example.org/720.mp4"),
            QualityOption(1080, "https://example.org/1080.mp4")
        )
        assertEquals(listOf(2160, 1080, 720, 480), numberedDownloadOptions(options).map { it.height })
    }

    @Test fun includesOriginalMp4AndAdaptiveButHidesInvalidSchemes() {
        val options = listOf(
            QualityOption(0, "https://example.org/unknown.mp4"),
            QualityOption(720, "https://example.org/720.m3u8"),
            QualityOption(480, "file:///tmp/example.mp4"),
            QualityOption(1080, "https://example.org/1080.mp4")
        )
        assertEquals(listOf(1080, 720, 0), numberedDownloadOptions(options).map { it.height })
    }

    @Test fun showsOnlyOneButtonForEachResolution() {
        val options = listOf(
            QualityOption(720, "https://example.org/a.mp4"),
            QualityOption(720, "https://example.org/b.mp4"),
            QualityOption(480, "https://example.org/c.mp4")
        )
        assertEquals(listOf(720, 480), numberedDownloadOptions(options).map { it.height })
    }

    @Test fun hidesUnknownUnsupportedFormats() {
        assertEquals(emptyList<QualityOption>(), numberedDownloadOptions(
            listOf(QualityOption(0, "https://example.org/unknown.mkv"))
        ))
    }
    @Test fun ceeAutoHlsRemainsDownloadableWithoutInventingAResolution() {
        val relay=QualityOption(0,"https://stream.cinemana.cc/cinema-stream?url=example", "CEE HLS", "application/x-mpegURL")
        assertEquals(listOf(relay), numberedDownloadOptions(listOf(relay)))
        assertEquals("Auto (offline)",downloadQualityLabel(relay))
    }
    @Test fun unknownMp4ResolutionStillOffersTheOriginalWithoutInventingAHeight() {
        val source=QualityOption(0,"https://media.example/movie.mp4?token=example")
        assertEquals(listOf(source),numberedDownloadOptions(listOf(source)))
        assertEquals("Original file",downloadQualityLabel(source))
    }
    @Test fun ordinaryAutoHlsAndDashAreAlsoDownloadable() {
        val hls=QualityOption(0,"https://media.example/master.m3u8")
        val dash=QualityOption(0,"https://media.example/master.mpd")
        assertEquals(listOf(hls,dash),numberedDownloadOptions(listOf(hls,dash)))
    }
}
