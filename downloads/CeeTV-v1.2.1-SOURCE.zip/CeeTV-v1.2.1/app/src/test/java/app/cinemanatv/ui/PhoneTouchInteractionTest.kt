package app.cinemanatv.ui

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import app.cinemanatv.Services
import app.cinemanatv.data.*
import kotlinx.coroutines.CompletableDeferred
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w720dp-h400dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PhoneTouchInteractionTest {
    @get:Rule val compose=createComposeRule()
    private val movie=Video(nb="cee_1",kind="1",enTitle="Example",providerPageId="1")
    @Before fun setup(){
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cinemana_tv",0).edit().clear().commit();app.getSharedPreferences("cinemana_library",0).edit().clear().commit()
        Services.prefs=Prefs(app);Services.repo=Repository(StubCeeCatalog())
    }
    @Test fun touchNavigationWorksAtPhoneLandscapeSize() {
        val data=HomeData(listOf(movie),listOf(ContentRow("Latest movies",listOf(movie))))
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val store=androidx.lifecycle.ViewModelStore()
        val vm=AppViewModel();store.put("phone",vm);vm.homeCache[0]=data;vm.markHomeFresh(0)
        try {
            compose.setContent{CinemanaTheme{MainShell(vm)}}
            compose.onNode(hasText("Movies") and hasClickAction()).performTouchInput{click()}
            compose.runOnIdle{assertEquals(2,vm.tab)}
        }finally{store.clear()}
    }
    @Test fun phonePlayerSettingsRemainReachableByTouch() {
        val pending=CompletableDeferred<PlaySources>()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=pending.await()})
        compose.setContent{CinemanaTheme{PlayerScreen(listOf(movie),0,onExit={},onRegisterBack={})}}
        compose.onNodeWithContentDescription("Player settings").performTouchInput{click()}
        compose.onNode(hasText("Video quality") and hasClickAction()).assertIsDisplayed()
    }
}
