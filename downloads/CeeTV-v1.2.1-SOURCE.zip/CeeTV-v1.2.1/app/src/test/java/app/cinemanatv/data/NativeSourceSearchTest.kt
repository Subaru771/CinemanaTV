package app.cinemanatv.data

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class NativeSourceSearchTest {
    private val pending=QualityOption(0,"https://media.example/uncertain.m3u8")
    private val good=PlaySources(listOf(QualityOption(720,"https://media.example/good.mp4")),emptyList())
    @Test fun checkedServerWinsOverAnUncertainCandidate() = runBlocking {
        val search=NativeSourceSearch()
        val result=search.find(3){server -> if(server==0){search.remember(listOf(pending));throw IOException("sample timed out")} else good}
        assertEquals(good,result)
    }
    @Test fun inconclusiveSamplesDoNotEraseDeclaredNativeStreams() = runBlocking {
        val search=NativeSourceSearch()
        val result=search.find(3){search.remember(listOf(pending));throw IOException("probe failed")}
        assertEquals(listOf(pending),result.qualities)
    }
    @Test fun cancellationDoesNotBecomeAnotherServerRetry() = runBlocking {
        var attempts=0
        val result=withTimeoutOrNull(100){NativeSourceSearch().find(4){attempts++;awaitCancellation()}}
        assertNull(result);assertEquals(1,attempts)
    }
}
