package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class CeePartialHomeTest {
    private val movie="<a href='https://cinamana.cc/watch=123/'><h2>فيلم Example 2026 مترجم</h2></a>"
    @Test fun failedSeriesPageDoesNotCancelReadableMovies() = runBlocking {
        val catalog=CeeHtmlCatalog { url -> when {
            url.endsWith("movies/")->movie
            else->throw IOException("Timed out")
        } }
        val home=catalog.home(null)
        assertEquals("cee_123",home.hero.single().id)
        assertEquals("Latest movies",home.rows.first().title)
    }
    @Test fun successfulCategoryIndexSurvivesBothListingFailures() = runBlocking {
        val catalog=CeeHtmlCatalog { url -> when {
            url.contains("/categories?")->"""[{"id":7,"name":"أفلام أجنبي","count":96}]"""
            url.contains("/posts?")->"""[{"id":123,"title":{"rendered":"فيلم Example 2026 مترجم"},"excerpt":{"rendered":"<p>Plot</p>"}}]"""
            else->throw IOException("Timed out")
        } }
        val home=catalog.home(1)
        assertEquals("cee_123",home.hero.single().id)
        assertEquals("International movies",home.rows.single().title)
    }
    @Test fun fullyUnavailableProviderStillReportsAnError() = runBlocking {
        try { CeeHtmlCatalog {throw IOException("Unavailable")}.home(null); fail("Expected error") }
        catch(expected:IOException){assertTrue(expected.message!!.contains("catalogue"))}
    }
}
