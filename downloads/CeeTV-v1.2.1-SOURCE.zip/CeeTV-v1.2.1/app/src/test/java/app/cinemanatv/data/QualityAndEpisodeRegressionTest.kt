package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class QualityAndEpisodeRegressionTest {
    @Test fun sourceLabelsSurviveExtraFieldsAndReorderedQuotedKeys() {
        val text="""<script>var sources=[{"label":"1080p", "type":"mp4", "file":"https://a.cdnz.quest/a.mp4?x=1\u0026y=2"},{file:'https://a.cdnz.quest/b.mp4',label:'720p',type:'mp4',default:true}];</script>"""
        val options=CeeAlternativeSource.qualities(text)
        assertEquals(listOf(1080,720),options.map{it.height})
        assertTrue(options.first().url.contains("&y=2"))
    }
    @Test fun commentedLegacySourcesAreNotQualityChoices() {
        val text="""<script>// {file:'https://a.cdnz.quest/old.mp4',label:'1080p'}
        var x={file:'https://a.cdnz.quest/new.mp4',type:'mp4',label:'720p'};</script>"""
        val options=CeeAlternativeSource.qualities(text)
        assertEquals(1,options.size);assertTrue(options.single().url.contains("new.mp4"))
    }
    @Test fun downloadCanReuseTheSuccessfulSourceAfterTheWarmPlayerResultIsConsumed() = runBlocking {
        var calls=0
        val sources=PlaySources(listOf(QualityOption(720,"https://a.cdnz.quest/a.mp4")),emptyList())
        val repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String):PlaySources{calls++;return sources}})
        repo.prefetchSources("cee_1");repo.takePrefetched("cee_1")
        assertEquals(sources,repo.sourceSnapshot("cee_1"));assertEquals(1,calls)
        repo.loadSources("cee_1");assertEquals(2,calls) // explicit reload still refreshes signed URLs
    }
    @Test fun episodeLabelsDoNotUseTheTitleYearAndSeasonsAreChronological() {
        val parent=Video(nb="cee_series_a",kind="2",enTitle="Example",providerPageId="1")
        val html="""<button class='season-trigger' data-target='s14'>الموسم الرابع عشر</button><div class='season-wrapper' id='s14'><div class='episodes-grid'><a href='/watch=3/' title='Example 2026 الحلقة ١٠'><span>Example 2026</span></a><a href='/watch=2/' data-episode='۲'><span>Example 2026</span></a></div></div><button class='season-trigger' data-target='s2'>موسم 2</button><div class='season-wrapper' id='s2'><div class='episodes-grid'><a href='/watch=1/'>EP 1</a></div></div>"""
        val episodes=CeeCatalogParser.episodes(html,parent)
        assertEquals(listOf(2,14,14),episodes.map{it.seasonNumber})
        assertEquals(listOf(1,2,10),episodes.map{it.episodeNumber})
        assertEquals(21,CeeCatalogParser.season("الموسم الحادي والعشرون"))
    }
    @Test fun reversedEpisodeBatchesAndQueuesAreSortedNumerically() = runBlocking {
        val reversed=listOf(10,2,1).map{Video(nb="cee_$it",kind="2",season="1",episodeNummer=it.toString())}
        val repo=Repository(object:StubCeeCatalog(){override suspend fun episodes(video:Video)=reversed})
        assertEquals(listOf(1,2,10),repo.episodePage(Video(nb="cee_series_a",kind="2")).videos.map{it.episodeNumber})
        assertEquals(listOf(1,2,10),chronologicalPlaybackQueue(reversed).map{it.episodeNumber})
        val movies=listOf(Video(nb="m2",kind="1"),Video(nb="m1",kind="1"))
        assertEquals(movies,chronologicalPlaybackQueue(movies))
    }
    @Test fun resumeUsesRecentViewingInsteadOfTheHighestEpisodeWithProgress() {
        val episodes=(1..10).map{Video(nb="ep$it",kind="2",season="1",episodeNummer=it.toString())}
        assertEquals(0,resumeEpisodeIndex(episodes,listOf("ep1","ep10")){if(it in listOf("ep1","ep10"))60_000 else 0})
    }
}
