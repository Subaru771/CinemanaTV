package app.cinemanatv.util

import org.junit.Assert.*
import org.junit.Test

class PlaybackReportTest {
    @Test fun signedUrlsPathsAndPrivateHeadersNeverAppearInTheCopiedReport() {
        val report=PlaybackReport.build("1.2.0","Android TV","Example","cee_123","Wi-Fi",
            "https://media.example/private-path?token=secret",
            "HTTP 403: https://media.example/private-path?token=secret\nAuthorization: Bearer private-access\nCookie: session=private-cookie")
        assertTrue(report.contains("media.example"));assertTrue(report.contains("HTTP 403"))
        listOf("secret","private-path","private-access","private-cookie").forEach{assertFalse(report.contains(it))}
    }
    @Test fun aLookupFailureCanBeReportedWithoutAResolvedStream() {
        val report=PlaybackReport.build("1.2.0","TV","Example","cee_123","Ethernet",null,"Provider HTTP 503")
        assertTrue(report.contains("cee_123"));assertTrue(report.contains("not resolved"));assertTrue(report.contains("503"))
    }
}
