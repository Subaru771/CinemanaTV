package app.cinemanatv.ui

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import androidx.compose.ui.platform.AbstractComposeView
import org.robolectric.android.controller.ActivityController

/** Manual Robolectric activities must dispose their compositions, including repeating effects. */
internal fun destroyActivity(controller:ActivityController<out Activity>) {
    fun dispose(view:View) {
        if(view is AbstractComposeView)view.disposeComposition()
        if(view is ViewGroup)for(index in 0 until view.childCount)dispose(view.getChildAt(index))
    }
    dispose(controller.get().window.decorView)
    controller.pause().stop().destroy()
}
