package app.cinemanatv.data

import app.cinemanatv.util.numberedDownloadOptions
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test

class QualityInventoryLiveTest {
    @Test fun viewingAndDownloadsGetTheSamePublishedHlsResolutions() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1")
        val source=CeeAlternativeSource.resolve("cee_2148687")
        val selected=source.qualities.first()
        val sizes=HlsManifest.heights(selected)
        assertTrue("No declared HLS resolutions",sizes.isNotEmpty())
        val downloads=numberedDownloadOptions(HlsManifest.downloadOptions(source.qualities))
        assertEquals(sizes,downloads.filter{it.height>0}.map{it.height})
        println("Live quality inventory: ${sizes.size} source-declared resolutions match between viewing and download choices")
    }
}
