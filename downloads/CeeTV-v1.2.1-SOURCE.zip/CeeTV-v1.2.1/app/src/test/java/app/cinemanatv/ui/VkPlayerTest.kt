package app.cinemanatv.ui
import android.app.Application
import android.os.Looper
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class VkPlayerTest {
    @Test fun officialEmbedComposesAndBackExitsAndDisposes() {
        val controller=Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        var back:(()->Unit)?=null
        var exited=false
        val activity=controller.get()
        activity.setContent {
            CinemanaTheme { VkPlayerScreen("https://vkvideo.ru/video_ext.php?oid=-123&id=456","VK sample",
                {exited=true},{back=it}) }
        }
        val decor=activity.window.decorView
        decor.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY))
        decor.layout(0,0,1280,720)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1))
        assertNotNull(back)
        back!!.invoke()
        assertTrue(exited)
        destroyActivity(controller)
        assertNull(back)
    }
}
