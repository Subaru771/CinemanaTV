package app.cinemanatv.data

import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class CancellableHttpTest {
    @Test fun cancellingBeforeHeadersCancelsTheActualCall() = runBlocking {
        val server=MockWebServer();server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE));server.start()
        val started=CompletableDeferred<Call>()
        val client=OkHttpClient.Builder().eventListener(object:EventListener(){override fun callStart(call:Call){started.complete(call)}}).build()
        try {
            val request=launch {CancellableHttp.read(client,Request.Builder().url(server.url("/slow")).build()){it.body!!.string()}}
            val call=withTimeout(3000){started.await()}
            request.cancelAndJoin()
            assertTrue(call.isCanceled())
        }finally{client.dispatcher.cancelAll();server.shutdown()}
    }
    @Test fun timeoutAlsoCancelsAStalledBodyAfterTheHeadersArrive() = runBlocking {
        val server=MockWebServer();server.enqueue(MockResponse().setBody("a".repeat(200_000)).throttleBody(1,5,TimeUnit.SECONDS));server.start()
        val reading=CompletableDeferred<Unit>();val callRef=AtomicReference<Call>()
        val client=OkHttpClient.Builder().eventListener(object:EventListener(){override fun callStart(call:Call){callRef.set(call)}}).build()
        try {
            val request=launch {CancellableHttp.read(client,Request.Builder().url(server.url("/body")).build()){reading.complete(Unit);it.body!!.string()}}
            withTimeout(3000){reading.await()}
            request.cancelAndJoin()
            assertTrue(callRef.get().isCanceled())
        }finally{client.dispatcher.cancelAll();server.shutdown()}
    }
    @Test fun ordinaryBodyIsReadAndConsumerErrorsArePropagated() = runBlocking {
        val server=MockWebServer();server.enqueue(MockResponse().setBody("hello"));server.enqueue(MockResponse().setBody("invalid"));server.start()
        val client=OkHttpClient()
        try {
            assertEquals("hello",CancellableHttp.read(client,Request.Builder().url(server.url("/ok")).build()){it.body!!.string()})
            try { CancellableHttp.read(client,Request.Builder().url(server.url("/bad")).build()){throw java.io.IOException("parse failed")};fail() }
            catch(expected:java.io.IOException){assertEquals("parse failed",expected.message)}
        }finally{server.shutdown()}
    }
}
