# CinemanaTV v1.4.5 — Verification report

## Source identity
- Source integrated from the user-uploaded v1.4.4 and the earlier mature-filter fixes package.
- Android application ID retained: `app.cinemanatv`.
- Version name/code: `1.4.5` / `40`.
- No new account or cloud-sign-in features.

## Confirmed offline checks
- **34 Kotlin-only tests** passed with Kotlin 1.9, Java 21 and a minimal JUnit assertion shim. These cover mature content, complete rating queue, network diagnostics, remote Back behavior, intro markers, stream-quality selection, subtitle preference and subtitle cue timing.
- **5 UI-language logic tests** passed using minimal Compose compile-time shims, including Arabic Reset label and the new filtered-list messages.
- **13 Android XML files** parsed successfully.
- Static wiring check passed: unified Downloads visibility, Home/Watchlist/Recent metadata requests, preserved search focus, cancellation-safe bounded lookup, failure treated as unknown, no `take(160)` cap, corrected workflow names, stable application ID.

## Unverified / limitations
- **Full Android Gradle compilation and packaged APK:** NOT verified; the wrapper cannot download Gradle 8.14.3 in this environment (`UnknownHostException: services.gradle.org`).
- Real network/provider responses, Android TV remote navigation, playback, downloads and existing signing-key compatibility: NOT device tested.
- These are **focused Kotlin checks**, not the entire Gradle/JUnit or Android instrumentation test suite.
- Content restrictions use provider metadata. They cannot detect specific scenes, and Hide Mature mode may permit unrated titles after a successful detail lookup. Failed lookups remain hidden until retried.
- The optimized build is signed using the *building machine's debug key*, not a real publication key. Do not uninstall old builds merely to force a new install; you may lose local data.

## How to complete full testing
1. On Windows with Android SDK and JDK 17+, extract the package and run `RUN-V1.4.5-FULL-TEST.cmd`.
2. The script runs `testDebugUnitTest assembleRelease` and captures `output/CinemanaTV-v1.4.5-BUILD.log`.
3. If successful, test `output/CinemanaTV-v1.4.5-test.apk` on Android/Google TV, but only update an existing installation when signing certificates match.
4. Follow `TV-TEST-CHECKLIST.md` and `TESTING.md` before distribution.
