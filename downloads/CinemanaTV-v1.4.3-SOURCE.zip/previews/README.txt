These are visual design concepts generated from the requested reference, NOT
screenshots of the compiled Android TV application. The actual startup popup
is implemented natively using Jetpack Compose in StartupAnnouncements.kt,
with its text chosen by telegramCardCopy(language).
