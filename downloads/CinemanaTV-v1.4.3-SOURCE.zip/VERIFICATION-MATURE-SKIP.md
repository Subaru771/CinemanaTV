# Mature-skip repair: verification status (2026-11-09)

- MovieHavenDB: verified against the GitHub repository. `master/movies/tt0266543.json` is the only file. It is mute-only and not a mature skip.
- Core Kotlin sources (`ExternalSceneMarkers.kt`, `MatureSkipAvailability.kt`) compiled using lightweight Gson/Android stand-ins; this is a syntax smoke check, not an Android build.
- 11 Kotlin behavior smoke tests passed against the actual patched production helper methods, using in-memory JSON objects mirroring the supplied CleanStream response structure.
- Gradle wrapper could not download Gradle: `java.net.UnknownHostException: services.gradle.org`. No Android SDK/Gradle toolchain available.
- NOT VERIFIED: real Gson/JUnit test suite; actual CleanStream network call from this runtime; Android compilation, APK signing, playback skipping on hardware.
- Do not distribute an older v1.5.4 APK under this version.


Smoke output:
PASS: legacy import accepted: two mature entries
PASS: legacy import listed status
PASS: unverified import has lower confidence
PASS: empty response counts no markers
PASS: mismatched IMDb unknown
PASS: mismatched declared edition blocked
PASS: in-range declared edition accepted
PASS: downvoted marker blocked
PASS: out of range blocked against real duration
PASS: malformed segments unknown
PASS: MovieHaven mute-only is not mature skip
