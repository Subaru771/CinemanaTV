# Cinemana TV 1.5.4 — restore top-bar search

- Restores **Up on the focused top navigation bar** opening the search overlay, as in v1.5.1.
- Keeps the pinned Search button on the right, the full search experience, and v1.5.3 Settings D-pad navigation.
- Search remains an overlay, not a tab.
- No changes to playback or mature-content filtering.
