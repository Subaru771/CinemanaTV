# CinemanaTV v1.6.4 — TV Telegram focus refinement

- Removed the thick white focus rectangle around Telegram invitation buttons (including Not Now and the opt-out control).
- Replaced pale focused-button fills with subtle dark/red shades and a 1dp theme-matched border, preserving D-pad focus visibility and accessibility.
- Kept language-specific English/Arabic dialogs, existing dismiss/never-show preference, and independent update alerts unchanged.
- Version 1.6.4 / code 59. No package ID or signing changes.
- Build verification: source-level checks; no compiled Android APK produced in this environment.
