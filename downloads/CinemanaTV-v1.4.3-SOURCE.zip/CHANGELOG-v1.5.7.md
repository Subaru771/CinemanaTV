# v1.5.7 — Mature-marker loading repair

- Fetch mature timestamps independently of intro/credit services, with a separate runtime-specific cache.
- Retry transient marker errors and missing IMDb details every 30 seconds while playback is open.
- Retry unknown status on visible cards instead of leaving SKIP ? indefinitely after a failed lookup.
- Treat empty/zero parent IDs on movie cards as movie metadata, not proof of an episode.
- Accept partial detail records carrying IMDb metadata without requiring a repeated title and ID; preserve catalogue fields and reject metadata for a different title.
- Add IMDb string/URL aliases without mistaking a numeric IMDb rating for a title ID.
- Display persistent player status for active skipping, missing IMDb, missing timestamps, cut mismatch, network errors, and unsupported episodes, with Arabic translations.
- Keep saved scene ranges, app ID, preferences, history, and download formats. Version code 52.

Published timestamps remain incomplete community data. Public mature sources currently support movies only. No video analysis or timestamp guessing was added. APKs use a local debug signing key; upgrading an existing installation requires the same signing key.
