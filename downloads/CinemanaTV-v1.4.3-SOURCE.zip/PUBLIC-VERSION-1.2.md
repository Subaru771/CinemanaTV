# Cinemana TV v1.2 — version alignment

Prepared from CinemanaTV-v1.6.5-No-White-Focus-SOURCE.zip, preserving player, search, subtitle, settings and focus behavior.

- User-facing Android `versionName`: `1.2`
- Monotonic Android `versionCode`: `120`, formerly `60`
- Windows APK builders, verification tool, CI APK filename: `v1.2`
- The update notification displays `versionName` taken from the update server, so the publisher must also say `1.2` and code `120` for this release; a future release must use a greater code.
- Historical changelogs and earlier test fixtures retain their accurate historical version numbers.

Android compilation and playback have not been verified in this environment because the Android SDK is unavailable.

See `updates/publish-v1.2.example.json` for the release manifest shape used by the current TV app. Upload it to your HTTPS update feed only after the APK is released. It is not deployed by this package.
