# Cinemana TV v1.2 — Cloudflare updater integrated

- Feed URL configured by default: `https://cinemana-updates-e8l.pages.dev/updates.json`
- Uses your original TV startup UI (Telegram card + remote-focus-friendly update dialog).
- Accepts the shared Cloudflare `schema=1`, `tv` release object; respects `enabled=false`.
- Compares Android `versionCode` (installed v1.2 = 120), not string labels.
- English/Arabic release notes and actions follow the app language.
- Remembers a dismissed update; newer releases still show.
- Does not download/install APKs silently and sends no private data to Cloudflare.

## How to produce an APK on your Windows machine
Run `BUILD-APK.cmd` from this root (JDK 17+, Android SDK & Gradle internet access are required). This produces a **test/debug-key-signed** APK by default, not a public production-signed update. Use your existing release signing certificate to update installed copies without uninstalling; a different signature is rejected by Android. The project already includes a GitHub Actions build workflow if you prefer a PRIVATE repository.

## Release testing
Leave `tv.enabled=false` while initially installing v1.2 (code 120). After a verified 1.3 (code 130) APK is hosted, update and deploy the Cloudflare JSON with enabled=true, versionCode=130, and its HTTPS download link. The v1.2 app should show the update after next launch.
