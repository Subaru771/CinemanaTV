# Cinemana TV v1.5.2 — Compact UI & Focus Repair

- TV settings focus no longer replaces the detail pane during D-pad traversal. Select a category with OK.
- Focused controls automatically scroll into view and draw a high-contrast outline.
- Removes technical paragraphs, obsolete version label, empty account card and no-data warning pills.
- Integrates third intro/credits fallback from TheIntroDB v4 with multiple timestamp ranges.
- Adds optional runtime-verified CleanStream community mature-scene lookup for movies, alongside MovieHavenDB.
- Requires movie edition duration within 5s and sufficient community votes; ignores unsupported scenes and mismatched streams.
- No arbitrary intro jump or video AI scanning; watch history and file contents are never sent to the scene APIs.
- Build 47; tests cover timestamp parsers, duplicate entries and edition mismatches.

Data sources: SkipDB ODbL with reciprocity; IntroDB terms; TheIntroDB API terms; MovieHavenDB CC BY 4.0; CleanStream community data includes contributions imported from VideoSkip. Confirm third-party data redistribution/licensing and coverage before public distribution.
