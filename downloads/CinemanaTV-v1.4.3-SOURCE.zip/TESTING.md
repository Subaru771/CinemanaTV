# v1.4.7 — Verification and TV acceptance checklist

## Automated source checks
- ZIP integrity and no unsafe file paths.
- Parse every Android XML resource.
- Kotlin-only tests: mature rating logic and uncapped maturity queue.
- Inspect manifest, versionCode/versionName, Windows script, and workflow consistency.

## Windows / TV checks not possible in this environment
1. Run `RUN-V1.4.7-FULL-TEST.cmd` on a PC with JDK/Android SDK and network access.
2. Keep a copy of the existing APK and local data; do not uninstall to bypass signature errors.
3. Install the newly built APK only when the signing certificate matches installed builds.
4. Launch on Android TV/Google TV and verify TV remote Left/Right/Up/Down/Back.
5. Check Home and Search, search focus, and every tab on a 720p layout.
6. In Settings > Mature Content check Off / Skip marked scenes / Hide mature titles. For Skip, mark a start and an end in Player Settings, then replay the scene to verify skipping. No unmarked scene is auto-detected.
7. Open long catalog pages (>160 items), My List, recently watched, History, Downloads,
   More Like This and a series with episodes. Confirm blocked titles stay hidden.
8. Unplug network and confirm filtering fails closed while data loads or when lookup fails.
9. Verify selecting an allowed title, 4K/1080p source choice, subtitle selection,
   seeking, playback resumption, next episode and remote Back behavior.
10. Verify downloads progress/retry/delete, and that changing filter does not delete files.
11. Report any fatal errors with `output/CinemanaTV-v1.4.7-BUILD.log` or Android logcat.

**Remember:** Metadata-only filtering is not guaranteed parental protection and
unknown titles remain permitted in Hide Mature after a successful unrated lookup.
