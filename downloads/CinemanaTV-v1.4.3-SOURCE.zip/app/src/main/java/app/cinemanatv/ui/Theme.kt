package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.tv.material3.LocalContentColor
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme

object C {
    val Red = Color(0xFFFF5262)
    val Bg = Color(0xFF0B0E15)
    val Panel = Color(0xFF171D28)
    val Dim = Color(0xFFA9B1C0)
}

@Composable
fun CinemanaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Red,
            background = C.Bg,
            surface = C.Panel,
            onSurface = Color.White,
            onBackground = Color.White,
        )
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Box(Modifier.fillMaxSize().background(C.Bg)) { content() }
        }
    }
}
