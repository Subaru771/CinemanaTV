package app.cinemanatv.util

import app.cinemanatv.data.QualityOption

/**
 * Download selector: show only real, numbered video resolutions, never a fabricated
 * default, unknown "Auto" entry, or playlist-only quality. Duplicate heights are
 * collapsed so each resolution appears just once in the TV remote chooser.
 */
fun numberedDownloadOptions(options: List<QualityOption>): List<QualityOption> =
    options.asSequence()
        .filter { it.height > 0 &&
            (it.url.startsWith("https://") || it.url.startsWith("http://")) }
        .sortedByDescending { it.height }
        .distinctBy { it.height }
        .toList()
