package app.cinemanatv.ui

import android.view.View
import android.view.ViewGroup
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.tv.material3.Text
import app.cinemanatv.data.CeeWebRoutes
import app.cinemanatv.util.CrashReports

/** Website-owned HTML5 playback, matching the verified CEE WebView architecture. */
@Composable
fun CeeWebScreen(url: String, onExit: () -> Unit, onRegisterBack: ((() -> Unit)?) -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current
    var fullView by remember { mutableStateOf<View?>(null) }
    var fullCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var report by remember { mutableStateOf<String?>(null) }
    fun closeFullscreen() {
        fullView = null
        val callback = fullCallback
        fullCallback = null
        callback?.onCustomViewHidden()
    }
    val web = remember(context) {
        try {
            WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                settings.useWideViewPort = true
                settings.loadWithOverviewMode = true
                settings.allowFileAccess = false
                settings.allowContentAccess = false
                settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                keepScreenOn = true
                isFocusable = true
                isFocusableInTouchMode = true
                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, startedUrl: String, favicon: Bitmap?) {
                        loading = true
                        error = null
                    }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                        request.url.scheme !in listOf("https", "http")
                    override fun onPageFinished(view: WebView, finishedUrl: String) { loading = false }
                    override fun onReceivedError(view: WebView, request: WebResourceRequest, failure: WebResourceError) {
                        if (request.isForMainFrame) {
                            loading = false
                            error = CrashReports.redact(failure.description.toString()).take(400)
                        }
                    }
                }
                webChromeClient = object : WebChromeClient() {
                    override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                        if (fullView != null) callback.onCustomViewHidden()
                        else { fullCallback = callback; fullView = view }
                    }
                    override fun onHideCustomView() = closeFullscreen()
                }
            }
        } catch (failure: Exception) {
            CrashReports.record(context, failure)
            error = "Android System WebView is unavailable: ${CrashReports.summary(failure)}"
            null
        } catch (failure: LinkageError) {
            CrashReports.record(context, failure)
            error = "Android System WebView is unavailable: ${CrashReports.summary(failure)}"
            null
        }
    }
    val back by rememberUpdatedState<() -> Unit> {
        when {
            fullView != null -> closeFullscreen()
            web?.canGoBack() == true -> web.goBack()
            else -> onExit()
        }
    }
    DisposableEffect(web, lifecycle) {
        onRegisterBack { back() }
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) web?.onPause()
            if (event == Lifecycle.Event.ON_START) web?.onResume()
        }
        lifecycle.lifecycle.addObserver(observer)
        onDispose {
            onRegisterBack(null)
            lifecycle.lifecycle.removeObserver(observer)
            runCatching { closeFullscreen() }
            runCatching { web?.stopLoading(); (web?.parent as? ViewGroup)?.removeView(web); web?.destroy() }
        }
    }
    LaunchedEffect(web, url) {
        if (web != null && CeeWebRoutes.validStart(url)) {
            web.loadUrl(url)
            web.requestFocus()
        } else if (web != null) { loading = false; error = "Unsupported alternative website address." }
    }
    report?.let { CrashReportDialog(it) { report = null } }
    Box(Modifier.fillMaxSize().background(C.Bg)) {
        Column(Modifier.fillMaxSize()) {
            if (fullView == null) Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AppButton("Back") { back() }
                AppButton("Reload") { error = null; loading = true; web?.reload() }
                Text(if (loading) "CEE web player · loading…" else "CEE website controls · native scene skipping unavailable")
            }
            if (web != null) AndroidView(factory = { web }, modifier = Modifier.weight(1f).fillMaxWidth())
            error?.let { message ->
                Column(Modifier.fillMaxWidth().background(C.Panel).padding(20.dp)) {
                    Text(message)
                    AppButton("Error details") { report = CrashReports.last(context) ?: message }
                }
            }
        }
        fullView?.let { videoView ->
            AndroidView(factory = { FrameLayout(context).apply {
                (videoView.parent as? ViewGroup)?.removeView(videoView)
                addView(videoView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            } }, modifier = Modifier.fillMaxSize())
        }
    }
}
