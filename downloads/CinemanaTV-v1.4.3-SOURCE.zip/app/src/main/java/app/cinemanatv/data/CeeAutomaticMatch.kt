package app.cinemanatv.data

import java.text.Normalizer
import java.util.Locale

/** Conservative identity match: release year, exact title, and exact episode when applicable. */
object CeeAutomaticMatch {
    private val year = Regex("\\b(?:19|20)[0-9]{2}\\b")
    private val episode = Regex("(?i)(?:s\\s*([0-9]+)\\s*e\\s*([0-9]+)|(?:season|الموسم)\\s*([0-9]+)\\s*[-:،· ]*\\s*(?:episode|الحلقة|حلقة)\\s*([0-9]+))")
    private fun digits(text: String): String = text.map { c ->
        if (c in '\u0660'..'\u0669') '0' + (c - '\u0660')
        else if (c in '\u06f0'..'\u06f9') '0' + (c - '\u06f0') else c
    }.joinToString("")

    private fun title(text: String, releaseYear: String): String {
        var value = Normalizer.normalize(digits(text), Normalizer.Form.NFKC).lowercase(Locale.ROOT)
        value = value.replace(Regex("\\b${Regex.escape(releaseYear)}\\b"), " ")
        value = value.replace(episode, " ")
        value = value.replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
        value = value.replace(Regex("^(?:(?:فيلم|مسلسل|مشاهدة|تحميل) +)+"), "")
            .replace(Regex("(?: +(?:مترجم|مدبلج|كامل|اونلاين))+$"), "")
        return value.replace(Regex("\\s+"), " ").trim()
    }

    fun queries(original: Video): List<String> {
        val identity = if (original.episodeNumber > 0) original.rootSeriesInfo ?: original else original
        return listOfNotNull(identity.enTitle, identity.arTitle).map(String::trim)
            .filter { it.isNotBlank() }.distinct().take(2)
    }

    fun select(original: Video, candidates: List<Video>): Video? {
        if (CeeAlternativeSource.owns(original.id) || (original.kind == "2" && original.episodeNumber == 0)) return null
        val identity = if (original.episodeNumber > 0) original.rootSeriesInfo ?: original else original
        val releaseYear = identity.year?.let { year.find(digits(it))?.value } ?: return null
        val titles = queries(original).map { title(it, releaseYear) }.filter { it.isNotBlank() }.toSet()
        if (titles.isEmpty()) return null
        return candidates.distinctBy { it.id }.filter { candidate ->
            if (!CeeAlternativeSource.owns(candidate.id)) return@filter false
            val raw = digits(candidate.title)
            val candidateYear = candidate.year?.let { year.find(digits(it))?.value }
                ?: year.findAll(raw).lastOrNull()?.value
            if (candidateYear != releaseYear || title(raw, releaseYear) !in titles) return@filter false
            val coordinates = episode.find(raw)
            if (original.episodeNumber > 0) {
                if (coordinates == null) return@filter false
                val groups = coordinates.groupValues
                val season = (groups[1].ifBlank { groups[3] }).toIntOrNull()
                val number = (groups[2].ifBlank { groups[4] }).toIntOrNull()
                season == original.seasonNumber && number == original.episodeNumber
            } else coordinates == null && !Regex("(?i)\\b(?:season|episode|الموسم|الحلقة|حلقة|مسلسل)\\b").containsMatchIn(raw)
        }.singleOrNull()
    }
}
