package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.CeeAlternativeSource
import app.cinemanatv.data.ContentFilterMode
import app.cinemanatv.data.Video
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/** The user explicitly confirms the provider's own title; no fuzzy automatic substitutions. */
@Composable
fun AlternativeSourceDialog(initialQuery: String = "", onDismiss: () -> Unit, onPlay: (Video) -> Unit) {
    val ar = LocalInterfaceLanguage.current == "ar"
    fun label(en: String, arabic: String) = if (ar) arabic else en
    var query by remember { mutableStateOf(initialQuery) }
    var results by remember { mutableStateOf<List<Video>>(emptyList()) }
    var selected by remember { mutableStateOf<Video?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val inputFocus = remember { FocusRequester() }
    val allowed = Services.prefs.contentFilterMode == ContentFilterMode.OFF
    fun search() {
        if (busy || !allowed) return
        busy = true; selected = null; results = emptyList(); message = ""
        scope.launch {
            try {
                results = CeeAlternativeSource.search(query)
                if (results.isEmpty()) message = label("No matching titles. Try an Arabic title or an exact episode page URL.",
                    "لا توجد نتائج. جرّب عنواناً عربياً أو رابط صفحة الحلقة المحددة.")
            } catch (c: CancellationException) { throw c }
              catch (e: Exception) { message = e.message ?: label("Alternative source unavailable.", "المصدر البديل غير متاح.") }
            finally { busy = false }
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.widthIn(max = 900.dp).fillMaxWidth(0.9f).fillMaxHeight(0.9f)
            .background(C.Panel, RoundedCornerShape(22.dp)).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(label("CEE alternative source", "مصدر CEE البديل"), fontSize = 23.sp)
            Text(label("Choose the exact movie/year or season/episode. This source has separate history and no Cinemana subtitles or scene markers. Availability varies.",
                "اختر الفيلم وسنته أو الموسم والحلقة بدقة. لهذا المصدر سجل مستقل، ولا تُنقل ترجمة سينمانا أو علامات المشاهد إليه. قد يختلف التوفر."),
                color = C.Dim, fontSize = 13.sp)
            if (!allowed) {
                Text(label("Alternative titles have no verified age ratings and are unavailable while content filtering is enabled.",
                    "لا تتوفر تصنيفات عمرية موثقة للعناوين البديلة، لذا لا يمكن استخدامها أثناء تفعيل فلتر المحتوى."), color = C.Dim)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TvTextField(query, { query = it }, label("Title or exact cinamana.cc episode URL", "العنوان أو رابط الحلقة من cinamana.cc"),
                        Modifier.weight(1f).focusRequester(inputFocus), imeAction = ImeAction.Done, onDone = { search() })
                    AppButton(if (busy) label("Searching…", "جارٍ البحث…") else label("Search", "بحث")) { search() }
                }
                if (message.isNotBlank()) Text(message, color = C.Dim, fontSize = 14.sp)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(results, key = { it.id }) { video ->
                        AppButton((if (selected?.id == video.id) "✓ " else "") + video.title,
                            Modifier.fillMaxWidth(), primary = selected?.id == video.id) { selected = video }
                    }
                }
                selected?.let { video ->
                    Text(label("Selected: ", "المحدد: ") + video.title, fontSize = 15.sp)
                    AppButton(label("Play selected title", "تشغيل العنوان المحدد"), primary = true) {
                        onPlay(video)
                        onDismiss()
                    }
                }
            }
            AppButton(label("Close", "إغلاق")) { onDismiss() }
        }
        LaunchedEffect(Unit) {
            if (allowed) {
                runCatching { inputFocus.requestFocus() }
                search()
            }
        }
    }
}
