package app.cinemanatv.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonParser
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Settings and session storage.
 * Secrets are encrypted with a non-exportable Android Keystore key. Some cheap TV boxes ship a broken
 * Keystore; in that case we fall back to app-private storage ("p:" prefix) instead of crashing.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("cinemana_tv", Context.MODE_PRIVATE)
    private val store = context.getSharedPreferences("cinemana_library", Context.MODE_PRIVATE)
    private val alias = "cinemana_tv_session_v2"
    private val gson = Gson()
    @Volatile private var keystoreOk = true

    init {
        // One-time migration of values written by older builds in plain text.
        listOf("access", "refresh").forEach { name ->
            val v = sp.getString(name, "").orEmpty()
            if (v.isNotBlank() && !v.startsWith("v2:") && !v.startsWith("p:")) setSession(name, v)
        }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(
                KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
        }.generateKey()
    }

    private fun encrypt(value: String): String {
        if (keystoreOk) {
            try {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, key())
                return "v2:" + Base64.encodeToString(c.iv + c.doFinal(value.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
            } catch (_: Exception) {
                keystoreOk = false
            }
        }
        return "p:" + Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    }

    private fun decrypt(stored: String): String = try {
        if (stored.startsWith("p:")) {
            String(Base64.decode(stored.removePrefix("p:"), Base64.NO_WRAP), Charsets.UTF_8)
        } else {
            val raw = Base64.decode(stored.removePrefix("v2:"), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            String(c.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
        }
    } catch (_: Exception) { "" }

    private fun session(name: String): String {
        val stored = sp.getString(name, "").orEmpty()
        return if (stored.isBlank()) "" else decrypt(stored)
    }

    private fun setSession(name: String, value: String) {
        if (value.isBlank()) sp.edit().remove(name).apply()
        else sp.edit().putString(name, encrypt(value)).apply()
    }

    // ---- session ----
    var accessToken: String
        get() = session("access")
        set(v) = setSession("access", v)
    var refreshToken: String
        get() = session("refresh")
        set(v) = setSession("refresh", v)
    var expiresAt: Long
        get() = sp.getLong("expires_at", 0L)
        set(v) = sp.edit().putLong("expires_at", v).apply()
    var username: String
        get() = sp.getString("user", "").orEmpty()
        set(v) = sp.edit().putString("user", v).apply()
    fun clearSession() {
        sp.edit().remove("access").remove("refresh").remove("expires_at").remove("user").apply()
    }

    // ---- sign-in setup (entered by the user on the TV) ----
    var clientId: String
        get() = sp.getString("client_id", "").orEmpty()
        set(v) = sp.edit().putString("client_id", v.trim()).apply()
    var clientSecret: String
        get() = session("client_secret")
        set(v) = setSession("client_secret", v.trim())
    var scope: String
        get() = sp.getString("scope", "").orEmpty()
        set(v) = sp.edit().putString("scope", v.trim()).apply()

    // ---- TV interface language (independent of device language) ----
    var interfaceLanguage: String
        get() = if (sp.getString("interface_language", "en") == "ar") "ar" else "en"
        set(value) = sp.edit().putString("interface_language", if (value == "ar") "ar" else "en").apply()

    // ---- optional startup invitation (user can opt out permanently) ----
    var hideTelegramInvitation: Boolean
        get() = sp.getBoolean("hide_telegram_invitation", false)
        set(value) = sp.edit().putBoolean("hide_telegram_invitation", value).apply()

    // ---- cached age-certificate / genre metadata used by the mature-content filter ----
    fun maturityCached(id: String): String? = store.getString("maturity_$id", null)
    fun maturityStore(id: String, json: String) { store.edit().putString("maturity_$id", json).apply() }

    private fun validAlternative(id: String): Boolean = id.startsWith("cee_") &&
        id.removePrefix("cee_").let { it.length in 1..12 && it.all { c -> c in '0'..'9' } }

    /** Persist only a user-confirmed title identity, never a signed stream URL. */
    fun rememberAlternative(originalId: String, alternative: app.cinemanatv.data.Video) {
        if (originalId.isBlank() || originalId.startsWith("cee_") || !validAlternative(alternative.id)) return
        val identity = app.cinemanatv.data.Video(nb = alternative.id, enTitle = alternative.title, year = alternative.year)
        store.edit().putString("alternative_$originalId", gson.toJson(identity)).apply()
    }

    fun confirmedAlternative(originalId: String): app.cinemanatv.data.Video? = runCatching {
        val json = store.getString("alternative_$originalId", null) ?: return@runCatching null
        gson.fromJson(json, app.cinemanatv.data.Video::class.java)?.takeIf { validAlternative(it.id) }
    }.getOrNull()

    // ---- Android TV Watch Next integration (viewer can disable from Settings) ----
    var tvHomeEnabled: Boolean
        get() = sp.getBoolean("tv_home_watch_next", true)
        set(value) = sp.edit().putBoolean("tv_home_watch_next", value).apply()

    // Legacy hide-title modes are migrated to scene-only skipping; catalog entries stay visible.
    // Existing local watch history and downloads are never deleted.
    /** Legacy preference retained for saved settings compatibility; the player now uses community markers automatically. */
    var communitySceneMarkersEnabled: Boolean
        get() = sp.getBoolean("community_scene_markers", true)
        set(value) = sp.edit().putBoolean("community_scene_markers", value).apply()

    /** Skip intros and recaps automatically when a verified marker exists (credits/previews always need a press). */
    var autoSkipIntro: Boolean
        get() = sp.getBoolean("auto_skip_intro", true)
        set(value) = sp.edit().putBoolean("auto_skip_intro", value).apply()

    var matureAction: MatureAction
        get() {
            val stored = sp.getString("mature_action_v2", null)
            if (stored == "HIDE_TITLES" || (stored == null && contentFilterMode != ContentFilterMode.OFF)) {
                sp.edit().putString("mature_action_v2", "SKIP_SCENES").apply()
                contentFilterMode = ContentFilterMode.OFF
                return MatureAction.SKIP_SCENES
            }
            return if (stored == "SKIP_SCENES") MatureAction.SKIP_SCENES else MatureAction.OFF
        }
        set(value) {
            sp.edit().putString("mature_action_v2", if (value == MatureAction.OFF) "OFF" else "SKIP_SCENES").apply()
            contentFilterMode = ContentFilterMode.OFF
        }

    /** Cheap check for list/grid rendering: avoids JSON parsing for the (common) no-ranges case. */
    fun hasSceneRanges(videoId: String): Boolean {
        if (videoId.isBlank()) return false
        val raw = store.getString("scene_ranges_$videoId", null) ?: return false
        return raw.length > 2 && sceneRanges(videoId).isNotEmpty()
    }

    /** User-marked timestamps only. This does not infer sexual/violent scenes by itself. */
    fun sceneRanges(videoId: String): List<SceneRange> = runCatching {
        val raw = store.getString("scene_ranges_$videoId", "[]") ?: "[]"
        val ranges = JsonParser.parseString(raw).asJsonArray.mapNotNull { item ->
            runCatching {
                val obj = item.asJsonObject
                SceneRange(obj.get("startMs").asLong, obj.get("endMs").asLong)
            }.getOrNull()
        }
        SceneSkipping.normalize(ranges)
    }.getOrDefault(emptyList())

    fun saveSceneRanges(videoId: String, ranges: List<SceneRange>) {
        if (videoId.isBlank()) return
        store.edit().putString("scene_ranges_$videoId", gson.toJson(SceneSkipping.normalize(ranges))).apply()
    }

    // ---- viewer content & discovery preferences (local, opt-in, default unchanged) ----
    var contentFilterMode: ContentFilterMode
        get() = ContentFilterMode.entries.getOrNull(sp.getInt("content_filter_mode", 0)) ?: ContentFilterMode.OFF
        set(value) = sp.edit().putInt("content_filter_mode", value.ordinal).apply()

    var showContinueRow: Boolean
        get() = sp.getBoolean("home_show_continue", true)
        set(value) = sp.edit().putBoolean("home_show_continue", value).apply()
    var showMyListRow: Boolean
        get() = sp.getBoolean("home_show_my_list", true)
        set(value) = sp.edit().putBoolean("home_show_my_list", value).apply()
    var hideWatchedDiscovery: Boolean
        get() = sp.getBoolean("home_hide_watched", false)
        set(value) = sp.edit().putBoolean("home_hide_watched", value).apply()

    // ---- playback preferences ----
    var maxQuality: Int
        get() = sp.getInt("max_quality", 0)
        set(v) = sp.edit().putInt("max_quality", v).apply()
    var subtitleLabel: String
        get() = sp.getString("sub_label", "").orEmpty()
        set(v) = sp.edit().putString("sub_label", v).apply()
    /** TV-wide preferred subtitle language; never override a manual in-player choice. */
    var preferredSubtitleLanguage: String
        get() = sp.getString("preferred_subtitle_language", "auto")?.takeIf { it in setOf("auto", "ar", "en", "off") } ?: "auto"
        set(value) = sp.edit().putString("preferred_subtitle_language", value.takeIf { it in setOf("auto", "ar", "en", "off") } ?: "auto").apply()
    /** Subtitle size multiplier (1.0 = default). */
    var subtitleScale: Float
        get() = sp.getFloat("sub_scale", 1f)
        set(v) = sp.edit().putFloat("sub_scale", v).apply()

    /** Subtitle delay: positive = later, negative = earlier; bounded to ±10 seconds. */
    var subtitleDelayMs: Long
        get() = sp.getLong("sub_delay_ms", 0L).coerceIn(-10_000L, 10_000L)
        set(v) = sp.edit().putLong("sub_delay_ms", v.coerceIn(-10_000L, 10_000L)).apply()
    /** 0 outlined white, 1 golden, 2 white text on translucent black. */
    var subtitleStyle: Int
        get() = sp.getInt("sub_style", 0).coerceIn(0, 2)
        set(v) = sp.edit().putInt("sub_style", v.coerceIn(0, 2)).apply()
    /** 0 low, 1 standard, 2 raised above typical player controls. */
    var subtitlePlacement: Int
        get() = sp.getInt("sub_placement", 1).coerceIn(0, 2)
        set(v) = sp.edit().putInt("sub_placement", v.coerceIn(0, 2)).apply()

    // ---- local watchlist (independent of download and watch history) ----
    fun watchlist(): List<Video> = readList("watchlist")
    fun isWatchlisted(id: String): Boolean = watchlist().any { it.id == id }
    fun toggleWatchlist(video: Video): Boolean {
        val existing = watchlist()
        val added = existing.none { it.id == video.id }
        writeList("watchlist", if (added) (listOf(video) + existing).take(500)
            else existing.filter { it.id != video.id })
        return added
    }
    fun removeWatchlist(id: String) = writeList("watchlist", watchlist().filter { it.id != id })

    /** Global autoplay-next preference; can still be cancelled in the player. */
    var autoPlayNextEnabled: Boolean
        get() = sp.getBoolean("autoplay_next_episode", true)
        set(value) = sp.edit().putBoolean("autoplay_next_episode", value).apply()

    /** Stop an unattended TV from automatically playing an entire season. */
    var bingeCheckEnabled: Boolean
        get() = sp.getBoolean("binge_check_enabled", true)
        set(value) = sp.edit().putBoolean("binge_check_enabled", value).apply()

    // ---- resume positions (bounded) ----
    private var resumePruneCounter = 0
    fun resume(id: String): Long = store.getLong("pos_$id", 0L)
    fun setResume(id: String, ms: Long) {
        val e = store.edit()
        if (ms <= 0L) e.remove("pos_$id") else {
            e.putLong("pos_$id", ms)
            // SharedPreferences.all materializes the entire preference map; never do it
            // on each periodic playback checkpoint on a low-power TV processor.
            resumePruneCounter++
            if (resumePruneCounter % 48 == 0) {
                val keys = store.all.keys.filter { it.startsWith("pos_") }
                if (keys.size > 300) keys.take(100).forEach { e.remove(it) }
            }
        }
        e.apply()
    }

    // ---- small video lists: "Continue watching" and "Downloads" ----
    // Home re-reads these lists on every recomposition; parsing the JSON each time made D-pad
    // navigation stutter. The raw string is the cache key, so any write invalidates it.
    private val listMemo = HashMap<String, Pair<String, List<Video>>>()

    private fun readList(name: String): List<Video> {
        val raw = store.getString(name, "[]") ?: "[]"
        synchronized(listMemo) {
            val hit = listMemo[name]
            if (hit != null && hit.first == raw) return hit.second
        }
        val parsed = runCatching {
            JsonParser.parseString(raw).asJsonArray.mapNotNull { el ->
                runCatching { gson.fromJson(el, Video::class.java) }.getOrNull()
                    ?.takeIf { it.id.isNotBlank() && it.title.isNotBlank() }
            }
        }.getOrDefault(emptyList())
        synchronized(listMemo) { listMemo[name] = raw to parsed }
        return parsed
    }

    private fun writeList(name: String, list: List<Video>) {
        store.edit().putString(name, gson.toJson(list)).apply()
    }

    fun recent(): List<Video> = readList("recent")
    fun touchRecent(v: Video) {
        val current = recent()
        // Don't re-serialize the list every 15 seconds while watching one item.
        if (current.firstOrNull()?.id == v.id) return
        writeList("recent", (listOf(v) + current.filter { it.id != v.id }).take(12))
    }
    fun dropRecent(id: String) {
        val cur = recent()
        if (cur.any { it.id == id }) writeList("recent", cur.filter { it.id != id })
    }

    // ---- watch history (most recent first, bounded) ----
    fun history(): List<Video> = readList("history")
    fun addHistory(v: Video) {
        val current = history()
        if (current.firstOrNull()?.id == v.id) return
        writeList("history", (listOf(v) + current.filter { it.id != v.id }).take(200))
    }
    fun removeHistory(id: String) = writeList("history", history().filter { it.id != id })
    fun clearHistory() { store.edit().remove("history").apply() }

    fun downloads(): List<Video> = readList("downloads")
    fun addDownload(v: Video) = writeList("downloads", (listOf(v) + downloads().filter { it.id != v.id }).take(200))
    fun removeDownload(id: String) = writeList("downloads", downloads().filter { it.id != id })


    // ---- offline download preferences (independent from streaming quality) ----
    var downloadUnmeteredOnly: Boolean
        get() = sp.getBoolean("download_unmetered_only", false)
        set(value) = sp.edit().putBoolean("download_unmetered_only", value).apply()
    var downloadLocation: Int
        get() = sp.getInt("download_location", 0).coerceAtLeast(0)
        set(value) = sp.edit().putInt("download_location", value.coerceAtLeast(0)).apply()
    fun downloadSlot(id: String): Int = store.getInt("dl_slot_$id", 0).coerceAtLeast(0)
    fun setDownloadSlot(id: String, slot: Int) = store.edit().putInt("dl_slot_$id", slot.coerceAtLeast(0)).apply()
    fun downloadQuality(id: String): String = store.getString("dl_quality_$id", "").orEmpty()
    fun setDownloadQuality(id: String, quality: String) = store.edit().putString("dl_quality_$id", quality).apply()

    /** Internal cache for adaptive downloads; direct MP4 downloads keep their existing files. */
    fun downloadKind(id: String): String = store.getString("dl_kind_$id", "direct") ?: "direct"
    fun setDownloadKind(id: String, kind: String) {
        if (kind == "direct") store.edit().remove("dl_kind_$id").apply()
        else store.edit().putString("dl_kind_$id", kind).apply()
    }

    // ---- download bookkeeping ----
    fun downloadId(id: String): Long = store.getLong("dl_$id", 0L)
    fun setDownloadId(id: String, dm: Long) {
        if (dm <= 0L) store.edit().remove("dl_$id").apply() else store.edit().putLong("dl_$id", dm).apply()
    }
    fun downloadDone(id: String): Boolean = store.getBoolean("dldone_$id", false)
    fun setDownloadDone(id: String, done: Boolean) {
        if (done) store.edit().putBoolean("dldone_$id", true).apply() else store.edit().remove("dldone_$id").apply()
    }
}
