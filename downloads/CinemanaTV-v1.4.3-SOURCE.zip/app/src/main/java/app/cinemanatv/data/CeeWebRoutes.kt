package app.cinemanatv.data

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** Public alternative website reached through CEE's verified non-Earthlink navigation. */
object CeeWebRoutes {
    const val HOME = "https://cinamana.cc/main"
    fun title(original: Video, matched: Video? = null): String {
        val id = matched?.id?.takeIf { it.startsWith("cee_") }?.removePrefix("cee_")
            ?.takeIf { it.length in 1..12 && it.all { c -> c in '0'..'9' } }
        if (id != null) return "https://cinamana.cc/watch=$id/"
        val query = original.rootSeriesInfo?.title?.takeIf { it.isNotBlank() } ?: original.title
        return if (query.isBlank()) HOME else "https://cinamana.cc/".toHttpUrl().newBuilder()
            .addQueryParameter("s", query.take(250)).build().toString()
    }

    fun validStart(value: String): Boolean {
        val url = value.toHttpUrlOrNull() ?: return false
        return url.scheme == "https" && url.host == "cinamana.cc" && url.port == 443 &&
            url.username.isEmpty() && url.password.isEmpty() &&
            (url.encodedPath in listOf("/", "/main") || CeeAlternativeSource.pageId(value) != null)
    }
}
