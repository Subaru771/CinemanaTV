package app.cinemanatv.data

import android.util.Base64
import app.cinemanatv.BuildConfig
import com.google.gson.GsonBuilder
import com.google.gson.JsonParser
import okhttp3.OkHttpClient
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.Header
import retrofit2.http.POST
import java.io.IOException
import java.util.concurrent.TimeUnit

interface AccountApi {
    @FormUrlEncoded
    @POST("core/connect/token")
    suspend fun token(
        @Header("Authorization") basic: String,
        @Field("grant_type") grantType: String,
        @Field("scope") scope: String? = null,
        @Field("username") username: String? = null,
        @Field("password") password: String? = null,
        @Field("refresh_token") refreshToken: String? = null,
        @Field("device_code") deviceCode: String? = null,
    ): Response<TokenResponse>

    @FormUrlEncoded
    @POST("core/connect/deviceauthorization")
    suspend fun deviceAuthorization(
        @Header("Authorization") basic: String,
        @Field("scope") scope: String? = null,
    ): Response<DeviceAuthResponse>
}

class AuthRepository(private val prefs: Prefs) {
    private val api: AccountApi = Retrofit.Builder()
        .baseUrl("https://account.shabakaty.com/")
        .client(
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()
        )
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create()))
        .build()
        .create(AccountApi::class.java)

    // The Client ID can come from the build or be typed in on the TV (Sign-in setup).
    private val clientId: String get() = prefs.clientId.ifBlank { BuildConfig.CLIENT_ID }
    private val clientSecret: String get() = prefs.clientSecret.ifBlank { BuildConfig.CLIENT_SECRET }
    private val scope: String? get() = prefs.scope.ifBlank { BuildConfig.SCOPE }.ifBlank { null }

    val isConfigured: Boolean get() = clientId.isNotBlank()
    val isLoggedIn: Boolean get() = prefs.refreshToken.isNotBlank() ||
        (prefs.accessToken.isNotBlank() && prefs.expiresAt > System.currentTimeMillis())
    val username: String get() = prefs.username

    fun saveSetup(id: String, secret: String, scope: String) {
        prefs.clientId = id
        prefs.clientSecret = secret
        prefs.scope = scope
    }
    val savedClientId: String get() = prefs.clientId
    val savedScope: String get() = prefs.scope

    private fun basic(): String =
        "Basic " + Base64.encodeToString("$clientId:$clientSecret".toByteArray(), Base64.NO_WRAP)

    @Volatile private var cachedBearer: String? = null
    @Volatile private var bearerCachedUntil = 0L

    private fun save(t: TokenResponse, user: String?) {
        bearerCachedUntil = 0L
        prefs.accessToken = t.accessToken.orEmpty()
        if (!t.refreshToken.isNullOrBlank()) prefs.refreshToken = t.refreshToken
        prefs.expiresAt = System.currentTimeMillis() + (t.expiresIn ?: 3600L) * 1000L
        if (!user.isNullOrBlank()) prefs.username = user
    }

    private fun errorCode(body: String): String? = runCatching {
        val o = JsonParser.parseString(body).asJsonObject
        o.get("error")?.asString
    }.getOrNull()

    private fun errorText(code: Int, body: String): String {
        val err = errorCode(body)
        val desc = runCatching { JsonParser.parseString(body).asJsonObject.get("error_description")?.asString }.getOrNull()
        return when {
            err == "invalid_client" || code == 401 -> "The server rejected the Client ID. Open Sign-in setup and check it."
            err == "invalid_grant" -> "Wrong username or password."
            err == "invalid_scope" -> "The server rejected the scope. Open Sign-in setup and clear or fix it."
            err == "unauthorized_client" || err == "unsupported_grant_type" -> "This Client ID isn't allowed to use that sign-in method."
            !desc.isNullOrBlank() -> desc
            err != null -> err
            code == 404 -> "The account server doesn't support this sign-in method."
            else -> "Sign-in failed ($code)."
        }
    }

    private fun bodyOf(r: Response<*>): String = runCatching { r.errorBody()?.string() }.getOrNull().orEmpty()
    private val offline = "Can't reach the account server. Check the internet connection."

    suspend fun login(user: String, pass: String): Result<Unit> = try {
        if (!isConfigured) error("Sign-in isn't set up yet. Open Sign-in setup and enter the Client ID.")
        val r = api.token(basic(), "password", scope, username = user, password = pass)
        val token = r.body()?.takeIf { r.isSuccessful && it.accessToken != null }
            ?: error(errorText(r.code(), bodyOf(r)))
        save(token, user)
        Result.success(Unit)
    } catch (e: IOException) {
        Result.failure(IllegalStateException(offline))
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun startDeviceLogin(): Result<DeviceAuthResponse> = try {
        if (!isConfigured) error("Sign-in isn't set up yet.")
        val r = api.deviceAuthorization(basic(), scope)
        val device = r.body()?.takeIf { r.isSuccessful && it.deviceCode != null }
            ?: error(errorText(r.code(), bodyOf(r)))
        Result.success(device)
    } catch (e: IOException) {
        Result.failure(IllegalStateException(offline))
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    /** Done = signed in, Pending/SlowDown = keep polling, failure = expired or denied. */
    suspend fun pollDeviceLogin(deviceCode: String): Result<Poll> = try {
        val r = api.token(basic(), "urn:ietf:params:oauth:grant-type:device_code", scope, deviceCode = deviceCode)
        val token = r.body()?.takeIf { r.isSuccessful && it.accessToken != null }
        if (token != null) {
            save(token, "TV user")
            Result.success(Poll.Done)
        } else {
            val text = bodyOf(r)
            when (errorCode(text)) {
                "authorization_pending" -> Result.success(Poll.Pending)
                "slow_down" -> Result.success(Poll.SlowDown)
                else -> Result.failure(IllegalStateException(errorText(r.code(), text)))
            }
        }
    } catch (e: IOException) {
        Result.success(Poll.Pending) // transient network blip: keep waiting
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: Exception) {
        Result.failure(e)
    }

    @Volatile private var refreshFailedAt = 0L

    /**
     * Called from OkHttp threads, hence blocking. A failed refresh is not retried for 30 s so a bad
     * token can't slow down every request.
     */
    @Synchronized
    fun refreshBlocking(force: Boolean = false): Boolean {
        val rt = prefs.refreshToken
        if (rt.isBlank() || !isConfigured) return false
        val now = System.currentTimeMillis()
        if (!force && prefs.expiresAt > now + 60_000L) return true // someone else just refreshed
        if (now - refreshFailedAt < 30_000L) return false
        return try {
            kotlinx.coroutines.runBlocking {
                val r = api.token(basic(), "refresh_token", scope, refreshToken = rt)
                val token = r.body()?.takeIf { r.isSuccessful && it.accessToken != null }
                if (token != null) {
                    save(token, null); true
                } else {
                    refreshFailedAt = System.currentTimeMillis()
                    if (errorCode(bodyOf(r)) == "invalid_grant") {
                        cachedBearer = null
                        bearerCachedUntil = 0L
                        prefs.clearSession() // dead token: sign out cleanly
                    }
                    false
                }
            }
        } catch (_: Exception) {
            refreshFailedAt = System.currentTimeMillis()
            false
        }
    }

    // The Keystore can be extremely slow on entry-level TV chips. Avoid decrypting
    // exactly the same bearer token for every request in a catalog burst.
    @Synchronized
    fun bearer(): String? {
        val now = System.currentTimeMillis()
        if (now < bearerCachedUntil) return cachedBearer
        cachedBearer = prefs.accessToken.takeIf { it.isNotBlank() }?.let { "Bearer $it" }
        bearerCachedUntil = now + 30_000L
        return cachedBearer
    }

    fun logout() {
        cachedBearer = null
        bearerCachedUntil = 0L
        prefs.clearSession()
    }
}
