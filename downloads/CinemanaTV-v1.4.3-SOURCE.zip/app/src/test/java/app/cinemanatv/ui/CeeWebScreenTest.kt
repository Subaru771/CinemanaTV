package app.cinemanatv.ui

import android.app.Application
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebChromeClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
@LooperMode(LooperMode.Mode.PAUSED)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class CeeWebScreenTest {
    private fun browser(view: View): WebView? {
        if (view is WebView) return view
        if (view is ViewGroup) for (i in 0 until view.childCount) browser(view.getChildAt(i))?.let { return it }
        return null
    }
    @Test fun embeddedPlayerLoadsDirectlyAndBackExitsFullscreenFirst() {
        val controller = Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        val activity = controller.get()
        var back: (() -> Unit)? = null
        var exited = false
        activity.setContent { CinemanaTheme {
            CeeWebScreen("https://cinamana.cc/watch=123/", { exited = true }, { back = it })
        } }
        val decor = activity.window.decorView
        decor.measure(View.MeasureSpec.makeMeasureSpec(1280, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(720, View.MeasureSpec.EXACTLY))
        decor.layout(0, 0, 1280, 720)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(1))
        val web = browser(decor)!!
        assertEquals("https://cinamana.cc/watch=123/", web.url)
        assertTrue(web.settings.javaScriptEnabled)
        assertTrue(web.settings.domStorageEnabled)
        assertFalse(web.settings.mediaPlaybackRequiresUserGesture)
        assertFalse(web.settings.allowFileAccess)
        var hidden = false
        web.webChromeClient!!.onShowCustomView(View(activity), WebChromeClient.CustomViewCallback { hidden = true })
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(100))
        back!!.invoke()
        assertTrue(hidden)
        assertFalse(exited)
        back!!.invoke()
        assertTrue(exited)
        controller.pause().stop().destroy()
    }
}
