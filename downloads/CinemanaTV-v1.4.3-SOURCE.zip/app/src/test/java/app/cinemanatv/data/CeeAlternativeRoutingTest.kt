package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.lang.reflect.Proxy

class CeeAlternativeRoutingTest {
    @Test fun alternativeMetadataNeverRequestsTheOriginalProvidersEndpoints() = runBlocking {
        val api = Proxy.newProxyInstance(CinemanaApi::class.java.classLoader,
            arrayOf(CinemanaApi::class.java)) { _, method, _ ->
            throw AssertionError("Unexpected original-provider call: ${method.name}")
        } as CinemanaApi
        val repository = Repository(api)
        val alternative = Video(nb = "cee_123", enTitle = "Selected external title")
        assertSame(alternative, repository.info(alternative))
        assertSame(alternative, repository.infoOrNull(alternative))
        assertTrue(repository.episodes(alternative.id).isEmpty())
        assertTrue(repository.related(alternative.id).isEmpty())
        assertTrue(repository.loadSubtitles(alternative.id).isEmpty())
        assertFalse(CeeAlternativeSource.owns("123"))
        assertTrue(CeeAlternativeSource.owns(alternative.id))
    }
}
