package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test

class CeeAutomaticMatchTest {
    private val original = Video(nb = "123", kind = "1", enTitle = "The Matrix", year = "1999")
    private fun candidate(id: String, title: String, year: String? = null) = Video(nb = "cee_$id", enTitle = title, year = year)

    @Test fun exactTitleYearSelectsTheUniqueMatch() {
        val correct = candidate("1", "فيلم The Matrix 1999 مترجم")
        assertEquals(correct, CeeAutomaticMatch.select(original,
            listOf(candidate("2", "The Matrix Resurrections 2021"), correct)))
    }
    @Test fun missingYearOrDifferentReleaseDoesNotSwitch() {
        assertNull(CeeAutomaticMatch.select(original.copy(year = null), listOf(candidate("1", "The Matrix 1999"))))
        assertNull(CeeAutomaticMatch.select(original, listOf(candidate("1", "The Matrix 2021"))))
        assertNull(CeeAutomaticMatch.select(original, listOf(candidate("1", "The Matrix"))))
    }
    @Test fun ambiguousMatchesAreNeverChosenAutomatically() {
        val a = candidate("1", "The Matrix 1999")
        assertNull(CeeAutomaticMatch.select(original, listOf(a, a.copy(nb = "cee_2"))))
        assertEquals(a, CeeAutomaticMatch.select(original, listOf(a, a)))
    }
    @Test fun sequelsAndYearNumbersInsideTitlesArePreserved() {
        val movie = original.copy(enTitle = "Blade Runner 2049", year = "2017")
        val correct = candidate("1", "فيلم Blade Runner 2049 2017 مترجم", "2017")
        assertEquals(correct, CeeAutomaticMatch.select(movie, listOf(correct)))
        assertNull(CeeAutomaticMatch.select(original, listOf(candidate("2", "The Matrix 2 1999"))))
    }
    @Test fun exactSeasonEpisodeAndSeriesYearAreRequired() {
        val series = Video(nb = "10", enTitle = "Breaking Bad", year = "2008")
        val episode = Video(nb = "11", episodeNummer = "2", season = "1", rootSeriesInfo = series)
        val correct = candidate("1", "مسلسل Breaking Bad 2008 الموسم 1 الحلقة 2 مترجم")
        assertEquals(correct, CeeAutomaticMatch.select(episode, listOf(correct)))
        assertNull(CeeAutomaticMatch.select(episode.copy(episodeNummer = "3"), listOf(correct)))
        assertNull(CeeAutomaticMatch.select(episode.copy(season = "2"), listOf(correct)))
        assertNull(CeeAutomaticMatch.select(episode, listOf(candidate("2", "Breaking Bad 2008"))))
    }
    @Test fun alternativeTitlesAndSeriesParentsCannotLoop() {
        assertNull(CeeAutomaticMatch.select(original.copy(nb = "cee_1"), listOf(candidate("2", "The Matrix 1999"))))
        assertNull(CeeAutomaticMatch.select(original.copy(kind = "2"), listOf(candidate("2", "The Matrix 1999"))))
    }
    @Test fun movieCannotSelectAnEpisodeOrUnrelatedTitle() {
        assertNull(CeeAutomaticMatch.select(original, listOf(candidate("2", "The Matrix 1999 S01E01"))))
        assertNull(CeeAutomaticMatch.select(original, listOf(candidate("2", "The Matrix Reloaded 1999"))))
    }
}
