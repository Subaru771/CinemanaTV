package app.cinemanatv.util

import android.app.Application
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import app.cinemanatv.data.Prefs
import app.cinemanatv.data.Video

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
class CrashReportsTest {
    @Test fun confirmedPairingPersistsOnlyAlternativeIdentity() {
        val context = RuntimeEnvironment.getApplication()
        Prefs(context).rememberAlternative("original_123", Video(nb = "cee_456", enTitle = "Confirmed title", year = "2018", imdbRef = "tt1234567"))
        val saved = Prefs(context).confirmedAlternative("original_123")!!
        assertEquals("cee_456", saved.id)
        assertEquals("Confirmed title", saved.title)
        assertNull(saved.imdbRef)
        Prefs(context).rememberAlternative("bad_original", Video(nb = "original_456"))
        assertNull(Prefs(context).confirmedAlternative("bad_original"))
    }
    @Test fun savedReportRedactsStreamTokensAndHeaders() {
        val context = RuntimeEnvironment.getApplication()
        val error = IllegalStateException("Stream https://media.example/video.mp4?token=private\nAuthorization: Bearer private-key\nCookie: session=private-cookie")
        CrashReports.record(context, error)
        val report = CrashReports.last(context)!!
        assertTrue(report.contains("IllegalStateException"))
        assertTrue(report.contains("API 28"))
        assertFalse(report.contains("token=private"))
        assertFalse(report.contains("private-key"))
        assertFalse(report.contains("private-cookie"))
    }

    @Test fun fatalReportIsShownOnlyOnceButRemainsAvailableInSettings() {
        val context = RuntimeEnvironment.getApplication()
        CrashReports.record(context, IllegalArgumentException("Cannot initialize player"), pending = true)
        assertNotNull(CrashReports.consumePending(context))
        assertNull(CrashReports.consumePending(context))
        assertTrue(CrashReports.last(context)!!.contains("Cannot initialize player"))
    }
}
