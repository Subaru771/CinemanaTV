package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test
import okhttp3.HttpUrl.Companion.toHttpUrl

class CeeWebRoutesTest {
    @Test fun matchedMovieOpensItsPlayerWithoutSourceSelection() {
        assertEquals("https://cinamana.cc/watch=123/", CeeWebRoutes.title(
            Video(enTitle = "The Matrix"), Video(nb = "cee_123")))
    }
    @Test fun unmatchedTitleUsesTheWebsitesOwnSearch() {
        val url = CeeWebRoutes.title(Video(enTitle = "Movie & sequel")).toHttpUrl()
        assertEquals("cinamana.cc", url.host)
        assertEquals("Movie & sequel", url.queryParameter("s"))
        assertEquals(CeeWebRoutes.HOME, CeeWebRoutes.title(Video()))
    }
    @Test fun onlyKnownHttpsWebsiteEntryRoutesAreAccepted() {
        assertTrue(CeeWebRoutes.validStart(CeeWebRoutes.HOME))
        assertTrue(CeeWebRoutes.validStart("https://cinamana.cc/?s=movie"))
        assertTrue(CeeWebRoutes.validStart("https://cinamana.cc/watch=123/"))
        for (url in listOf("javascript:alert(1)", "file:///etc/passwd", "https://evil.example/main", "https://user@cinamana.cc/main"))
            assertFalse(url, CeeWebRoutes.validStart(url))
    }
}
