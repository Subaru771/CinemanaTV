# Build status — CinemanaTV 1.5.6

- Based on full v1.5.5 source (v1.5.4+ restored Search and refined remote navigation).
- Source changes implemented: marker lookup, status badge, local filter, tests, translation keys, version code.
- Pure Kotlin search/filter smoke check: PASS (5 checks); API model compilation smoke using stubs: PASS.
- Android compile and testDebugUnitTest: NOT RUN (Android SDK and Gradle 8.14.3 distribution not installed in this runtime).
- APK: NOT BUILT. Use `RUN-FULL-TEST.cmd` on a Windows machine with JDK 17+ and Android SDK 35.
- IMPORTANT: A badge means published scene timestamps exist for a source-listed cut. It does not mean a file is safe or completely filtered. Player still validates actual stream duration.
