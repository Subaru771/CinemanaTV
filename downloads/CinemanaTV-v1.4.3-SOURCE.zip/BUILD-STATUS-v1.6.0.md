# Build status — 1.6.0

- Android testDebugUnitTest and assembleRelease: PASS; 129 tests, no failures/errors.
- R8 optimization, resource shrinking and release packaging completed.
- APK signature verified against the previous chat builds' certificate (same key). Manifest: version 1.6.0, code 55; release is configured non-debuggable.
- APK size: 3146529 bytes.
- Source checks: Components.kt and Detail.kt contain no automatic ensureMatureSkip calls or skipStatus reads. Explicit mature-skip search and player marker loads remain.
- Removed artificial 650ms minimum startup delay. No overall launch-time multiplier measured.
- Episode decode target: 397,320 pixels → 99,120 pixels; RGB565 allowed, actual format depends on image/decoder.
- Device/TV performance and release playback not verified in this environment. ADB could not initialize its read-only home state. No real-device speed multiplier is claimed.
