# Mature-scene skipping — v1.5.7

## On your TV

1. Check Settings → About shows **1.5.7**; enable **Mature content → Skip mature scenes**.
2. Open a movie, such as Titanic, with a published CleanStream entry. Wait for its details/marker lookup.
3. Show playback controls. Under the title, expect **Mature skip active · marked scenes only** when ranges have been accepted. The ✂ count shows how many normalized ranges will be skipped.
4. Seek just before a published range and play through it. Confirm the player seeks beyond the end. Press Left to test Undo.
5. If skipping is unavailable, read the persistent line under the title or Settings → Technical details → MATURE SKIP:
   - IMDb ID missing: source metadata could not identify the movie; detail lookup retries.
   - Service unreachable: the TV cannot complete the marker request; retry occurs after 30 seconds.
   - No published markers: the sources responded but have no eligible timestamps.
   - Markers do not match this cut: timestamps/runtime do not fit this playback edition.
   - Public markers unavailable for TV episodes: the current public mature sources are movie-only; previously saved local episode ranges still work.
6. Disconnect/reconnect networking during an initial lookup. The same movie should recover without closing playback. Visible movie cards with SKIP ? also recheck while they remain visible.
7. Switch quality/cut: stale markers must be cleared and revalidated against the new duration.

For diagnostics from a connected PC:

```sh
adb logcat -s MatureSkip:D '*:S'
```

Look for `status=READY accepted=N` and `skipping title=... fromMs=... toMs=...`. The badge lists published timestamps; it cannot verify actual playback coverage. Source timestamps can be inaccurate, including imports with no edition runtime. No automatic scene detection occurs.

See BUILD-STATUS-v1.5.7.md for checks actually completed in this environment.
