# Cinemana TV v1.5.5 — search focus and settings navigation

- The top-right **Search** action and **Up from the top navigation** both open the standalone search panel. Search is not a tab.
- Prevents hidden Home, Settings, Downloads, or History controls from receiving D-pad focus while Search is open. Only one content screen is composed at once.
- The search input requests focus after its controls are composed for better remote and keyboard reliability.
- Settings category selection now follows **D-pad focus**, without requiring OK. The highlighted category and right-hand settings pane update together.
- Settings remembers the selected category when leaving and returning to the screen.
- Playback, downloads, mature-scene skipping and age restrictions are unchanged. Scene skipping still requires valid time-coded markers.

## Validation

The project still requires Android SDK 35 and Gradle 8.14.3 to build and test. Run `RUN-FULL-TEST.cmd` on Windows. No APK was generated or installed in this environment. Check real-TV focus behavior after building.
