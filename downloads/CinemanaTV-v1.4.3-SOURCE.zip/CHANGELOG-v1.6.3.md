# CinemanaTV 1.6.3 — Language-matched Telegram TV invitation

- Native red/black landscape Cinemana Hub card inspired by the provided Android reference.
- English and Arabic are now two separate designs selected automatically by **Settings > Interface language**. Never mix both languages in the same card.
- Redesigned TV-friendly layout: brandmark, Telegram icon, feature strip, prominent join and skip buttons, TV remote focus outlines, close control, and opt-out checkbox.
- **Don't show this again** is saved in local preferences; once checked, the prompt is hidden on future launches. Toggle off again while the card is open to reverse.
- An actual newer-version notification remains separate from the Telegram invitation and is not suppressed by the opt-out checkbox.
- Version 1.6.3 / code 58. The catalog, player, account, and other features are preserved.
- Build status: Android compilation not verified in this environment. The included Windows builder and GitHub Actions workflow remain available.
