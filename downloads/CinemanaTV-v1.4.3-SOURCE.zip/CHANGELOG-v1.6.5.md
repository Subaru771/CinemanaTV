# CinemanaTV v1.6.5 — TV focus highlight fix

## Actual bug fixed

- **Settings and all shared buttons** previously drew a hardcoded 3dp white focus border with `Modifier.border`, then let the TV Material Button draw its own focused appearance. On a TV the two layers produced a thick white double ring and pale selected row.
- **Telegram startup invitation** still used a separate `Modifier.border` around the underlying TV Material Button. When focused, the two shapes did not align and created nested, misaligned highlights.

## Changes

- Use exactly one built-in TV Material button focus border (subtle 1.5dp muted red), with the *same* 16/19dp rounded shape as the button.
- Remove modifier-level focus borders on both controls and disable automatic focus enlargement to keep border/background aligned.
- Keep non-primary focused buttons dark with **white text**, never pale lavender/white.
- Center Telegram popup button labels; remove the redundant sidebar arrow in Settings while retaining its existing selection bar.
- Replace remaining white focus states in top navigation tabs, poster/episode tiles, search fields and player options with dark themed focus states.
- Preserve D-pad focus navigation, first-focus behavior, English/Arabic popup selection, and update alerts.
- Version 1.6.5 / versionCode 60; app package ID unchanged.

## Verification

- Static source assertions check that the old hardcoded white borders and pale focused fills are absent from both components.
- Source ZIP validates with ZIP integrity check.
- Android APK **not compiled or tested on a real TV** in this environment (Android SDK/Gradle distribution unavailable).
- On your TV, check Settings (move between left categories and right settings) and Telegram popup (all controls); focus should be a darkened background plus one muted red outline, with no white double ring.
