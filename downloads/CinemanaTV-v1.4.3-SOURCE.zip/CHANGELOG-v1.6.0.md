# v1.6.0 — Badge removal and browsing performance

- Remove skip-status and rating overlays from posters, skip/resume overlays from episode cards, and marker-status text from detail headers.
- Remove passive marker discovery and 30-second retry loops from composed posters/detail screens. Merely browsing cards now starts no marker lookup. Explicit Search → Mature skip filtering still checks markers when requested; playback still loads published timestamps.
- Remove the artificial 650 ms minimum splash delay. Cached data can enter Home as soon as the normal readiness check sees it; cold-start network timeout remains bounded.
- Parse catalogue/details/media/subtitle JSON on Dispatchers.Default rather than the caller's UI dispatcher.
- Decode episode artwork at 420×236 rather than 840×473 for a 210dp card, with RGB565 permitted.
- Remember search rankings across focus/redraws; marker-driven updates remain available for explicit mature-skip searches.
- Deliver minified, resource-shrunk, non-debuggable release APK using the existing local test key, rather than a debug APK.

No measured TV speed multiplier is claimed. Network latency, storage and TV hardware still determine real performance. Version 1.6.0 / code 55. Published scene skipping and saved data formats remain supported.
