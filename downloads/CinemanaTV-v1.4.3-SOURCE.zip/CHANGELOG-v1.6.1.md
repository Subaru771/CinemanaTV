# Cinemana TV v1.6.1 — Telegram and Update Alerts

- Official Cinemana Hub startup invite, https://t.me/CinemanaHub, dismissible via Back/Continue.
- Remote/D-pad-friendly focused notice shown at startup after the original splash (no splash delays).
- Nonblocking HTTPS version check on cold launch and in-app update dialog only if a newer numeric versionCode is published.
- English/Arabic text; update notes support localized `notesAr` field.
- Existing catalog, player, maturity filters, and data are unchanged.
- Current application versionCode 56 (1.6.1).
- Hosting the version feed and adding its URL at build time are required to activate update notices.

**Build status:** Not compiled here: Gradle wrapper download was blocked by unavailable DNS/network; use included Windows build scripts or GitHub Actions.
