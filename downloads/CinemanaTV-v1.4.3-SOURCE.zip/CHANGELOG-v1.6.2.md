# Cinemana TV v1.6.2 — Bilingual Telegram card

- Telegram startup invitation is now one compact bilingual card. Arabic and English remain visible together, regardless of the application language setting.
- Both buttons display English and Arabic, are D-pad focusable, and work with TV remotes.
- The update check remains unchanged: alerts appear only for a genuinely newer version published in the configured HTTPS feed.
- Application versionName 1.6.2, versionCode 57.
- Original catalog, playback, and other settings are unchanged.

**Build status:** Source updated, no signed APK built in this environment (Android SDK/Gradle unavailable).
