# Build status — 1.5.9

- Android testDebugUnitTest + assembleDebug: PASS, 129 tests, zero failures/errors.
- Live generic discovery: Game of Thrones S1E1 READY/6 mature ranges; Breaking Bad S1E1 READY/5; The Matrix Reloaded READY/1.
- Actual IMDb verification and existing timestamp files used; no title-specific ID whitelist.
- New regression tests cover other-series discovery, separate movie/series candidates, exact IMDb boundaries, legacy timestamp format, and retained cut/episode checks.
- Same existing local debug signing key. No TV hardware playback or Cinemana edition alignment verified.
- Existing timestamps only. No video processing or uploads. Source coverage may be incomplete and community timestamps may be inaccurate.
