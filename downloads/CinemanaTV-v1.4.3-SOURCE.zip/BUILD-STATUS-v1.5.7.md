# Build status — Cinemana TV 1.5.7

- Full Android Gradle testDebugUnitTest and assembleDebug: PASS.
- 119 unit tests; 0 failures/errors.
- Focused standalone regression suite: 59 passed with real Gson/JUnit/coroutines.
- Installable debug APK built with SDK 35 / JDK 17 / Gradle 8.14.3.
- APK uses a new local debug key; an existing install with another key cannot update in place.
- Real TV playback and provider-specific IMDb responses not verified.
- Published markers remain incomplete; no skipping without timestamps.
