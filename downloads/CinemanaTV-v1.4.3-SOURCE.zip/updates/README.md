# Cinemana TV v1.2 automatic update feed

This application reads the shared Cloudflare manifest:

`https://cinemana-updates-e8l.pages.dev/updates.json`

Only `schema=1` and `tv.enabled=true` with a strictly greater `tv.versionCode` will trigger a notification. The original version 1.2 is Android versionCode 120. A dismissed version is remembered, but a newer one can prompt again.

Publish updates by changing the single JSON file in the `cloudflare` folder from the Cinemana Update System package. Keep both platform entries disabled until tested binaries have been uploaded.

You may override the feed through `cinemana.updateFeedUrl` in a local.properties file or Gradle property.

Keep the package ID (`app.cinemanatv`) and signing key stable. Android cannot silently install third-party APKs.
