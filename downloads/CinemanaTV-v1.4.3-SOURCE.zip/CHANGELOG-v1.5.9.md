# v1.5.9 — General published timestamp discovery

- Removed series-specific IDs and paths from production code.
- Search VideoSkip for any movie/parent series title; require the exact IMDb ID before accepting it.
- Resolve exact season/episode, preserving parent title and identity in playback queues.
- Movies retain CleanStream/MovieHaven primary lookups and use VideoSkip as a fallback.
- Both browsing badges and playback can discover published movie/episode files.
- Parse both explicit-action and legacy implicit-action skip files. Ignore audio-only mute and unrelated content categories.
- Cache a bounded number of source pages and reject out-of-bounds files. Do not combine different editions/files.
- No video uploads, video analysis, model inference, or analysis billing.

All titles are eligible for discovery, but source coverage is incomplete and community timing may not match Cinemana's cut. No skipping is possible without eligible published/saved ranges. Hardware playback is not certified by unit tests.
