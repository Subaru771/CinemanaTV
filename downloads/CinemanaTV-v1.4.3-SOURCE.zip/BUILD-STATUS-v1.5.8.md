# Build status — 1.5.8

- testDebugUnitTest + assembleDebug: PASS; 125 tests, no failures/errors.
- Live VideoSkip Game of Thrones S1E1 lookup: READY, 6 mature ranges.
- Regression tests: exact episode selection, wrong-series rejection, full-file boundary rejection, non-mature/mute exclusions, parent ID propagation, published-file-to-skip-decision.
- APK signature verified; uses existing chat build debug key.
- No TV hardware or actual Cinemana cut alignment verified. Community timestamps can miss scenes and have timing differences. Episode support limited to Game of Thrones published skip files.
