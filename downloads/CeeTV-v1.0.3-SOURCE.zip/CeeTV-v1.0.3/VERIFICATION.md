# Cee TV download fix

Confirmed cause: numberedDownloadOptions filtered out every height=0 source, including the typed extensionless HLS relay and CDNPlus HLS Auto sources. The chooser now allows adaptive sources without a numeric height, retains existing numbered MP4 options and excludes unknown-resolution direct files. UI and saved download labels no longer show 0p. Offline track selection is bounded to the configured quality limit.

Regression checks cover typed extensionless HLS, regular HLS/DASH, old MP4 filtering and a real Media3 HLS downloader/cache roundtrip using small deterministic data. Long downloads, device storage/background service execution and TV hardware playback remain device checks. Existing VK limitation is unchanged.

Build verification: 172 automated tests passed with zero failures/errors/skips, including live CEE checks and the deterministic segmented-download/cache roundtrip. Native ICU checks passed.
