# Cee TV 1.0.3

Native Android TV CEE catalogue/player app. This update adds a light green theme, Cee TV launcher name/banner and splash, and fixes missing Auto HLS/DASH options in the movie download chooser. Package remains app.cinemanatv.cee so it can update the previous app (same signing key required). Version code 4; Android 8+.

Adaptive Auto downloads use Media3 offline cache in private device storage and select a single best supported track within the saved quality limit, with a 1080p fallback. A separate MP4 remains managed by Android DownloadManager. Auto is labelled honestly, without inventing a resolution. No full film is downloaded during automated tests.

Build with JDK 17 and SDK 35: `bash gradlew testDebugUnitTest assembleRelease`. Optional live tests: `CEE_LIVE_TEST=1 bash gradlew testDebugUnitTest`.

A deterministic offline test downloads a small HLS fixture into Media3 cache and reads the segment back without upstream access. Provider availability, signed-link expiry and long TV background transfers still require device testing. VK-hosted titles remain unsupported; inherited server-slot fallback does not establish a working VK alternative. No all-network guarantee.
