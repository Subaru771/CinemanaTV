#!/usr/bin/env python3
"""Check the real provider pattern with Linux ICU, the regex family Android uses."""
import ctypes
import ctypes.util
import pathlib
import re

root = pathlib.Path(__file__).resolve().parents[1]
source = root / 'app/src/main/java/app/cinemanatv/data/CeeAlternativeSource.kt'
pattern = re.search(r'SOURCE_PATTERN\s*=\s*"""(.*?)"""', source.read_text(), re.S).group(1)
library = ctypes.util.find_library('icui18n')
if not library:
    raise SystemExit('Native ICU not installed; this check requires Linux libicui18n/libicuuc.')
version = re.search(r'\.so\.(\d+)', library).group(1)
icu = ctypes.CDLL(library)

class ParseError(ctypes.Structure):
    _fields_ = [('line', ctypes.c_int32), ('offset', ctypes.c_int32),
                ('before', ctypes.c_uint16 * 16), ('after', ctypes.c_uint16 * 16)]

open_regex = getattr(icu, 'uregex_open_' + version)
open_regex.argtypes = [ctypes.POINTER(ctypes.c_uint16), ctypes.c_int32, ctypes.c_uint32,
                       ctypes.POINTER(ParseError), ctypes.POINTER(ctypes.c_int32)]
open_regex.restype = ctypes.c_void_p
close_regex = getattr(icu, 'uregex_close_' + version)
close_regex.argtypes = [ctypes.c_void_p]
uc = ctypes.CDLL(ctypes.util.find_library('icuuc'))
error_name = getattr(uc, 'u_errorName_' + version)
error_name.argtypes = [ctypes.c_int32]
error_name.restype = ctypes.c_char_p

def compile_pattern(value):
    raw = value.encode('utf-16le')
    chars = (ctypes.c_uint16 * (len(raw) // 2)).from_buffer_copy(raw)
    status, detail = ctypes.c_int32(0), ParseError()
    pointer = open_regex(chars, len(chars), 0, ctypes.byref(detail), ctypes.byref(status))
    if pointer:
        close_regex(pointer)
    return status.value, error_name(status.value).decode(), detail.offset

assert pattern.endswith(r'\}'), 'The literal closing brace must be escaped.'
broken = compile_pattern(pattern[:-2] + '}')
fixed = compile_pattern(pattern)
assert broken[0] > 0, f'The old Android-incompatible pattern should be rejected: {broken}'
assert fixed[0] <= 0, f'The production pattern must compile with native ICU: {fixed}'
print(f'Old pattern reproduced: {broken[1]} at offset {broken[2]}')
print(f'Production pattern: {fixed[1]} (ICU {version})')

# Check other non-interpolated literal patterns used by the alternative provider.
import json
checked = 0
for kotlin in source.parent.glob('Cee*.kt'):
    for literal in re.findall(r'Regex\((?!""")("(?:[^"\\]|\\.)*")', kotlin.read_text()):
        value = json.loads(literal)
        if '${' in value:
            continue
        result = compile_pattern(value)
        assert result[0] <= 0, f'{kotlin.name}: native ICU rejected {value!r}: {result}'
        checked += 1
print(f'Other literal provider patterns accepted by native ICU: {checked}')

raw_checked = 0
for kotlin in source.parent.glob('Cee*.kt'):
    for value in re.findall(r'Regex\("""(.*?)"""', kotlin.read_text(), re.S):
        if '${' in value:
            continue
        result = compile_pattern(value)
        assert result[0] <= 0, f'{kotlin.name}: ICU rejected raw pattern: {result}'
        raw_checked += 1
print(f'Raw provider patterns accepted by native ICU: {raw_checked}')
