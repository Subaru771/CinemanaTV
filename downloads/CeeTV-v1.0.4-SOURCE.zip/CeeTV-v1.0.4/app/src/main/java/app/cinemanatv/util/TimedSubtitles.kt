package app.cinemanatv.util

/** Plain text SRT/WebVTT subtitle timeline for adjustable ± synchronization. */
data class TimedCaption(val startMs: Long, val endMs: Long, val text: String)

private val timeMark = Regex("""(\d{1,2}:)?\d{1,2}:\d{2}[.,]\d{1,3}""")

fun parseCaptionTime(raw: String): Long? {
    val parts = raw.trim().replace(',', '.').split(':')
    if (parts.size !in 2..3) return null
    val seconds = parts.last().toDoubleOrNull() ?: return null
    val minutes = parts[parts.lastIndex - 1].toLongOrNull() ?: return null
    val hours = if (parts.size == 3) parts[0].toLongOrNull() ?: return null else 0L
    if (seconds !in 0.0..<60.0 || minutes !in 0..59 || hours !in 0..99) return null
    return (hours * 3_600_000 + minutes * 60_000 + seconds * 1000).toLong()
}

fun parseTimedSubtitles(raw: String): List<TimedCaption> {
    if (raw.length > 4_000_000) return emptyList()
    val normalized = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
    val result = ArrayList<TimedCaption>()
    for (block in normalized.split(Regex("""\n[ \t]*\n+"""))) {
        val rows = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val timelineIdx = rows.indexOfFirst { "-->" in it }
        if (timelineIdx < 0 || timelineIdx >= rows.lastIndex) continue
        val markers = rows[timelineIdx].split("-->", limit = 2)
        if (markers.size != 2) continue
        val left = timeMark.find(markers[0])?.value ?: continue
        val right = timeMark.find(markers[1])?.value ?: continue
        val start = parseCaptionTime(left) ?: continue
        val end = parseCaptionTime(right) ?: continue
        if (end <= start || end - start > 60_000L) continue
        val text = rows.drop(timelineIdx + 1).filterNot { it.startsWith("NOTE ") }
            .joinToString("\n").replace(Regex("""<[^>]*>"""), "").replace("&amp;", "&")
            .replace("&lt;", "<").replace("&gt;", ">").trim()
        if (text.isNotBlank()) result.add(TimedCaption(start, end, text))
        if (result.size >= 15_000) break
    }
    return result.sortedBy { it.startMs }
}

fun activeCaptions(cues: List<TimedCaption>, mediaMs: Long, delayMs: Long): List<TimedCaption> {
    val playTime = mediaMs - delayMs
    var left = 0
    var right = cues.size
    while (left < right) {
        val mid = (left + right) ushr 1
        if (cues[mid].startMs <= playTime) left = mid + 1 else right = mid
    }
    val selected = ArrayList<TimedCaption>()
    for (i in (left - 1) downTo 0) {
        val cue = cues[i]
        if (cue.startMs < playTime - 60_000L) break
        if (playTime < cue.endMs) selected.add(cue)
    }
    return selected.asReversed()
}
