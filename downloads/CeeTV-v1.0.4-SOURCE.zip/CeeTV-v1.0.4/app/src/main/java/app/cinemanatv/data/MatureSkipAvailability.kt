package app.cinemanatv.data

import android.util.Log
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Badge/filter status describes PUBLISHED scene markers, not whether playback is safe. */
enum class MatureSkipStatus {
    UNKNOWN, CHECKING, LISTED, NOT_LISTED,
}

enum class MatureSkipFilter(val label: String) {
    ANY("Any status"),
    HAS_MARKERS("Has mature skip"),
    NO_MARKERS("No markers found"),
    UNCHECKED("Unknown / unchecked");

    fun matches(status: MatureSkipStatus): Boolean = when (this) {
        ANY -> true
        HAS_MARKERS -> status == MatureSkipStatus.LISTED
        NO_MARKERS -> status == MatureSkipStatus.NOT_LISTED
        UNCHECKED -> status == MatureSkipStatus.UNKNOWN || status == MatureSkipStatus.CHECKING
    }
}

/**
 * Listing-only check: validates community entries with each database's OWN reported release runtime.
 * This does NOT prove that the viewer's stream is the same cut. Player.kt independently validates
 * markers against the ACTUAL playback duration before it skips any scene.
 * Series are intentionally not classified: mature timestamps are currently movie-only.
 */
object MatureSkipAvailability {
    private sealed interface Fetch {
        data class Json(val body: JsonElement) : Fetch
        data object Missing : Fetch
        data object Failed : Fetch
    }

    private fun get(url: String): Fetch = try {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 8_000
        connection.readTimeout = 8_000
        connection.setRequestProperty("Accept", "application/json")
        try {
            when (connection.responseCode) {
                404, 410 -> Fetch.Missing
                in 200..299 -> connection.inputStream.use { stream ->
                    val result = ByteArrayOutputStream()
                    val chunk = ByteArray(8192)
                    while (true) {
                        val n = stream.read(chunk)
                        if (n < 0) break
                        if (result.size() + n > 256_000) return@use Fetch.Failed
                        result.write(chunk, 0, n)
                    }
                    runCatching { Fetch.Json(JsonParser.parseString(result.toString("UTF-8"))) }
                        .getOrDefault(Fetch.Failed)
                }
                else -> Fetch.Failed
            }
        } finally { connection.disconnect() }
    } catch (_: Exception) { Fetch.Failed }

    /** Uses the exact runtime embedded in the movie's marker source for initial discovery. */
    fun movieHavenStatus(json: JsonElement?, imdb: String): MatureSkipStatus {
        val body = runCatching { json?.asJsonObject }.getOrNull() ?: return MatureSkipStatus.UNKNOWN
        val sourceId = runCatching { body.get("imdb_id")?.asString }.getOrNull()
        if (ExternalSceneMarkers.imdbID(sourceId) != imdb) return MatureSkipStatus.UNKNOWN
        val runtimeSec = runCatching { body.get("duration")?.asDouble }.getOrNull()
        if (runtimeSec == null || runtimeSec !in 60.0..21_600.0) return MatureSkipStatus.UNKNOWN
        if (body.get("scenes")?.isJsonArray != true) return MatureSkipStatus.UNKNOWN
        val markers = ExternalSceneMarkers.movieHaven(json, imdb, (runtimeSec * 1_000).toLong())
        return if (markers.any { it.kind == "mature" }) MatureSkipStatus.LISTED else MatureSkipStatus.NOT_LISTED
    }

    /**
     * Badges describe published eligible timestamps, NOT verified playback coverage.
     * Legacy imports frequently have `runtime: null, releases: []`, so an empty
     * release list must not hide perfectly valid published marker rows.
     */
    fun cleanStreamStatus(json: JsonElement?, imdb: String): MatureSkipStatus {
        if (!ExternalSceneMarkers.isCleanStreamResponse(json, imdb)) return MatureSkipStatus.UNKNOWN
        if (!ExternalSceneMarkers.hasCleanStreamMatureRanges(json, imdb)) return MatureSkipStatus.NOT_LISTED
        val runtimes = ExternalSceneMarkers.cleanStreamDeclaredRuntimes(json, imdb)
        if (runtimes.isEmpty()) return MatureSkipStatus.LISTED
        return if (runtimes.any { runtime ->
                runtime in 60_000L..21_600_000L &&
                    ExternalSceneMarkers.cleanStream(json, imdb, runtime).any { it.kind == "mature" }
            }) MatureSkipStatus.LISTED else MatureSkipStatus.NOT_LISTED
    }

    /** No negative status on a timeout, invalid JSON, mismatched IMDb ID or partial failure. */
    suspend fun check(imdbInput: String?): MatureSkipStatus = coroutineScope {
        val imdb = ExternalSceneMarkers.imdbID(imdbInput) ?: return@coroutineScope MatureSkipStatus.UNKNOWN
        val haven = async(Dispatchers.IO) { get(ExternalSceneMarkers.movieHavenURL(imdb)!!) }
        val clean = async(Dispatchers.IO) { get(ExternalSceneMarkers.cleanStreamURL(imdb)!!) }
        fun movieResult(fetched: Fetch): MatureSkipStatus = when (fetched) {
            is Fetch.Json -> movieHavenStatus(fetched.body, imdb)
            Fetch.Missing -> MatureSkipStatus.NOT_LISTED
            Fetch.Failed -> MatureSkipStatus.UNKNOWN
        }
        fun cleanResult(fetched: Fetch): MatureSkipStatus = when (fetched) {
            is Fetch.Json -> cleanStreamStatus(fetched.body, imdb)
            Fetch.Missing -> MatureSkipStatus.NOT_LISTED
            Fetch.Failed -> MatureSkipStatus.UNKNOWN
        }
        val statuses = listOf(movieResult(haven.await()), cleanResult(clean.await()))
        Log.d("MatureSkip", "badge imdb=$imdb MovieHavenDB=${statuses[0]} CleanStream=${statuses[1]}")
        when {
            MatureSkipStatus.LISTED in statuses -> MatureSkipStatus.LISTED
            statuses.all { it == MatureSkipStatus.NOT_LISTED } -> MatureSkipStatus.NOT_LISTED
            else -> MatureSkipStatus.UNKNOWN
        }
    }
}
