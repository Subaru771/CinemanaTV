package app.cinemanatv.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.util.concurrent.TimeUnit

/** Non-invasive probe of a link already provided by Cinemana.
 * A 1-byte HTTP range request tests reachability without downloading a movie.
 * It never sends account tokens to third-party hosts or uses relay/proxy servers.
 */
object MediaRouteProbe {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(7, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun check(url: String): String = withContext(Dispatchers.IO) {
        val parsed = url.toHttpUrlOrNull()
            ?: return@withContext "The provider supplied an invalid stream URL."
        if (parsed.scheme != "https" && parsed.scheme != "http")
            return@withContext "Unsupported stream URL scheme."
        val host = parsed.host
        val request = Request.Builder()
            .url(parsed)
            .header("User-Agent", userAgent())
            .header("Range", "bytes=0-0")
            .header("Accept-Encoding", "identity")
            .get()
            .build()
        try {
            client.newCall(request).execute().use { response ->
                "Media host: $host\n${NetworkProbeLogic.response(response.code, response.header("Content-Type"))}"
            }
        } catch (c: CancellationException) { throw c }
          catch (e: Exception) {
            "Media host: $host\n${NetworkProbeLogic.failure(e.javaClass.simpleName)}"
          }
    }
}
