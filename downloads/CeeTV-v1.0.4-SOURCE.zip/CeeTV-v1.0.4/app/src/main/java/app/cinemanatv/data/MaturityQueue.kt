package app.cinemanatv.data

/** Select all distinct unclassified items; deliberately no arbitrary catalog-size cap. */
internal object MaturityQueue {
    fun <T> pending(
        items: List<T>,
        id: (T) -> String,
        hasMetadata: (T) -> Boolean,
        hasResolvedMetadata: (String) -> Boolean,
    ): List<T> {
        val visited = HashSet<String>()
        return items.filter { item ->
            val key = id(item)
            key.isNotBlank() && visited.add(key) &&
                !hasMetadata(item) && !hasResolvedMetadata(key)
        }
    }
}
