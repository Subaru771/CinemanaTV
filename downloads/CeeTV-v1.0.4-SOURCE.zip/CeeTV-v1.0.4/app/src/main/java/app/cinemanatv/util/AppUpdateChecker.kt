package app.cinemanatv.util

import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** A passive, HTTPS-only version check. Never downloads or silently installs an APK. */
data class AvailableAppUpdate(
    val versionCode: Long,
    val versionName: String,
    val downloadUrl: String,
    val notes: String,
    val notesArabic: String,
)

object AppUpdateChecker {
    /** Keep this testable without an Android device. */
    fun parseManifest(json: String, installedCode: Long): AvailableAppUpdate? = runCatching {
        // Shared Cloudflare v1 schema. Ignore releases for other platforms.
        val root = JsonParser.parseString(json).asJsonObject
        if (root.get("schema")?.asInt != 1) return@runCatching null
        val release = root.getAsJsonObject("tv") ?: return@runCatching null
        if (release.get("enabled")?.asBoolean != true) return@runCatching null
        val code = release.get("versionCode")?.asLong ?: return@runCatching null
        if (code <= installedCode) return@runCatching null
        val name = release.get("version")?.asString?.trim().orEmpty()
        val url = release.get("downloadUrl")?.asString?.trim().orEmpty()
        val localized = release.getAsJsonObject("notes")
        val notes = localized?.get("en")?.asString?.trim().orEmpty().take(240)
        val notesArabic = localized?.get("ar")?.asString?.trim().orEmpty().take(240)
        if (name.isEmpty() || name.length > 32 || !isSafeWebUrl(url)) return@runCatching null
        AvailableAppUpdate(code, name, url, notes, notesArabic)
    }.getOrNull()

    fun isSafeWebUrl(value: String): Boolean = runCatching {
        val url = URL(value)
        url.protocol.equals("https", ignoreCase = true) &&
            url.host.isNotBlank() && url.userInfo == null && value.length < 2048
    }.getOrDefault(false)

    /** A failed or unavailable feed is silent; no fabricated "update available" alert. */
    suspend fun check(feedUrl: String, installedCode: Long): AvailableAppUpdate? = withContext(Dispatchers.IO) {
        if (!isSafeWebUrl(feedUrl)) return@withContext null
        runCatching {
            val connection = (URL(feedUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 5_000
                readTimeout = 5_000
                instanceFollowRedirects = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Cache-Control", "no-cache")
                setRequestProperty("User-Agent", "CinemanaTV-UpdateChecker")
            }
            try {
                if (connection.responseCode != HttpURLConnection.HTTP_OK) return@runCatching null
                if (connection.contentLength > 32_768) return@runCatching null
                val output = java.io.ByteArrayOutputStream()
                connection.inputStream.use { input ->
                    val chunk = ByteArray(4096)
                    while (output.size() <= 32_768) {
                        val n = input.read(chunk)
                        if (n < 0) break
                        output.write(chunk, 0, n)
                    }
                }
                if (output.size() > 32_768) null
                else parseManifest(output.toString(Charsets.UTF_8.name()), installedCode)
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }
}
