package app.cinemanatv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.io.IOException
import java.security.MessageDigest

interface CeeCatalog {
    suspend fun home(kind: Int?): HomeData
    suspend fun search(query: String): List<Video>
    suspend fun detail(video: Video): Video
    suspend fun episodes(video: Video): List<Video>
    suspend fun related(video: Video): List<Video>
    suspend fun sources(id: String): PlaySources
    suspend fun subtitles(id: String): List<SubtitleOption> = emptyList()
}

/** HTML data adapter for the public catalogue/player route verified from CEE. No web UI. */
object CeeCatalogParser {
    private val year = Regex("\\b(?:19|20)[0-9]{2}\\b")
    private val episodePattern = Regex("(?i)(?:الحلقة|حلقة|episode|ep)\\s*[-:]?\\s*([0-9]+)|\\bS[0-9]+E([0-9]+)\\b")
    private val seasonPattern = Regex("(?i)(?:الموسم|موسم|season)\\s+([^\\s–—:]+)|\\bS([0-9]+)E[0-9]+\\b")
    private val ordinals = mapOf("الاول" to 1, "الأول" to 1, "الأولى" to 1, "الاولى" to 1, "الثاني" to 2,
        "الثالث" to 3, "الرابع" to 4, "الخامس" to 5, "السادس" to 6, "السابع" to 7, "الثامن" to 8, "التاسع" to 9, "العاشر" to 10)
    private fun digits(s: String) = s.map { if (it in '\u0660'..'\u0669') '0' + (it - '\u0660') else it }.joinToString("")
    private fun number(s: String): Int? = digits(s).trim().toIntOrNull() ?: ordinals[s.trim()]
    fun season(s: String): Int = seasonPattern.find(digits(s))?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }?.let(::number) ?: 1
    fun episode(s: String): Int = episodePattern.find(digits(s))?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }?.toIntOrNull() ?: 0
    fun seriesTitle(s: String): String {
        val markers = listOf("الموسم", "الحلقة", "حلقة", "season", "episode")
        val at = markers.map { s.indexOf(it, ignoreCase = true) }.filter { it >= 0 }.minOrNull() ?: s.length
        return s.take(at).trim(' ', '-', '–', '—', ':').removePrefix("مسلسل ").removePrefix("انمي ").removePrefix("أنمي ").trim()
    }
    private fun safeUrl(s: String?): String? = s?.toHttpUrlOrNullSafe()
    private fun String.toHttpUrlOrNullSafe(): String? = runCatching {
        val u = toHttpUrl(); if (u.scheme == "https" && u.username.isEmpty() && u.password.isEmpty()) u.toString() else null
    }.getOrNull()
    private fun poster(element: Element): String? {
        val image = element.selectFirst("img[data-src], img[src]")
        safeUrl(image?.let { it.attr("data-src").ifBlank { it.absUrl("src") } })?.let { return it }
        val style = element.selectFirst("[style*=background-image]")?.attr("style").orEmpty()
        return safeUrl(style.substringAfter("url(", "").substringBefore(')').trim(' ', '\'', '"'))
    }
    private fun card(id: String, title: String, image: String?, expectedKind: String? = null): Video {
        val ep = episode(title)
        val isSeries = expectedKind == "2" || (expectedKind != "1" && (ep > 0 || title.contains("مسلسل") || title.contains("الموسم") || title.contains("انمي") || title.contains("أنمي")))
        return Video(nb = "cee_$id", kind = if (isSeries) "2" else "1", enTitle = title,
            year = year.findAll(digits(title)).lastOrNull()?.value, imgObjUrl = image,
            season = if (isSeries && ep > 0) season(title).toString() else null,
            episodeNummer = if (isSeries && ep > 0) ep.toString() else null, providerPageId = id)
    }
    fun cards(html: String, expectedKind: String? = null): List<Video> = Jsoup.parse(html, CeeAlternativeSource.BASE)
        .select("a[href]").asSequence().filterNot { it.hasClass("cn-mega-item") }.mapNotNull { link ->
            val id = CeeAlternativeSource.pageId(link.absUrl("href")) ?: return@mapNotNull null
            val title = link.selectFirst("h2,h3")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            card(id, title, poster(link), expectedKind)
        }.distinctBy { it.id }.take(180).toList()

    fun parent(video: Video): Video {
        val name = seriesTitle(video.title)
        val key = MessageDigest.getInstance("SHA-256").digest((name.lowercase()+"|"+video.year.orEmpty()).toByteArray())
            .take(8).joinToString("") { "%02x".format(it.toInt() and 255) }
        return video.copy(nb = "cee_series_$key", kind = "2", enTitle = name, season = null,
            episodeNummer = null, rootSeries = null, rootSeriesInfo = null)
    }
    fun postId(video: Video): String = (video.providerPageId ?: video.id.removePrefix("cee_")).takeIf {
        it.length in 1..12 && it.all { c -> c in '0'..'9' }
    } ?: throw IOException("CEE title is missing its source page identity.")

    fun detail(html: String, fallback: Video): Video {
        val doc = Jsoup.parse(html, CeeAlternativeSource.BASE)
        val heading = doc.selectFirst("h1")?.text()?.takeIf { it.isNotBlank() } ?: fallback.title
        val image = safeUrl(doc.selectFirst("#watch-later-btn")?.attr("data-poster"))
            ?: safeUrl(doc.selectFirst("meta[property=og:image]")?.attr("content")) ?: fallback.poster
        val parsed = card(postId(fallback), heading, image, fallback.kind)
        val description = doc.selectFirst("[itemprop=description], .story, .StoryArea, .post-story")?.text()
            ?: doc.selectFirst("meta[property=og:description]")?.attr("content")
        val imdb = doc.select("a[href*=imdb.com/title/]").mapNotNull {
            ExternalSceneMarkers.imdbID(it.attr("href"))
        }.distinct().singleOrNull()
        val result = parsed.copy(enContent = description?.take(2000)?.takeIf { it.isNotBlank() } ?: fallback.enContent,
            imdbRef = imdb ?: fallback.imdbRef, year = parsed.year ?: fallback.year,
            categories = fallback.categories, filmRating = fallback.filmRating)
        return if (fallback.id.startsWith("cee_series_")) parent(result).copy(nb = fallback.id, enTitle = fallback.title)
        else result.copy(nb = fallback.id, rootSeries = fallback.rootSeries, rootSeriesInfo = fallback.rootSeriesInfo)
    }

    fun episodes(html: String, parent: Video): List<Video> {
        val doc = Jsoup.parse(html, CeeAlternativeSource.BASE)
        val labels = doc.select(".season-trigger[data-target]").associate { it.attr("data-target") to it.text() }
        return doc.select(".season-wrapper").flatMap { section ->
            val season = season(labels[section.id()].orEmpty())
            section.select(".episodes-grid a[href]").mapNotNull { link ->
                val id = CeeAlternativeSource.pageId(link.absUrl("href")) ?: return@mapNotNull null
                val ep = Regex("[0-9]+").find(digits(link.text()))?.value?.toIntOrNull() ?: return@mapNotNull null
                Video(nb = "cee_$id", kind = "2", enTitle = "${parent.title} · S$season E$ep",
                    imgObjUrl = parent.poster, year = parent.year, season = season.toString(), episodeNummer = ep.toString(),
                    rootSeries = parent.id, rootSeriesInfo = parent, providerPageId = id)
            }
        }.distinctBy { it.id }.sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber }))
    }
}

class CeeHtmlCatalog : CeeCatalog {
    private data class Page(val body: String, val expires: Long)
    private val pages = LinkedHashMap<String, Page>()
    private suspend fun page(url: String): String {
        synchronized(pages) { pages[url]?.takeIf { it.expires > System.currentTimeMillis() } }?.let { return it.body }
        val html = CeeAlternativeSource.document(url)
        synchronized(pages) {
            pages[url] = Page(html, System.currentTimeMillis()+120_000)
            while(pages.size>8) pages.remove(pages.keys.first())
        }
        return html
    }
    private fun url(video: Video) = "${CeeAlternativeSource.BASE}watch=${CeeCatalogParser.postId(video)}/"
    override suspend fun home(kind: Int?): HomeData = coroutineScope {
        val movies = if (kind != 2) async { CeeCatalogParser.cards(page("${CeeAlternativeSource.BASE}movies/"), "1") } else null
        val episodes = if (kind != 1) async { CeeCatalogParser.cards(page("${CeeAlternativeSource.BASE}series/"), "2") } else null
        val films = movies?.await().orEmpty()
        val recent = episodes?.await().orEmpty()
        val series = recent.map(CeeCatalogParser::parent).distinctBy { it.id }
        val rows = buildList {
            if (films.isNotEmpty()) add(ContentRow("Latest movies", films))
            if (series.isNotEmpty()) add(ContentRow("Series", series))
            if (recent.isNotEmpty()) add(ContentRow("Latest episodes", recent))
        }
        if (rows.isEmpty()) throw IOException("CEE did not return recognizable catalogue titles.")
        HomeData((films.ifEmpty { series }).take(6), rows)
    }
    override suspend fun search(query: String): List<Video> {
        val address = CeeAlternativeSource.BASE.toHttpUrl().newBuilder().addQueryParameter("s", query.trim().take(250)).build().toString()
        return CeeCatalogParser.cards(page(address)).map { if(it.kind=="2") CeeCatalogParser.parent(it) else it }.distinctBy { it.id }
    }
    override suspend fun detail(video: Video): Video = withContext(Dispatchers.IO) { CeeCatalogParser.detail(page(url(video)), video) }
    override suspend fun episodes(video: Video): List<Video> = withContext(Dispatchers.IO) {
        if (video.kind=="1") return@withContext emptyList()
        val body = page(url(video))
        val parent = if(video.id.startsWith("cee_series_")) video else CeeCatalogParser.parent(CeeCatalogParser.detail(body,video))
        CeeCatalogParser.episodes(body,parent)
    }
    override suspend fun related(video: Video): List<Video> = CeeCatalogParser.cards(page(url(video)))
        .filter { it.id != video.id }.map { if(it.kind=="2") CeeCatalogParser.parent(it) else it }.distinctBy { it.id }.take(24)
    override suspend fun sources(id: String): PlaySources {
        if(id.startsWith("cee_series_")) throw IOException("Choose an episode from this series.")
        return CeeAlternativeSource.resolve(id)
    }
}
