package app.cinemanatv.data

/** The new app identifies itself; it does not use the Shabakaty client identity. */
fun userAgent(): String = "CinemanaCEE-TV/1.0"
