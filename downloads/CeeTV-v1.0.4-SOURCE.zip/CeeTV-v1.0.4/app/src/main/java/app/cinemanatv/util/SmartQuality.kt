package app.cinemanatv.util

/**
 * Conservative mapping from an observed throughput estimate to a provider supplied resolution.
 * This policy never manufactures a stream URL/quality and only considers entries returned by the
 * provider. Use Media3's adaptive track selection instead for a single HLS/DASH playlist.
 */
object SmartQuality {
    data class Option(val height: Int, val adaptive: Boolean = false)

    private fun requiredMbps(height: Int): Double = when {
        height >= 2160 -> 19.0
        height >= 1440 -> 12.0
        height >= 1080 -> 7.0
        height >= 720 -> 3.8
        height >= 480 -> 2.0
        else -> 0.8
    }

    fun choose(options: List<Option>, availableMbps: Double, maxHeight: Int): Int {
        if (options.isEmpty()) return -1
        val supported = options.indices.filter { i ->
            val height = options[i].height
            height == 0 || height <= maxHeight
        }.ifEmpty { options.indices.toList() }
        // No reliable estimate yet: begin at 720p or lower, then measure during playback.
        val budget = if (availableMbps.isFinite() && availableMbps > 0.0)
            availableMbps * 0.70 else 4.0
        return supported.filter { requiredMbps(options[it].height) <= budget }
            .maxWithOrNull(compareBy<Int> { options[it].height })
            ?: supported.minBy { options[it].height }
    }

    /**
     * A user-selected playback resolution is a preference, not an ABR speed estimate.
     * Pick the highest provider-confirmed rendition at/below the requested height;
     * when none exists, choose the lowest confirmed rendition above it. An unknown
     * resolution is only selected when no provider-confirmed numeric choice exists.
     * Adaptive playlists are constrained separately by Media3's max-video-height.
     */
    fun preferredIndex(options: List<Option>, preferredHeight: Int): Int {
        if (options.isEmpty() || preferredHeight <= 0) return -1
        val confirmed = options.indices.filter { options[it].height > 0 }
        if (confirmed.isEmpty()) return options.indices.first()
        val withinLimit = confirmed.filter { options[it].height <= preferredHeight }
        return if (withinLimit.isNotEmpty())
            withinLimit.maxBy { options[it].height }
        else confirmed.minBy { options[it].height }
    }

    /** Switch at most one provider rung per evaluation to avoid rapid stream restarts. */
    fun nextIndex(current: Int, preferred: Int, options: List<Option>): Int {
        if (current !in options.indices || preferred !in options.indices) return current
        if (current == preferred) return current
        val candidates = options.indices.sortedBy { options[it].height }
        val cur = candidates.indexOf(current)
        val dst = candidates.indexOf(preferred)
        return candidates[(cur + if (dst > cur) 1 else -1).coerceIn(0, candidates.lastIndex)]
    }
}
