package app.cinemanatv.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import app.cinemanatv.R
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

private val MarkLight = Color(0xFFD3FF9D)
private val MarkDark = Color(0xFF85CB43)

/**
 * The Cinemana mark: an open "C" ring wrapped around a play triangle.
 * Same geometry as the launcher icon (108-unit grid), so the app icon, the system splash
 * and this screen all read as one continuous brand.
 *
 * [ring] 0..1 draws the ring in; [play] 0..1 fades/scales the triangle in.
 */
@Composable
fun CinemanaMark(size: Dp, modifier: Modifier = Modifier, ring: Float = 1f, play: Float = 1f) {
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 108f
        val brush = Brush.linearGradient(
            listOf(MarkLight, MarkDark),
            start = Offset(32f * k, 32f * k), end = Offset(78f * k, 78f * k),
        )
        // Ring: starts at the lower right and sweeps clockwise round to the upper right.
        val r = 22f * k
        val c = Offset(54f * k, 54f * k)
        drawArc(
            brush = brush, startAngle = 40f, sweepAngle = 280f * ring.coerceIn(0f, 1f), useCenter = false,
            topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2),
            style = Stroke(width = 9f * k, cap = StrokeCap.Round),
        )
        // Play triangle, scaled about its centre.
        val p = play.coerceIn(0f, 1f)
        if (p > 0f) {
            val cx = 54f; val cy = 54f
            fun pt(x: Float, y: Float) = Offset((cx + (x - cx) * (0.6f + 0.4f * p)) * k, (cy + (y - cy) * (0.6f + 0.4f * p)) * k)
            val tri = Path().apply {
                val a = pt(48f, 43f); val b = pt(48f, 65f); val d = pt(66f, 54f)
                moveTo(a.x, a.y); lineTo(b.x, b.y); lineTo(d.x, d.y); close()
            }
            drawPath(tri, brush, alpha = p, style = Fill)
            drawPath(tri, brush, alpha = p, style = Stroke(width = 3f * k, join = StrokeJoin.Round))
        }
    }
}

/**
 * Cinematic startup, matching the TV tile and adaptive launcher icon.
 * The actual duration is controlled ONLY by AppRoot's initialCatalogReady flag.
 * This composition never delays entry and can be dropped immediately on a fast connection.
 * Our live indicator overlays the baked-in preview loader (so Arabic is localized).
 */
@Composable
fun CinemaStartup() {
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        reveal.animateTo(1f, tween(durationMillis = 300, easing = FastOutSlowInEasing))
    }
    val transition = rememberInfiniteTransition(label = "cinemana-startup")
    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1150, easing = LinearEasing)),
        label = "loader-rotation",
    )
    val glow by transition.animateFloat(
        initialValue = 0.68f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1150), repeatMode = RepeatMode.Reverse),
        label = "loader-glow",
    )
    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF08070D)),
        contentAlignment = Alignment.Center,
    ) {
        Column(Modifier.align(Alignment.Center).alpha(reveal.value), horizontalAlignment = Alignment.CenterHorizontally) {
            CinemanaMark(160.dp)
            Text("Cee TV", fontSize = 42.sp, fontWeight = FontWeight.Bold, color = C.Accent)
        }
        // The source preview includes a decorative static loading glyph.
        // A dark glass panel covers it with a genuinely animated, locale-aware indicator.
        Column(
            modifier = Modifier.align(Alignment.BottomCenter)
                .padding(bottom = 38.dp)
                .width(216.dp)
                .height(114.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xF6140712), Color(0xF90E0710)),
                    ),
                )
                .padding(vertical = 15.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Canvas(modifier = Modifier.size(39.dp)) {
                drawCircle(Color(0xFF355A2A), style = Stroke(width = 4.dp.toPx()))
                drawArc(
                    color = Color(0xFFB5F36D).copy(alpha = glow),
                    startAngle = rotation,
                    sweepAngle = 248f,
                    useCenter = false,
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                t("Loading…"),
                color = Color(0xFFEFE8ED),
                fontWeight = FontWeight.Medium,
                fontSize = 14.sp,
            )
        }
    }
}
