package app.cinemanatv.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.Video
import app.cinemanatv.data.supportsPublicMatureMarkers
import app.cinemanatv.data.ContentFilterMode
import app.cinemanatv.data.MediaContentFilter
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import app.cinemanatv.util.Downloads
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DetailScreen(
    video: Video,
    queue: List<Video>? = null,
    queueIndex: Int = 0,
    contentMode: ContentFilterMode = ContentFilterMode.OFF,
    vm: AppViewModel? = null,
    onPlay: (queue: List<Video>, index: Int) -> Unit,
    onOpen: (Video) -> Unit,
    onOpenEpisode: (queue: List<Video>, index: Int) -> Unit = { q, i -> onPlay(q, i) },
) {
    // One episode picked from a series page: show its own page, but play on through the season.
    val episodeMode = queue != null || video.episodeNumber > 0
    val repo = Services.repo
    val prefs = Services.prefs
    var info by remember(video.id) { mutableStateOf(video) }
    var episodes by remember(video.id) { mutableStateOf<List<Video>>(emptyList()) }
    var detailError by remember(video.id) { mutableStateOf<String?>(null) }
    var related by remember(video.id) { mutableStateOf<List<Video>>(emptyList()) }
    var inMyList by remember(video.id) { mutableStateOf(prefs.isWatchlisted(video.id)) }
    val playFocus = remember { FocusRequester() }
    val context = LocalContext.current
    val backgroundRequest = remember(context, info.backdrop) {
        ImageRequest.Builder(context).data(info.backdrop).size(1280, 720).crossfade(false).build()
    }

    LaunchedEffect(video.id) {
        coroutineScope {
            launch { info = repo.info(video) }
            if (queue == null) launch {
                try { episodes = repo.episodes(video.id) }
                catch (c: kotlinx.coroutines.CancellationException) { throw c }
                catch (_: Exception) { detailError = "CEE episode list could not be loaded. Go back and reopen this title to retry." }
            }
            launch {
                val list = try { repo.related(video.id).filter { it.id != video.id } }
                catch (c: kotlinx.coroutines.CancellationException) { throw c }
                catch (_: Exception) { emptyList() }
                // Related cards carry no certificate or tags: look each one up before showing it,
                // otherwise mature titles leak in through "More like this".
                related = if (contentMode == ContentFilterMode.OFF) list else coroutineScope {
                    list.take(30).map { r ->
                        async {
                            if (r.filmRating != null || r.categories != null || r.adult != null) r
                            else repo.infoOrNull(r)
                        }
                    }.awaitAll().filterNotNull()
                }
            }
        }
    }
    LaunchedEffect(video.id) { runCatching { playFocus.requestFocus() } }

    // Episodes often omit the parent series' age certification: inherit it for both
    // filtering and the queue handed to the player (including Auto Next).
    val visibleEpisodes = remember(episodes, info, contentMode) {
        MediaContentFilter.visible(episodes.map { MediaContentFilter.withParentRating(it, if (episodeMode) it.rootSeriesInfo ?: info else info) }, contentMode)
    }
    val visibleRelated = remember(related, contentMode) { MediaContentFilter.visible(related, contentMode) }
    if (!MediaContentFilter.allowed(info, contentMode)) {
        Column(Modifier.fillMaxSize().padding(48.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(t("Hidden by content settings"), fontSize = 25.sp, color = C.Dim)
            Text(t("This title's metadata does not meet your current content filter."), color = C.Dim)
        }
        return
    }

    if (!episodeMode && episodes.isNotEmpty() && visibleEpisodes.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(48.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(t("No episodes match your content filter."), fontSize = 25.sp, color = C.Dim)
            Text(t("Change the content filter in Settings to see other episodes."), color = C.Dim)
        }
        return
    }

    val seasons = remember(visibleEpisodes) { visibleEpisodes.map { it.seasonNumber }.distinct().sorted() }
    var season by remember(visibleEpisodes) { mutableIntStateOf(seasons.firstOrNull() ?: 1) }
    val seasonEpisodes = remember(visibleEpisodes, season) { visibleEpisodes.filter { it.seasonNumber == season } }
    val isSeries = !episodeMode && visibleEpisodes.isNotEmpty()

    // Which episode "Play" should start: last one with saved progress, else the first.
    val resumeIdx = remember(visibleEpisodes) { visibleEpisodes.indexOfLast { prefs.resume(it.id) > 10_000 } }
    val playLabel = when {
        isSeries && resumeIdx >= 0 -> "Resume S${visibleEpisodes[resumeIdx].seasonNumber}:E${visibleEpisodes[resumeIdx].episodeNumber}"
        !isSeries && prefs.resume(video.id) > 10_000 -> "Resume"
        else -> "Play"
    }

    // Resolve the stream list while the user reads the synopsis, so pressing Play starts
    // from a warm result. Only fires if they actually linger, and URLs are single-use / short-lived.
    val playTargetId = if (isSeries) visibleEpisodes[if (resumeIdx >= 0) resumeIdx else 0].id else video.id // episodeMode: video is the episode
    val canPrefetch = isSeries || episodeMode || info.kind != "2"
    LaunchedEffect(playTargetId, canPrefetch) {
        if (!canPrefetch) return@LaunchedEffect
        delay(700L)
        if (Downloads.local(context, playTargetId) == null) repo.prefetchSources(playTargetId)
    }

    Box(Modifier.fillMaxSize()) {
        AsyncImage(
            model = backgroundRequest,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = Modifier.align(Alignment.TopEnd).fillMaxWidth(0.6f).fillMaxHeight(0.8f),
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0.22f to C.Bg, 0.68f to Color(0xF00B0E15), 1f to Color(0x440B0E15))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.5f to Color.Transparent, 0.85f to C.Bg)))

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 44.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            item {
                Column(Modifier.padding(horizontal = 48.dp).fillMaxWidth(0.5f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (episodeMode && LocalInterfaceLanguage.current == "ar") "الموسم ${video.seasonNumber}  ·  الحلقة ${video.episodeNumber}"
                        else if (episodeMode) "SEASON ${video.seasonNumber}  ·  EPISODE ${video.episodeNumber}"
                        else t("NOW SHOWING"),
                        fontSize = 11.sp, color = C.Accent, fontWeight = FontWeight.Bold,
                    )
                    Text(info.title, fontSize = 38.sp, fontWeight = FontWeight.Bold, lineHeight = 43.sp)
                    val meta = listOfNotNull(info.rating, info.year, info.filmRating, info.duration?.takeIf { it.isNotBlank() && !isSeries })
                        .plus(info.genres.take(3)).joinToString("  •  ")
                    if (meta.isNotBlank()) Text(meta, fontSize = 14.sp, color = C.Dim)
                    Text(info.description, fontSize = 14.sp, color = Color(0xFFDDDDDD), maxLines = 5, overflow = TextOverflow.Ellipsis)
                    detailError?.let { Text(it, fontSize = 13.sp, color = C.Dim) }
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppButton(
                            playLabel, Modifier.focusRequester(playFocus), icon = Icons.Filled.PlayArrow, primary = true,
                        ) {
                            when {
                                episodeMode -> {
                                    val playQueue = queue ?: visibleEpisodes.ifEmpty { listOf(info) }
                                    val at = if (queue != null) queueIndex else playQueue.indexOfFirst { it.id == video.id }.coerceAtLeast(0)
                                    onPlay(playQueue, at)
                                }
                                isSeries -> onPlay(visibleEpisodes, if (resumeIdx >= 0) resumeIdx else 0)
                                else -> onPlay(listOf(info), 0)
                            }
                        }
                        // Series: download the episode that "Play" would start.
                        val dl = when {
                            episodeMode -> video
                            isSeries -> visibleEpisodes[if (resumeIdx >= 0) resumeIdx else 0]
                            else -> info
                        }
                        AppButton(if (inMyList) "✓ " + t("In My List") else "+ " + t("Add to My List")) {
                            inMyList = prefs.toggleWatchlist(if (episodeMode) video else info)
                        }
                        DownloadButton(dl, tag = if (isSeries || episodeMode) " S${dl.seasonNumber}:E${dl.episodeNumber}" else "")
                    }

                }
            }

            if (isSeries) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (seasons.size > 1) {
                            LazyRow(contentPadding = PaddingValues(horizontal = 48.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                itemsIndexed(seasons) { _, s ->
                                    AppButton("Season $s", primary = s == season) { season = s }
                                }
                            }
                        } else {
                            Text(t("Episodes"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 48.dp))
                        }
                        LazyRow(contentPadding = PaddingValues(horizontal = 48.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            itemsIndexed(seasonEpisodes) { i, ep ->
                                EpisodeCard(ep, vm) { onOpenEpisode(seasonEpisodes, i) }
                            }
                        }
                    }
                }
            }

            if (visibleRelated.isNotEmpty()) {
                item {
                    Column {
                        Text(t("More Like This"), fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 48.dp, bottom = 8.dp))
                        LazyRow(contentPadding = PaddingValues(horizontal = 48.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            itemsIndexed(visibleRelated) { _, v -> PosterCard(v, vm = vm, onClick = { onOpen(v) }) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeCard(ep: Video, vm: AppViewModel?, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val ctx = LocalContext.current
    val artwork = ep.episodeArtwork
    val thumbRequest = remember(ctx, artwork) {
        ImageRequest.Builder(ctx)
            .data(artwork)
            // Match the 210dp TV card at 2x density; avoid decoding 4x unused pixels.
            .size(420, 236)
            .allowRgb565(true)
            .crossfade(false)
            .build()
    }
    Column(Modifier.width(210.dp)) {
        Surface(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
            shape = ClickableSurfaceDefaults.shape(shape),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.08f),
            border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(1.5.dp, Color(0xFFB5F36D)), shape = shape)),
            colors = ClickableSurfaceDefaults.colors(containerColor = C.Panel),
        ) {
            Box {
                AsyncImage(model = thumbRequest, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())

            }
        }
        Text(
            t("E${ep.episodeNumber}  ${ep.title}"), fontSize = 13.sp, color = C.Dim, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp),
        )
        Spacer(Modifier.height(5.dp))
        DownloadButton(ep, modifier = Modifier.fillMaxWidth(), compact = true)
    }
}
