package app.cinemanatv.data

/** Applies the metadata rule consistently to catalog cards, lists and playback navigation. */
object MediaContentFilter {
    private fun adult(video: Video?): Boolean {
        val flag = video?.adult?.takeIf { it.isJsonPrimitive }?.asString?.trim()?.lowercase()
        return flag in setOf("true", "1", "yes", "y")
    }

    fun allowed(video: Video, mode: ContentFilterMode, parent: Video? = null): Boolean {
        val inherited = parent ?: video.rootSeriesInfo
        return ContentMaturity.allowed(
            video.filmRating, video.allTags, adult(video), mode,
            inherited?.filmRating, inherited?.allTags.orEmpty(), adult(inherited)
        )
    }

    fun visible(items: List<Video>, mode: ContentFilterMode, parent: Video? = null): List<Video> =
        if (mode == ContentFilterMode.OFF) items else items.filter { allowed(it, mode, parent) }

    /** Preserve the parent rating on an episode so subsequent player navigation remains filtered. */
    fun withParentRating(video: Video, parent: Video): Video = video.copy(
        filmRating = video.filmRating ?: parent.filmRating,
        categories = video.categories ?: parent.categories,
        adult = video.adult ?: parent.adult,
        rootSeriesInfo = video.rootSeriesInfo ?: parent,
        rootSeries = video.rootSeries?.takeIf { it.isNotBlank() && it != "0" } ?: parent.id,
    )
}
