package app.cinemanatv.data

import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import java.net.URI

/** Pure parsing helpers; do not silently mistake an unknown response envelope for an empty catalog. */
object Payloads {
    private val gson = Gson()
    private val listKeys = listOf("data", "result", "results", "items", "videos", "video", "movies", "films", "banner", "banners", "rows", "content", "list", "episodes", "season", "files", "qualities", "transcodedFiles", "transcoddedFiles")
    private fun text(o: JsonObject, vararg keys: String): String? = keys.firstNotNullOfOrNull { key ->
        o.get(key)?.takeIf { it.isJsonPrimitive }?.asString?.trim()?.takeIf(String::isNotEmpty)
    }
    private fun validUrl(raw: String?): String? = raw?.takeIf { input ->
        runCatching { val u = URI(input); (u.scheme == "https" || u.scheme == "http") && !u.host.isNullOrBlank() }.getOrDefault(false)
    }
    private val imageExt = Regex("\\.(jpe?g|png|webp|gif|bmp|svg)$", RegexOption.IGNORE_CASE)
    private val qualityKey = Regex("^(\\d{3,4}p?|\\d{3,4}x\\d{3,4}|[24]k|uhd|fhd|hd|sd)$", RegexOption.IGNORE_CASE)
    private val imdbKeys = listOf("imdbUrlRef", "imdbID", "imdbId", "imdb_id", "imdbURL", "imdbLink", "imdbUrl", "imdb_url", "imdb")
    private fun parseMetadata(obj: JsonObject): Video? = runCatching {
        // Some responses contain both an IMDb URL and an `imdb` numeric score. Do not let
        // a later empty/invalid alias overwrite the actual identifier during Gson parsing.
        val reference = imdbKeys.firstNotNullOfOrNull { key ->
            obj.get(key)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }
                ?.asString?.let(ImdbReferenceAdapter::reference)
        }
        val normalized = JsonObject()
        obj.entrySet().forEach { (key, value) -> if (key !in imdbKeys) normalized.add(key, value) }
        if (reference != null) normalized.addProperty("imdbUrlRef", reference)
        gson.fromJson(normalized, Video::class.java)
    }.getOrNull()
    /** A playable URL: valid http(s) and not a poster/thumbnail. */
    private fun videoUrl(raw: String?): String? = validUrl(raw)?.takeIf { !imageExt.containsMatchIn(it.substringBefore('?').substringBefore('#')) }
    private fun parseVideo(element: JsonElement): Video? = runCatching {
        if (!element.isJsonObject) return@runCatching null
        val video = parseMetadata(element.asJsonObject) ?: return@runCatching null
        video.takeIf { it.id.isNotBlank() && it.title.isNotBlank() }
    }.getOrNull()

    /** Bound depth prevents accidental recursive traversal of large or cyclic-looking envelopes. */
    fun videos(root: JsonElement?, maxItems: Int = 120): List<Video> {
        if (root == null || root.isJsonNull) return emptyList()
        val results = LinkedHashMap<String, Video>()
        fun visit(e: JsonElement, depth: Int) {
            if (depth > 5 || results.size >= maxItems) return
            when {
                e.isJsonArray -> e.asJsonArray.forEach { visit(it, depth + 1) }
                e.isJsonObject -> {
                    val o = e.asJsonObject
                    parseVideo(e)?.let { results.putIfAbsent(it.id, it) }
                    listKeys.forEach { k -> o.get(k)?.let { visit(it, depth + 1) } }
                }
            }
        }
        visit(root, 0)
        return results.values.toList()
    }

    private val certKey = Regex("(?i)^(film_?rating|content_?rating|age_?rating|certification|certificate|parental_?rating|mpaa(_?rating)?|age_?limit|min_?age|minimum_?age|age_?restriction|restriction)$")
    private val adultKey = Regex("(?i)^(is_?adult|adult|adult_?content|explicit|is_?explicit|mature|is_?mature|isForAdults|for_?adults)$")
    private val truthy = setOf("true", "1", "yes", "y")

    /** Certificate / adult flag found anywhere in the raw detail record (bounded depth). */
    internal fun maturitySignals(root: JsonElement?): Pair<String?, JsonElement?> {
        var cert: String? = null
        var adult: JsonElement? = null
        fun visit(e: JsonElement, depth: Int) {
            if (depth > 3) return
            when {
                e.isJsonArray -> e.asJsonArray.take(4).forEach { visit(it, depth + 1) }
                e.isJsonObject -> e.asJsonObject.entrySet().forEach { (k, v) ->
                    if (v.isJsonPrimitive) {
                        val text = v.asString.trim()
                        if (cert == null && certKey.matches(k) && text.isNotEmpty()) cert = text
                        if (adultKey.matches(k) && text.lowercase() in truthy) adult = v
                    } else if (k != "categories" && k != "genres") visit(v, depth + 1)
                }
            }
        }
        root?.let { visit(it, 0) }
        return cert to adult
    }

    private data class DetailRecord(val json: JsonObject, val video: Video)

    /** Details can omit the catalogue's ID/title. Never borrow metadata from another title. */
    private fun detailRecord(root: JsonElement?, fallback: Video): DetailRecord? {
        val matching = mutableListOf<DetailRecord>()
        val partial = mutableListOf<DetailRecord>()
        val envelopes = listOf("data", "result", "results", "items", "video", "videos", "movie", "movies", "film", "films", "content", "list")
        val knownTitles = listOfNotNull(fallback.enTitle, fallback.arTitle)
            .map { it.trim().lowercase() }.filter(String::isNotEmpty)
        fun visit(element: JsonElement, depth: Int, allowPartial: Boolean) {
            if (depth > 5) return
            when {
                element.isJsonArray -> element.asJsonArray.take(120).forEach {
                    // Multiple anonymous records cannot be reliably tied to the requested title.
                    visit(it, depth + 1, allowPartial && element.asJsonArray.size() == 1)
                }
                element.isJsonObject -> {
                    val obj = element.asJsonObject
                    val id = text(obj, "nb", "id", "videoId", "video_id")
                    if (id != null && id != fallback.id) return
                    val video = parseMetadata(obj)
                    val hasMaturityField = obj.entrySet().any { certKey.matches(it.key) || adultKey.matches(it.key) }
                    if (video != null && (video.copy(nb = null) != Video() || hasMaturityField)) {
                        val record = DetailRecord(obj, video)
                        if (id != null && id == fallback.id) matching.add(record)
                        else if (allowPartial && (video.title.isBlank() || knownTitles.isEmpty() ||
                                video.title.trim().lowercase() in knownTitles)) partial.add(record)
                    }
                    // Only response envelopes, not related/recommended items or arbitrary children.
                    envelopes.forEach { key -> obj.get(key)?.let { visit(it, depth + 1, allowPartial) } }
                }
            }
        }
        root?.let { visit(it, 0, true) }
        return matching.firstOrNull() ?: partial.singleOrNull()
    }

    fun detail(root: JsonElement?, fallback: Video): Video {
        val record = detailRecord(root, fallback) ?: return fallback
        val found = record.video
        val (cert, adult) = maturitySignals(record.json)
        fun keep(value: String?, previous: String?): String? = value?.takeIf(String::isNotBlank) ?: previous
        fun keepJson(value: JsonElement?, previous: JsonElement?): JsonElement? =
            value?.takeUnless { it.isJsonNull } ?: previous
        // Detail records are often partial; enriching an IMDb ID must retain existing card data.
        return fallback.copy(
            nb = keep(found.nb, fallback.nb),
            kind = keep(found.kind, fallback.kind),
            enTitle = keep(found.enTitle, fallback.enTitle),
            arTitle = keep(found.arTitle, fallback.arTitle),
            enContent = keep(found.enContent, fallback.enContent),
            arContent = keep(found.arContent, fallback.arContent),
            stars = keep(found.stars, fallback.stars),
            year = keep(found.year, fallback.year),
            duration = keep(found.duration, fallback.duration),
            img = keep(found.img, fallback.img),
            imgObjUrl = keep(found.imgObjUrl, fallback.imgObjUrl),
            imgThumbObjUrl = keep(found.imgThumbObjUrl, fallback.imgThumbObjUrl),
            imgMediumThumbObjUrl = keep(found.imgMediumThumbObjUrl, fallback.imgMediumThumbObjUrl),
            season = keep(found.season, fallback.season),
            episodeNummer = keep(found.episodeNummer, fallback.episodeNummer),
            rootSeries = keep(found.rootSeries, fallback.rootSeries),
            imdbRef = keep(found.imdbRef, fallback.imdbRef),
            filmRating = keep(found.filmRating, cert ?: fallback.filmRating),
            adult = keepJson(found.adult, adult ?: fallback.adult),
            rootSeriesInfo = found.rootSeriesInfo ?: fallback.rootSeriesInfo,
            introStart = keep(found.introStart, fallback.introStart),
            introEnd = keep(found.introEnd, fallback.introEnd),
            introStartMs = found.introStartMs ?: fallback.introStartMs,
            introEndMs = found.introEndMs ?: fallback.introEndMs,
            categories = keepJson(found.categories, fallback.categories),
        )
    }

    private fun qualityHeight(label: String): Int {
        val s = label.lowercase()
        return when {
            "2160" in s || "4k" in s || "uhd" in s -> 2160
            "1440" in s || "2k" in s -> 1440
            "1080" in s || "fhd" in s -> 1080
            "720" in s || s.trim() == "hd" -> 720
            "480" in s || s.trim() == "sd" -> 480
            else -> Regex("(\\d{3,4})").find(s)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        }
    }

    fun sources(root: JsonElement?): List<QualityOption> {
        val found = LinkedHashMap<String, QualityOption>()
        fun visit(e: JsonElement, depth: Int, inherited: String = "") {
            if (depth > 5 || found.size >= 35) return
            when {
                e.isJsonArray -> e.asJsonArray.forEach { visit(it, depth + 1, inherited) }
                e.isJsonObject -> {
                    val o = e.asJsonObject
                    val name = text(o, "resolution", "quality", "height", "name", "label", "videoQuality") ?: inherited
                    val url = videoUrl(text(o, "videoUrl", "videoURL", "url", "file", "path", "src", "link", "videoFileUrl"))
                    if (url != null) found.putIfAbsent(url, QualityOption(qualityHeight(name), url))
                    // Supports maps such as { "2160p": "https://...", "1080p": "https://..." }.
                    o.entrySet().forEach { (key, value) ->
                        if (value.isJsonPrimitive && value.asJsonPrimitive.isString && qualityKey.matches(key.trim())) {
                            videoUrl(value.asString)?.let { found.putIfAbsent(it, QualityOption(qualityHeight(key), it)) }
                        }
                    }
                    // Nested objects in the reference app include videoFile/transcodedFiles.
                    listOf("data", "results", "items", "files", "qualities", "videoFile", "videoFiles", "transcodedFiles", "transcoddedFiles", "video", "sources", "streams").forEach {
                        key -> o.get(key)?.let { visit(it, depth + 1, name) }
                    }
                }
                e.isJsonPrimitive && e.asJsonPrimitive.isString -> {
                    videoUrl(e.asString)?.let { found.putIfAbsent(it, QualityOption(qualityHeight(inherited), it)) }
                }
            }
        }
        root?.let { visit(it, 0) }
        return found.values.sortedByDescending { it.height }
    }

    fun subtitles(root: JsonElement?): List<SubtitleOption> {
        val found = LinkedHashMap<String, SubtitleOption>()
        fun add(label: String, url: String?) {
            val safe = validUrl(url) ?: return
            val mime = if (safe.substringBefore('?').lowercase().endsWith(".vtt")) "text/vtt" else "application/x-subrip"
            found.putIfAbsent(safe, SubtitleOption(label, safe, mime))
        }
        fun visit(e: JsonElement, depth: Int) {
            if (depth > 4) return
            when {
                e.isJsonArray -> e.asJsonArray.forEach { visit(it, depth + 1) }
                e.isJsonObject -> {
                    val o = e.asJsonObject
                    add("English", text(o, "enTranslationFilePath", "englishSubtitle"))
                    add("العربية", text(o, "arTranslationFilePath", "arabicSubtitle"))
                    add(text(o, "name", "lang", "language", "label") ?: "Subtitle", text(o, "file", "url", "path"))
                    listOf("data", "result", "translations", "translationFiles", "subtitles", "items", "files").forEach { k -> o.get(k)?.let { visit(it, depth + 1) } }
                }
            }
        }
        root?.let { visit(it, 0) }
        val used = mutableMapOf<String, Int>()
        return found.values.map { item ->
            val occurrence = (used[item.label] ?: 0) + 1
            used[item.label] = occurrence
            if (occurrence == 1) item else item.copy(label = "${item.label} $occurrence")
        }
    }
}
