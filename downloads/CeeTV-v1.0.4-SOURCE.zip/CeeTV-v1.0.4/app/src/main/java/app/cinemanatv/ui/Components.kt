package app.cinemanatv.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import app.cinemanatv.data.QualityOption
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import app.cinemanatv.util.Downloads
import app.cinemanatv.util.rememberDownloadStatus
import kotlinx.coroutines.launch
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.tv.material3.Border
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Icon
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.Video
import kotlinx.coroutines.delay
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppButton(
    text: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    primary: Boolean = false,
    showFocusChevron: Boolean = false,
    onFocused: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val bringIntoView = remember { BringIntoViewRequester() }
    // Compose TV Button owns focus decoration. Never overlay Modifier.border() on
    // top of its internal focused shape: that creates the double/white outline
    // visible on Settings and other D-pad buttons.
    val tvButtonShape = RoundedCornerShape(16.dp)
    Button(
        onClick = onClick,
        modifier = modifier
            .bringIntoViewRequester(bringIntoView)
            .onFocusChanged { state ->
                val nowFocused = state.hasFocus
                if (focused != nowFocused) {
                    focused = nowFocused
                    if (nowFocused) {
                        onFocused?.invoke()
                        scope.launch { bringIntoView.bringIntoView() }
                    }
                }
            },
        shape = ButtonDefaults.shape(shape = tvButtonShape),
        scale = ButtonDefaults.scale(focusedScale = 1f),
        border = ButtonDefaults.border(
            focusedBorder = Border(
                BorderStroke(1.5.dp, Color(0xFFB5F36D)), shape = tvButtonShape,
            ),
        ),
        colors = ButtonDefaults.colors(
            containerColor = if (primary) C.Accent else C.Panel,
            contentColor = if (primary) Color(0xFF10200C) else Color.White,
            focusedContainerColor = if (primary) Color(0xFF9CDE55) else Color(0xFF294432),
            focusedContentColor = if (primary) Color(0xFF10200C) else Color.White,
        ),
    ) {
        if (showFocusChevron && focused) {
            Text("›", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(5.dp))
        }
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(t(text), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun PosterCard(
    video: Video,
    modifier: Modifier = Modifier,
    width: androidx.compose.ui.unit.Dp = 112.dp,
    onFocus: () -> Unit = {},
    onLongClick: (() -> Unit)? = null,
    vm: AppViewModel? = null,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(12.dp)
    val ctx = LocalContext.current
    var cardFocused by remember { mutableStateOf(false) }
    val posterRequest = remember(ctx, video.poster) {
        ImageRequest.Builder(ctx).data(video.poster).size(224, 336).crossfade(false).build()
    }
    Column(Modifier.width(width)) {
        Surface(
            onClick = onClick,
            onLongClick = onLongClick,
            modifier = modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .onFocusChanged {
                    if (cardFocused != it.hasFocus) cardFocused = it.hasFocus
                    if (it.hasFocus) onFocus()
                },
            shape = ClickableSurfaceDefaults.shape(shape),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.065f),
            border = ClickableSurfaceDefaults.border(
                focusedBorder = Border(BorderStroke(1.5.dp, Color(0xFFB5F36D)), shape = shape)
            ),
            colors = ClickableSurfaceDefaults.colors(containerColor = C.Panel),
        ) {
            Box(Modifier.fillMaxSize()) {
                AsyncImage(
                    model = posterRequest,
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )

            }
        }
        Text(
            video.title,
            fontSize = 12.sp,
            fontWeight = if (cardFocused) FontWeight.SemiBold else FontWeight.Normal,
            color = if (cardFocused) Color.White else Color(0xFFB4BCCB),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp),
        )
    }
}

@Composable
fun TvTextField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    password: Boolean = false,
    imeAction: ImeAction = ImeAction.Next,
    onDone: () -> Unit = {},
) {
    var focused by remember { mutableStateOf(false) }
    val fm = LocalFocusManager.current
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
        cursorBrush = SolidColor(Color.White),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (password) KeyboardType.Password else KeyboardType.Text,
            imeAction = imeAction,
        ),
        keyboardActions = KeyboardActions(
            onNext = { fm.moveFocus(FocusDirection.Down) },
            onDone = { onDone() },
            onSearch = { onDone() },
        ),
        modifier = modifier
            .onFocusChanged { focused = it.hasFocus }
            .clip(RoundedCornerShape(10.dp))
            .background(C.Panel)
            .border(1.5.dp, if (focused) Color(0xFFB5F36D) else Color(0xFF454E62), RoundedCornerShape(10.dp))
            .padding(horizontal = 16.dp, vertical = 14.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) Text(t(hint), color = C.Dim, fontSize = 18.sp)
                inner()
            }
        },
    )
}

@Composable
fun CenterMessage(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(t(text), color = C.Dim, fontSize = 18.sp)
    }
}


/** One movie or episode: only real, numbered provider qualities are offered. */
@Composable
private fun DownloadOptionsDialog(video: Video, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = Services.prefs
    val language = LocalInterfaceLanguage.current
    val scope = rememberCoroutineScope()
    var options by remember(video.id) { mutableStateOf<List<QualityOption>>(emptyList()) }
    var loading by remember(video.id) { mutableStateOf(true) }
    var error by remember(video.id) { mutableStateOf("") }
    var saving by remember(video.id) { mutableStateOf(false) }
    var slot by remember(video.id) { mutableIntStateOf(prefs.downloadLocation) }
    var unmetered by remember(video.id) { mutableStateOf(prefs.downloadUnmeteredOnly) }
    val locations = remember(ctx) { Downloads.locations(ctx) }
    LaunchedEffect(video.id) {
        try {
            options = Downloads.choices(video)
            if (options.isEmpty()) error = if (language == "ar")
                "لا تتوفر ملفات قابلة للتنزيل لهذا العنوان."
                else "No downloadable streams are available for this title."
        } catch (c: CancellationException) { throw c }
          catch (failure: Exception) {
            error = if (failure.message?.startsWith("VK Video") == true) failure.message.orEmpty() else if (language == "ar") "تعذّر جلب خيارات التنزيل. تحقق من الشبكة أو المصدر."
                else "Couldn't load download options. Check your connection or provider access."
        } finally { loading = false }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.width(592.dp).heightIn(max = 590.dp)
                .clip(RoundedCornerShape(20.dp)).background(C.Bg)
                .border(1.dp, C.Accent, RoundedCornerShape(20.dp))
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(t("Download options"), fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(video.title, color = C.Dim, maxLines = 2)
            Text(t("Choose quality"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            if (loading) Text(t("Finding available files…"), color = C.Dim)
            if (error.isNotBlank()) Text(error, color = C.Dim)
            if (options.isNotEmpty()) {
                // Only provider-confirmed numeric resolutions. No Auto/Recommended/Source.
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { selected ->
                        AppButton(if (selected.height > 0) "${selected.height}p" else if (language == "ar") "تلقائي · تنزيل" else "Auto · Download") {
                            if (!saving) {
                                saving = true
                                scope.launch {
                                    val message = withContext(Dispatchers.IO) {
                                        Downloads.start(ctx, video, selected, slot, unmetered)
                                    }
                                    saving = false
                                    if (message == null) {
                                        Toast.makeText(ctx, if (language == "ar") "تمت إضافة التنزيل إلى القائمة" else "Download added to queue", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    } else error = message
                                }
                            }
                        }
                    }
                }
            }
            if (locations.isNotEmpty()) {
                Text(t("Save to"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    locations.forEach { loc ->
                        val label = if (loc.slot == 0) t("Device storage") else t("External storage") + " ${loc.slot}"
                        AppButton(if (loc.slot == slot) "✓ $label" else label,
                            primary = loc.slot == slot) { slot = loc.slot }
                    }
                }
                val free = locations.firstOrNull { it.slot == slot }?.free ?: 0L
                Text(t("Free space") + ": " + String.format(java.util.Locale.US, "%.1f GB", free / 1_073_741_824.0),
                    color = C.Dim, fontSize = 13.sp)
            }
            AppButton(if (unmetered) "✓ " + t("Unmetered networks only")
                else "□ " + t("Unmetered networks only"), primary = unmetered) { unmetered = !unmetered }
            Text(t("Direct files and supported HLS/DASH playlists can be saved. Adaptive playlists use device storage only; provider restrictions still apply."),
                color = C.Dim, fontSize = 12.sp)
            AppButton("Close") { onDismiss() }
        }
    }
}

/** Download button opens a quality/storage chooser rather than immediately downloading. */
@Composable
fun DownloadButton(video: Video, modifier: Modifier = Modifier, tag: String = "", compact: Boolean = false) {
    val ctx = LocalContext.current
    val language = LocalInterfaceLanguage.current
    val st by rememberDownloadStatus(video.id)
    var showOptions by remember(video.id) { mutableStateOf(false) }
    var showCancel by remember(video.id) { mutableStateOf(false) }
    val name = when (st.state) {
        Downloads.State.NONE -> t(if (compact) "Download" else "Download options") + tag
        Downloads.State.QUEUED -> t("Queued")
        Downloads.State.RUNNING -> t(if (compact) "Downloading" else "Downloading") +
            (if (st.total > 0L) " ${st.percent}%" else " · ${st.bytes / 1_048_576} MB")
        Downloads.State.PAUSED -> t("Paused") + " ${st.percent}%"
        Downloads.State.FAILED -> t(if (compact) "Retry" else "Retry download")
        Downloads.State.DONE -> t(if (compact) "Saved ✓" else "Downloaded ✓")
    }
    AppButton(name, modifier) {
        when (st.state) {
            Downloads.State.NONE, Downloads.State.FAILED -> showOptions = true
            Downloads.State.QUEUED, Downloads.State.RUNNING, Downloads.State.PAUSED -> showCancel = true
            Downloads.State.DONE -> Toast.makeText(ctx, if (language == "ar") "افتح التنزيلات لإدارة الملف" else "Open Downloads to manage this file", Toast.LENGTH_SHORT).show()
        }
    }
    if (showOptions) DownloadOptionsDialog(video) { showOptions = false }
    if (showCancel) {
        Dialog(onDismissRequest = { showCancel = false }) {
            Column(Modifier.width(410.dp).clip(RoundedCornerShape(16.dp))
                .background(C.Bg).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(t("Cancel this download?"), fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppButton("Keep downloading", primary = true) { showCancel = false }
                    AppButton("Cancel download") {
                        Downloads.remove(ctx, video.id)
                        showCancel = false
                    }
                }
            }
        }
    }
}
