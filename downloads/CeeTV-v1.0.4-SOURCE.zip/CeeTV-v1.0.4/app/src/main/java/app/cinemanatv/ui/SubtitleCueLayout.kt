@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.ui

import android.text.SpannableStringBuilder
import androidx.media3.common.text.Cue

/**
 * SubtitleView supports all active cues, but legacy/unpositioned overlapping SRT/SSA
 * events can be painted in the exact same bottom slot and obscure each other.
 * Preserve the player's complete CueGroup; stack ONLY unpositioned text cues into
 * one multiline cue, retaining any spans/styles. Explicit positions, VTT placement,
 * image captions, and SSA/ASS layout are left untouched.
 *
 * An empty group stays empty so no stale caption remains after the cues expire.
 */
internal fun layoutSimultaneousSubtitleCues(cues: List<Cue>): List<Cue> {
    if (cues.size < 2) return cues
    val toStack = cues.indices.filter { index ->
        val cue = cues[index]
        cue.bitmap == null && !cue.text.isNullOrBlank() &&
            cue.line == Cue.DIMEN_UNSET && cue.position == Cue.DIMEN_UNSET
    }
    if (toStack.size < 2) return cues
    val combined = SpannableStringBuilder()
    toStack.forEach { index ->
        if (combined.isNotEmpty()) combined.append('\n')
        combined.append(cues[index].text)
    }
    val first = toStack.first()
    val skip = toStack.drop(1).toSet()
    return cues.mapIndexedNotNull { index, cue ->
        when {
            index == first -> cue.buildUpon().setText(combined).build()
            index in skip -> null
            else -> cue
        }
    }
}
