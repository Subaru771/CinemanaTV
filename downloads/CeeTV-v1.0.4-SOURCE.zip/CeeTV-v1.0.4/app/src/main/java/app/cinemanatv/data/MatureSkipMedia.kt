package app.cinemanatv.data

/** Parent IDs can be empty or "0" on movie cards; neither makes a movie an episode. */
val Video.supportsPublicMatureMarkers: Boolean
    get() = episodeNumber == 0 && kind != "2" &&
        (kind == "1" || rootSeries.isNullOrBlank() || rootSeries.trim() == "0")
