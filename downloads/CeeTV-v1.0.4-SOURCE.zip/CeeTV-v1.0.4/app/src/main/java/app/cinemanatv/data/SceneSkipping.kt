package app.cinemanatv.data

/** Scene timestamps are milliseconds, not guessed from an age rating or the movie's duration. */
data class SceneRange(val startMs: Long, val endMs: Long)

object SceneSkipping {
    private const val MAX_SCENES = 80
    private const val MAX_SCENE_MS = 20 * 60 * 1000L
    private const val MIN_SCENE_MS = 1_000L

    fun normalize(ranges: List<SceneRange>): List<SceneRange> {
        val valid = ranges.filter {
            it.startMs >= 0L && it.endMs - it.startMs in MIN_SCENE_MS..MAX_SCENE_MS
        }.sortedBy { it.startMs }.take(MAX_SCENES)
        if (valid.isEmpty()) return emptyList()
        val merged = mutableListOf<SceneRange>()
        for (range in valid) {
            val previous = merged.lastOrNull()
            if (previous != null && range.startMs <= previous.endMs &&
                maxOf(previous.endMs, range.endMs) - previous.startMs <= MAX_SCENE_MS) {
                merged[merged.lastIndex] = SceneRange(previous.startMs, maxOf(previous.endMs, range.endMs))
            } else merged.add(range)
        }
        return merged
    }

    fun add(ranges: List<SceneRange>, startMs: Long, endMs: Long): List<SceneRange> =
        normalize(ranges + SceneRange(startMs, endMs))

    /** User-entered position in mm:ss or hh:mm:ss. Reject incomplete/invalid timestamps. */
    fun parseStamp(text: String): Long? {
        val parts = text.trim().split(':')
        if (parts.size !in 2..3 || parts.any { it.isBlank() || it.any { c -> !c.isDigit() } }) return null
        val nums = parts.map { it.toLongOrNull() ?: return null }
        if (nums.drop(1).any { it !in 0L..59L }) return null
        val sec = if (nums.size == 2) nums[0] * 60L + nums[1]
            else nums[0] * 3600L + nums[1] * 60L + nums[2]
        return sec.takeIf { it in 0L..86_400L }?.times(1000L)
    }

    /**
     * Only poll rapidly near an actual marked section. This keeps the v1.5 exact-seek/Undo
     * behavior while restoring the adaptive low-CPU schedule from v1.4.10.
     * Ranges passed here are already normalized/sorted, and Undo-exempted ones are ignored.
     */
    fun pollDelayMs(positionMs: Long, playing: Boolean, ranges: List<SceneRange>,
                    exempt: Set<SceneRange>): Long {
        if (!playing || ranges.isEmpty()) return 1_000L
        val upcoming = ranges.firstOrNull { it.endMs > positionMs && it !in exempt } ?: return 1_000L
        val gap = upcoming.startMs - positionMs
        return when {
            gap <= 4_000L -> 120L
            gap <= 20_000L -> 350L
            gap <= 60_000L -> 700L
            else -> 1_000L
        }
    }

    /** Return the exact range that would be skipped, so Undo never unmasks a different scene. */
    fun activeRange(positionMs: Long, ranges: List<SceneRange>, durationMs: Long): SceneRange? {
        if (positionMs < 0L || durationMs <= 0L) return null
        // A scene that ends exactly at the runtime is valid (it is simply the last thing in the file);
        // one that ends beyond this cut belongs to a different edition and is ignored.
        return ranges.firstOrNull { positionMs + 250L >= it.startMs && positionMs < it.endMs &&
            it.endMs <= durationMs }
    }

    /** Seek only while inside a confirmed marked scene. Never skip an unmarked video. */
    fun skipTarget(positionMs: Long, ranges: List<SceneRange>, durationMs: Long): Long? {
        val active = activeRange(positionMs, ranges, durationMs) ?: return null
        val target = (active.endMs + 250L).coerceAtMost(durationMs)
        return target.takeIf { it > positionMs + 250L }
    }
}
