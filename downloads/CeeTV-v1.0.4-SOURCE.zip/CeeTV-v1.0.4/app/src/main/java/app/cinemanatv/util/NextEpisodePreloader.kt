@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.util

import android.content.Context
import android.net.Uri
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import app.cinemanatv.data.QualityOption
import app.cinemanatv.data.userAgent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

/** Shared bounded cache: prepared bytes are actually consumed by the player's DataSource. */
object NextEpisodePreloader {
    private const val MAX_BYTES = 48L * 1024L * 1024L
    private const val WARM_BYTES = 512L * 1024L
    private val guard = Any()
    @Volatile private var instance: SimpleCache? = null
    private val http = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private fun cache(context: Context): SimpleCache = synchronized(guard) {
        instance ?: SimpleCache(
            File(context.applicationContext.cacheDir, "next_episode_bytes"),
            LeastRecentlyUsedCacheEvictor(MAX_BYTES),
            StandaloneDatabaseProvider(context.applicationContext)
        ).also { instance = it }
    }

    fun dataSourceFactory(context: Context): DataSource.Factory {
        val upstream = DefaultDataSource.Factory(
            context.applicationContext,
            OkHttpDataSource.Factory(http).setUserAgent(userAgent())
        )
        return CacheDataSource.Factory()
            .setCache(cache(context))
            .setUpstreamDataSourceFactory(upstream)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
    }

    /**
     * Fetch a small byte range only for direct HTTP video. Avoid preloading offline items,
     * adaptive playlists, and remote URLs that are not HTTP(S). Any failure is non-fatal.
     */
    suspend fun warm(context: Context, selected: QualityOption): Boolean = withContext(Dispatchers.IO) {
        if (selected.adaptive || !selected.progressive ||
            (!selected.url.startsWith("https://") && !selected.url.startsWith("http://"))) {
            return@withContext false
        }
        runCatching {
            val source = dataSourceFactory(context).createDataSource() as CacheDataSource
            val spec = DataSpec.Builder().setUri(Uri.parse(selected.url))
                .setPosition(0L).setLength(WARM_BYTES).build()
            CacheWriter(source, spec, null, null).cache()
            true
        }.getOrDefault(false)
    }

    fun bytes(context: Context): Long = runCatching { cache(context).cacheSpace }.getOrDefault(0L)

    /** Removes only the preloading cache. Offline downloads live in a separate directory. */
    fun clear(context: Context): Long = synchronized(guard) {
        val c = cache(context)
        val before = c.cacheSpace
        c.keys.toList().forEach { key -> runCatching { c.removeResource(key) } }
        before - c.cacheSpace
    }
}
