package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Text

@Composable
fun CrashReportDialog(report: String, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxWidth(0.9f).fillMaxHeight(0.85f).background(C.Panel).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Player error details", fontSize = 23.sp)
            Text("Please send a photo of the error below. Stream URLs and authentication headers are removed.", fontSize = 14.sp, color = C.Dim)
            Text(report, Modifier.weight(1f).verticalScroll(rememberScrollState()), fontSize = 13.sp)
            AppButton("Close", primary = true, onClick = onDismiss)
        }
    }
}
