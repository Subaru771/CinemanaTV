package app.cinemanatv.util

import android.content.Context
import android.os.Build
import java.io.File

/** App-private diagnostics only; no crash report is uploaded automatically. */
object CrashReports {
    private const val FILE = "last_player_error.txt"
    internal fun redact(text: String): String = text
        .replace(Regex("https?://[^\\s<>]+"), "<URL removed>")
        .replace(Regex("(?im)(authorization|cookie|set-cookie)\\s*:[^\\r\\n]*"), "$1: <removed>")
        .take(24_000)

    fun summary(error: Throwable): String = redact("${error.javaClass.simpleName}: ${error.message.orEmpty()}").take(400)

    fun record(context: Context, error: Throwable, pending: Boolean = false) {
        runCatching {
            val header = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n"
            File(context.filesDir, FILE).writeText(header + redact(error.stackTraceToString()))
            if (pending) context.getSharedPreferences("crash_report", Context.MODE_PRIVATE)
                .edit().putBoolean("pending", true).commit()
        }
    }

    fun last(context: Context): String? = runCatching {
        File(context.filesDir, FILE).takeIf { it.isFile }?.readText()?.take(24_500)
    }.getOrNull()

    fun consumePending(context: Context): String? {
        val prefs = context.getSharedPreferences("crash_report", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("pending", false)) return null
        prefs.edit().putBoolean("pending", false).apply()
        return last(context)
    }

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            record(app, error, pending = true)
            previous?.uncaughtException(thread, error)
        }
    }
}
