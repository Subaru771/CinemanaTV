package app.cinemanatv.util

import app.cinemanatv.data.QualityOption

/** Keep real resolutions and adaptive Auto entries; never invent a resolution. */
fun numberedDownloadOptions(options: List<QualityOption>): List<QualityOption> =
    options.asSequence()
        .filter { (it.height > 0 || it.adaptive) &&
            (it.url.startsWith("https://") || it.url.startsWith("http://")) }
        .sortedByDescending { it.height }
        .distinctBy { if (it.height > 0) "height:${it.height}" else "adaptive:${it.url}" }
        .toList()

fun downloadQualityLabel(choice: QualityOption): String =
    if (choice.height > 0) "${choice.height}p" else "Auto (offline)"
