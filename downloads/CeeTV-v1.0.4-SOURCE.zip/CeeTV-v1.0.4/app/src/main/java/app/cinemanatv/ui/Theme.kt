package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.tv.material3.LocalContentColor
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme

object C {
    val Accent = Color(0xFFB5F36D)
    val Bg = Color(0xFF0B130F)
    val Panel = Color(0xFF17271D)
    val Dim = Color(0xFFB2C4B7)
}

@Composable
fun CinemanaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Accent,
            background = C.Bg,
            surface = C.Panel,
            onPrimary = Color(0xFF10200C),
            onSurface = Color.White,
            onBackground = Color.White,
        )
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Box(Modifier.fillMaxSize().background(C.Bg)) { content() }
        }
    }
}
