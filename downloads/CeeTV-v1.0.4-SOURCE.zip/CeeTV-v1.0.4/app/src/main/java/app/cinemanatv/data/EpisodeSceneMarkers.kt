package app.cinemanatv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

/** Published VideoSkip files for any discoverable movie/series; edition alignment is unverified. */
object EpisodeSceneMarkers {
    private const val HOST = "https://videoskip.herokuapp.com"
    private data class CachedPage(val at: Long, val text: String)
    private val pages = LinkedHashMap<String, CachedPage>()
    fun seriesImdb(video: Video, details: Video?): String? =
        listOf(video.rootSeriesInfo?.imdbRef, details?.rootSeriesInfo?.imdbRef)
            .mapNotNull(ExternalSceneMarkers::imdbID).firstOrNull()

    fun seriesTitle(video: Video, details: Video?): String? =
        listOf(video.rootSeriesInfo?.title, details?.rootSeriesInfo?.title)
            .firstOrNull { !it.isNullOrBlank() }

    internal fun confirmsImdb(html: String, imdb: String): Boolean =
        Regex("/title/" + Regex.escape(imdb) + "(?:[/\"'?#]|$)").containsMatchIn(html)

    internal fun candidates(html: String, episodes: Boolean): List<String> {
        val type = if (episodes) "series" else "videos"
        return Regex("href=\"(/exchange/$type/[0-9]+/)\"").findAll(html)
            .map { it.groupValues[1] }.distinct().take(12).toList()
    }

    internal fun episodePath(html: String, imdb: String, season: Int, episode: Int): String? {
        if (!confirmsImdb(html, imdb)) return null
        val pattern = Regex("href=\"(/exchange/videos/[0-9]+/)\">S([0-9]+) E([0-9]+):")
        return pattern.findAll(html).firstOrNull {
            it.groupValues[2].toInt() == season && it.groupValues[3].toInt() == episode
        }?.groupValues?.get(1)
    }

    internal fun parse(text: String, durationMs: Long): List<ExternalSceneMarker> {
        fun stamp(raw: String): Long {
            val p = raw.split(':')
            return ((p[0].toDouble() * 3600 + p[1].toDouble() * 60 + p[2].toDouble()) * 1000).toLong()
        }
        val pattern = Regex("(?m)^\\s*(\\d+:\\d{2}:\\d{2}(?:\\.\\d+)?)\\s*-->\\s*(\\d+:\\d{2}:\\d{2}(?:\\.\\d+)?)\\s*\\r?\\n(sex|nudity)[ \\t]+(?:(skip|image|mute)[ \\t]+)?[123](?:[ \\t]+\\([^\\r\\n]*\\))?[ \\t]*$")
        val rows = pattern.findAll(text).filter { it.groupValues[4] != "mute" }.map {
            ExternalSceneMarker("mature", stamp(it.groupValues[1]), stamp(it.groupValues[2]),
                "VideoSkip (community, edition unverified)", 0.55, it.groupValues[3])
        }.toList()
        // Reject the file as a whole if it cannot fit this cut. Never borrow another episode.
        if (rows.isEmpty() || rows.any { !ExternalSceneMarkers.validated(it, durationMs) }) return emptyList()
        return rows.map { it.padded(1500L, 1000L, durationMs) }
    }

    suspend fun load(imdb: String?, season: Int, episode: Int, durationMs: Long, title: String? = null): MatureSceneLookupResult = withContext(Dispatchers.IO) {
        fun result(s: MatureSceneLookupStatus, retry: Boolean = false) = MatureSceneLookupResult(emptyList(), s, retry)
        val id = ExternalSceneMarkers.imdbID(imdb)
            ?: return@withContext result(MatureSceneLookupStatus.NETWORK_ERROR, true)
        if (title.isNullOrBlank()) return@withContext result(MatureSceneLookupStatus.NETWORK_ERROR, true)
        val isEpisode = season > 0 && episode > 0
        if ((season > 0) != (episode > 0)) return@withContext result(MatureSceneLookupStatus.NETWORK_ERROR, true)
        fun get(path: String): String {
            synchronized(pages) {
                pages[path]?.takeIf { (System.nanoTime() - it.at) / 1_000_000L < 600_000L }?.text
            }?.let { return it }
            val connection = URL(HOST + path).openConnection() as HttpURLConnection
            connection.connectTimeout = 8000; connection.readTimeout = 8000
            try {
                check(connection.responseCode == 200)
                val text = connection.inputStream.use { input ->
                    String(input.readBytesBounded(), Charsets.UTF_8)
                }
                synchronized(pages) {
                    pages[path] = CachedPage(System.nanoTime(), text)
                    while (pages.size > 24) pages.remove(pages.keys.first())
                }
                return text
            } finally { connection.disconnect() }
        }
        try {
            val search = get("/exchange/search/?q=" + java.net.URLEncoder.encode(title, "UTF-8"))
            if (!search.contains("Showing results for"))
                return@withContext result(MatureSceneLookupStatus.NETWORK_ERROR, true)
            var html: String? = null
            for (candidate in candidates(search, isEpisode)) {
                val page = get(candidate)
                if (!confirmsImdb(page, id)) continue
                if (isEpisode) {
                    val path = episodePath(page, id, season, episode) ?: continue
                    val episodePage = get(path)
                    if (!episodePage.contains("S$season E$episode:"))
                        return@withContext result(MatureSceneLookupStatus.NETWORK_ERROR, true)
                    html = episodePage
                } else html = page
                break
            }
            if (html == null) return@withContext result(MatureSceneLookupStatus.NO_MARKERS)
            val files = Regex("action=\"(/exchange/skip/[0-9]+/download/)\"").findAll(html)
                .map { it.groupValues[1] }.distinct().take(3).toList()
            var mismatch = false
            for (file in files) {
                val text = get(file)
                val markers = parse(text, durationMs)
                if (markers.isNotEmpty()) return@withContext MatureSceneLookupResult(markers, MatureSceneLookupStatus.READY)
                if (Regex("(?m)^(sex|nudity)[ \\t]+(?:(skip|image)[ \\t]+)?[123]").containsMatchIn(text)) mismatch = true
            }
            result(if (mismatch) MatureSceneLookupStatus.CUT_MISMATCH else MatureSceneLookupStatus.NO_MARKERS)
        } catch (c: kotlinx.coroutines.CancellationException) { throw c }
          catch (_: Exception) { result(MatureSceneLookupStatus.NETWORK_ERROR, true) }
    }

    private fun java.io.InputStream.readBytesBounded(): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val n = read(buffer)
            if (n < 0) break
            check(out.size() + n <= 256_000)
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }
}
