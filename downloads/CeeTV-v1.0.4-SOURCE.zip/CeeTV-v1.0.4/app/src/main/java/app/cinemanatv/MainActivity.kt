package app.cinemanatv

import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import app.cinemanatv.data.Video
import app.cinemanatv.util.TvHomeIntegration
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import app.cinemanatv.ui.LocalInterfaceLanguage
import app.cinemanatv.ui.AppViewModel
import app.cinemanatv.ui.CinemanaTheme
import app.cinemanatv.ui.DetailScreen
import app.cinemanatv.ui.MainShell
import app.cinemanatv.ui.PlayerScreen
import app.cinemanatv.ui.Screen
import app.cinemanatv.ui.CinemaStartup
import app.cinemanatv.ui.StartupAnnouncements
import app.cinemanatv.util.AvailableAppUpdate
import app.cinemanatv.util.AppUpdateChecker
import app.cinemanatv.util.BackDestination
import app.cinemanatv.util.BackPressGate
import app.cinemanatv.util.backDestination

/**
 * One owner for ALL TV Back input. The previous release sent remote events to
 * onBackPressedDispatcher, but when a Compose handler was absent during a screen
 * transition the dispatcher could fall through and finish the Activity.
 *
 * The enabled Activity callback is installed before composition, and never
 * delegates to the framework's default finish behavior. Hardware keys and
 * Android 13+ system Back both feed routeBack() instead of triggering separate
 * per-screen onBackPressed handlers.
 */
class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val backGate = BackPressGate()
    private var telegramStartupVisible by mutableStateOf(true)
    private var updatePromptVisible by mutableStateOf(true)
    private var availableUpdate by mutableStateOf<AvailableAppUpdate?>(null)
    private var playerBackAction: (() -> Unit)? = null
    private var pendingCrashReport by mutableStateOf<String?>(null)
    // Registered *after* AndroidX's onStart registration. Android 13+ firmware
    // can route remote Back via this platform API without delivering KEYCODE_BACK.
    private var platformBackCallback: OnBackInvokedCallback? = null

    private fun trace(message: String) {
        Log.i("CinemanaBack", "${SystemClock.elapsedRealtime()} $message")
    }

    private fun registerPlatformBack() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        unregisterPlatformBack()
        val callback = OnBackInvokedCallback { routeBack("platform") }
        onBackInvokedDispatcher.registerOnBackInvokedCallback(
            OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback
        )
        platformBackCallback = callback
        trace("platform callback registered")
    }

    private fun unregisterPlatformBack() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        platformBackCallback?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        platformBackCallback = null
    }

    override fun onPostResume() {
        super.onPostResume()
        registerPlatformBack()
        trace("onPostResume screen=${vm.stack.lastOrNull()?.javaClass?.simpleName} depth=${vm.stack.size}")
    }

    override fun onUserLeaveHint() {
        trace("onUserLeaveHint: system switching away; this may be a HOME event")
        super.onUserLeaveHint()
    }

    override fun onPause() {
        trace("onPause finishing=$isFinishing depth=${vm.stack.size}")
        unregisterPlatformBack()
        super.onPause()
    }

    override fun onStop() {
        trace("onStop finishing=$isFinishing depth=${vm.stack.size}")
        super.onStop()
    }

    override fun onDestroy() {
        trace("onDestroy finishing=$isFinishing changingConfigurations=$isChangingConfigurations depth=${vm.stack.size}")
        unregisterPlatformBack()
        super.onDestroy()
    }

    override fun finish() {
        trace("finish() invoked - not called by CinemanaBack navigation")
        super.finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Pre-Android-13 fallback. Never call super: the default may exit the task.
        routeBack("legacy")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingCrashReport = app.cinemanatv.util.CrashReports.consumePending(this)
        // Only show the Telegram invitation on a fresh launch, not activity recreation.
        telegramStartupVisible = false
        lifecycleScope.launch {
            val candidate = AppUpdateChecker.check(BuildConfig.UPDATE_FEED_URL, BuildConfig.VERSION_CODE.toLong())
            val prefs = getSharedPreferences("cinemana_updates", MODE_PRIVATE)
            availableUpdate = candidate?.takeIf { update ->
                val skipped = prefs.getLong("skipped_tv_version_code", 0L)
                // A new release always prompts, even if a prior release was snoozed.
                val lastReminded = prefs.getLong("remind_tv_at", 0L)
                val remindedVersion = prefs.getLong("reminded_tv_version_code", 0L)
                val due = remindedVersion != update.versionCode || lastReminded <= 0L || System.currentTimeMillis() >= lastReminded
                update.versionCode > skipped && due
            }
        }

        // Always registered, including while loading, swapping screens or
        // when the player is being disposed. Also covers predictive/system Back.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = routeBack("androidx")
        })

        setContent {
            CinemanaTheme {
                AppRoot(
                    vm = vm,
                    onPlayerBackChanged = { playerBackAction = it },
                    showTelegram = telegramStartupVisible,
                    update = availableUpdate.takeIf { updatePromptVisible },
                    onTelegram = {
                        telegramStartupVisible = false
                        openLink("https://t.me/CinemanaHub")
                    },
                    onUpdate = {
                        val link = availableUpdate?.downloadUrl
                        if (link != null) {
                            remindUpdateLater()
                            updatePromptVisible = false
                            openLink(link)
                        }
                    },
                    onSkipUpdate = {
                        skipUpdateVersion()
                        updatePromptVisible = false
                    },
                    onDismissNotices = {
                        // Separate dialogs: dismiss Telegram first, then let a real
                        // update alert appear (including a check that finishes later).
                        if (telegramStartupVisible) telegramStartupVisible = false
                        else if (availableUpdate != null) {
                            remindUpdateLater()
                            updatePromptVisible = false
                        }
                    },
                )
                pendingCrashReport?.let { report ->
                    app.cinemanatv.ui.CrashReportDialog(report) { pendingCrashReport = null }
                }
            }
        }
        openFromTvHome(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openFromTvHome(intent)
    }

    /** A Watch Next card must resume its episode instead of only opening the Home tab. */
    private fun openFromTvHome(incoming: Intent?) {
        val id = incoming?.getStringExtra(TvHomeIntegration.EXTRA_WATCH_VIDEO)
            ?.takeIf { it.isNotBlank() } ?: return
        // Prevent a configuration change or an activity recreation from re-launching the video.
        incoming.removeExtra(TvHomeIntegration.EXTRA_WATCH_VIDEO)
        lifecycleScope.launch {
            val target = withContext(Dispatchers.IO) {
                Services.prefs.recent().firstOrNull { it.id == id }
                    ?: Services.prefs.history().firstOrNull { it.id == id }
                    ?: Services.repo.info(Video(nb = id, enTitle = "Continue watching"))
            }
            vm.stack.clear()
            vm.stack.add(Screen.Main)
            vm.push(Screen.Play(listOf(target), 0))
        }
    }

    private fun remindUpdateLater() {
        val code = availableUpdate?.versionCode ?: return
        getSharedPreferences("cinemana_updates", MODE_PRIVATE).edit()
            .putLong("reminded_tv_version_code", code)
            .putLong("remind_tv_at", System.currentTimeMillis() + 24L * 60L * 60L * 1000L)
            .remove("dismissed_tv_version_code")
            .apply()
    }

    private fun skipUpdateVersion() {
        availableUpdate?.let { update ->
            getSharedPreferences("cinemana_updates", MODE_PRIVATE).edit()
                .putLong("skipped_tv_version_code", update.versionCode)
                .remove("remind_tv_at")
                .remove("dismissed_tv_version_code")
                .apply()
        }
    }

    /** Most Android TVs use a browser; on browserless TVs the notice shows the URL. */
    private fun openLink(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)
        if (runCatching { startActivity(intent) }.isFailure) {
            val message = if (vm.interfaceLanguage == "ar") "افتح الرابط على هاتفك: $url"
                else "Open $url on your phone"
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun routeBack(source: String) {
        trace("BACK source=$source screen=${vm.stack.lastOrNull()?.javaClass?.simpleName} depth=${vm.stack.size} tab=${vm.tab}")
        // Some firmware dispatches both KEYCODE_BACK and the Android Back
        // callback for one physical press. Do not navigate twice.
        if (!backGate.tryHandle(SystemClock.elapsedRealtime())) {
            trace("BACK deduplicated source=$source")
            return
        }

        val current = vm.stack.lastOrNull()
        if (current is Screen.Play) {
            // A player submenu must close before the player itself exits.
            // Without a live player callback, only pop the page; never finish.
            val action = playerBackAction
            if (action != null) action() else vm.pop()
            trace("Player Back completed; depth=${vm.stack.size}")
            return
        }

        if (current == Screen.Main && (telegramStartupVisible ||
                    (updatePromptVisible && availableUpdate != null))) {
            if (telegramStartupVisible) telegramStartupVisible = false
            else if (availableUpdate != null) {
                remindUpdateLater()
                updatePromptVisible = false
            }
            trace("Startup notice dismissed via Back")
            return
        }

        val destination = backDestination(vm.stack.size, vm.tab)
        when (destination) {
            BackDestination.POP_PAGE -> vm.pop()
            BackDestination.HOME_TAB -> vm.tab = if (vm.tab == 3) vm.lastTab else 0
            else -> Unit // Home/splash: stay in the app, even on repeated Back.
        }
        trace("Back=$destination completed depth=${vm.stack.size} tab=${vm.tab}")
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_BUTTON_B -> {
                // Consume BOTH DOWN and UP, including repeats, so the TV cannot
                // pass the release to the system and close the Activity.
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && !event.isCanceled) {
                    routeBack("key:${event.keyCode}")
                }
                return true
            }
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
            event.keyCode == KeyEvent.KEYCODE_HOME) {
            trace("HOME key observed: Android system owns HOME, not app navigation")
        }
        return super.dispatchKeyEvent(event)
    }
}

@Composable
fun AppRoot(
    vm: AppViewModel,
    onPlayerBackChanged: ((() -> Unit)?) -> Unit,
    showTelegram: Boolean,
    update: AvailableAppUpdate?,
    onTelegram: () -> Unit,
    onUpdate: () -> Unit,
    onDismissNotices: () -> Unit,
    onSkipUpdate: () -> Unit,
) {
    // Navigation is exclusively managed by MainActivity. Do NOT add another
    // Compose BackHandler: it reintroduces races / double-pop on Android TV.
    val showSplash = vm.stack.size == 1 && vm.stack.last() == Screen.Main &&
        !vm.splashFinished
    if (showSplash) {
        CompositionLocalProvider(LocalInterfaceLanguage provides vm.interfaceLanguage) {
            CinemaStartup()
        }
        return
    }

    // The video timeline retains LTR semantics even when Arabic interface is enabled.
    val isPlayer = vm.stack.last() is Screen.Play
    val direction = if (vm.interfaceLanguage == "ar" && !isPlayer) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(
        LocalInterfaceLanguage provides vm.interfaceLanguage,
        LocalLayoutDirection provides direction,
    ) {
    androidx.compose.foundation.layout.Box {
    when (val screen = vm.stack.last()) {
        Screen.Main -> MainShell(vm)
        is Screen.Detail -> DetailScreen(
            video = screen.video,
            queue = screen.queue,
            queueIndex = screen.index,
            contentMode = vm.contentFilterMode,
            vm = vm,
            onPlay = { queue, index -> vm.push(Screen.Play(queue, index)) },
            onOpen = { vm.push(Screen.Detail(it)) },
            onOpenEpisode = { queue, index -> vm.push(Screen.Detail(queue[index], queue, index)) },
        )
        is Screen.Play -> androidx.compose.runtime.key(screen.queue, screen.index) { PlayerScreen(
            queue = screen.queue,
            startIndex = screen.index,
            onExit = { vm.pop() },
            onRegisterBack = onPlayerBackChanged,
        ) }
    }
    }
    if (vm.stack.last() == Screen.Main && (showTelegram || update != null)) {
        StartupAnnouncements(showTelegram, update, onTelegram, onUpdate, onDismissNotices, onSkipUpdate)
    }
    }
}
