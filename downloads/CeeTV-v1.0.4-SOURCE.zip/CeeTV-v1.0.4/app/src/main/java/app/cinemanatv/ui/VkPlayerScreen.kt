package app.cinemanatv.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.tv.material3.Text
import app.cinemanatv.data.CeeAlternativeSource

/** Official provider embed. No stream interception, native JS bridge, or CAPTCHA bypass. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun VkPlayerScreen(url:String, title:String, onExit:()->Unit,
    onRegisterBack:((()->Unit)?)->Unit, onNext:(()->Unit)?=null) {
    if (!CeeAlternativeSource.isVkPlayer(url)) {
        Column(Modifier.fillMaxSize().padding(32.dp)) {
            Text("Invalid VK player address.")
            AppButton("Back",onClick=onExit)
        }
        return
    }
    val context=LocalContext.current
    val owner=LocalLifecycleOwner.current
    var loading by remember(url) { mutableStateOf(true) }
    var error by remember(url) { mutableStateOf<String?>(null) }
    var fullscreen by remember(url) { mutableStateOf<View?>(null) }
    val callback=remember(url) { arrayOfNulls<WebChromeClient.CustomViewCallback>(1) }
    val created=remember(url,context) { runCatching { WebView(context) } }
    val web=created.getOrNull()
    fun closeFullscreen() { fullscreen=null;callback[0]?.onCustomViewHidden();callback[0]=null }
    val back by rememberUpdatedState<()->Unit>({if(fullscreen!=null)closeFullscreen() else onExit()})
    DisposableEffect(url) {
        onRegisterBack { back() }
        onDispose { onRegisterBack(null) }
    }
    DisposableEffect(web,owner) {
        val observer=LifecycleEventObserver { _,event ->
            when(event){Lifecycle.Event.ON_STOP -> {
                web?.evaluateJavascript("document.querySelectorAll('video').forEach(v=>v.pause())",null)
                web?.onPause()
            };Lifecycle.Event.ON_START -> web?.onResume();else -> Unit}
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            callback[0]?.onCustomViewHidden();callback[0]=null
            web?.stopLoading();web?.onPause()
            (web?.parent as? ViewGroup)?.removeView(web)
            web?.destroy()
        }
    }
    if(web==null){
        Column(Modifier.fillMaxSize().padding(32.dp)) {
            Text("VK player could not start. Install or update Android System WebView.")
            AppButton("Back",onClick=onExit)
        }
        return
    }
    Box(Modifier.fillMaxSize().background(C.Bg)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                AppButton("Back",onClick=onExit)
                AppButton("Play / Pause") {
                    web.evaluateJavascript("document.querySelectorAll('video').forEach(v=>{if(v.paused){v.play().catch(()=>{})}else{v.pause()}})",null)
                    web.requestFocus()
                }
                AppButton("Reload") { error=null;loading=true;web.reload() }
                if(onNext!=null)AppButton("Next episode",onClick=onNext)
            }
            Text("VK Video · $title",Modifier.padding(horizontal=16.dp),color=C.Accent,maxLines=1)
            if(loading)Text("Loading VK player…",Modifier.padding(16.dp),color=C.Dim)
            error?.let { Text(it,Modifier.padding(16.dp),color=C.Dim) }
            AndroidView(modifier=Modifier.weight(1f).fillMaxWidth(),factory={
                web.apply {
                    setBackgroundColor(android.graphics.Color.BLACK)
                    settings.javaScriptEnabled=true
                    settings.domStorageEnabled=true
                    settings.mediaPlaybackRequiresUserGesture=false
                    settings.allowFileAccess=false
                    settings.allowContentAccess=false
                    settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    webViewClient=object:WebViewClient(){
                        override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean =
                            request.isForMainFrame && !CeeAlternativeSource.isVkPlayer(request.url.toString())
                        override fun onPageStarted(view:WebView,address:String,icon:Bitmap?){loading=true}
                        override fun onPageFinished(view:WebView,address:String){loading=false}
                        override fun onReceivedError(view:WebView,request:WebResourceRequest,failure:WebResourceError){
                            if(request.isForMainFrame){loading=false;error="VK could not load. Check your connection, then reload."}
                        }
                    }
                    webChromeClient=object:WebChromeClient(){
                        override fun onShowCustomView(view:View,cb:CustomViewCallback){
                            if(fullscreen!=null){cb.onCustomViewHidden();return}
                            callback[0]=cb;fullscreen=view
                        }
                        override fun onHideCustomView(){closeFullscreen()}
                    }
                    loadUrl(url)
                    requestFocus()
                }
            })
        }
        fullscreen?.let { view ->
            AndroidView(modifier=Modifier.fillMaxSize().background(C.Bg),factory={
                (view.parent as? ViewGroup)?.removeView(view)
                view
            })
        }
    }
}
