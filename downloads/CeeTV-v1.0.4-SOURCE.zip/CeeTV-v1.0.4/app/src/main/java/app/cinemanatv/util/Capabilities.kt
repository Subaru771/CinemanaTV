package app.cinemanatv.util

import android.content.Context
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

object Capabilities {
    private val ladder = listOf(2160, 1440, 1080, 720, 480, 360, 240)

    // Walking MediaCodecList is slow on TV boxes (100ms+). Do it once, and let App warm it
    // on a background thread so the player never pays for it on the main thread.
    private val decodable: Int by lazy { computeDecodableHeight() }

    /** Tallest video the hardware decoders (H.264 / HEVC) can handle on this device. */
    fun maxDecodableHeight(): Int = decodable

    private fun computeDecodableHeight(): Int {
        var best = 480
        runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
                .filter { !it.isEncoder }
                .forEach { info ->
                    info.supportedTypes
                        .filter { it == "video/avc" || it == "video/hevc" }
                        .forEach { type ->
                            val vc: MediaCodecInfo.VideoCapabilities =
                                info.getCapabilitiesForType(type).videoCapabilities ?: return@forEach
                            when {
                                vc.isSizeSupported(3840, 2160) -> best = max(best, 2160)
                                vc.isSizeSupported(1920, 1080) -> best = max(best, 1080)
                                vc.isSizeSupported(1280, 720) -> best = max(best, 720)
                            }
                        }
                }
        }
        return best
    }

    /** Tallest resolution the connected display can show. */
    @Suppress("DEPRECATION")
    fun maxDisplayHeight(context: Context): Int {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return runCatching { wm.defaultDisplay.supportedModes.maxOf { it.physicalHeight } }
            .getOrDefault(1080)
    }

    /** Best height we should ask for when the user left quality on "Auto". */
    fun autoHeight(context: Context): Int {
        val cap = min(maxDecodableHeight(), maxDisplayHeight(context))
        return ladder.firstOrNull { it <= cap + 8 } ?: 480
    }
}
