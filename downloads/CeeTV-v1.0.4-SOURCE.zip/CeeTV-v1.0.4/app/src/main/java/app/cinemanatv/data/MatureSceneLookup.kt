package app.cinemanatv.data

import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

enum class MatureSceneLookupStatus { READY, NO_MARKERS, CUT_MISMATCH, NETWORK_ERROR }

data class MatureSceneLookupResult(
    val markers: List<ExternalSceneMarker>,
    val status: MatureSceneLookupStatus,
    /** Some usable markers may be ready while the other database needs a retry. */
    val hasTransientFailure: Boolean = false,
)

/** Mature markers load independently of intro services, and failures remain retryable. */
object MatureSceneLookup {
    const val RETRY_DELAY_MS = 30_000L
    private const val POSITIVE_TTL_MS = 21_600_000L
    private const val NO_DATA_TTL_MS = 600_000L
    private data class Cached(val atNanos: Long, val ttlMs: Long, val result: MatureSceneLookupResult)
    private val cache = LinkedHashMap<String, Cached>()

    internal sealed interface Fetch {
        data class Json(val body: JsonElement) : Fetch
        data object Missing : Fetch
        data object Failed : Fetch
    }

    suspend fun load(imdbInput: String?, durationMs: Long, title: String? = null): MatureSceneLookupResult {
        val imdb = ExternalSceneMarkers.imdbID(imdbInput)
            ?: return MatureSceneLookupResult(emptyList(), MatureSceneLookupStatus.NETWORK_ERROR, true)
        if (durationMs < 60_000L)
            return MatureSceneLookupResult(emptyList(), MatureSceneLookupStatus.CUT_MISMATCH)
        // Keep cuts separate: a result accepted for one runtime must not leak to another.
        val key = "$imdb|$durationMs"
        synchronized(cache) {
            cache[key]?.takeIf { (System.nanoTime() - it.atNanos) / 1_000_000L < it.ttlMs }?.result
        }?.let { return it }
        val primary = lookup(imdb, durationMs, ::fetchJson)
        val fallback = if (primary.markers.isEmpty() && !title.isNullOrBlank())
            EpisodeSceneMarkers.load(imdb, 0, 0, durationMs, title) else null
        val result = when {
            fallback == null -> primary
            fallback.markers.isNotEmpty() -> fallback
            primary.hasTransientFailure || fallback.hasTransientFailure ->
                MatureSceneLookupResult(emptyList(), MatureSceneLookupStatus.NETWORK_ERROR, true)
            primary.status == MatureSceneLookupStatus.CUT_MISMATCH -> primary
            else -> fallback
        }
        currentCoroutineContext().ensureActive()
        val ttlMs = when {
            result.hasTransientFailure -> RETRY_DELAY_MS
            result.status == MatureSceneLookupStatus.READY -> POSITIVE_TTL_MS
            else -> NO_DATA_TTL_MS
        }
        synchronized(cache) {
            cache[key] = Cached(System.nanoTime(), ttlMs, result)
            while (cache.size > 40) cache.remove(cache.keys.first())
        }
        return result
    }

    /** Uncached seam for deterministic tests using the same real JSON parsers as playback. */
    internal suspend fun lookup(
        imdb: String, durationMs: Long, fetch: suspend (String) -> Fetch,
    ): MatureSceneLookupResult = coroutineScope {
        val haven = async(Dispatchers.IO) { fetch(ExternalSceneMarkers.movieHavenURL(imdb)!!) }
        val clean = async(Dispatchers.IO) { fetch(ExternalSceneMarkers.cleanStreamURL(imdb)!!) }
        val havenResult = haven.await()
        val cleanResult = clean.await()
        var failed = havenResult == Fetch.Failed || cleanResult == Fetch.Failed
        var published = false
        val markers = mutableListOf<ExternalSceneMarker>()

        if (havenResult is Fetch.Json) {
            val body = havenResult.body.takeIf { it.isJsonObject }?.asJsonObject
            val sourceId = runCatching { body?.get("imdb_id")?.asString }.getOrNull()
            val runtime = runCatching { body?.get("duration")?.asDouble }.getOrNull()
            if (ExternalSceneMarkers.imdbID(sourceId) != imdb || runtime == null ||
                runtime !in 60.0..21_600.0 || body?.get("scenes")?.isJsonArray != true) {
                failed = true
            } else {
                // Validate the source's own edition before deciding that this stream is a mismatch.
                val listed = runCatching { ExternalSceneMarkers.movieHaven(body, imdb, (runtime * 1000).toLong()) }
                val accepted = runCatching { ExternalSceneMarkers.movieHaven(body, imdb, durationMs) }
                if (listed.isFailure || accepted.isFailure) failed = true
                else {
                    published = published || listed.getOrThrow().isNotEmpty()
                    markers += accepted.getOrThrow()
                }
            }
        }
        if (cleanResult is Fetch.Json) {
            if (!ExternalSceneMarkers.isCleanStreamResponse(cleanResult.body, imdb)) {
                failed = true
            } else {
                val accepted = runCatching { ExternalSceneMarkers.cleanStream(cleanResult.body, imdb, durationMs) }
                if (accepted.isFailure) failed = true
                else {
                    published = published || ExternalSceneMarkers.hasCleanStreamMatureRanges(cleanResult.body, imdb)
                    markers += accepted.getOrThrow()
                }
            }
        }
        val found = markers.distinctBy { it.startMs to it.endMs }.sortedBy { it.startMs }
        val status = when {
            found.isNotEmpty() -> MatureSceneLookupStatus.READY
            failed -> MatureSceneLookupStatus.NETWORK_ERROR
            published -> MatureSceneLookupStatus.CUT_MISMATCH
            else -> MatureSceneLookupStatus.NO_MARKERS
        }
        MatureSceneLookupResult(found, status, failed)
    }

    private suspend fun fetchJson(address: String): Fetch {
        currentCoroutineContext().ensureActive()
        return try {
            val connection = URL(address).openConnection() as HttpURLConnection
            connection.connectTimeout = 8_000
            connection.readTimeout = 8_000
            connection.setRequestProperty("Accept", "application/json")
            try {
                when (connection.responseCode) {
                    404, 410 -> Fetch.Missing
                    in 200..299 -> connection.inputStream.use { input ->
                        val output = ByteArrayOutputStream()
                        val bytes = ByteArray(8192)
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val count = input.read(bytes)
                            if (count < 0) break
                            if (output.size() + count > 256_000) return@use Fetch.Failed
                            output.write(bytes, 0, count)
                        }
                        currentCoroutineContext().ensureActive()
                        Fetch.Json(JsonParser.parseString(output.toString("UTF-8")))
                    }
                    else -> Fetch.Failed
                }
            } finally { connection.disconnect() }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            Fetch.Failed
        }
    }
}
