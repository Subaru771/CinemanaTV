package app.cinemanatv.util

/** Back-navigation precedence, independent of the remote and Compose implementation. */
enum class BackDestination { CLOSE_SUBMENU, CLOSE_PANEL, POP_PAGE, HOME_TAB, STAY }

/**
 * [panelLevel] is -1 outside a player, 0 for no open panel, 1 for root settings,
 * and 2 for a settings submenu. Pages always pop before home-tab navigation.
 */
fun backDestination(stackDepth: Int, homeTab: Int, panelLevel: Int = -1): BackDestination = when {
    panelLevel >= 2 -> BackDestination.CLOSE_SUBMENU
    panelLevel == 1 -> BackDestination.CLOSE_PANEL
    stackDepth > 1 -> BackDestination.POP_PAGE
    homeTab != 0 -> BackDestination.HOME_TAB
    else -> BackDestination.STAY
}


/** Deduplicates a single TV Back press when firmware sends key + system callbacks. */
class BackPressGate(private val duplicateWindowMs: Long = 220L) {
    private var lastAcceptedAt: Long? = null

    fun tryHandle(elapsedRealtimeMs: Long): Boolean {
        val previous = lastAcceptedAt
        if (previous != null && elapsedRealtimeMs >= previous &&
            elapsedRealtimeMs - previous < duplicateWindowMs) return false
        lastAcceptedAt = elapsedRealtimeMs
        return true
    }
}
