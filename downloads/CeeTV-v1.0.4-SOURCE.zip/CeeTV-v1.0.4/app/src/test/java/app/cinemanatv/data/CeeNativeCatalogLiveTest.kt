package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

class CeeNativeCatalogLiveTest {
    @Test fun catalogueSearchDetailsAndEpisodesUseCeeDirectly() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST") == "1")
        val backend = CeeHtmlCatalog()
        val home = backend.home(null)
        assertTrue(home.rows.size >= 2)
        assertTrue(home.rows.flatMap { it.items }.all { it.id.startsWith("cee_") })
        assertTrue(home.rows.flatMap { it.items }.any { !it.poster.isNullOrBlank() })
        val results = backend.search("Avengers Infinity War")
        assertTrue(results.isNotEmpty())
        val detail = backend.detail(results.first())
        assertTrue(detail.title.isNotBlank())
        val sample = Video(nb="cee_3216134", kind="2", enTitle="Sample", providerPageId="3216134")
        val episodes = backend.episodes(sample)
        assertTrue(episodes.size >= 2)
        assertTrue(episodes.all { it.episodeNumber > 0 && it.rootSeries != null })
        println("Native CEE: ${home.rows.size} rows, ${results.size} search results, ${episodes.size} episode links")
    }
    @Test fun movieResolvesToAnExplicitlyTypedReadableHlsManifest() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST") == "1")
        val streams = CeeHtmlCatalog().sources("cee_2148687").qualities
        val stream = streams.first()
        assertEquals("application/x-mpegURL", stream.mimeType)
        val http = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
        http.newCall(Request.Builder().url(stream.url).header("User-Agent", userAgent()).build()).execute().use {
            assertTrue(it.isSuccessful)
            val body = it.body!!.source().readUtf8Line().orEmpty()
            assertEquals("#EXTM3U", body.trim())
        }
        println("Native CEE: valid typed HLS master playlist")
    }
}
