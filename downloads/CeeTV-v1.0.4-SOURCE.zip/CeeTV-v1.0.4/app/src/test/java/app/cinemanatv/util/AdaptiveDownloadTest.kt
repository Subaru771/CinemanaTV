@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package app.cinemanatv.util

import android.app.Application
import android.net.Uri
import androidx.media3.common.MimeTypes
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.offline.DefaultDownloaderFactory
import androidx.media3.exoplayer.offline.DownloadRequest
import org.junit.Test
import org.junit.Rule
import org.junit.Assert.*
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.util.concurrent.Executor

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28], application=Application::class)
class AdaptiveDownloadTest {
    @get:Rule val folder=TemporaryFolder()
    @Test fun extensionlessHlsDownloadsSegmentsAndCanReadThemWithoutNetwork() {
        val root="https://fixture.example/cinema-stream?url=example"
        val segment="https://fixture.example/segment.ts"
        val media=ByteArray(376) { if(it%188==0) 0x47.toByte() else 0 }
        val files=mapOf(root to "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:3\n#EXT-X-MEDIA-SEQUENCE:0\n#EXTINF:3.0,\n$segment\n#EXT-X-ENDLIST\n".toByteArray(), segment to media)
        var transfers=0
        val upstream=DataSource.Factory {
            object:BaseDataSource(false) {
                var current:Uri?=null
                var input=ByteArrayInputStream(byteArrayOf())
                override fun open(spec:DataSpec):Long {
                    transfers++
                    current=spec.uri
                    val bytes=files[spec.uri.toString()] ?: error("Unexpected fixture request")
                    input=ByteArrayInputStream(bytes)
                    input.skip(spec.position)
                    return bytes.size.toLong()-spec.position
                }
                override fun read(buffer:ByteArray,offset:Int,length:Int)=input.read(buffer,offset,length)
                override fun getUri()=current
                override fun close(){input.close()}
            }
        }
        val database=StandaloneDatabaseProvider(RuntimeEnvironment.getApplication())
        val cache=SimpleCache(folder.newFolder(),NoOpCacheEvictor(),database)
        try {
            val sources=CacheDataSource.Factory().setCache(cache).setUpstreamDataSourceFactory(upstream)
            val request=DownloadRequest.Builder("fixture",Uri.parse(root)).setMimeType(MimeTypes.APPLICATION_M3U8).build()
            val downloader=DefaultDownloaderFactory(sources,Executor { it.run() }).createDownloader(request)
            downloader.download(null)
            assertTrue(transfers>=2)
            val before=transfers
            val offline=CacheDataSource.Factory().setCache(cache).setUpstreamDataSourceFactory(null).createDataSource()
            try {
                offline.open(DataSpec(Uri.parse(segment)))
                val result=ByteArray(376)
                var count=0
                while(count<result.size){val n=offline.read(result,count,result.size-count);check(n>0);count+=n}
                assertArrayEquals(media,result)
                assertEquals(before,transfers)
            } finally { offline.close() }
        } finally { cache.release();database.close() }
    }
}
