package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class MatureSkipAvailabilityTest {
    private val id = "tt1234567"
    @Test fun validMovieHavenSourceShowsPublishedMarkers() {
        val json = JsonParser.parseString("""{
          "imdb_id":"$id", "duration":5400,
          "scenes":[{"reason":"nudity","skip":true,"start":100,"end":115}]
        }""")
        assertEquals(MatureSkipStatus.LISTED, MatureSkipAvailability.movieHavenStatus(json, id))
    }
    @Test fun movieWithNoEligibleScenesDoesNotClaimSkipCoverage() {
        val json = JsonParser.parseString("""{
          "imdb_id":"$id", "duration":5400,
          "scenes":[{"reason":"violence","skip":true,"start":100,"end":115}]
        }""")
        assertEquals(MatureSkipStatus.NOT_LISTED, MatureSkipAvailability.movieHavenStatus(json, id))
    }
    @Test fun mismatchedSourceOrMissingRuntimeStaysUnknown() {
        val mismatch = JsonParser.parseString("""{"imdb_id":"tt7654321","duration":5400,"scenes":[]}""")
        val missing = JsonParser.parseString("""{"imdb_id":"$id","scenes":[]}""")
        assertEquals(MatureSkipStatus.UNKNOWN, MatureSkipAvailability.movieHavenStatus(mismatch, id))
        assertEquals(MatureSkipStatus.UNKNOWN, MatureSkipAvailability.movieHavenStatus(missing, id))
    }
    @Test fun cleanStreamEmptyAndUnreviewedResponsesAreDistinct() {
        val import = JsonParser.parseString("""{
           "imdbId":"$id", "type":"movie", "runtime":null, "releases":[],
           "segments":[{"category":"nudity","startMs":100000,"endMs":115000,
                       "votes":{"up":0,"down":0},"verified":false}]
        }""")
        assertEquals(MatureSkipStatus.LISTED, MatureSkipAvailability.cleanStreamStatus(import, id))
        val empty = JsonParser.parseString("""{
           "imdbId":"$id", "type":"movie", "runtime":null, "releases":[], "segments":[]
        }""")
        assertEquals(MatureSkipStatus.NOT_LISTED, MatureSkipAvailability.cleanStreamStatus(empty, id))
        val malformed = JsonParser.parseString("""{"imdbId":"$id","segments":{}}""")
        assertEquals(MatureSkipStatus.UNKNOWN, MatureSkipAvailability.cleanStreamStatus(malformed, id))
    }

    @Test fun validatedCleanStreamSegmentsShowMarkers() {
        val json = JsonParser.parseString("""{
          "imdbId":"$id", "type":"movie", "releases":[{"runtime":5400000}],
          "segments":[{"category":"nudity","startMs":100000,"endMs":115000,
                       "votes":{"up":4,"down":0}}]
        }""")
        assertEquals(MatureSkipStatus.LISTED, MatureSkipAvailability.cleanStreamStatus(json, id))
    }
    @Test fun downvotedRowsAndBadReleasesDoNotCountAsAvailable() {
        val untrusted = JsonParser.parseString("""{
          "imdbId":"$id", "type":"movie", "releases":[{"runtime":5400000}],
          "segments":[{"category":"nudity","startMs":100000,"endMs":115000,
                       "votes":{"up":0,"down":1}}]
        }""")
        assertEquals(MatureSkipStatus.NOT_LISTED, MatureSkipAvailability.cleanStreamStatus(untrusted, id))
        val missingRuntime = JsonParser.parseString("""{
          "imdbId":"$id", "type":"movie", "releases":[], "segments":[]
        }""")
        assertEquals(MatureSkipStatus.NOT_LISTED, MatureSkipAvailability.cleanStreamStatus(missingRuntime, id))
    }
}
