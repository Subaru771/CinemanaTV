package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class CeeAlternativeRoutingTest {
    @Test fun ceeIsThePrimaryMetadataAndPlaybackBackend() = runBlocking {
        val calls=mutableListOf<String>()
        val backend=object:StubCeeCatalog(){
            override suspend fun detail(video:Video):Video { calls+="detail";return video.copy(enContent="Real CEE metadata") }
            override suspend fun sources(id:String):PlaySources { calls+="sources";return PlaySources(listOf(QualityOption(480,"https://node.cdnz.quest/video.mp4")),emptyList()) }
        }
        val repository=Repository(backend)
        val video=Video(nb="cee_123",enTitle="CEE title",providerPageId="123")
        assertEquals("Real CEE metadata",repository.info(video).description)
        assertEquals(1,repository.loadSources(video.id).qualities.size)
        assertEquals(listOf("detail","sources"),calls)
    }
    @Test fun sourcePrefetchIsSingleUseAndDoesNotChangeIdentity() = runBlocking {
        val backend=object:StubCeeCatalog(){
            override suspend fun sources(id:String)=PlaySources(listOf(QualityOption(480,"https://node.cdnz.quest/video.mp4")),emptyList())
        }
        val repository=Repository(backend)
        repository.prefetchSources("cee_123")
        assertNotNull(repository.takePrefetched("cee_123"))
        assertNull(repository.takePrefetched("cee_123"))
    }
}
