package app.cinemanatv.util

import org.junit.Assert.assertEquals
import org.junit.Test

class SmartQualityTest {
    private val options = listOf(2160, 1080, 720, 480).map { SmartQuality.Option(it) }

    @Test fun bandwidthChoosesActualProviderQuality() {
        assertEquals(1, SmartQuality.choose(options, 12.0, 2160)) // 1080p
        assertEquals(2, SmartQuality.choose(options, 6.0, 2160)) // 720p
        assertEquals(3, SmartQuality.choose(options, 2.0, 2160)) // 480p
    }

    @Test fun respectsMaximumAndEmptyOptions() {
        assertEquals(2, SmartQuality.choose(options, 100.0, 720))
        assertEquals(-1, SmartQuality.choose(emptyList(), 100.0, 2160))
    }

    @Test fun doesNotInventResolutionWhenBandwidthMissing() {
        assertEquals(2, SmartQuality.choose(options, Double.NaN, 2160))
        assertEquals(0, SmartQuality.choose(listOf(SmartQuality.Option(1080)), 0.0, 2160))
    }

    @Test fun preferredResolutionIgnoresColdBandwidthEstimate() {
        assertEquals(1, SmartQuality.preferredIndex(options, 1080))
        assertEquals(0, SmartQuality.preferredIndex(options, 2160))
        assertEquals(2, SmartQuality.preferredIndex(options, 720))
        assertEquals(3, SmartQuality.preferredIndex(options, 480))
    }

    @Test fun preferredResolutionFallsBackPredictably() {
        assertEquals(2, SmartQuality.preferredIndex(options, 900)) // highest below
        assertEquals(3, SmartQuality.preferredIndex(options, 240)) // smallest above
        assertEquals(0, SmartQuality.preferredIndex(listOf(SmartQuality.Option(0, true)), 1080))
        assertEquals(1, SmartQuality.preferredIndex(
            listOf(SmartQuality.Option(0, true), SmartQuality.Option(720)), 1080))
        assertEquals(-1, SmartQuality.preferredIndex(options, 0))
        assertEquals(-1, SmartQuality.preferredIndex(emptyList(), 720))
    }

    @Test fun limitsSwitchToOneRung() {
        assertEquals(1, SmartQuality.nextIndex(0, 3, options))
        assertEquals(2, SmartQuality.nextIndex(3, 0, options))
        assertEquals(1, SmartQuality.nextIndex(1, 1, options))
    }
}
