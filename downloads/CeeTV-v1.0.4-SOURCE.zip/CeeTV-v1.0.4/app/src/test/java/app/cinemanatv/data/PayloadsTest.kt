package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class PayloadsTest {
    private fun json(s: String) = JsonParser.parseString(s)

    @Test fun parsesReferenceModelFieldNames() {
        val result = Payloads.videos(json("""
            {"result":{"items":[
              {"id":472,"englishTitle":"Arrival","arabicTitle":"وصول","imageThumbMediumUrl":"https://img.example/poster.jpg"},
              {"nb":"473","ar_title":"فيلم عربي","imgMediumThumbObjUrl":"https://img.example/ar.jpg"}
            ]}}
        """))
        assertEquals(2, result.size)
        assertEquals("472", result[0].id)
        assertEquals("Arrival", result[0].title)
        assertEquals("https://img.example/poster.jpg", result[0].poster)
        assertEquals("فيلم عربي", result[1].title)
    }

    @Test fun ignoresNonVideosAndDeduplicates() {
        val result = Payloads.videos(json("""
            {"data":[{"id":"4","title":"Real"},{"id":"4","title":"Duplicate"},{"irrelevant":"ignored"},{"id":"5"}]}
        """))
        assertEquals(1, result.size)
        assertEquals("Real", result.first().title)
    }

    @Test fun handlesNestedQualityLadderAnd4K() {
        val options = Payloads.sources(json("""
          {"videoFile":{"transcodedFiles":[
            {"resolution":"1920x1080","videoUrl":"https://cdn.example/1080.mp4"},
            {"name":"4K UHD","url":"https://cdn.example/2160.m3u8"},
            {"name":"720p","file":"https://cdn.example/720.mp4"}
          ]}}
        """))
        assertEquals(listOf(2160, 1080, 720), options.map { it.height })
        assertEquals("4K (2160p)", options[0].label)
    }

    @Test fun acceptsQualityMap() {
        val options = Payloads.sources(json("""{"qualities":{"2160p":"https://cdn.example/4k.m3u8", "1080p":"https://cdn.example/hd.mp4"}}"""))
        assertEquals(listOf(2160, 1080), options.map { it.height })
    }

    @Test fun unknownResolutionStillProducesPlayableSource() {
        val options = Payloads.sources(json("""[{"url":"https://cdn.example/video.mp4"}]"""))
        assertEquals(1, options.size)
        assertEquals(0, options[0].height)
        assertEquals("Auto", options[0].label)
    }

    @Test fun rejectsLocalFileUrlsAndParsesSubtitles() {
        assertEquals(0, Payloads.sources(json("""[{"name":"4K","url":"file:///etc/passwd"}]""")).size)
        val subs = Payloads.subtitles(json("""
            {"data":{"enTranslationFilePath":"https://cdn.example/en.vtt", "translations":[
               {"name":"العربية","file":"https://cdn.example/ar.srt"}
            ]}}
        """))
        assertEquals(2, subs.size)
        assertEquals("text/vtt", subs.first().mime)
        assertEquals("application/x-subrip", subs.last().mime)
    }

    @Test fun neverTreatsPostersAsStreams() {
        val options = Payloads.sources(json("""
            {"id":"9","title":"X","imgObjUrl":"https://img.example/p.jpg","imgThumbObjUrl":"https://img.example/t.png",
             "videoFile":{"transcodedFiles":[{"resolution":"720","videoUrl":"https://cdn.example/720.mp4"}]}}
        """))
        assertEquals(listOf("https://cdn.example/720.mp4"), options.map { it.url })
    }

    @Test fun progressiveFlagExcludesPlaylists() {
        assertTrue(QualityOption(720, "https://cdn.example/a.mp4?x=1").progressive)
        assertFalse(QualityOption(720, "https://cdn.example/a.m3u8").progressive)
    }

    @Test fun detailPicksUpCertificateAndAdultFlagFromRawRecord() {
        val fallback = Video(nb = "9", enTitle = "X")
        val d = Payloads.detail(json("""{"nb":"9","en_title":"X","mpaa_rating":"R","is_adult":"1"}"""), fallback)
        assertEquals("R", d.filmRating)
        assertTrue(d.adult?.asString == "1")
    }

    @Test fun arabicOnlyGenreTagIsVisibleToTheFilter() {
        val v = Payloads.videos(json("""[{"nb":"1","en_title":"T","categories":[{"id":"5","ar_title":"للكبار فقط"}]}]""")).first()
        assertTrue(v.allTags.contains("للكبار فقط"))
        assertFalse(MediaContentFilter.allowed(v, ContentFilterMode.HIDE_MATURE))
    }

    @Test fun partialDetailAddsImdbWithoutLosingCatalogueMetadata() {
        val fallback = Video(nb = "9", kind = "1", enTitle = "Arrival", arTitle = "وصول",
            enContent = "Catalogue description", stars = "7.9", year = "2016",
            imgObjUrl = "https://img.example/backdrop.jpg", imgMediumThumbObjUrl = "https://img.example/poster.jpg",
            filmRating = "PG-13", categories = json("""["Drama"]"""), introStartMs = 1_000L, introEndMs = 20_000L)
        val d = Payloads.detail(json("""{"data":{"imdbUrl":"https://www.imdb.com/title/tt2543164/"}}"""), fallback)
        assertEquals(fallback.copy(imdbRef = "https://www.imdb.com/title/tt2543164/"), d)
    }

    @Test fun matchingDetailCanOmitTitleAndRetainBlankOrNullFallbackFields() {
        val fallback = Video(nb = "9", enTitle = "Arrival", imgObjUrl = "https://img.example/p.jpg",
            enContent = "Existing description", rootSeries = "8", season = "2", episodeNummer = "3")
        val d = Payloads.detail(json("""{"result":{"id":9,"englishTitle":" ","description":null,
            "imageObjUrl":"","imdbID":"tt2543164","introStartMs":1000,"introEndMs":20000}}"""), fallback)
        assertEquals(fallback.copy(imdbRef = "tt2543164", introStartMs = 1_000L, introEndMs = 20_000L), d)
    }

    @Test fun choosesMatchingIdRatherThanFirstUnrelatedTitle() {
        val d = Payloads.detail(json("""{"results":[
            {"id":"10","title":"Unrelated","imdbID":"tt0120338"},
            {"id":"9","imdbID":"tt2543164"}
        ]}"""), Video(nb = "9", enTitle = "Arrival"))
        assertEquals("9", d.id)
        assertEquals("Arrival", d.title)
        assertEquals("tt2543164", d.imdbRef)
    }

    @Test fun neverBorrowsImdbFromRelatedOrMismatchedRecords() {
        val fallback = Video(nb = "9", enTitle = "Arrival")
        val responses = listOf(
            """{"data":{"related":[{"id":"10","title":"Unrelated","imdbID":"tt0120338"}]}}""",
            """{"data":{"id":"10","title":"Arrival","imdbID":"tt0120338"}}""",
            """{"data":{"title":"Unrelated","imdbID":"tt0120338"}}""",
            """{"data":[{"imdbID":"tt0120338"},{"imdbID":"tt2543164"}]}"""
        )
        responses.forEach { assertEquals(it, fallback, Payloads.detail(json(it), fallback)) }
    }

    @Test fun directPartialMetadataIgnoresNestedRelatedTitle() {
        val d = Payloads.detail(json("""{"data":{"imdb_url":"tt2543164",
            "related":{"id":"10","title":"Unrelated","imdbID":"tt0120338"}}}"""),
            Video(nb = "9", enTitle = "Arrival"))
        assertEquals("9", d.id)
        assertEquals("tt2543164", d.imdbRef)
    }

    @Test fun imdbAliasesUseRealGsonForCatalogueAndPartialDetails() {
        listOf("imdbUrlRef", "imdbID", "imdbId", "imdb_id", "imdbURL", "imdbLink", "imdbUrl", "imdb_url", "imdb").forEach { key ->
            val d = Payloads.detail(json("""{"$key":"tt2543164"}"""), Video(nb = "9", enTitle = "Arrival"))
            assertEquals(key, "tt2543164", d.imdbRef)
            val card = Payloads.videos(json("""{"id":"9","title":"Arrival","$key":"tt2543164"}""")).single()
            assertEquals(key, "tt2543164", card.imdbRef)
        }
    }

    @Test fun malformedImdbMetadataDoesNotDiscardVideoOrOverwriteKnownReference() {
        val fallback = Video(nb = "9", enTitle = "Arrival", imdbRef = "tt2543164")
        listOf("2543164", "7.9", "null", "{}", "[]", "\"7.9\"", "\"\"").forEach { value ->
            val raw = """{"id":"9","title":"Arrival","description":"Detail description","imdb":$value}"""
            val d = Payloads.detail(json(raw), fallback)
            assertEquals(value, "tt2543164", d.imdbRef)
            assertEquals(value, "Detail description", d.description)
            assertEquals(value, "Arrival", Payloads.videos(json(raw)).single().title)
        }
    }

    @Test fun numericImdbScoreCannotOverrideValidUrlAliasInSameRecord() {
        val raw = json("""{"id":"9","title":"Arrival","imdbUrlRef":"https://www.imdb.com/title/tt2543164/",
            "imdb":7.9,"imdbID":null}""")
        assertEquals("https://www.imdb.com/title/tt2543164/", Payloads.videos(raw).single().imdbRef)
        assertEquals("https://www.imdb.com/title/tt2543164/",
            Payloads.detail(raw, Video(nb = "9", enTitle = "Arrival")).imdbRef)
    }
}
