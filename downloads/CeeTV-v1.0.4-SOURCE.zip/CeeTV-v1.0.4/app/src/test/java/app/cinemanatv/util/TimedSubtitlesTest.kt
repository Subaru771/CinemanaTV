package app.cinemanatv.util

import org.junit.Assert.*
import org.junit.Test

class TimedSubtitlesTest {
    @Test fun preservesOverlappingCuesAndShiftsBothDirections() {
        val cues = parseTimedSubtitles("""1
00:00:02,000 --> 00:00:05,000
Hello

2
00:00:03,000 --> 00:00:04,000
مرحبا
""")
        assertEquals(2, activeCaptions(cues, 3_500L, 0L).size)
        assertEquals(0, activeCaptions(cues, 3_500L, 2_000L).size)
        assertEquals(2, activeCaptions(cues, 1_500L, -2_000L).size)
    }
    @Test fun supportsWebVttAndRejectsMalformed() {
        val cues = parseTimedSubtitles("""WEBVTT

00:03.500 --> 00:04.500
Hello there
""")
        assertEquals("Hello there", cues.single().text)
        assertEquals(emptyList<TimedCaption>(), parseTimedSubtitles("bogus subtitle"))
    }
}
