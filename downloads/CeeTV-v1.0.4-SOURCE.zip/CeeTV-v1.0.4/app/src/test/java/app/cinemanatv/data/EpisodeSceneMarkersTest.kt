package app.cinemanatv.data
import org.junit.Assert.*
import org.junit.Test
class EpisodeSceneMarkersTest {
    private fun resource(name: String) = javaClass.getResource("/episode-markers/$name")!!.readText()
    @Test fun resolvesAnotherSeriesWithoutTitleSpecificRules() {
        val page = resource("bb-series.html")
        assertEquals("/exchange/videos/925/",EpisodeSceneMarkers.episodePath(page,"tt0903747",1,1))
        assertNull(EpisodeSceneMarkers.episodePath(page,"tt0944947",1,1))
    }
    @Test fun discoversSeriesAndMoviesSeparatelyFromActualSearchPages() {
        assertEquals(listOf("/exchange/series/1105/","/exchange/series/10641/"),
            EpisodeSceneMarkers.candidates(resource("search-bb.html"),true))
        assertEquals(listOf("/exchange/videos/498/","/exchange/videos/7757/"),
            EpisodeSceneMarkers.candidates(resource("search-matrix.html"),false))
    }
    @Test fun matchingTitlesCannotSubstituteForExactImdbIdentity() {
        assertTrue(EpisodeSceneMarkers.confirmsImdb("href=\"https://imdb.com/title/tt0133093/\"", "tt0133093"))
        assertFalse(EpisodeSceneMarkers.confirmsImdb("href=\"https://imdb.com/title/tt01330934/\"", "tt0133093"))
        assertFalse(EpisodeSceneMarkers.confirmsImdb("The Matrix", "tt0133093"))
    }
    @Test fun legacyFilesWithoutActionProducePublishedRanges() {
        assertEquals(5,EpisodeSceneMarkers.parse(resource("bb-legacy.txt"),3_720_000L).size)
        assertEquals(1,EpisodeSceneMarkers.parse(resource("matrix-legacy.txt"),9_000_000L).size)
    }
    @Test fun choosesExactEpisodeNotAdjacentEpisode() {
        val page = resource("got-series.html")
        assertEquals("/exchange/videos/435/", EpisodeSceneMarkers.episodePath(page,"tt0944947",1,1))
        assertEquals("/exchange/videos/438/", EpisodeSceneMarkers.episodePath(page,"tt0944947",1,2))
        assertNull(EpisodeSceneMarkers.episodePath(page,"tt0903747",1,1))
        assertNull(EpisodeSceneMarkers.episodePath(page,"tt0944947",99,1))
    }
    @Test fun realPublishedEpisodeFileReachesSkipDecision() {
        val markers = EpisodeSceneMarkers.parse(resource("got-s1e1.txt"),3_720_000)
        assertEquals(6,markers.size)
        val ranges = SceneSkipping.normalize(markers.map { SceneRange(it.startMs,it.endMs) })
        for (r in ranges) assertTrue(SceneSkipping.skipTarget(r.startMs,ranges,3_720_000)!! >= r.endMs)
    }
    @Test fun wrongCutRejectsEntireFile() {
        assertTrue(EpisodeSceneMarkers.parse(resource("got-s1e1.txt"),3_000_000).isEmpty())
    }
    @Test fun muteAndUnrelatedCategoriesDoNotBecomeSkips() {
        assertTrue(EpisodeSceneMarkers.parse("0:01:00 --> 0:01:10\nsex mute 3\n\n0:02:00 --> 0:02:10\nviolence skip 3",3_720_000).isEmpty())
    }
    @Test fun seriesDetailQueuePreservesParentIdentityForPlayer() {
        val ep=MediaContentFilter.withParentRating(Video(nb="ep",episodeNummer="1",imdbRef="tt1480055"),
            Video(nb="parent",imdbRef="tt0944947"))
        assertEquals("parent",ep.rootSeries)
        assertEquals("tt0944947",EpisodeSceneMarkers.seriesImdb(ep,null))
    }
    @Test fun parentSeriesIdWinsOverEpisodeImdb() {
        val ep=Video(imdbRef="tt1480055",episodeNummer="1",rootSeriesInfo=Video(imdbRef="tt0944947"))
        assertEquals("tt0944947",EpisodeSceneMarkers.seriesImdb(ep,null))
        assertNull(EpisodeSceneMarkers.seriesImdb(Video(imdbRef="tt1480055"),null))
    }
}
