package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

class CeeRecheckLiveTest {
    private val http = OkHttpClient.Builder().callTimeout(25,TimeUnit.SECONDS).build()
    private fun get(url:String):String = http.newCall(Request.Builder().url(url).header("User-Agent",userAgent()).build()).execute().use {
        check(it.isSuccessful) { "HTTP ${it.code} on ${it.request.url.host}" }; it.body!!.string()
    }
    @Test fun currentHomeTitlesHaveArtworkDetailsAndResolvableStreams() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1")
        val backend=CeeHtmlCatalog()
        val home=backend.home(null)
        for(kind in listOf(1,2)) assertTrue(backend.home(kind).rows.isNotEmpty())
        val sample=home.rows.first { it.title=="Latest movies" }.items.take(3)+
            home.rows.first { it.title=="Latest episodes" }.items.take(2)
        for(v in sample) {
            val d=backend.detail(v)
            assertEquals(v.id,d.id)
            assertTrue(d.title.isNotBlank())
            if(v.episodeNumber>0) {
                assertEquals("Episode number lost for ${v.id}",v.episodeNumber,d.episodeNumber)
                assertEquals("Season lost for ${v.id}",v.seasonNumber,d.seasonNumber)
            }
            val poster=v.poster ?: error("Missing poster for ${v.id}")
            http.newCall(Request.Builder().url(poster).build()).execute().use {
                assertTrue("Poster unavailable for ${v.id}: ${it.code}",it.isSuccessful)
                assertTrue(it.header("Content-Type").orEmpty().startsWith("image/"))
            }
            assertTrue("No stream for ${v.id}",backend.sources(v.id).qualities.isNotEmpty())
            println("Recheck: ${v.id}: details, poster and source resolved")
        }
        assertTrue(backend.search("ليل").isNotEmpty())
    }
    @Test fun hlsVariantAndSegmentAreReadable() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1")
        val source=CeeHtmlCatalog().sources("cee_2148687").qualities.first()
        val master=get(source.url)
        assertTrue(master.startsWith("#EXTM3U"))
        val variant=master.lineSequence().map { it.trim() }.first { it.isNotEmpty() && !it.startsWith("#") }
        val address=source.url.toHttpUrl().resolve(variant)!!.toString()
        val media=get(address)
        assertTrue(media.startsWith("#EXTM3U"))
        val segment=media.lineSequence().map { it.trim() }.first { it.isNotEmpty() && !it.startsWith("#") }
        val segmentUrl=address.toHttpUrl().resolve(segment)!!
        http.newCall(Request.Builder().url(segmentUrl).header("Range","bytes=0-511").build()).execute().use {
            assertTrue(it.isSuccessful)
            val bytes=it.body!!.source().readByteArray(376)
            assertEquals(0x47,bytes[0].toInt() and 255)
            assertEquals(0x47,bytes[188].toInt() and 255)
        }
        println("Recheck: HLS master, variant and MPEG-TS segment readable")
    }
}
