package app.cinemanatv.data
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
class VkRouteLiveTest {
    @Test fun formerlyVkTitleResolvesTheCurrentActiveHlsPlayer()=runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1")
        val source=CeeAlternativeSource.resolve("cee_3217325")
        assertTrue(source.qualities.isNotEmpty())
        assertNull(source.vkPlayerUrl)
        assertEquals("application/x-mpegURL",source.qualities.first().mimeType)
        println("Former VK title resolves current active HLS source; old iframe is commented out")
    }
}
