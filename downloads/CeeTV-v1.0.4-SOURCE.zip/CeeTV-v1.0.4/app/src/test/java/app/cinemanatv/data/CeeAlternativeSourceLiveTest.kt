package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.util.concurrent.TimeUnit

/** Optional provider smoke test; ordinary unit tests never depend on a live website. */
class CeeAlternativeSourceLiveTest {
    @Test fun selectedPageResolvesToReadableNativeMedia() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST") == "1")
        val selected = CeeAlternativeSource.search("https://cinamana.cc/watch=3216134/").single()
        assertEquals("cee_3216134", selected.id)
        assertTrue(selected.title.isNotBlank())
        val streams = CeeAlternativeSource.resolve(selected.id).qualities
        assertTrue(streams.isNotEmpty())
        val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
        val request = Request.Builder().url(streams.first().url)
            .header("Range", "bytes=0-511")
            .header("User-Agent", "Android-TV 12;40510;AB CBOX 3.0")
            .header("Accept-Encoding", "identity").build()
        http.newCall(request).execute().use { response ->
            assertEquals(206, response.code)
            assertTrue(response.header("Content-Type").orEmpty().startsWith("video/mp4"))
            val first = ByteArray(12)
            response.body!!.byteStream().use { input ->
                var offset = 0
                while (offset < first.size) {
                    val count = input.read(first, offset, first.size - offset)
                    check(count > 0) { "Media response was truncated" }
                    offset += count
                }
            }
            assertEquals("ftyp", String(first.copyOfRange(4, 8), Charsets.US_ASCII))
            println("CEE live check: ${streams.size} qualities; ${response.request.url.host}; HTTP ${response.code}; valid MP4 header")
        }
    }
}
