package app.cinemanatv.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ContentMaturityTest {
    private fun visible(rating: String?, mode: ContentFilterMode,
                        genre: List<String> = emptyList(), explicit: Boolean = false,
                        parentRating: String? = null): Boolean =
        ContentMaturity.allowed(rating, genre, explicit, mode, parentRating)

    @Test fun offDoesNotHideTitles() {
        assertTrue(visible("NC-17", ContentFilterMode.OFF))
        assertTrue(visible(null, ContentFilterMode.OFF, listOf("Erotica")))
    }

    @Test fun hideMatureCatchesAgeRatings() {
        listOf("R", "NC-17", "TV-MA", "16+", "18", "18A", "MA15+").forEach {
            assertFalse("Should hide $it", visible(it, ContentFilterMode.HIDE_MATURE))
        }
        listOf("PG", "PG-13", "TV-14", null, "NR").forEach {
            assertTrue("Should show $it", visible(it, ContentFilterMode.HIDE_MATURE))
        }
    }

    @Test fun familyModeRequiresYoungRatingAndBlocksUnknown() {
        listOf("G", "PG", "TV-Y7", "TV-PG", "12+").forEach {
            assertTrue("Should permit $it", visible(it, ContentFilterMode.FAMILY))
        }
        listOf("PG-13", "TV-14", "R", "NC-17", "16+", "18+", null, "NR", "8.4").forEach {
            assertFalse("Should block $it", visible(it, ContentFilterMode.FAMILY))
        }
    }

    @Test fun explicitSignalsOverrideLowRating() {
        assertFalse(visible("G", ContentFilterMode.FAMILY, explicit = true))
        assertFalse(visible("PG", ContentFilterMode.HIDE_MATURE, listOf("Erotica")))
        assertFalse(visible("PG", ContentFilterMode.FAMILY, listOf("للكبار فقط")))
    }

    @Test fun seriesCertificateCanBeInherited() {
        assertTrue(visible(null, ContentFilterMode.FAMILY, parentRating = "PG"))
        assertFalse(visible("G", ContentFilterMode.FAMILY, parentRating = "TV-MA"))
    }

    @Test fun widerCertificateSpellingsAreHidden() {
        listOf("Rated R", "R-RATED", "TV-MA-L", "tv ma", "Restricted", "+18", "NC17").forEach {
            assertFalse("Should hide $it", visible(it, ContentFilterMode.HIDE_MATURE))
        }
    }
}
