package app.cinemanatv.util

import org.junit.Assert.*
import org.junit.Test

class AppUpdateCheckerTest {
    private val manifest = """{
      "schema":1,
      "tv":{"enabled":true,"version":"1.3.0","versionCode":130,
        "downloadUrl":"https://example.org/CinemanaTV.apk",
        "notes":{"en":"New version","ar":"نسخة جديدة"}},
      "ios":{"enabled":true,"version":"3.0.0","build":999,"downloadUrl":"https://example.org/ios.ipa"}
    }"""

    @Test fun newerVersionTriggersNotice() {
        val update = AppUpdateChecker.parseManifest(manifest, 120)
        assertNotNull(update)
        assertEquals(130L, update!!.versionCode)
        assertEquals("1.3.0", update.versionName)
        assertEquals("New version", update.notes)
        assertEquals("نسخة جديدة", update.notesArabic)
    }
    @Test fun sameOrOlderVersionsNeverTrigger() {
        assertNull(AppUpdateChecker.parseManifest(manifest, 130))
        assertNull(AppUpdateChecker.parseManifest(manifest, 140))
    }
    @Test fun disabledAndMismatchedSchemaNeverTrigger() {
        assertNull(AppUpdateChecker.parseManifest(manifest.replace("\"enabled\":true", "\"enabled\":false"), 120))
        assertNull(AppUpdateChecker.parseManifest(manifest.replace("\"schema\":1", "\"schema\":2"), 120))
    }
    @Test fun unsafeAndMalformedUrlsRejected() {
        assertNull(AppUpdateChecker.parseManifest(manifest.replace("https://example.org/CinemanaTV.apk", "http://example.org/a.apk"), 120))
        assertNull(AppUpdateChecker.parseManifest(manifest.replace("https://example.org/CinemanaTV.apk", "javascript:alert(1)"), 120))
        assertNull(AppUpdateChecker.parseManifest("{oops", 120))
    }
    @Test fun missingRequiredFieldsRejected() {
        assertNull(AppUpdateChecker.parseManifest("""{"schema":1,"tv":{"enabled":true,"version":"1.3.0","versionCode":130}}""", 120))
    }
}
