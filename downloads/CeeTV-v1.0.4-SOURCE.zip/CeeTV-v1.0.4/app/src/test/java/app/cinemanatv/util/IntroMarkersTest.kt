package app.cinemanatv.util

import org.junit.Assert.*
import org.junit.Test

class IntroMarkersTest {
    @Test fun parsesSecondsAndTimecodes() {
        assertEquals(42_500L, parseIntroStamp("42.5"))
        assertEquals(90_000L, parseIntroStamp("01:30"))
        assertEquals(3_650_000L, parseIntroStamp("01:00:50"))
    }
    @Test fun rejectsMissingOrInventedMarkers() {
        assertNull(introWindow(null, 120_000L))
        assertNull(introWindow(0L, 0L))
        assertNull(introWindow(0L, 700_000L))
        assertEquals(20_000L until 80_000L, introWindow(20_000L, 80_000L))
    }
}
