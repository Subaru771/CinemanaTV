package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test

class MatureSkipMediaTest {
    @Test fun movieCardsWithEmptyOrZeroParentIdsAreNotExcluded() {
        for (root in listOf(null, "", " ", "0")) {
            assertTrue(Video(kind = "1", rootSeries = root).supportsPublicMatureMarkers)
            assertTrue(Video(rootSeries = root).supportsPublicMatureMarkers)
        }
    }

    @Test fun episodeAndSeriesNeverUseMovieTimestamps() {
        assertFalse(Video(kind = "2").supportsPublicMatureMarkers)
        assertFalse(Video(kind = "1", episodeNummer = "3").supportsPublicMatureMarkers)
        assertFalse(Video(rootSeries = "42").supportsPublicMatureMarkers)
    }
}
