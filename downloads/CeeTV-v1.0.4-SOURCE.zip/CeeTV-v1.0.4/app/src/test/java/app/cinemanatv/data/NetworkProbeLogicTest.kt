package app.cinemanatv.data

import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkProbeLogicTest {
    @Test fun acceptedStream() {
        assertTrue(NetworkProbeLogic.response(206, "video/mp4").contains("accepted"))
    }
    @Test fun providerRefusal() {
        assertTrue(NetworkProbeLogic.response(403, null).contains("denied access"))
        assertTrue(NetworkProbeLogic.response(451, null).contains("restriction"))
    }
    @Test fun captivePortalHtmlIsNotPlaybackSuccess() {
        assertTrue(NetworkProbeLogic.response(200, "text/html").contains("web page"))
    }
    @Test fun expiredLinkIsSeparate() {
        assertTrue(NetworkProbeLogic.response(404, null).contains("expired"))
    }
    @Test fun dnsFailureIsDistinct() {
        assertTrue(NetworkProbeLogic.failure("UnknownHostException").contains("DNS"))
    }
}
