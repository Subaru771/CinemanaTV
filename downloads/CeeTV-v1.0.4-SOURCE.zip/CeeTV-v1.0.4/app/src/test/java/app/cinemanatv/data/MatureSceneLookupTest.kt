package app.cinemanatv.data

import com.google.gson.JsonParser
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

class MatureSceneLookupTest {
    private val imdb = "tt0120338"
    private val durationMs = 11_700_000L
    private fun json(body: String) = MatureSceneLookup.Fetch.Json(JsonParser.parseString(body))
    private fun legacy(runtime: String = "null", start: Long = 3_720_000L) = json("""{
        "imdbId":"$imdb","type":"movie","runtime":$runtime,"releases":[],
        "segments":[{"startMs":$start,"endMs":${start + 60_000},"category":"nudity",
          "votes":{"up":0,"down":0},"verified":false}]
    }""")

    @Test fun legacyCommunityMarkersBecomeActualSkipTargets() = runBlocking {
        val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
            if (url.contains("cleanstream")) legacy() else MatureSceneLookup.Fetch.Missing
        }
        assertEquals(MatureSceneLookupStatus.READY, result.status)
        assertFalse(result.hasTransientFailure)
        val range = result.markers.single()
        assertEquals(3_718_500L, range.startMs)
        val normalized = SceneSkipping.normalize(listOf(SceneRange(range.startMs, range.endMs)))
        assertEquals(3_781_250L, SceneSkipping.skipTarget(3_719_000L, normalized, durationMs))
    }

    @Test fun capturedLiveTitanicResponseReachesPlaybackSkipDecision() = runBlocking {
        // Captured from https://cleanstream.elfhosted.com/api/filters/tt0120338,
        // 2026-11-09. Playback duration is supplied by the video, not this runtime-null response.
        val fixture = javaClass.getResourceAsStream("/scene-markers/cleanstream-tt0120338.json")!!
            .bufferedReader().use { JsonParser.parseReader(it) }
        val actualDuration = 11_640_000L
        val result = MatureSceneLookup.lookup(imdb, actualDuration) { url ->
            if (url.contains("cleanstream")) MatureSceneLookup.Fetch.Json(fixture)
            else MatureSceneLookup.Fetch.Missing
        }
        assertEquals(MatureSceneLookupStatus.READY, result.status)
        val matureRows = fixture.asJsonObject.getAsJsonArray("segments")
            .filter { it.asJsonObject.get("category").asString in setOf("nudity", "sex") }
        assertTrue(matureRows.isNotEmpty())
        val ranges = SceneSkipping.normalize(result.markers.map { SceneRange(it.startMs, it.endMs) })
        for (row in matureRows) {
            val start = row.asJsonObject.get("startMs").asLong
            val end = row.asJsonObject.get("endMs").asLong
            val seekTo = SceneSkipping.skipTarget(start, ranges, actualDuration)
            assertNotNull("The published mature marker must reach the skip decision", seekTo)
            assertTrue("The seek must land past the published mature scene", seekTo!! > end)
        }
    }

    @Test fun temporaryFailureCanRecoverOnTheNextAttempt() = runBlocking {
        var available = false
        val fetch: suspend (String) -> MatureSceneLookup.Fetch = { url ->
            when {
                !url.contains("cleanstream") -> MatureSceneLookup.Fetch.Missing
                available -> legacy()
                else -> MatureSceneLookup.Fetch.Failed
            }
        }
        val first = MatureSceneLookup.lookup(imdb, durationMs, fetch)
        assertEquals(MatureSceneLookupStatus.NETWORK_ERROR, first.status)
        assertTrue(first.hasTransientFailure)
        available = true
        val second = MatureSceneLookup.lookup(imdb, durationMs, fetch)
        assertEquals(MatureSceneLookupStatus.READY, second.status)
        assertEquals(1, second.markers.size)
    }

    @Test fun bothMatureSourcesStartTogetherWithoutRequestingIntroServices() = runBlocking {
        val count = AtomicInteger()
        val bothStarted = CompletableDeferred<Unit>()
        val result = withTimeout(5_000) {
            MatureSceneLookup.lookup(imdb, durationMs) { url ->
                assertTrue(url.contains("MovieHavenDB") || url.contains("cleanstream"))
                if (count.incrementAndGet() == 2) bothStarted.complete(Unit)
                bothStarted.await()
                if (url.contains("cleanstream")) legacy() else MatureSceneLookup.Fetch.Missing
            }
        }
        assertEquals(2, count.get())
        assertEquals(MatureSceneLookupStatus.READY, result.status)
    }

    @Test fun partialFailureDoesNotHoldBackUsableMarkers() = runBlocking {
        val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
            if (url.contains("cleanstream")) legacy() else MatureSceneLookup.Fetch.Failed
        }
        assertEquals(MatureSceneLookupStatus.READY, result.status)
        assertEquals(1, result.markers.size)
        assertTrue(result.hasTransientFailure)
    }

    @Test fun validEmptyResponseAndMissingSourcesAreDefinitiveNegatives() = runBlocking {
        val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
            if (url.contains("cleanstream")) json("""{"imdbId":"$imdb","segments":[]}""")
            else MatureSceneLookup.Fetch.Missing
        }
        assertEquals(MatureSceneLookupStatus.NO_MARKERS, result.status)
        assertFalse(result.hasTransientFailure)
        assertTrue(result.markers.isEmpty())
    }

    @Test fun malformedAndMismatchedResponsesNeverBecomeNoMarkers() = runBlocking {
        for (body in listOf(
            """{"imdbId":"$imdb","segments":{}}""",
            """{"imdbId":"tt0111161","segments":[]}""",
        )) {
            val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
                if (url.contains("cleanstream")) json(body) else MatureSceneLookup.Fetch.Missing
            }
            assertEquals(MatureSceneLookupStatus.NETWORK_ERROR, result.status)
            assertTrue(result.hasTransientFailure)
        }
    }

    @Test fun knownDifferentCutIsReportedWithoutAcceptingItsMarkers() = runBlocking {
        val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
            if (url.contains("cleanstream")) legacy(runtime = "${durationMs + 10_000}")
            else MatureSceneLookup.Fetch.Missing
        }
        assertEquals(MatureSceneLookupStatus.CUT_MISMATCH, result.status)
        assertFalse(result.hasTransientFailure)
        assertTrue(result.markers.isEmpty())
    }

    @Test fun unknownRuntimeMarkersMustStillFitTheActualVideo() = runBlocking {
        val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
            if (url.contains("cleanstream")) legacy(start = durationMs + 5_000)
            else MatureSceneLookup.Fetch.Missing
        }
        assertEquals(MatureSceneLookupStatus.CUT_MISMATCH, result.status)
        assertTrue(result.markers.isEmpty())
    }

    @Test fun movieHavenRuntimeMismatchIsDistinguishedFromNoCoverage() = runBlocking {
        val result = MatureSceneLookup.lookup(imdb, durationMs) { url ->
            if (url.contains("MovieHavenDB")) json("""{
                "imdb_id":"$imdb","duration":${durationMs / 1000 + 30},
                "scenes":[{"reason":"nudity","skip":true,"start":100,"end":115}]
            }""") else MatureSceneLookup.Fetch.Missing
        }
        assertEquals(MatureSceneLookupStatus.CUT_MISMATCH, result.status)
        assertTrue(result.markers.isEmpty())
    }

    @Test fun cancelledPlaybackCancelsItsPendingLookup() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val pending = async {
            MatureSceneLookup.lookup(imdb, durationMs) {
                started.complete(Unit)
                awaitCancellation()
            }
        }
        withTimeout(5_000) { started.await() }
        pending.cancelAndJoin()
        assertTrue(pending.isCancelled)
    }
}
