package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test

class CeeCatalogParserTest {
    @Test fun cardsUseRealSourceIdentityAndArtwork() {
        val cards=CeeCatalogParser.cards("""<a href="/watch=123/"><div style="background-image:url('https://cinamana.cc/poster.jpg')"></div><h3>فيلم Avengers Infinity War 2018 مترجم</h3></a>""","1")
        assertEquals("cee_123",cards.single().id)
        assertEquals("2018",cards.single().year)
        assertEquals("https://cinamana.cc/poster.jpg",cards.single().poster)
        assertEquals("123",cards.single().providerPageId)
    }
    @Test fun seriesIdentitySurvivesNewEpisodeCards() {
        val one=Video(nb="cee_1",enTitle="مسلسل Example الموسم الأول – الحلقة 1",kind="2",providerPageId="1")
        val two=one.copy(nb="cee_2",enTitle="مسلسل Example الموسم الثاني – الحلقة 4",providerPageId="2")
        assertEquals(CeeCatalogParser.parent(one).id,CeeCatalogParser.parent(two).id)
        assertEquals("Example",CeeCatalogParser.parent(one).title)
    }
    @Test fun seasonAndEpisodeGridIsMappedToTheSelectedSeries() {
        val parent=Video(nb="cee_series_abc",enTitle="Example",providerPageId="123",kind="2")
        val html="""<button class="season-trigger" data-target="season-9">موسم 2</button><div id="season-9" class="season-wrapper"><div class="episodes-grid"><a href="/watch=202/"><span>EP</span><span>2</span></a><a href="/watch=201/"><span>EP</span><span>1</span></a></div></div>"""
        val episodes=CeeCatalogParser.episodes(html,parent)
        assertEquals(listOf(1,2),episodes.map{it.episodeNumber})
        assertTrue(episodes.all{it.seasonNumber==2 && it.rootSeries==parent.id && it.rootSeriesInfo==parent})
    }
    @Test fun nativeDetailUsesThePageInsteadOfFakingMetadata() {
        val video=Video(nb="cee_123",kind="1",enTitle="Original",providerPageId="123")
        val detail=CeeCatalogParser.detail("""<h1>فيلم Example 2024 مترجم</h1><button id="watch-later-btn" data-poster="https://cinamana.cc/example.jpg"></button><meta property="og:description" content="Actual provider synopsis">""",video)
        assertEquals("Actual provider synopsis",detail.description)
        assertEquals("2024",detail.year)
        assertNull(detail.imdbRef)
    }
}
