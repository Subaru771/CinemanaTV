package app.cinemanatv.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SubtitleLanguagePreferenceTest {
    @Test fun supportsLanguageTagsAndDisplayNames() {
        assertEquals("ar-IQ · Arabic CC", preferredSubtitleLabel("ar", listOf("English", "ar-IQ · Arabic CC")))
        assertEquals("en-US [SDH]", preferredSubtitleLabel("en", listOf("العربية", "en-US [SDH]")))
        assertEquals("العربية", preferredSubtitleLabel("ar", listOf("English", "العربية")))
        assertEquals("الإنجليزية", preferredSubtitleLabel("en", listOf("Arabic", "الإنجليزية")))
    }

    @Test fun preservesNoTrackWhenUnavailable() {
        assertNull(preferredSubtitleLabel("ar", listOf("French", "English")))
        assertNull(preferredSubtitleLabel("off", listOf("Arabic")))
        assertNull(preferredSubtitleLabel("auto", listOf("Arabic")))
        assertNull(preferredSubtitleLabel("ar", emptyList()))
    }

    @Test fun explicitLanguageTagOutranksDescription() {
        assertEquals("ar", preferredSubtitleLabel("ar", listOf("Arabic (auto)", "ar")))
        assertEquals("English", preferredSubtitleLabel("en", listOf("English", "English (SDH)")))
    }
}
