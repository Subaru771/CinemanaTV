package app.cinemanatv.data

open class StubCeeCatalog : CeeCatalog {
    override suspend fun home(kind:Int?) = HomeData(emptyList(),emptyList())
    override suspend fun search(query:String):List<Video> = emptyList()
    override suspend fun detail(video:Video) = video
    override suspend fun episodes(video:Video):List<Video> = emptyList()
    override suspend fun related(video:Video):List<Video> = emptyList()
    override suspend fun sources(id:String) = PlaySources(emptyList(),emptyList())
}
