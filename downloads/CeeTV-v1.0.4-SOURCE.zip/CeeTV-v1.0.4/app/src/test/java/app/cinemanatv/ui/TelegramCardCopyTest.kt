package app.cinemanatv.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TelegramCardCopyTest {
    @Test fun `English mode never mixes Arabic into Telegram card`() {
        val copy = telegramCardCopy("en")
        assertEquals("Join Our Telegram Channel", copy.title)
        assertEquals("Join the Channel", copy.join)
        val fields = listOf(copy.title, copy.description, copy.updates, copy.features, copy.news, copy.join, copy.later, copy.neverShow)
        assertFalse(fields.any { it.any { c -> c in '\u0600'..'\u06FF' } })
    }

    @Test fun `Arabic mode displays only Arabic card labels`() {
        val copy = telegramCardCopy("ar")
        assertEquals("الانضمام إلى القناة", copy.join)
        val fields = listOf(copy.title, copy.description, copy.updates, copy.features, copy.news, copy.join, copy.later, copy.neverShow)
        assertTrue(fields.all { it.any { c -> c in '\u0600'..'\u06FF' } })
        assertFalse(fields.any { it.any { c -> c in 'A'..'Z' || c in 'a'..'z' } })
    }

    @Test fun `Unknown language safely falls back to English`() {
        assertEquals(telegramCardCopy("en"), telegramCardCopy("fr"))
    }
}
