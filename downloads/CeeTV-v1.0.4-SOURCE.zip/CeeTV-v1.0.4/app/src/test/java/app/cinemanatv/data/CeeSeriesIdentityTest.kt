package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class CeeSeriesIdentityTest {
    @Test fun idOnlyParentLookupRetainsTheSourcePageForEpisodeNavigation() = runBlocking {
        val series=Video(nb="cee_series_stable",kind="2",enTitle="Example",providerPageId="123")
        val backend=object:StubCeeCatalog() {
            override suspend fun home(kind:Int?)=HomeData(listOf(series),listOf(ContentRow("Series",listOf(series))))
            override suspend fun detail(video:Video):Video {
                CeeCatalogParser.postId(video)
                return video
            }
            override suspend fun episodes(video:Video):List<Video> {
                assertEquals("123",CeeCatalogParser.postId(video))
                return listOf(Video(nb="cee_124",kind="2",rootSeries=video.id,episodeNummer="1"))
            }
        }
        val repo=Repository(backend)
        repo.loadHome(2)
        assertNotNull(repo.infoOrNull(Video(nb=series.id)))
        assertEquals("cee_124",repo.episodes(series.id).single().id)
    }
}
