package app.cinemanatv.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class BackNavigationTest {
    @Test fun nestedDetailPopsBeforeTab() {
        assertEquals(BackDestination.POP_PAGE, backDestination(3, 4))
    }

    @Test fun playerClosesSubmenuThenPanelThenPage() {
        assertEquals(BackDestination.CLOSE_SUBMENU, backDestination(2, 0, 2))
        assertEquals(BackDestination.CLOSE_PANEL, backDestination(2, 0, 1))
        assertEquals(BackDestination.POP_PAGE, backDestination(2, 0, 0))
    }

    @Test fun rootTabReturnsHomeWithoutExit() {
        assertEquals(BackDestination.HOME_TAB, backDestination(1, 6))
        assertEquals(BackDestination.STAY, backDestination(1, 0))
    }

    @Test fun singleBackIsNeverPassedToSystemAtHome() {
        assertEquals(BackDestination.STAY, backDestination(1, 0))
        assertEquals(BackDestination.STAY, backDestination(1, 0))
        assertEquals(BackDestination.STAY, backDestination(1, 0))
    }

    @Test fun tvKeyAndSystemCallbackDoNotDoubleNavigate() {
        val gate = BackPressGate()
        assertTrue(gate.tryHandle(1_000L))
        assertFalse(gate.tryHandle(1_070L))
        assertFalse(gate.tryHandle(1_219L))
        assertTrue(gate.tryHandle(1_240L))
        assertFalse(gate.tryHandle(1_310L))
    }

    @Test fun backAfterClockResetIsAccepted() {
        val gate = BackPressGate()
        assertTrue(gate.tryHandle(1_000L))
        assertTrue(gate.tryHandle(10L))
    }

    @Test fun loginReturnsToSettingsPage() {
        assertEquals(BackDestination.POP_PAGE, backDestination(2, 6))
    }
}
