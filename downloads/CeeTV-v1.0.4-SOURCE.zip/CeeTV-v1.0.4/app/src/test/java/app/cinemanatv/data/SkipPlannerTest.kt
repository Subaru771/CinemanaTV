package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test

class SkipPlannerTest {
    private val duration = 2_700_000L
    private val intro = ExternalSceneMarker("intro", 30_000L, 90_000L, "SkipDB", 0.95)
    private val outro = ExternalSceneMarker("outro", 2_640_000L, duration, "SkipDB", 0.9)

    @Test fun offerAppearsSlightlyBeforeTheSegmentAndEndsBeforeItDoes() {
        assertNull(SkipPlanner.offer(27_000L, duration, listOf(intro)))
        assertNotNull(SkipPlanner.offer(28_500L, duration, listOf(intro)))
        assertEquals(90_000L, SkipPlanner.offer(45_000L, duration, listOf(intro))!!.targetMs)
        assertNull(SkipPlanner.offer(89_500L, duration, listOf(intro)))
        assertNull(SkipPlanner.offer(120_000L, duration, listOf(intro)))
    }

    @Test fun creditsToTheEndTargetTheRuntimeAndAreFlagged() {
        val offer = SkipPlanner.offer(2_650_000L, duration, listOf(outro))!!
        assertTrue(offer.toEnd)
        assertEquals(duration, offer.targetMs)
        assertFalse(offer.autoEligible) // credits are never skipped without a press
    }

    @Test fun providerIntroWindowUsesTheSameModel() {
        val m = SkipPlanner.fromProvider(20_000L until 80_000L)!!
        assertEquals(80_000L, m.endMs)
        assertEquals("intro", SkipPlanner.offer(25_000L, duration, listOf(m))!!.kind)
        assertNull(SkipPlanner.fromProvider(null))
    }

    @Test fun matureMarkersNeverProduceAButton() {
        val mature = ExternalSceneMarker("mature", 100_000L, 130_000L, "MovieHavenDB", 0.8)
        assertNull(SkipPlanner.offer(110_000L, duration, listOf(mature)))
    }

    @Test fun autoSkipWaitsForTheSegmentAndFiresOnlyOnce() {
        val offer = SkipPlanner.offer(28_500L, duration, listOf(intro))!!
        assertFalse(SkipPlanner.shouldAutoSkip(offer, 28_500L, emptySet())) // still in lead-in
        assertTrue(SkipPlanner.shouldAutoSkip(offer, 30_000L, emptySet()))
        assertFalse(SkipPlanner.shouldAutoSkip(offer, 31_000L, setOf(offer.key))) // already handled / undone
    }

    @Test fun noUsableDurationMeansNoOffer() {
        assertNull(SkipPlanner.offer(40_000L, 0L, listOf(intro)))
    }
}
