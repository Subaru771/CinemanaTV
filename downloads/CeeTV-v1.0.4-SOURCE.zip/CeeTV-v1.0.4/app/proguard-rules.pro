# --- App models are (de)serialised by Gson via reflection; keep names and fields ---
-keep class app.cinemanatv.data.** { *; }
-keep interface app.cinemanatv.data.CinemanaApi { *; }
-keep interface app.cinemanatv.data.AccountApi { *; }

# --- Gson / Retrofit reflection needs generic signatures and annotations ---
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*, RuntimeVisibleAnnotations
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken
-keep class com.google.gson.stream.** { *; }

# --- Optional TLS providers OkHttp probes for ---
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn okhttp3.internal.platform.**
-dontwarn javax.annotation.**
