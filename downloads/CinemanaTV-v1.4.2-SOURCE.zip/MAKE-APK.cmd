@echo off
setlocal
cd /d "%~dp0"
title CinemanaTV v1.4.2 - Build APK
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0MAKE-APK.ps1"
if errorlevel 1 (
  echo.
  echo Build failed. Review output\CinemanaTV-v1.4.2-BUILD.log
  echo.
) else (
  echo.
  echo Build completed. See the output folder for the APK.
)
pause
