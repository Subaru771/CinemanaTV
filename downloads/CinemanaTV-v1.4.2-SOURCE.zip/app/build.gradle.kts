import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

fun cfg(name: String): String =
    localProps.getProperty(name)
        ?: (project.findProperty(name) as String?)
        ?: System.getenv(name.replace('.', '_').uppercase())
        ?: ""

android {
    namespace = "app.cinemanatv"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.cinemanatv"
        minSdk = 26
        targetSdk = 34
        versionCode = 124
        versionName = "1.4.2"
        buildConfigField("String", "CLIENT_ID", "\"${cfg("cinemana.clientId")}\"")
        buildConfigField("String", "CLIENT_SECRET", "\"\"")
        buildConfigField("String", "SCOPE", "\"${cfg("cinemana.scope")}\"")
        // Supply cinemana.updateFeedUrl from local.properties, Gradle -P, or CI.
        // Leave blank until the JSON manifest is published over HTTPS.
        val updateFeed = cfg("cinemana.updateFeedUrl")
            .ifBlank { "https://cinemana-updates-e8l.pages.dev/updates.json" }
            .replace("\\", "\\\\").replace("\"", "\\\"")
        buildConfigField("String", "UPDATE_FEED_URL", "\"$updateFeed\"")

    }

    buildTypes {
        release {
            // Optimized for sideload testing, but signed using this computer's debug key.
            // This is NOT a distributable production-signed release. It can update only
            // installations signed by the exact same key.
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    lint {
        // Lint on release builds adds minutes and can fail a sideload build for unrelated reasons.
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.tv:tv-material:1.0.0")

    implementation("androidx.tvprovider:tvprovider:1.1.0")
    implementation("androidx.media3:media3-exoplayer:1.8.1")
    implementation("androidx.media3:media3-ui:1.8.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.8.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.8.1")
    implementation("androidx.media3:media3-database:1.8.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.8.1")
    // Installs the Baseline Profiles embedded in Compose / Media3 on first launch (faster cold start).
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")

    implementation("io.coil-kt:coil-compose:2.7.0")

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.18.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}
