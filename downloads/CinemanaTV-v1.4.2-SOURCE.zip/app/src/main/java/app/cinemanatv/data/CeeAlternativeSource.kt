package app.cinemanatv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.IOException
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/** Independent, explicitly selected provider. Never reuses a Cinemana ID or session. */
object CeeAlternativeSource {
    const val BASE = "https://cinamana.cc/"
    private val client by lazy { OkHttpClient.Builder()
        .followRedirects(false).followSslRedirects(false)
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS).build() }
    // owns() is used by original-provider metadata lookups on the main thread.
    // Keep it independent of HTTP/TLS setup and Android's native regex compiler.
    private val postId by lazy { Regex("[0-9]{1,12}") }
    private val watchPath by lazy { Regex("/watch=([0-9]{1,12})/?") }
    // ICU (Android) rejects the unescaped closing brace that the JDK accepts.
    internal const val SOURCE_PATTERN = """\{\s*file\s*:\s*["']([^"']+)["']\s*,\s*label\s*:\s*["']([^"']*)["']\s*\}"""
    private val source by lazy { Regex(SOURCE_PATTERN) }

    fun owns(id: String): Boolean = id.startsWith("cee_")

    internal fun pageId(url: String): String? {
        val parsed = url.toHttpUrlOrNull() ?: return null
        if (parsed.scheme != "https" || parsed.host != "cinamana.cc" || parsed.port != 443 ||
            parsed.username.isNotEmpty() || parsed.password.isNotEmpty()) return null
        return watchPath.matchEntire(parsed.encodedPath)?.groupValues?.get(1)
    }

    internal fun catalog(html: String): List<Video> = Jsoup.parse(html, BASE)
        .select("a[href]").asSequence().filterNot { it.hasClass("cn-mega-item") }
        .mapNotNull { anchor ->
            val id = pageId(anchor.absUrl("href")) ?: return@mapNotNull null
            val title = anchor.selectFirst("h2, h3")?.text()?.trim()
                ?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            // Do not inherit IMDb IDs, ratings, timestamps or season queues from another cut.
            Video(nb = "cee_$id", enTitle = title,
                year = Regex("\\b(?:19|20)[0-9]{2}\\b").findAll(title).lastOrNull()?.value,
                enContent = "CEE alternative source · $BASE" )
        }.distinctBy { it.id }.take(40).toList()

    internal fun embed(html: String): HttpUrl {
        val raw = Jsoup.parse(html, BASE).selectFirst("iframe[src]")?.absUrl("src")
            ?.toHttpUrlOrNull() ?: throw IOException("Alternative source returned no supported player.")
        val target = if (raw.host == "cinamana.cc" && raw.encodedPath == "/acm.php") {
            raw.queryParameter("url")?.toHttpUrlOrNull()
        } else raw
        if (target == null || !allowedPage(target) || target.host != "mp4plus.org" ||
            !Regex("/embed-[A-Za-z0-9]+\\.html").matches(target.encodedPath))
            throw IOException("Alternative source uses an unsupported player host.")
        return target
    }

    internal fun qualities(html: String): List<QualityOption> = source.findAll(html).mapNotNull { match ->
        val url = match.groupValues[1].replace("\\/", "/").toHttpUrlOrNull()
            ?: return@mapNotNull null
        if (!allowedMedia(url)) return@mapNotNull null
        val height = Regex("[0-9]{3,4}").find(match.groupValues[2])?.value?.toIntOrNull() ?: 0
        QualityOption(height, url.toString(), if (height > 0) "CEE · ${height}p" else "CEE · Auto")
    }.distinctBy { it.url }.sortedByDescending { it.height }.toList()

    internal fun allowedMedia(url: HttpUrl): Boolean = url.scheme == "https" && url.port == 443 &&
        url.username.isEmpty() && url.password.isEmpty() && url.host.endsWith(".cdnz.quest") &&
        listOf(".mp4", ".m3u8", ".mpd").any { url.encodedPath.lowercase().endsWith(it) }

    private fun allowedPage(url: HttpUrl): Boolean = url.scheme == "https" && url.port == 443 &&
        url.username.isEmpty() && url.password.isEmpty() && url.host in setOf("cinamana.cc", "mp4plus.org")

    /** Bounded HTTP fetch; validate each redirect before sending a request to its destination. */
    private fun fetch(initial: Request): String {
        var request = initial
        repeat(6) {
            if (!allowedPage(request.url)) throw IOException("Unsupported alternative source address.")
            client.newCall(request).execute().use { response ->
                if (response.code in listOf(301, 302, 303, 307, 308)) {
                    val next = response.header("Location")?.let(request.url::resolve)
                        ?: throw IOException("Alternative source returned an invalid redirect.")
                    request = if (response.code in listOf(301, 302, 303))
                        request.newBuilder().url(next).get().build()
                    else request.newBuilder().url(next).build()
                } else {
                    if (!response.isSuccessful) throw IOException("Alternative source HTTP ${response.code}.")
                    val body = response.body ?: throw IOException("Alternative source returned no page.")
                    val bytes = body.byteStream().use { input ->
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (output.size() + count > 2_000_000)
                                throw IOException("Alternative source page is too large.")
                            output.write(buffer, 0, count)
                        }
                        output.toByteArray()
                    }
                    return String(bytes, Charsets.UTF_8)
                }
            }
        }
        throw IOException("Alternative source redirected too many times.")
    }

    private fun request(url: HttpUrl): Request.Builder = Request.Builder().url(url)
        .header("User-Agent", "Mozilla/5.0")

    suspend fun search(query: String): List<Video> = withContext(Dispatchers.IO) {
        val trimmed = query.trim().take(250)
        // A precise episode page can be selected when the website's search lacks episode results.
        if (trimmed.startsWith("https://")) {
            val id = pageId(trimmed) ?: throw IOException("Enter a cinamana.cc/watch=… page URL.")
            val html = fetch(request("${BASE}watch=$id/".toHttpUrlOrNull()!!).build())
            val title = Jsoup.parse(html).selectFirst("h1")?.text()?.trim()
                ?.takeIf { it.isNotBlank() } ?: throw IOException("The selected page has no title.")
            return@withContext listOf(Video(nb = "cee_$id", enTitle = title,
                enContent = "CEE alternative source · $BASE"))
        }
        val url = if (trimmed.isBlank()) "${BASE}main".toHttpUrlOrNull()!!
            else BASE.toHttpUrlOrNull()!!.newBuilder().addQueryParameter("s", trimmed).build()
        catalog(fetch(request(url).build()))
    }

    suspend fun resolve(id: String): PlaySources = withContext(Dispatchers.IO) {
        val number = id.removePrefix("cee_")
        if (!owns(id) || !postId.matches(number)) throw IOException("Invalid alternative title ID.")
        val endpoint = "${BASE}wp-content/themes/EEE/Inc/Ajax/Single/Server.php".toHttpUrlOrNull()!!
        val response = fetch(request(endpoint).header("Referer", "${BASE}watch=$number/")
            .post(FormBody.Builder().add("post_id", number).add("server", "0").build()).build())
        val player = embed(response)
        val streams = qualities(fetch(request(player).header("Referer", BASE).build()))
        if (streams.isEmpty()) throw IOException("No supported MP4, HLS or DASH streams were returned. Try another title.")
        // Resolve again on retry; signed stream URLs never enter persistent preferences.
        PlaySources(streams, emptyList())
    }

    suspend fun automaticMatch(original: Video): Video? {
        val candidates = mutableListOf<Video>()
        // Collect both title-language searches before choosing, so duplicates stay ambiguous.
        for (query in CeeAutomaticMatch.queries(original)) candidates += search(query)
        return CeeAutomaticMatch.select(original, candidates)
    }
}
