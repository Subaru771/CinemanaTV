# Cinemana CEE TV 1.0.1

A separate native Android TV app using the Cinemana TV interface and the public catalogue/player route traced from CEE mobile. Package: `app.cinemanatv.cee`. Android 8.0 or newer. Installs beside Cinemana TV.

## Behaviour

CEE is the primary provider from startup. Native home rows, posters, movie and series search, details, season/episode navigation, watchlist, resume and Media3 playback use CEE identities. There is no original-network availability gate, title matching or manual alternative-source selection. The app resolves a fresh player URL for each movie or episode and supports the observed MP4Plus MP4 and CDNPlus packed HLS sources and the site's HLS relay with explicit HLS typing.

The new Leanback APK was inspected as a TV interface reference. Its protected backend could not be recovered. This app implements the verified public CEE mobile website route (`cinamana.cc`); it does not claim to reproduce the protected Leanback application's backend. No protected binaries, AppCloner components or vendor credentials are included.

## Build

Install JDK 17 and Android SDK platform 35/build tools 35. Put `sdk.dir=/path/to/Android/Sdk` in local.properties, or set ANDROID_HOME.

```sh
bash gradlew testDebugUnitTest assembleRelease
```

APK: `app/build/outputs/apk/release/app-release.apk`. Release is optimized and test-signed. Keep the signing key to update an installed build. A fresh builder's debug key will differ.

Optional live checks: `CEE_LIVE_TEST=1 bash gradlew testDebugUnitTest`. Native ICU regex verification: `python3 tools/check_android_icu_regex.py` (requires Linux ICU).

## Limits

VK Video titles are not supported by the native player. Provider availability, catalogue HTML and media hosts may change. No all-network guarantee is made. Only episode links present in the selected source page are exposed. Ratings, scene markers and subtitles are shown only when available; the app does not invent IMDb mappings. TV hardware decoding and remote-control behaviour still require an actual device check. Automatic updates are disabled until a feed for this separate package is configured.
