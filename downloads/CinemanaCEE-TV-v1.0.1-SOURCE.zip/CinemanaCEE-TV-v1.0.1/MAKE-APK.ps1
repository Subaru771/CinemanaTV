param(
    [switch]$SkipTests
)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $project
$out = Join-Path $project 'output'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$log = Join-Path $out 'CinemanaCEE-TV-v1.0.1-BUILD.log'
function Fail([string]$message) {
    Write-Host "`nBUILD FAILED: $message" -ForegroundColor Red
    Write-Host "Log: $log" -ForegroundColor Yellow
    if (Test-Path $log) { Get-Content -LiteralPath $log -Tail 30 }
    exit 1
}
function Get-Exe($cmd) { try { (Get-Command $cmd -ErrorAction Stop).Source } catch { $null } }
Write-Host 'Cinemana CEE TV 1.0.1 -- APK Builder' -ForegroundColor Cyan
Write-Host '-----------------------------------------'
# Prefer configured JAVA_HOME; standard PATH fallback.
$java = Get-Exe 'java.exe'
if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    $java = Join-Path $env:JAVA_HOME 'bin\java.exe'
}
if (-not $java) { Fail 'Java 17 or newer is required. Install JDK 17 or 21, then run MAKE-APK.cmd again.' }
$javaOut = (& cmd.exe /d /c ('"' + $java + '" -version 2>&1') | Out-String)
if ($javaOut -notmatch 'version "(?:1\.)?(\d+)') { Fail "Cannot identify Java version: $javaOut" }
if ([int]$Matches[1] -lt 17) { Fail "Java 17+ required. Found Java $($Matches[1])." }
Write-Host "Java: $($Matches[1])"
# Reuse installed SDK rather than re-download. Android Studio default is tried automatically.
$candidates = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, (Join-Path $env:LOCALAPPDATA 'Android\Sdk'), 'C:\Android\Sdk')
$sdk = $candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) } | Select-Object -First 1
if (-not $sdk) { Fail 'Android SDK not found. Install Android Studio / SDK once (API 35). Usual path: %LOCALAPPDATA%\Android\Sdk' }
$env:ANDROID_HOME = $sdk
$env:ANDROID_SDK_ROOT = $sdk
Write-Host "Android SDK: $sdk"
$localProps = Join-Path $project 'local.properties'
if (-not (Test-Path -LiteralPath $localProps)) {
    $escapedSdk = $sdk.Replace('\\','/').Replace('\','/')
    [IO.File]::WriteAllText($localProps, "sdk.dir=$escapedSdk`n")
}
$platformJar = Join-Path $sdk 'platforms\android-35\android.jar'
$buildTool = Get-ChildItem (Join-Path $sdk 'build-tools') -Directory -ErrorAction SilentlyContinue | Sort-Object -Property Name -Descending | Select-Object -First 1
if (-not (Test-Path $platformJar) -or -not $buildTool) {
    $managers = @((Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'), (Join-Path $sdk 'tools\bin\sdkmanager.bat'))
    $sdkmanager = $managers | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if (-not $sdkmanager) { Fail 'SDK 35 is missing, and sdkmanager is not installed. In Android Studio > SDK Manager install Android API 35 and Build Tools 35.' }
    Write-Host 'Installing Android API 35 and Build Tools 35...' -ForegroundColor Cyan
    # sdkmanager prompts for license acceptance; standard new installs may need an interactive confirmation.
    & $sdkmanager ("--sdk_root=$sdk") 'platforms;android-35' 'build-tools;35.0.0' 'platform-tools' 2>&1 | Tee-Object -FilePath $log
    if ($LASTEXITCODE -ne 0) { Fail 'Unable to download Android SDK packages. Accept SDK licenses in Android Studio, then retry.' }
}
if (-not (Test-Path $platformJar)) { Fail 'API 35 did not install successfully.' }
$buildTool = Get-ChildItem (Join-Path $sdk 'build-tools') -Directory -ErrorAction SilentlyContinue | Sort-Object -Property Name -Descending | Select-Object -First 1
if (-not $buildTool) { Fail 'Android build-tools are missing.' }
$gradlew = Join-Path $project 'gradlew.bat'
if (-not (Test-Path $gradlew)) { Fail 'Gradle wrapper is missing. Extract the full ZIP.' }
Write-Host 'Running unit tests and building the release APK...' -ForegroundColor Cyan
Write-Host 'The Gradle wrapper will automatically download Gradle/dependencies on first run.'
$args = @('--no-daemon','--stacktrace')
if (-not $SkipTests) { $args += 'testDebugUnitTest' }
$args += 'assembleRelease'
$originalJavaHome = $env:JAVA_HOME
try {
    # Let Gradle use the same JDK checked above. Save build output as well as displaying it.
    # Use Gradle's normal Java lookup when JAVA_HOME is unset.
    $ErrorActionPreference = 'Continue'  # Gradle may write normal progress messages to stderr.
    & $gradlew @args 2>&1 | Tee-Object -FilePath $log
    $gradleExitCode = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($gradleExitCode -ne 0) { Fail 'Gradle compilation, tests or packaging failed.' }
} finally { $env:JAVA_HOME = $originalJavaHome }
$apk = Join-Path $project 'app\build\outputs\apk\release\app-release.apk'
if (-not (Test-Path $apk)) { Fail 'Gradle completed but no APK was generated.' }
$dest = Join-Path $out 'CinemanaCEE-TV-v1.0.1.apk'
Copy-Item -LiteralPath $apk -Destination $dest -Force
# Verify zip envelope and classes dex. This does not substitute for on-device testing.
try {
    Add-Type -AssemblyName System.IO.Compression
    $zip = [IO.Compression.ZipFile]::OpenRead($dest)
    try {
        $entryNames = @($zip.Entries | ForEach-Object FullName)
        if ('classes.dex' -notin $entryNames -or 'AndroidManifest.xml' -notin $entryNames) { Fail 'Output APK does not contain expected Android components.' }
    } finally { $zip.Dispose() }
} catch { Fail "APK integrity check failed: $($_.Exception.Message)" }
# Verify signature using SDK build-tools, if available.
$apksigner = Join-Path $buildTool.FullName 'apksigner.bat'
if (Test-Path $apksigner) {
    & $apksigner verify --verbose $dest
    if ($LASTEXITCODE -ne 0) { Fail 'APK signature verification failed.' }
}
$hash = (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant()
[IO.File]::WriteAllText((Join-Path $out 'SHA256.txt'), "$hash  CinemanaCEE-TV-v1.0.1.apk`n")
Write-Host "`nSUCCESS: $dest" -ForegroundColor Green
Write-Host "SHA-256: $hash"
Write-Host 'IMPORTANT: This APK uses your local debug signing certificate.' -ForegroundColor Yellow
Write-Host 'A mismatched signature prevents in-place updates to an older installation.' -ForegroundColor Yellow
Start-Process explorer.exe -ArgumentList ('"' + $out + '"')
