package app.cinemanatv.ui

import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.R
import app.cinemanatv.data.ContentRow
import app.cinemanatv.data.Video
import app.cinemanatv.data.MediaContentFilter
import app.cinemanatv.util.NetworkResilience
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import coil.compose.AsyncImage

private val TABS = listOf(0 to "Home", 1 to "Series", 2 to "Movies", 4 to "History", 5 to "My List", 6 to "Downloads", 7 to "Settings")
private const val CONTINUE = "Continue Watching"

@Composable
fun MainShell(vm: AppViewModel) {
    val searchOpen = vm.tab == 3
    // Search is a panel that drops down over whichever page was open, not a page of its own.
    val base = if (searchOpen) vm.lastTab else vm.tab
    Column(Modifier.fillMaxSize()) {
        TopBar(
            selected = vm.tab,
            onUpAtTop = { if (vm.tab != 3) { vm.lastTab = vm.tab; vm.tab = 3 } },
            onSearch = { if (vm.tab == 3) vm.tab = vm.lastTab else { vm.lastTab = vm.tab; vm.tab = 3 } },
        ) { picked -> vm.tab = picked }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            // Search covers the entire content area. Do NOT keep the underlying screen
            // composed: focusProperties(canFocus=false) only disables that parent node,
            // not its descendant TV buttons. They could steal remote focus through the
            // search overlay, especially after coming back from Settings or Downloads.
            if (searchOpen) {
                Box(Modifier.fillMaxSize().background(C.Bg)) { SearchScreen(vm) }
            } else {
                when (base) {
                    0 -> HomeScreen(null, vm)
                    1 -> HomeScreen(2, vm)
                    2 -> HomeScreen(1, vm)
                    4 -> HistoryScreen(vm)
                    5 -> WatchlistScreen(vm)
                    6 -> DownloadsScreen(vm)
                    7 -> SettingsScreen(vm)
                    else -> HomeScreen(null, vm)
                }
            }
        }
    }
}

@Composable
private fun TopBar(selected: Int, onUpAtTop: () -> Unit, onSearch: () -> Unit, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(C.Bg)
            // On the top navigation row, Up is the shortcut to the search overlay.
            // v1.5.2 accidentally removed this handler while refining D-pad focus.
            // Scope this ONLY to the top bar so Up still navigates normally in Settings.
            .onPreviewKeyEvent { event ->
                if (event.key == Key.DirectionUp && selected != 3) {
                    if (event.type == KeyEventType.KeyDown) onUpAtTop()
                    true
                } else false
            }
            .padding(horizontal = 28.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Image(painterResource(R.drawable.brandmark), contentDescription = "CinemanaTV",
            modifier = Modifier.size(40.dp), contentScale = ContentScale.Fit)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Cinemana", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("CEE", color = Color(0xFFF7354B), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        // Only actual destinations are tabs. The search action is fixed on the right,
        // outside the scrolling tab strip, so it stays reachable on 720p televisions.
        Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TABS.forEach { (i, label) ->
                val selectedTab = i == selected
                Surface(
                    onClick = { onSelect(i) },
                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
                    colors = ClickableSurfaceDefaults.colors(
                        containerColor = if (selectedTab) C.Panel else Color.Transparent,
                        contentColor = if (selectedTab) Color.White else C.Dim,
                        focusedContainerColor = Color(0xFF31354B),
                        focusedContentColor = Color.White,
                    ),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1f),
                    border = ClickableSurfaceDefaults.border(
                        focusedBorder = Border(BorderStroke(1.dp, Color(0xFFB64C62)),
                            shape = RoundedCornerShape(10.dp)),
                    ),
                ) {
                    Text(t(label), fontSize = 14.sp,
                        fontWeight = if (selectedTab) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp))
                }
            }
        }
        AppButton(if (selected == 3) "✕  " + t("Close") else "⌕  " + t("Search"),
            primary = selected == 3, onClick = onSearch)
    }
}

@Composable
fun HomeScreen(kind: Int?, vm: AppViewModel) {

    val key = kind ?: 0
    var data by remember(key) { mutableStateOf(vm.homeCache[key]) }
    var error by remember(key) { mutableStateOf<String?>(null) }
    var generation by remember(key) { mutableIntStateOf(0) }
    var diagnostic by remember(key) { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(key, context) {
        var previous = NetworkResilience.link(context)
        NetworkResilience.watch(context).collect { current ->
            if (error != null && current.connected && previous.routeId != current.routeId) {
                diagnostic = null
                generation++
            }
            previous = current
        }
    }

    LaunchedEffect(key, generation) {
        // 1) Paint last session's catalog right away if this tab has none in memory yet.
        if (data == null) {
            Services.repo.cachedHome(kind)?.let { vm.homeCache[key] = it; data = it }
        }
        // 2) Refresh behind it (stale-while-revalidate). A failed refresh never replaces
        //    good content with an error screen.
        if (data == null || generation > 0 || !vm.isHomeFresh(key)) {
            if (data == null) error = null
            try {
                val loaded = Services.repo.loadHome(kind)
                if (loaded.rows.isEmpty()) {
                    if (data == null) error = "CEE answered, but no titles were recognised."
                } else {
                    vm.homeCache[key] = loaded
                    vm.markHomeFresh(key)
                    error = null
                    if (loaded != data) data = loaded
                }
            } catch (c: CancellationException) { throw c }
              catch (e: Exception) {
                  if (data == null) error = NetworkResilience.diagnose(context, e).message
              }
        }
    }

    val d = data
    if (d == null) {
        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text(t("DISCOVER"), color = C.Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(t(error ?: "Finding movies and series…"), fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
            if (error != null) {
                Text(t("Connection: ${NetworkResilience.link(context).type}"), color = C.Dim, fontSize = 14.sp)
                if (diagnostic != null) Text(diagnostic.orEmpty(), color = C.Dim, fontSize = 14.sp)
            }
            if (error == null) {
                repeat(2) { row ->
                    Text(t(if (row == 0) "Trending" else "Recently added"), color = C.Dim, fontSize = 16.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        repeat(6) {
                            Box(Modifier.width(112.dp).height(166.dp).clip(RoundedCornerShape(12.dp))
                                .background(C.Panel))
                        }
                    }
                }
            }
            if (error != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppButton("Retry", primary = true) { diagnostic = null; generation++ }
                    AppButton("Check source") {
                        scope.launch { diagnostic = Services.repo.probe() }
                    }
                    AppButton("Downloads") { vm.tab = 6 }
                }

            }
        }
        return
    }

    // "Continue Watching" works for guests too: it comes from this device.
    val mode = vm.contentFilterMode
    LaunchedEffect(d, mode) {
        if (mode != app.cinemanatv.data.ContentFilterMode.OFF)
            vm.resolveMaturity(d.hero + d.rows.flatMap { it.items } +
                Services.prefs.recent() + Services.prefs.watchlist())
    }
    // Recomputing this on every recomposition (it used to run on EVERY focus move) re-filtered the
    // whole catalog on each D-pad press. It only depends on the data, the filter and the row toggles.
    val showContinue = vm.showContinueRow
    val showMyList = vm.showMyListRow
    val hideWatched = vm.hideWatchedDiscovery
    val maturityBusy = vm.maturityBusy
    val rows = remember(d, mode, showContinue, showMyList, hideWatched, maturityBusy) {
        val recent = if (kind == null && showContinue) vm.visible(Services.prefs.recent()) else emptyList()
        val saved = if (kind == null && showMyList) vm.visible(Services.prefs.watchlist()) else emptyList()
        val hiddenWatchedIds = if (hideWatched) Services.prefs.history().mapTo(hashSetOf()) { it.id }
            else emptySet()
        val pinned = buildList {
            if (recent.isNotEmpty()) add(ContentRow(CONTINUE, recent))
            if (saved.isNotEmpty()) add(ContentRow("My List", saved))
        }
        pinned + d.rows.mapNotNull { row ->
            if (pinned.any { it.title == row.title }) null
            else vm.visible(row.items).filterNot { it.id in hiddenWatchedIds }
                .takeIf { it.isNotEmpty() }?.let { ContentRow(row.title, it) }
        }
    }
    if (rows.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (vm.maturityBusy) Text(t("Checking age ratings…"), color = C.Dim)
            else {
                Text(t("No titles match your content restrictions."), color = C.Dim)
                AppButton("Content settings", primary = true) { vm.tab = 7 }
            }
        }
        return
    }

    val colState = remember(key) { vm.colState(key) }
    val restore = remember(key) { vm.homeFocus[key] }
    val targetRow = restore?.first?.takeIf { t -> rows.any { it.title == t } } ?: rows.first().title
    val targetCol = if (restore != null && restore.first == targetRow) restore.second else 0
    val target = remember(key) { FocusRequester() }

    // Focus is tracked as state that is NOT read during composition: moving the D-pad must not
    // recompose the whole page. Only Hero observes the (debounced) preview.
    val focused = remember(key) { mutableStateOf<Video?>(null) }
    val preview = remember(key) { mutableStateOf<Video?>(null) }
    LaunchedEffect(key) {
        snapshotFlow { focused.value?.id }.distinctUntilChanged().collectLatest {
            delay(500) // Never decode a fullscreen backdrop during rapid D-pad navigation.
            preview.value = focused.value
        }
    }
    val fallback = vm.visible(d.hero).firstOrNull() ?: rows.first().items.firstOrNull() ?: return

    // Coming back from a title: restore the scroll position and put focus on the card we left.
    // Keyed by tab, not by data: a silent background refresh must never move the user's focus.
    LaunchedEffect(key) {
        val ri = rows.indexOfFirst { it.title == targetRow }
        if (ri > 0) colState.scrollToItem(ri)
        if (targetCol > 0) vm.rowState(key, targetRow).scrollToItem(targetCol)
        delay(80)
        runCatching { target.requestFocus() }
    }

    Column(Modifier.fillMaxSize()) {
        Hero(preview, fallback)
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = colState,
            contentPadding = PaddingValues(top = 4.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(19.dp),
        ) {
            itemsIndexed(rows, key = { _, r -> r.title }) { _, row ->
                Column {
                    Text(
                        t(row.title), fontSize = 19.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 48.dp, bottom = 7.dp),
                    )
                    LazyRow(
                        state = vm.rowState(key, row.title),
                        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(row.items, key = { _, v -> v.id }) { ci, v ->
                            PosterCard(
                                v,
                                vm = vm,
                                modifier = if (row.title == targetRow && ci == targetCol) Modifier.focusRequester(target) else Modifier,
                                onFocus = { focused.value = v; vm.homeFocus[key] = row.title to ci },
                                onClick = { vm.push(Screen.Detail(v)) },
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Featured area intentionally loads a modest backdrop, not the original huge image. */
@Composable
private fun Hero(focused: State<Video?>, fallback: Video) {
    val v = focused.value ?: fallback
    val ctx = LocalContext.current
    val backdrop = remember(ctx, v.backdrop) {
        ImageRequest.Builder(ctx).data(v.backdrop).size(1120, 630).crossfade(false).build()
    }
    Box(Modifier.fillMaxWidth().height(258.dp).background(C.Bg)) {
        AsyncImage(
            model = backdrop,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.align(Alignment.CenterEnd).fillMaxWidth(0.62f).fillMaxHeight(),
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(
            0.22f to C.Bg, 0.61f to Color(0xF00B0E15), 1f to Color(0x110B0E15))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            0.55f to Color.Transparent, 1f to C.Bg)))
        Column(
            Modifier.align(Alignment.CenterStart).padding(start = 48.dp).fillMaxWidth(0.49f),
            verticalArrangement = Arrangement.spacedBy(11.dp),
        ) {
            Text(t("FEATURED  /  DISCOVER"), color = C.Red, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Text(v.title, fontSize = 33.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, lineHeight = 38.sp, overflow = TextOverflow.Ellipsis)
            val meta = listOfNotNull(v.rating, v.year, v.filmRating).plus(v.genres.take(2)).joinToString("   ·   ")
            if (meta.isNotBlank()) Text(meta, fontSize = 13.sp, color = Color(0xFFCCD2DE))
            Text(v.description, fontSize = 13.sp, color = C.Dim, maxLines = 3,
                lineHeight = 19.sp, overflow = TextOverflow.Ellipsis)
        }
    }
}
