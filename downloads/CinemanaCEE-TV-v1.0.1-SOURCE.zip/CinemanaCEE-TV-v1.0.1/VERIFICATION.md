# Cinemana CEE TV 1.0.1 recheck

Rechecked 2026-11-12. Package `app.cinemanatv.cee`, versionCode 2, minSdk 26.

## Findings and fixes

The 1.0 download matched the original built APK, and its source ZIP passed CRC verification. Broader live testing then found that current episodes used a CDNPlus packed HLS player missing from the original adapter. Version 1.0.1 parses that player's bounded string dictionary without executing its scripts and validates the discovered HTTPS stream host. A long-page regression test covers a stack overflow encountered during development of the parser.

A separate regression reproduced loss of a virtual series' source page during an ID-only metadata lookup. The repository now retains the known series identity so subsequent episode navigation still uses the correct source page.

## Checks

Final automated result: 164 tests, zero failures/errors/skips, including the live checks. This count includes rejection/error checks; it does not imply VK playback succeeded.

The suite covers catalogue parsing, movie/series browse tabs, English/Arabic search, native detail identities, season/episode links, native Media3 preparation, resume/queue models and errors. Live checks sample three current movies and two current episodes for details, reachable artwork and stream resolution. Additional checks read HLS master/variant playlists and a bounded MPEG-TS segment; the existing MP4 smoke test reads an HTTP 206 MP4 header. Extensionless HLS preparation is checked on Robolectric API 35. Native ICU validates the provider regex grammar.

The new CDNPlus episode's HLS master and variant returned HTTP 200 and a segment returned video/MP2T with valid TS sync bytes. Media reads are bounded; entire films are not downloaded by the checks.

## Limits

No physical TV or emulator is attached here. Hardware decoding, sustained playback, audio routing, remote-control navigation and behaviour on other ISPs remain device checks. These tests do not prove that every title works. The catalogue exposes episode links present in the selected HTML page; provider-only pagination, absent subtitles, ratings and scene metadata remain limitations. The protected Leanback backend was not recovered: this app uses the public CEE mobile route.

Known failing title: cee_3217325 uses vkvideo.ru/video_ext.php. Its embed response presented a CAPTCHA and exposed no usable HLS stream. The app reports VK Video as unsupported; no stream is invented and the CAPTCHA is not bypassed. This is an unresolved playback limitation, not a passing playback check.
