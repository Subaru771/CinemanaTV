# Cee TV 1.2.0

Native CEE-backed Android TV app. Package `app.cinemanatv.cee`, version code 9, Android 8+. The release updates the existing separate Cee TV app; its local library is retained.

## Interface and navigation

A fixed navigation rail replaces the crowded top tabs. Home, Series, Movies, Search, History, My List, Downloads and Settings are directly reachable. The selected destination stays visible, and navigation does not expand over the content. Home has a compact featured area, Resume and My List actions, category shortcuts, poster rows and watch progress. Background artwork is softened on devices supporting Android blur effects. Decoder-supported quality rows show actual dimensions and bitrate when declared.

Focus restoration respects a viewer moving to another control. Search keeps the previous destination for Close/Back. Returning from a detail preserves a still-visible row/card position rather than snapping it to the beginning. The error screen's Quality action dismisses the error overlay so the quality menu can actually open. Error actions occupy separate rows and can scroll on smaller screens.

## Streaming and recovery

Network cancellation covers the response body as well as headers. Leaving a lookup or reaching its deadline cancels the actual OkHttp call. Source search retains a provider-declared native candidate if a sample is inconclusive and no checked alternative succeeds; the native player then determines whether it can play. A retained candidate is not labelled verified.

HLS checks can try another declared rendition, including alternatives at the same height, when one child playlist/segment fails. Redirects are validated over HTTPS and relative media URIs use the final playlist URL. Small range samples can fall back to an ordinary GET for servers rejecting the range method. Long movie playlists are sampled with a bounded prefix. Download quality discovery can inspect another master if the first has no readable rendition list. Masters remain intact for alternate audio.

Auto/manual quality, video-track overrides, audio, subtitles, resume, existing scene controls, local history/list/downloads, update notices and Telegram actions are retained. Actual source metadata, supported tracks and runtime determine which features are available. Genuine VK embeds use the official player's own controls; native offline/quality controls do not apply to that embedded player. Provider outages, access refusals and unsupported media cannot be guaranteed fixed by an APK.

## Playback reports

Copy report is available on a playback error and in the player options. It includes app version, Android/model, title ID, network type, media hostname and sanitized error text. URL paths/query tokens and private headers are removed. The viewer chooses where to share the copied text.

## Build and verification

Use JDK 17 and Android SDK 35. Run `bash gradlew testDebugUnitTest assembleRelease`. Optional provider checks require `CEE_LIVE_TEST=1`; their results are recorded separately. Regression tests include cancellation during headers/body, partial source/candidate failures, HLS variants and redirect bases, report redaction, TV remote controls and browse-position restoration. UI rendering is checked at 1280x720. No physical TV or sustained full-movie decoding test was available.

The release uses the same configured sideload signing key as previous Cee TV APKs. The passive update feed remains `https://raw.githubusercontent.com/Subaru771/CinemanaTV/main/downloads/CeeTV-updates.json`. Installation uses the Android system flow.
