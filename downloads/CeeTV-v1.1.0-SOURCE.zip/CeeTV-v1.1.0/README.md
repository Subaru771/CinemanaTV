# Cee TV 1.1.0

Native Android TV app using the user's Cinemana TV UI/player foundation and CEE's public catalogue/player route. Package app.cinemanatv.cee, version code 6, Android 8+. Optimized APK uses the same development signing key as previous Cee TV deliveries.

This release refines the green interface, cleans website wrappers from displayed titles, makes the hero scrollable, adds category grids with page loading/restored position, restores Telegram and update notices, and introduces an original vector logo and branded startup screen. Source-advertised extra episode pages can be loaded natively. Existing player, library, downloads and settings features are retained; see FEATURE-PARITY.md for provider-dependent limits.

Categories are read from the public WordPress category index; titles, artwork and excerpts from its public posts endpoint. The application does not fabricate category URLs or content ratings. HTML detail metadata supplies genres and ratings when actually present. Search offers explicit detail loading before applying metadata filters.

Update feed: https://raw.githubusercontent.com/Subaru771/CinemanaTV/main/downloads/CeeTV-updates.json
Telegram: https://t.me/CinemanaHub

The feed is separate from the original Cinemana TV app. A current build does not show a fake new-version notification; a future higher version prompts on startup, subject to skip/reminder preferences. Older builds with their feed disabled need this APK installed manually once.

Build with JDK 17 and Android SDK 35:

    bash gradlew testDebugUnitTest assembleRelease

Optional live network checks:

    CEE_LIVE_TEST=1 bash gradlew testDebugUnitTest

UI snapshots can be saved by setting CEE_PREVIEW_DIR during tests. A physical TV check is still required for remote feel, hardware decoding, long downloads and every provider-hosted video. Native test snapshots are automated rendering previews, not physical TV captures.
