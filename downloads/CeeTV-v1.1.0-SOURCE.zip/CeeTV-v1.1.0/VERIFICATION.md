# Verification

- Existing player, download, subtitle, scene-marker, network and preference tests retained.
- Category index/media type mapping and REST artwork/synopsis/source identity parsing tested with fixtures.
- Live provider check verifies seven category collections and a second page of actual movie titles.
- Display-only title cleanup tested without changing stored titles/source IDs.
- Source-declared genres/rating/synopsis extraction tested without invented IMDb references.
- Extra episode-page cursors and season/parent identities tested with source-shaped fixtures.
- Native UI rendering covers startup, home, About/settings and collection state retained through title navigation.
- Update parsing rejects a release identified as the original app package.
- Native ICU checks cover production provider regexes.

One intermediate live relay check returned HTTP 502 from stream.cinemana.cc. It is a provider response, separate from catalogue/UI checks. Final results are recorded after verification; a passing fixture or routing test does not establish universal video availability.

Final deterministic build: testDebugUnitTest and assembleRelease succeeded. 179 tests passed; seven optional live tests skipped for that build. The prior live run passed six of seven network checks, including categories/pagination and current source routes; one relay playlist request returned HTTP 502. This is not reported as a passing live playback check. Native home/startup/About UI previews were rendered and visually inspected. APK signature and package/version are checked before publishing.
