package app.cinemanatv.ui

import android.app.Application
import android.os.Looper
import android.view.View
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import app.cinemanatv.Services
import app.cinemanatv.data.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.time.Duration
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w1280dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class RefinedUiTest {
    private fun layout(view:View) {
        repeat(3) {
            androidx.compose.runtime.snapshots.Snapshot.sendApplyNotifications()
            view.measure(View.MeasureSpec.makeMeasureSpec(1280,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(720,View.MeasureSpec.EXACTLY))
            view.layout(0,0,1280,720)
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(400))
        }
    }
    private fun snapshot(view:View,name:String) {
        val path=System.getenv("CEE_PREVIEW_DIR") ?: return
        val bitmap=Bitmap.createBitmap(1280,720,Bitmap.Config.ARGB_8888)
        view.draw(Canvas(bitmap))
        val file=File(path,name+".png");file.parentFile!!.mkdirs()
        file.outputStream().use {bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
        bitmap.recycle()
    }
    @Test fun startupRendersAndCollectionStateSurvivesOpeningADetail() {
        val controller=Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        val activity=controller.get()
        Services.prefs=Prefs(activity)
        val movie=Video(nb="cee_123",kind="1",enTitle="فيلم Example 2026 مترجم",year="2026",providerPageId="123")
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=HomeData(listOf(movie),listOf(ContentRow("Latest movies",listOf(movie))))})
        val vm=AppViewModel()
        val section=CatalogSection("test","International movies",1,7,100)
        vm.push(Screen.Collection(section))
        val state=vm.collectionState(section.key)
        state.videos=listOf(movie);state.page=2;state.loadedPage=2
        vm.push(Screen.Detail(movie));assertTrue(vm.pop())
        assertSame(state,vm.collectionState(section.key))
        assertEquals(2,vm.collectionState(section.key).page)
        assertEquals(movie,vm.collectionState(section.key).videos.single())
        activity.setContent {CinemanaTheme{CinemaStartup()}}
        layout(activity.window.decorView)
        snapshot(activity.window.decorView,"Cee-TV-startup")
        assertFalse(activity.isFinishing)
        controller.pause().stop().destroy()
    }
    @Test fun homeAndSettingsRenderWithTheNewNavigation() {
        val controller=Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        val activity=controller.get()
        Services.prefs=Prefs(activity)
        val preview=System.getenv("CEE_PREVIEW_DATA")?.let { root ->
            val file=File(root,"posts.json")
            if(file.isFile)CeeSections.posts(file.readText(),1).map { v ->
                val image=File(root,v.id.removePrefix("cee_")+".jpg")
                if(image.isFile)v.copy(imgObjUrl=image.toURI().toString()) else v
            } else emptyList()
        }.orEmpty()
        val placeholders=(1..8).map {Video(nb="cee_$it",kind="1",enTitle="فيلم Story $it 2026 مترجم",year="2026",enContent="A new story to discover.",providerPageId=it.toString())}
        val titles=preview.ifEmpty{placeholders}
        val generated=HomeData(titles.take(2),listOf(ContentRow("Latest movies",titles),ContentRow("Indian cinema",titles,CatalogSection("indian","Indian cinema",1,2,40))))
        val savedHome=System.getenv("CEE_PREVIEW_DATA")?.let { File(it,"home.json") }?.takeIf{it.isFile}
        val data=savedHome?.let{com.google.gson.Gson().fromJson(it.readText(),HomeData::class.java)} ?: generated
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data})
        val vm=AppViewModel();vm.homeCache[0]=data;vm.markHomeFresh(0)
        activity.setContent {CinemanaTheme{MainShell(vm)}}
        layout(activity.window.decorView)
        snapshot(activity.window.decorView,"Cee-TV-home")
        controller.pause().stop().destroy()
        vm.tab=7;vm.settingsCategory=8
        val settings=Robolectric.buildActivity(ComponentActivity::class.java).setup().visible()
        settings.get().setContent {CinemanaTheme{MainShell(vm)}}
        layout(settings.get().window.decorView)
        snapshot(settings.get().window.decorView,"Cee-TV-settings")
        assertEquals(8,vm.settingsCategory)
        assertFalse(settings.get().isFinishing)
        settings.pause().stop().destroy()
    }
}
