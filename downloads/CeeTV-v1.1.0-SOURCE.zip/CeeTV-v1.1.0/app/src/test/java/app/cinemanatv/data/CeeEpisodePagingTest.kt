package app.cinemanatv.data
import org.junit.Test
import org.junit.Assert.*

class CeeEpisodePagingTest {
    private val parent=Video(nb="cee_series_example",kind="2",enTitle="Example",providerPageId="123")
    @Test fun readsOnlyTheRealSourcePagingButtonAndRetainsItsSeason() {
        val html="""<button class="season-trigger" data-target="s2">موسم2</button><div class="season-wrapper" id="s2"><button class="load-more-episodes" data-season="987" data-page="2" data-current="123">More</button></div><script>const example='.load-more-episodes';</script>"""
        val cursor=CeeCatalogParser.episodeCursors(html,parent).single()
        assertEquals(2,cursor.season)
        assertEquals("987",cursor.seasonId)
        assertEquals(2,cursor.page)
        assertEquals("123",cursor.currentPostId)
    }
    @Test fun laterEpisodeChunksPreserveSeriesIdentityAndSeason() {
        val videos=CeeCatalogParser.episodeChunk("""<a href="/watch=555/"><span>EP</span><span>11</span></a>""",parent,2)
        assertEquals("cee_555",videos.single().id)
        assertEquals(11,videos.single().episodeNumber)
        assertEquals(2,videos.single().seasonNumber)
        assertEquals(parent.id,videos.single().rootSeries)
    }
    @Test fun ignoresInvalidCursorsInsteadOfPostingArbitraryValues() {
        val html="""<button class="load-more-episodes" data-season="not-an-id" data-page="2"></button>"""
        assertTrue(CeeCatalogParser.episodeCursors(html,parent).isEmpty())
    }
}
