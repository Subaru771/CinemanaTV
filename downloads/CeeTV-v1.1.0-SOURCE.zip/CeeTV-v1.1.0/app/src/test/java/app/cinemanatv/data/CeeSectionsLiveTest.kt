package app.cinemanatv.data
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test

class CeeSectionsLiveTest {
    @Test fun categoryCollectionsProvideRealTitlesAndAPageBeyondTheFirst()=runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1")
        val backend=CeeHtmlCatalog()
        val home=backend.home(null)
        System.getenv("CEE_PREVIEW_DATA")?.let { root ->
            val file=java.io.File(root,"home.json");file.parentFile!!.mkdirs()
            file.writeText(com.google.gson.Gson().toJson(home))
        }
        val collections=home.rows.mapNotNull{it.section}
        assertTrue(collections.any{it.title=="Arabic series"})
        assertTrue(collections.any{it.title=="Indian cinema"})
        val films=collections.first{it.title=="International movies"}
        val one=backend.browse(films,1)
        val two=backend.browse(films,2)
        assertTrue(one.any{!it.poster.isNullOrBlank()})
        assertTrue(two.isNotEmpty())
        assertTrue(two.any{v->one.none{it.id==v.id}})
        assertTrue(one.all{it.kind=="1"})
        println("Verified ${collections.size} provider collections, posters, and second-page titles")
    }
}
