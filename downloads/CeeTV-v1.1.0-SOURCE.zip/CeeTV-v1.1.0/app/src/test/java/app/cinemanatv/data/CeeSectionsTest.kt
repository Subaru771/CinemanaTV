package app.cinemanatv.data
import org.junit.Assert.*
import org.junit.Test

class CeeSectionsTest {
    @Test fun categoriesComeFromProviderIdsAndHaveCorrectMediaKinds() {
        val sections=CeeSections.categories("""[{"id":7,"name":"أفلام أجنبي","count":96},{"id":8,"name":"مسلسلات عربية","count":72},{"id":9,"name":"اغاني عربي","count":2}]""")
        assertEquals(listOf(7,8),sections.map{it.categoryId})
        assertEquals(listOf(1,2),sections.map{it.kind})
        assertEquals(96,sections.first().totalPosts)
    }
    @Test fun restCardsHaveActualArtworkSynopsisAndSourceIdentity() {
        val videos=CeeSections.posts("""[{"id":123,"title":{"rendered":"فيلم Example &amp; More 2026 مترجم"},"excerpt":{"rendered":"<p>Actual synopsis</p>"},"_embedded":{"wp:featuredmedia":[{"source_url":"https://cinamana.cc/poster.jpg"}]}}]""",1)
        val video=videos.single()
        assertEquals("cee_123",video.id)
        assertEquals("123",video.providerPageId)
        assertEquals("Actual synopsis",video.description)
        assertEquals("https://cinamana.cc/poster.jpg",video.poster)
        assertEquals("Example & More",video.displayTitle)
    }
    @Test fun displayCleanupDoesNotChangeIdentityOrEraseANumericMovieName() {
        val source=Video(nb="cee_1",enTitle="فيلم 1917 مترجم",year="1917")
        assertEquals("1917",source.displayTitle)
        assertEquals("فيلم 1917 مترجم",source.title)
        assertEquals("cee_1",source.id)
    }
    @Test fun metadataUsesOnlyGenresAndRatingActuallyDeclaredByThePage() {
        val body="""<h1>فيلم Example 2026 مترجم</h1><span>IMDb 7.4</span><h4>القصة</h4><p>Verified plot</p><script>const postData = {genres:["%d8%af%d8%b1%d8%a7%d9%85%d8%a7"]};</script>"""
        val video=CeeCatalogParser.detail(body,Video(nb="cee_123",kind="1",enTitle="Example",providerPageId="123"))
        assertEquals("7.4",video.stars)
        assertEquals("Verified plot",video.description)
        assertEquals(listOf("دراما"),video.genres)
        assertNull(video.imdbRef)
    }
}
