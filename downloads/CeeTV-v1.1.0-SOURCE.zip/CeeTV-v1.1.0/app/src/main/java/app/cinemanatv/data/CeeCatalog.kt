package app.cinemanatv.data

import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import java.io.IOException
import java.security.MessageDigest

interface CeeCatalog {
    suspend fun browse(section: CatalogSection, page: Int): List<Video> = emptyList()
    suspend fun home(kind: Int?): HomeData
    suspend fun search(query: String): List<Video>
    suspend fun detail(video: Video): Video
    suspend fun episodePage(video:Video,cursors:List<EpisodeCursor>?=null):EpisodeBatch = EpisodeBatch(episodes(video))
    suspend fun episodes(video: Video): List<Video>
    suspend fun related(video: Video): List<Video>
    suspend fun sources(id: String): PlaySources
    suspend fun subtitles(id: String): List<SubtitleOption> = emptyList()
}

/** HTML data adapter for the public catalogue/player route verified from CEE. No web UI. */
object CeeCatalogParser {
    private val year = Regex("\\b(?:19|20)[0-9]{2}\\b")
    private val episodePattern = Regex("(?i)(?:الحلقة|حلقة|episode|ep)\\s*[-:]?\\s*([0-9]+)|\\bS[0-9]+E([0-9]+)\\b")
    private val seasonPattern = Regex("(?i)(?:الموسم|موسم|season)\\s*([^\\s–—:]+)|\\bS([0-9]+)E[0-9]+\\b")
    private val ordinals = mapOf("الاول" to 1, "الأول" to 1, "الأولى" to 1, "الاولى" to 1, "الثاني" to 2,
        "الثالث" to 3, "الرابع" to 4, "الخامس" to 5, "السادس" to 6, "السابع" to 7, "الثامن" to 8, "التاسع" to 9, "العاشر" to 10)
    private fun digits(s: String) = s.map { if (it in '\u0660'..'\u0669') '0' + (it - '\u0660') else it }.joinToString("")
    private fun number(s: String): Int? = digits(s).trim().toIntOrNull() ?: ordinals[s.trim()]
    fun season(s: String): Int = seasonPattern.find(digits(s))?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }?.let(::number) ?: 1
    fun episode(s: String): Int = episodePattern.find(digits(s))?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }?.toIntOrNull() ?: 0
    fun seriesTitle(s: String): String {
        val markers = listOf("الموسم", "الحلقة", "حلقة", "season", "episode")
        val at = markers.map { s.indexOf(it, ignoreCase = true) }.filter { it >= 0 }.minOrNull() ?: s.length
        return s.take(at).trim(' ', '-', '–', '—', ':').removePrefix("مسلسل ").removePrefix("انمي ").removePrefix("أنمي ").trim()
    }
    private fun safeUrl(s: String?): String? = s?.toHttpUrlOrNullSafe()
    private fun String.toHttpUrlOrNullSafe(): String? = runCatching {
        val u = toHttpUrl(); if (u.scheme == "https" && u.username.isEmpty() && u.password.isEmpty()) u.toString() else null
    }.getOrNull()
    private fun poster(element: Element): String? {
        val image = element.selectFirst("img[data-src], img[src]")
        safeUrl(image?.let { it.attr("data-src").ifBlank { it.absUrl("src") } })?.let { return it }
        val style = element.selectFirst("[style*=background-image]")?.attr("style").orEmpty()
        return safeUrl(style.substringAfter("url(", "").substringBefore(')').trim(' ', '\'', '"'))
    }
    internal fun card(id: String, title: String, image: String?, expectedKind: String? = null): Video {
        val ep = episode(title)
        val isSeries = expectedKind == "2" || (expectedKind != "1" && (ep > 0 || title.contains("مسلسل") || title.contains("الموسم")))
        return Video(nb = "cee_$id", kind = if (isSeries) "2" else "1", enTitle = title,
            year = year.findAll(digits(title)).lastOrNull()?.value, imgObjUrl = image,
            season = if (isSeries && ep > 0) season(title).toString() else null,
            episodeNummer = if (isSeries && ep > 0) ep.toString() else null, providerPageId = id)
    }
    fun cards(html: String, expectedKind: String? = null): List<Video> = Jsoup.parse(html, CeeAlternativeSource.BASE)
        .select("a[href]").asSequence().filterNot { it.hasClass("cn-mega-item") }.mapNotNull { link ->
            val id = CeeAlternativeSource.pageId(link.absUrl("href")) ?: return@mapNotNull null
            val title = link.selectFirst("h2,h3")?.text()?.trim()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            card(id, title, poster(link), expectedKind)
        }.distinctBy { it.id }.take(180).toList()

    fun parent(video: Video): Video {
        val name = seriesTitle(video.title)
        val key = MessageDigest.getInstance("SHA-256").digest((name.lowercase()+"|"+video.year.orEmpty()).toByteArray())
            .take(8).joinToString("") { "%02x".format(it.toInt() and 255) }
        return video.copy(nb = "cee_series_$key", kind = "2", enTitle = name, season = null,
            episodeNummer = null, rootSeries = null, rootSeriesInfo = null)
    }
    fun postId(video: Video): String = (video.providerPageId ?: video.id.removePrefix("cee_")).takeIf {
        it.length in 1..12 && it.all { c -> c in '0'..'9' }
    } ?: throw IOException("CEE title is missing its source page identity.")

    fun detail(html: String, fallback: Video): Video {
        val doc = Jsoup.parse(html, CeeAlternativeSource.BASE)
        val heading = doc.selectFirst("h1")?.text()?.takeIf { it.isNotBlank() } ?: fallback.title
        val image = safeUrl(doc.selectFirst("#watch-later-btn")?.attr("data-poster"))
            ?: safeUrl(doc.selectFirst("meta[property=og:image]")?.attr("content")) ?: fallback.poster
        val parsed = card(postId(fallback), heading, image, fallback.kind)
        val description = doc.selectFirst("[itemprop=description], .story, .StoryArea, .post-story")?.text()
            ?: doc.selectFirst("meta[property=og:description]")?.attr("content")
        val imdb = doc.select("a[href*=imdb.com/title/]").mapNotNull {
            ExternalSceneMarkers.imdbID(it.attr("href"))
        }.distinct().singleOrNull()
        val sourceScript=doc.select("script:not([src])").map { it.data() }.firstOrNull { it.contains("const postData =") }.orEmpty()
        val tags=runCatching {
            val array=Regex("""genres\s*:\s*(\[[^\]]*\])""").find(sourceScript)?.groupValues?.get(1)
            array?.let { com.google.gson.JsonParser.parseString(it).asJsonArray.map { item ->
                java.net.URLDecoder.decode(item.asString,"UTF-8").replace('-',' ')
            }.filter { tag-> tag.isNotBlank() }.distinct() }.orEmpty()
        }.getOrDefault(emptyList())
        val genreJson=tags.takeIf { it.isNotEmpty() }?.let { com.google.gson.Gson().toJsonTree(it) } ?: fallback.categories
        val providerPlot=doc.select("h4").firstOrNull { it.text().trim()=="القصة" }?.nextElementSibling()?.text()?.trim()?.takeIf { it.isNotBlank() }
        val score=doc.select("span").mapNotNull { badge ->
            Regex("""IMDb\s*([0-9]+(?:\.[0-9]+)?)""").matchEntire(badge.text().trim())?.groupValues?.get(1)
        }.filter { it.toDoubleOrNull()?.let { value -> value in 0.0..10.0 } == true }.distinct().singleOrNull()
        val result = parsed.copy(enContent = (providerPlot ?: description)?.take(2000)?.takeIf { it.isNotBlank() } ?: fallback.enContent,
            imdbRef = imdb ?: fallback.imdbRef, year = parsed.year ?: fallback.year,
            categories = genreJson, filmRating = fallback.filmRating, stars = score ?: fallback.stars,
            season = parsed.season ?: fallback.season, episodeNummer = parsed.episodeNummer ?: fallback.episodeNummer)
        return if (fallback.id.startsWith("cee_series_")) parent(result).copy(nb = fallback.id, enTitle = fallback.title)
        else result.copy(nb = fallback.id, rootSeries = fallback.rootSeries, rootSeriesInfo = fallback.rootSeriesInfo)
    }

    fun episodeCursors(html:String,video:Video):List<EpisodeCursor> {
        val doc=Jsoup.parse(html,CeeAlternativeSource.BASE)
        val labels=doc.select(".season-trigger[data-target]").associate { it.attr("data-target") to it.text() }
        return doc.select(".load-more-episodes[data-season][data-page]").mapNotNull { button ->
            val id=button.attr("data-season").takeIf { it.matches(Regex("[0-9]{1,12}")) } ?: return@mapNotNull null
            val page=button.attr("data-page").toIntOrNull()?.takeIf { it in 1..1000 } ?: return@mapNotNull null
            val current=button.attr("data-current").ifBlank { postId(video) }
                .takeIf { it.matches(Regex("[0-9]{1,12}")) } ?: return@mapNotNull null
            val section=button.parents().firstOrNull { it.hasClass("season-wrapper") }?.id().orEmpty()
            EpisodeCursor(season(labels[section].orEmpty()),id,current,page)
        }.distinctBy{it.seasonId}
    }
    fun episodeChunk(html:String,parent:Video,season:Int):List<Video> = episodes(
        "<button class='season-trigger' data-target='chunk'>موسم $season</button><div id='chunk' class='season-wrapper'><div class='episodes-grid'>$html</div></div>",parent)

    fun episodes(html: String, parent: Video): List<Video> {
        val doc = Jsoup.parse(html, CeeAlternativeSource.BASE)
        val labels = doc.select(".season-trigger[data-target]").associate { it.attr("data-target") to it.text() }
        return doc.select(".season-wrapper").flatMap { section ->
            val season = season(labels[section.id()].orEmpty())
            section.select(".episodes-grid a[href]").mapNotNull { link ->
                val id = CeeAlternativeSource.pageId(link.absUrl("href")) ?: return@mapNotNull null
                val ep = Regex("[0-9]+").find(digits(link.text()))?.value?.toIntOrNull() ?: return@mapNotNull null
                Video(nb = "cee_$id", kind = "2", enTitle = "${parent.title} · S$season E$ep",
                    imgObjUrl = parent.poster, year = parent.year, season = season.toString(), episodeNummer = ep.toString(),
                    rootSeries = parent.id, rootSeriesInfo = parent, providerPageId = id)
            }
        }.distinctBy { it.id }.sortedWith(compareBy({ it.seasonNumber }, { it.episodeNumber }))
    }
}

class CeeHtmlCatalog : CeeCatalog {
    private data class Page(val body: String, val expires: Long)
    private val pages = LinkedHashMap<String, Page>()
    private suspend fun page(url: String): String {
        synchronized(pages) { pages[url]?.takeIf { it.expires > System.currentTimeMillis() } }?.let { return it.body }
        val html = CeeAlternativeSource.document(url)
        synchronized(pages) {
            pages[url] = Page(html, System.currentTimeMillis()+120_000)
            while(pages.size>32) pages.remove(pages.keys.first())
        }
        return html
    }
    private fun url(video: Video) = "${CeeAlternativeSource.BASE}watch=${CeeCatalogParser.postId(video)}/"
    private val slots = kotlinx.coroutines.sync.Semaphore(3)
    private suspend fun restPage(section:CatalogSection, pageNumber:Int):List<Video> {
        require(pageNumber in 1..10000)
        val builder = (CeeAlternativeSource.BASE + "wp-json/wp/v2/posts").toHttpUrl().newBuilder()
            .addQueryParameter("per_page", "24").addQueryParameter("page", pageNumber.toString())
            .addQueryParameter("_embed", "wp:featuredmedia,wp:term")
            .addQueryParameter("_fields", "id,title,excerpt,_links,_embedded,categories")
        section.categoryId?.let { builder.addQueryParameter("categories", it.toString()) }
        return slots.withPermit { CeeSections.posts(page(builder.build().toString()), section.kind) }
    }
    override suspend fun browse(section:CatalogSection,page:Int):List<Video> {
        require(section.categoryId != null) { "This collection has no provider category." }
        return restPage(section,page)
    }
    override suspend fun home(kind: Int?): HomeData = coroutineScope {
        val movies = if (kind != 2) async { CeeCatalogParser.cards(page("${CeeAlternativeSource.BASE}movies/"), "1") } else null
        val episodes = if (kind != 1) async { CeeCatalogParser.cards(page("${CeeAlternativeSource.BASE}series/"), "2") } else null
        val sections = try { CeeSections.categories(page("${CeeAlternativeSource.BASE}wp-json/wp/v2/categories?per_page=100&hide_empty=true")) }
            catch(c:kotlinx.coroutines.CancellationException){throw c}catch(_:Exception){emptyList()}
        val chosen = sections.filter { kind == null || it.kind == null || it.kind == kind }
        val extra = chosen.map { section -> async {
            try {
                val videos=restPage(section,1).filter { kind == null || it.kind == kind.toString() }
                val cards=videos.map { if(it.kind=="2") CeeCatalogParser.parent(it) else it }.distinctBy { it.id }
                cards.takeIf { it.isNotEmpty() }?.let { ContentRow(section.title,it,section) }
            }catch(c:kotlinx.coroutines.CancellationException){throw c}catch(_:Exception){null}
        } }.mapNotNull { it.await() }
        val enriched = extra.flatMap { it.items }.associateBy { it.id }
        val films = movies?.await().orEmpty().map { enriched[it.id] ?: it }
        val recent = episodes?.await().orEmpty()
        val series = recent.map(CeeCatalogParser::parent).map { enriched[it.id] ?: it }.distinctBy { it.id }
        val rows = buildList {
            if (films.isNotEmpty()) add(ContentRow("Latest movies", films))
            if (series.isNotEmpty()) add(ContentRow("Recently updated series", series))
            addAll(extra)
            val premieres=recent.filter { it.episodeNumber==1 }.map(CeeCatalogParser::parent).distinctBy { it.id }
            if(premieres.isNotEmpty())add(ContentRow("Season premieres", premieres))
            if (recent.isNotEmpty()) add(ContentRow("Latest episodes", recent))
            for (year in films.mapNotNull{it.year}.distinct().sortedDescending().take(3)) {
                val titles=films.filter { it.year==year }
                if(titles.size>=3)add(ContentRow(year+" · Movies",titles))
            }
        }
        if (rows.isEmpty()) throw IOException("CEE did not return recognizable catalogue titles.")
        HomeData((films.ifEmpty { series }).take(6), rows)
    }
    override suspend fun search(query: String): List<Video> {
        val address = CeeAlternativeSource.BASE.toHttpUrl().newBuilder().addQueryParameter("s", query.trim().take(250)).build().toString()
        return CeeCatalogParser.cards(page(address)).map { if(it.kind=="2") CeeCatalogParser.parent(it) else it }.distinctBy { it.id }
    }
    override suspend fun detail(video: Video): Video = withContext(Dispatchers.IO) { CeeCatalogParser.detail(page(url(video)), video) }
    override suspend fun episodes(video:Video):List<Video> = episodePage(video).videos
    override suspend fun episodePage(video:Video,cursors:List<EpisodeCursor>?):EpisodeBatch = withContext(Dispatchers.IO) {
        if(video.kind=="1")return@withContext EpisodeBatch(emptyList())
        val body=page(url(video))
        val parent=if(video.id.startsWith("cee_series_"))video else CeeCatalogParser.parent(CeeCatalogParser.detail(body,video))
        if(cursors==null)return@withContext EpisodeBatch(CeeCatalogParser.episodes(body,parent),CeeCatalogParser.episodeCursors(body,video))
        coroutineScope {
            val chunks=cursors.map { cursor -> async {
                val html=slots.withPermit { CeeAlternativeSource.episodeDocument(cursor) }
                val items=CeeCatalogParser.episodeChunk(html,parent,cursor.season)
                items to cursor.takeIf{items.isNotEmpty() && cursor.page<1000}?.copy(page=cursor.page+1)
            } }.map { it.await() }
            EpisodeBatch(chunks.flatMap{it.first}.distinctBy{it.id},chunks.mapNotNull{it.second})
        }
    }
    override suspend fun related(video: Video): List<Video> = CeeCatalogParser.cards(page(url(video)))
        .filter { it.id != video.id }.map { if(it.kind=="2") CeeCatalogParser.parent(it) else it }.distinctBy { it.id }.take(24)
    override suspend fun sources(id: String): PlaySources {
        if(id.startsWith("cee_series_")) throw IOException("Choose an episode from this series.")
        return CeeAlternativeSource.resolve(id)
    }
}
