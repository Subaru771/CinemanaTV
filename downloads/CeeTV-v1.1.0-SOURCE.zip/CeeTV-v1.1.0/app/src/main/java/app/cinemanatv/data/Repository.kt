package app.cinemanatv.data

import android.content.Context
import com.google.gson.Gson
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Native CEE repository. No original-provider catalogue, matching step or fallback gate. */
class Repository(private val backend: CeeCatalog, private val homeDir: File? = null) {
    private val gson = Gson()
    private val models = ConcurrentHashMap<String,Video>()
    private val details = ConcurrentHashMap<String,Pair<Long,Video>>()
    private data class Warm(val at: Long, val sources: PlaySources)
    private val prefetched = LinkedHashMap<String,Warm>()
    private fun remember(v: Video): Video {
        models[v.id]=v
        if(models.size>512) models.keys.firstOrNull { it != v.id }?.let(models::remove)
        return v
    }
    private fun homeFile(kind: Int?) = homeDir?.let { File(it,"cee_home_${kind ?: 0}.json") }
    suspend fun cachedHome(kind: Int?): HomeData? = withContext(Dispatchers.IO) {
        try {
            val data = homeFile(kind)?.takeIf { it.isFile }?.readText()?.let { gson.fromJson(it,HomeData::class.java) }
            data?.rows?.forEach { row -> row.items.forEach(::remember) }
            data?.takeIf { it.rows.isNotEmpty() }
        } catch(c: CancellationException) { throw c } catch(_:Exception) { null }
    }
    fun clearHomeCache() { homeDir?.listFiles()?.forEach { it.delete() } }
    suspend fun loadHome(kind: Int?): HomeData {
        val data = withContext(Dispatchers.IO) { backend.home(kind) }
        data.rows.forEach { row -> row.items.forEach(::remember) }
        withContext(Dispatchers.IO) {
            runCatching {
                val target=homeFile(kind) ?: return@runCatching
                target.parentFile?.mkdirs()
                val temporary=File(target.parentFile,target.name+".tmp")
                temporary.writeText(gson.toJson(data));if(!temporary.renameTo(target)){target.delete();temporary.renameTo(target)}
            }
        }
        return data
    }
    suspend fun browse(section:CatalogSection,page:Int):List<Video> = withContext(Dispatchers.IO) { backend.browse(section,page) }.onEach(::remember)
    suspend fun search(query:String):List<Video> = withContext(Dispatchers.IO) { backend.search(query) }.onEach(::remember)
    suspend fun info(v:Video):Video = try { infoOrNull(v) ?: v } catch(c:CancellationException){throw c} catch(_:Exception){v}
    suspend fun infoOrNull(v:Video,refresh:Boolean=false):Video? {
        val selected = if(v.providerPageId == null) models[v.id] ?: v else v
        remember(selected)
        if(!refresh) details[v.id]?.takeIf { System.currentTimeMillis()-it.first<120_000 }?.let {return it.second}
        return try {
            withContext(Dispatchers.IO) { backend.detail(selected) }.also { remember(it);details[v.id]=System.currentTimeMillis() to it }
        }catch(c:CancellationException){throw c}catch(_:Exception){null}
    }
    suspend fun episodePage(video:Video,cursors:List<EpisodeCursor>?=null):EpisodeBatch = withContext(Dispatchers.IO){backend.episodePage(remember(video),cursors)}.also{it.videos.forEach(::remember)}
    suspend fun episodes(id:String):List<Video> = withContext(Dispatchers.IO) { backend.episodes(models[id] ?: Video(nb=id)) }.onEach(::remember)
    suspend fun related(id:String):List<Video> = withContext(Dispatchers.IO) { backend.related(models[id] ?: Video(nb=id)) }.onEach(::remember)
    suspend fun loadSources(id:String):PlaySources = backend.sources(id)
    suspend fun loadSubtitles(id:String):List<SubtitleOption> = backend.subtitles(id)
    suspend fun prefetchSources(id:String) {
        synchronized(prefetched){prefetched[id]?.takeIf{System.currentTimeMillis()-it.at<60_000}}?.let{return}
        try {
            val result=withTimeoutOrNull(10_000L){loadSources(id)} ?: return
            if(result.qualities.isEmpty() && result.vkPlayerUrl == null)return
            synchronized(prefetched){
                prefetched[id]=Warm(System.currentTimeMillis(),result)
                while(prefetched.size>4)prefetched.remove(prefetched.keys.first())
            }
        }catch(c:CancellationException){throw c}catch(_:Exception){ }
    }
    fun peekPrefetched(id:String,maxAgeMs:Long=150_000L):PlaySources? = synchronized(prefetched){
        prefetched[id]?.takeIf { System.currentTimeMillis()-it.at in 0..maxAgeMs }?.sources
    }
    fun takePrefetched(id:String,maxAgeMs:Long=150_000L):PlaySources? = synchronized(prefetched){
        prefetched.remove(id)?.takeIf { System.currentTimeMillis()-it.at in 0..maxAgeMs }?.sources
    }
    suspend fun probe():String = try {
        val data=withContext(Dispatchers.IO) { backend.home(null) }
        "CEE catalogue reachable: ${data.rows.sumOf{it.items.size}} titles in ${data.rows.size} rows."
    }catch(c:CancellationException){throw c}catch(e:Exception){"CEE catalogue unavailable: ${e.javaClass.simpleName}"}
    suspend fun networkReport(context:Context,recentVideoId:String?):String {
        val link=app.cinemanatv.util.NetworkResilience.link(context)
        if(!link.connected)return "No active connection."
        val catalogue=probe()
        val id=recentVideoId?.takeUnless{it.startsWith("cee_series_")}
            ?: return "Network: ${link.type}\n$catalogue\nOpen a movie or episode before checking media."
        return try {
            val sources=loadSources(id)
            if (sources.vkPlayerUrl != null) return "$catalogue\nMedia: VK official embedded player (provider-controlled availability)."
            val stream=sources.qualities.lastOrNull() ?: return "$catalogue\nNo playable media returned."
            "Network: ${link.type}\n$catalogue\n${MediaRouteProbe.check(stream.url)}"
        }catch(c:CancellationException){throw c}catch(e:Exception){"$catalogue\nMedia: ${e.javaClass.simpleName}"}
    }
}
