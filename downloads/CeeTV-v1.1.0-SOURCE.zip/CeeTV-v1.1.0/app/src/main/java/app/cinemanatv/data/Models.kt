package app.cinemanatv.data

import com.google.gson.JsonElement
import com.google.gson.TypeAdapter
import com.google.gson.annotations.JsonAdapter
import com.google.gson.annotations.SerializedName
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonToken
import com.google.gson.stream.JsonWriter

/** IMDb references are identifiers or URLs, never numeric ratings or nested IMDb metadata. */
internal class ImdbReferenceAdapter : TypeAdapter<String>() {
    companion object {
        private val identifier = Regex("tt[0-9]{7,10}", RegexOption.IGNORE_CASE)
        fun reference(value: String): String? = value.trim().takeIf(identifier::containsMatchIn)
    }

    override fun read(reader: JsonReader): String? {
        if (reader.peek() != JsonToken.STRING) {
            reader.skipValue()
            return null
        }
        return reference(reader.nextString())
    }

    override fun write(writer: JsonWriter, value: String?) {
        if (value == null) writer.nullValue() else writer.value(value)
    }
}

/** Field aliases derived from multiple revisions of the Cinemana Android model. */
data class Video(
    @SerializedName(value = "nb", alternate = ["id", "videoId", "video_id"]) val nb: String? = null,
    @SerializedName(value = "kind", alternate = ["videoKind", "video_kind"]) val kind: String? = null,
    @SerializedName(value = "en_title", alternate = ["englishTitle", "enTitle", "english_title", "title", "name"]) val enTitle: String? = null,
    @SerializedName(value = "ar_title", alternate = ["arabicTitle", "arTitle", "arabic_title"]) val arTitle: String? = null,
    @SerializedName(value = "en_content", alternate = ["englishContent", "enContent", "description", "overview"]) val enContent: String? = null,
    @SerializedName(value = "ar_content", alternate = ["arabicContent", "arContent"]) val arContent: String? = null,
    @SerializedName(value = "stars", alternate = ["rating", "imdbRating"]) val stars: String? = null,
    val year: String? = null,
    val duration: String? = null,
    @SerializedName(value = "img", alternate = ["imageUrl", "imageURL"]) val img: String? = null,
    @SerializedName(value = "imgObjUrl", alternate = ["imageObjUrl", "imagePosterUrl"]) val imgObjUrl: String? = null,
    @SerializedName(value = "imgThumbObjUrl", alternate = ["imageThumbUrl", "imageThumbObjUrl"]) val imgThumbObjUrl: String? = null,
    @SerializedName(value = "imgMediumThumbObjUrl", alternate = ["imageThumbMediumUrl", "imageMediumThumbUrl", "poster"]) val imgMediumThumbObjUrl: String? = null,
    val season: String? = null,
    @SerializedName(value = "episodeNummer", alternate = ["episodeNumber", "episode"]) val episodeNummer: String? = null,
    val rootSeries: String? = null,
    @JsonAdapter(ImdbReferenceAdapter::class)
    @SerializedName(value = "imdbUrlRef", alternate = ["imdbID", "imdbId", "imdb_id", "imdbURL", "imdbLink", "imdbUrl", "imdb_url", "imdb"])
    val imdbRef: String? = null,
    @SerializedName(value = "filmRating", alternate = ["contentRating", "ageRating", "certification", "parentalRating", "film_rating"])
    val filmRating: String? = null,
    @SerializedName(value = "adult", alternate = ["isAdult", "is_adult", "explicitAdult"])
    val adult: JsonElement? = null,
    val rootSeriesInfo: Video? = null,
    val providerPageId: String? = null,
    // Optional provider/episode metadata. Never guess intro boundaries from duration.
    @SerializedName(value = "intro_start", alternate = ["introStart", "introFrom", "skipIntroStart", "introStartTime"]) val introStart: String? = null,
    @SerializedName(value = "intro_end", alternate = ["introEnd", "introTo", "skipIntroEnd", "introEndTime"]) val introEnd: String? = null,
    @SerializedName(value = "intro_start_ms", alternate = ["introStartMs"]) val introStartMs: Long? = null,
    @SerializedName(value = "intro_end_ms", alternate = ["introEndMs"]) val introEndMs: Long? = null,
    @SerializedName(value = "categories", alternate = ["genres", "genre", "category"]) val categories: JsonElement? = null,
) {
    val id: String get() = nb.orEmpty()
    val title: String get() = enTitle?.takeIf(String::isNotBlank) ?: arTitle.orEmpty()
    val description: String get() = enContent?.takeIf(String::isNotBlank) ?: arContent.orEmpty()
    private fun image(vararg candidates: String?): String? = candidates.firstOrNull { !it.isNullOrBlank() }
    val poster: String? get() = image(imgMediumThumbObjUrl, imgThumbObjUrl, imgObjUrl, img)
    val backdrop: String? get() = image(imgObjUrl, img, imgMediumThumbObjUrl)
    val thumb: String? get() = image(imgThumbObjUrl, imgMediumThumbObjUrl, imgObjUrl, img)
    // Episode cards prefer the larger image over the compressed thumbnail field.
    // The source may still supply only small artwork; we do not upscale it artificially.
    val episodeArtwork: String? get() = image(imgObjUrl, imgMediumThumbObjUrl, imgThumbObjUrl, img)
    val introWindow: LongRange? get() = app.cinemanatv.util.introWindow(
        introStartMs ?: app.cinemanatv.util.parseIntroStamp(introStart),
        introEndMs ?: app.cinemanatv.util.parseIntroStamp(introEnd)
    )
    val seasonNumber: Int get() = season?.toIntOrNull() ?: 1
    val episodeNumber: Int get() = episodeNummer?.toIntOrNull() ?: 0
    private fun tagNames(keys: List<String>): List<String> = runCatching {
        fun label(e: JsonElement): String? = when {
            e.isJsonPrimitive && e.asJsonPrimitive.isString -> e.asString
            e.isJsonObject -> keys
                .mapNotNull { k -> e.asJsonObject.get(k)?.takeIf {
                    it.isJsonPrimitive && it.asJsonPrimitive.isString
                }?.asString }.takeIf { it.isNotEmpty() }?.joinToString(",")
            else -> null
        }
        val names = when {
            categories == null || categories.isJsonNull -> emptyList()
            categories.isJsonArray -> categories.asJsonArray.mapNotNull(::label)
            else -> listOfNotNull(label(categories))
        }
        names.flatMap { it.split(',', '|') }.map(String::trim)
            .filter { it.isNotBlank() && it.any(Char::isLetter) }
            .distinctBy(String::lowercase)
    }.getOrNull().orEmpty()
    /** English genre names, used for browse rows and search filters. */
    val genres: List<String> get() = tagNames(listOf("en_title", "englishTitle", "name", "title", "genre"))
    /** English AND Arabic tags: the mature filter must see tags that exist in only one language. */
    val allTags: List<String> get() = tagNames(listOf("en_title", "englishTitle", "name", "title", "genre", "ar_title", "arabicTitle"))
    val rating: String? get() = stars?.toDoubleOrNull()?.let { "★ " + "%.1f".format(it) }
}

data class TokenResponse(
    @SerializedName("access_token") val accessToken: String? = null,
    @SerializedName("refresh_token") val refreshToken: String? = null,
    @SerializedName("expires_in") val expiresIn: Long? = null,
    @SerializedName("token_type") val tokenType: String? = null,
)

enum class Poll { Done, Pending, SlowDown }

data class DeviceAuthResponse(
    @SerializedName("device_code") val deviceCode: String? = null,
    @SerializedName("user_code") val userCode: String? = null,
    @SerializedName("verification_uri") val verificationUri: String? = null,
    @SerializedName("verification_uri_complete") val verificationUriComplete: String? = null,
    @SerializedName("expires_in") val expiresIn: Long? = null,
    val interval: Long? = null,
)

data class EpisodeCursor(val season:Int,val seasonId:String,val currentPostId:String,val page:Int)
data class EpisodeBatch(val videos:List<Video>,val next:List<EpisodeCursor> = emptyList())
data class CatalogSection(val key: String, val title: String, val kind: Int? = null, val categoryId: Int? = null, val totalPosts: Int = 0)
data class ContentRow(val title: String, val items: List<Video>, val section: CatalogSection? = null)
data class HomeData(val hero: List<Video>, val rows: List<ContentRow>)
data class QualityOption(val height: Int, val url: String, val name: String? = null, val mimeType: String? = null) {
    val label: String get() = name ?: when {
        height >= 2160 -> "4K (2160p)"
        height > 0 -> "${height}p"
        else -> "Auto"
    }
    /** HLS/DASH use Media3's offline manager, direct files use Android DownloadManager. */
    val adaptive: Boolean get() = mimeType.equals("application/x-mpegURL", true) ||
        mimeType.equals("application/dash+xml", true) || url.substringBefore('?').lowercase().let {
        it.endsWith(".m3u8") || it.endsWith(".mpd")
    }
    val progressive: Boolean get() = !adaptive
}
data class SubtitleOption(val label: String, val url: String, val mime: String)
data class PlaySources(val qualities: List<QualityOption>, val subtitles: List<SubtitleOption>, val vkPlayerUrl: String? = null)
