package app.cinemanatv.data

import com.google.gson.JsonParser
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.jsoup.Jsoup
import java.io.IOException

/** Uses the provider's public WordPress index, never guessed category URLs. */
object CeeSections {
    private val known = mapOf(
        "أفلام أجنبي" to ("International movies" to 1),
        "أفلام هندي" to ("Indian cinema" to 1),
        "مسلسلات عربية" to ("Arabic series" to 2),
        "مسلسلات تركية" to ("Turkish series" to 2),
        "مسلسلات أجنبي" to ("International series" to 2),
        "مسلسلات آسيوية" to ("Asian series" to 2),
        "أنمي" to ("Anime" to null),
    )
    fun categories(json:String):List<CatalogSection> {
        val data=JsonParser.parseString(json)
        if(!data.isJsonArray)throw IOException("CEE category index is unavailable.")
        val indexed=data.asJsonArray.mapNotNull { entry -> runCatching {
            val value=entry.asJsonObject
            val name=Jsoup.parse(value.get("name").asString).text()
            val settings=known[name] ?: return@runCatching null
            val id=value.get("id").asInt.takeIf { it>0 } ?: return@runCatching null
            CatalogSection("category_$id",settings.first,settings.second,id,value.get("count")?.asInt ?: 0)
        }.getOrNull() }.associateBy { it.title }
        return known.values.mapNotNull { indexed[it.first] }
    }
    fun posts(json:String,kind:Int?):List<Video> {
        val data=JsonParser.parseString(json)
        if(!data.isJsonArray)throw IOException("CEE collection did not return titles.")
        return data.asJsonArray.mapNotNull { entry -> runCatching {
            val value=entry.asJsonObject
            val id=value.get("id").asString.takeIf { it.length in 1..12 && it.all { c->c in '0'..'9' } }
                ?: return@runCatching null
            val title=Jsoup.parse(value.getAsJsonObject("title").get("rendered").asString).text()
            if(title.isBlank())return@runCatching null
            val embed=value.getAsJsonObject("_embedded")
            val image=embed?.getAsJsonArray("wp:featuredmedia")?.firstOrNull()?.asJsonObject?.get("source_url")?.asString
                ?.toHttpUrlOrNull()?.takeIf { it.scheme=="https" && it.username.isEmpty() && it.password.isEmpty() }?.toString()
            val synopsis=value.getAsJsonObject("excerpt")?.get("rendered")?.asString?.let { Jsoup.parse(it).text().take(2000) }
            val video=CeeCatalogParser.card(id,title,image,kind?.toString())
            video.copy(enContent=synopsis)
        }.getOrNull() }.distinctBy { it.id }
    }
}
