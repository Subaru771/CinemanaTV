package app.cinemanatv.ui

/** Text for the native Android TV Telegram invitation. The chosen in-app
 * interface language, not the phone/TV system locale, is the single source
 * of truth. Changing Settings > Interface language updates this card as well.
 */
data class TelegramCardCopy(
    val title: String,
    val description: String,
    val updates: String,
    val features: String,
    val news: String,
    val join: String,
    val later: String,
    val neverShow: String,
    val close: String,
)

fun telegramCardCopy(language: String): TelegramCardCopy = if (language == "ar") {
    TelegramCardCopy(
        title = "انضم إلى قناتنا على تيليگرام",
        description = "تابع آخر التحديثات، الإصدارات الجديدة، والأخبار المهمة لتطبيق سي تي في.",
        updates = "تنبيهات التحديثات",
        features = "مميزات جديدة وتحسينات",
        news = "أخبار التطبيق والمستجدات",
        join = "الانضمام إلى القناة",
        later = "ليس الآن",
        neverShow = "عدم إظهار هذه الرسالة مرة أخرى",
        close = "إغلاق",
    )
} else {
    TelegramCardCopy(
        title = "Join Our Telegram Channel",
        description = "Get the latest updates, new releases, and important news about Cee TV.",
        updates = "Update Notifications",
        features = "New Features & Improvements",
        news = "App News & Announcements",
        join = "Join the Channel",
        later = "Not Now",
        neverShow = "Don't show this again",
        close = "Close",
    )
}
