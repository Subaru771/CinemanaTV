package app.cinemanatv.data

/** Presentation only: source IDs, stored titles and series identity remain intact. */
val Video.displayTitle:String get() {
    var name=title.trim().replace(Regex("^(?:مشاهدة\\s+)?(?:فيلم|مسلسل|انمي|أنمي)\\s+"),"")
    name=name.replace(Regex("\\s+(?:مترجم|مدبلج|كامل|اون لاين|أون لاين)(?:\\s+(?:كامل|اون لاين|أون لاين))*\\s*$"),"").trim()
    val withoutYear=year?.let { name.removeSuffix(" $it").trim() } ?: name
    return withoutYear.ifBlank { name }.ifBlank { title }
}
