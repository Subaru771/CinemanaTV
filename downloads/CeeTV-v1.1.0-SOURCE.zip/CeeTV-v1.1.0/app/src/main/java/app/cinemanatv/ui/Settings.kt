package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.focus.focusRequester
import kotlinx.coroutines.delay
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.MatureAction
import app.cinemanatv.util.Capabilities
import app.cinemanatv.util.NextEpisodePreloader
import app.cinemanatv.util.StorageDiagnostics
import app.cinemanatv.util.TvHomeIntegration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Focusable two-pane TV settings. Every choice is a real persisted action, not decorative text. */
@Composable
fun SettingsScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val prefs = Services.prefs
    val scope = rememberCoroutineScope()
    var errorReport by remember { mutableStateOf<String?>(null) }
    errorReport?.let { report -> CrashReportDialog(report) { errorReport = null } }

    val ar = vm.interfaceLanguage == "ar"
    fun label(en: String, arabic: String) = if (ar) arabic else en
    val sections = listOf(
        label("General", "عام"), label("Mature content", "المحتوى المخصص للكبار"),
        label("Playback", "التشغيل"), label("Subtitles", "الترجمة"),
        label("Home screen", "الرئيسية"), label("Downloads", "التنزيلات"),
        label("Storage", "التخزين"), label("Diagnostics", "فحص الاتصال"),
        label("About & updates", "حول التطبيق والتحديثات"),
    )
    // Retain the selected category when a search overlay temporarily replaces
    // Settings; recreating the pane should not send viewers back to General.
    var showInvitation by remember { mutableStateOf(!prefs.hideTelegramInvitation) }
    var updateBusy by remember { mutableStateOf(false) }
    var updateMessage by remember { mutableStateOf("") }
    var manualUpdate by remember { mutableStateOf<app.cinemanatv.util.AvailableAppUpdate?>(null) }
    fun openWeb(url:String) {
        runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(url))) }
            .onFailure { android.widget.Toast.makeText(ctx,label("No browser is installed.","لا يوجد متصفح مثبت."),android.widget.Toast.LENGTH_LONG).show() }
    }
    var selected by remember { mutableIntStateOf(vm.settingsCategory.coerceIn(0, sections.lastIndex)) }
    LaunchedEffect(selected) { vm.settingsCategory = selected }
    var pendingRightFocus by remember { mutableIntStateOf(-1) }
    // Each category owns a stable focus target. Recomposition of the right pane must not
    // invalidate the D-pad focus route back to the selected category.
    val categoryScroll=rememberLazyListState(initialFirstVisibleItemIndex=(selected-3).coerceAtLeast(0))
    val categoryFocus = remember { List(sections.size) { FocusRequester() } }
    val firstRightFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        // Restore the last category after returning from Search or another screen.
        // Do not reset to General whenever Settings is composed again.
        delay(70)
        runCatching { categoryFocus[selected].requestFocus() }
    }
    // When Right changes categories, wait for the new options to be composed before
    // requesting focus. Otherwise D-pad navigation can point at a removed control.
    LaunchedEffect(selected, pendingRightFocus) {
        if (pendingRightFocus == selected) {
            delay(32)
            runCatching { firstRightFocus.requestFocus() }
            pendingRightFocus = -1
        }
    }
    var quality by remember { mutableIntStateOf(prefs.maxQuality) }
    var subtitle by remember { mutableStateOf(prefs.preferredSubtitleLanguage) }
    var autoNext by remember { mutableStateOf(prefs.autoPlayNextEnabled) }
    var bingeCheck by remember { mutableStateOf(prefs.bingeCheckEnabled) }
    var unmetered by remember { mutableStateOf(prefs.downloadUnmeteredOnly) }
    var tvHome by remember { mutableStateOf(prefs.tvHomeEnabled) }
    var autoSkipIntro by remember { mutableStateOf(prefs.autoSkipIntro) }
    var storageRefresh by remember { mutableIntStateOf(0) }
    var diagnostic by remember { mutableStateOf("") }
    var diagnosing by remember { mutableStateOf(false) }

    Row(
        Modifier.fillMaxSize().background(
            Brush.horizontalGradient(listOf(Color(0xFF0D111B), C.Bg))
        ).padding(22.dp),
        horizontalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        Column(
            Modifier.width(238.dp).fillMaxHeight()
                .background(C.Panel, RoundedCornerShape(19.dp)).padding(13.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(label("SETTINGS", "الإعدادات"), color = Color.White,
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 12.dp, top = 10.dp))
            Spacer(Modifier.height(4.dp))
            LazyColumn(Modifier.fillMaxWidth().weight(1f), state=categoryScroll, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                itemsIndexed(sections) { i, name ->
                    AppButton(
                        if (i == selected) "▍  $name" else name,
                        Modifier.fillMaxWidth()
                            .focusRequester(categoryFocus[i])
                            .focusProperties {
                                right = firstRightFocus
                                up = FocusRequester.Default
                                down = FocusRequester.Default
                            }
                            // Explicit Right navigation avoids Compose's geometric search picking
                            // an unrelated button, or a target in a disappearing settings pane.
                            .onPreviewKeyEvent { event ->
                                if (event.key == Key.DirectionRight && event.type == KeyEventType.KeyDown) {
                                    selected = i
                                    pendingRightFocus = i
                                    true
                                } else false
                            },
                        primary = selected == i, showFocusChevron = false,
                        // One selection marker is enough; the extra focus chevron
                        // made the sidebar look cluttered on the TV.
                        // TV remote focus IS selection. Waiting for OK left the category
                        // marker and right-hand pane stuck on the previously clicked row.
                        onFocused = { selected = i },
                    ) { selected = i }
                }
            }
        }

        Column(Modifier.weight(1f).fillMaxHeight()) {
            Text(sections[selected], fontSize = 25.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp, top = 7.dp, bottom = 14.dp))
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentPadding = PaddingValues(bottom = 32.dp, end = 14.dp),
                verticalArrangement = Arrangement.spacedBy(15.dp),
            ) {
                when (selected) {
                    0 -> {
                        item {
                            SettingsCard(label("Interface language", "لغة الواجهة"),
                                "") {
                                SettingChoices(listOf("en" to "English", "ar" to "العربية"),
                                    vm.interfaceLanguage, firstFocus = firstRightFocus, backFocus = categoryFocus[selected]) { vm.changeInterfaceLanguage(it) }
                            }
                        }
                    }
                    1 -> {
                        item {
                            SettingsCard(label("Mature scenes", "المشاهد المخصصة للكبار"), label("Available when this version has reliable scene markers.","تعمل عند توفر علامات موثوقة للمشاهد في هذا الإصدار.")) {
                                SettingChoices(listOf(
                                    MatureAction.OFF.name to label("Off", "إيقاف"),
                                    MatureAction.SKIP_SCENES.name to label("Skip mature scenes", "تخطي المشاهد"),
                                ), vm.matureAction.name, firstFocus = firstRightFocus, backFocus = categoryFocus[selected]) {
                                    vm.changeMatureAction(MatureAction.valueOf(it), ctx)
                                }
                            }
                        }
                    }
                    2 -> {
                        item {
                            SettingsCard(label("Intro & credits", "المقدمة والنهاية"), "") {
                                SettingToggle(label("Skip intros and recaps automatically", "تخطي المقدمة والملخص تلقائياً"), autoSkipIntro, firstFocus = firstRightFocus, backFocus = categoryFocus[selected]) {
                                    autoSkipIntro = !autoSkipIntro
                                    prefs.autoSkipIntro = autoSkipIntro
                                }
                            }
                        }
                        item {
                            SettingsCard(label("Playback quality", "دقة التشغيل"),
                                "") {
                                SettingChoices(listOf("0" to label("Auto", "تلقائي"), "2160" to "4K",
                                    "1080" to "1080p", "720" to "720p", "480" to "480p"), quality.toString()) {
                                    quality = it.toInt(); prefs.maxQuality = quality
                                }
                            }
                        }
                        item {
                            SettingsCard(label("Episodes", "الحلقات"),
                                "") {
                                SettingToggle(label("Auto-play next episode", "تشغيل الحلقة التالية تلقائياً"), autoNext) {
                                    autoNext = !autoNext; prefs.autoPlayNextEnabled = autoNext
                                }
                                SettingToggle(label("Ask after three episodes", "اسأل بعد ثلاث حلقات"), bingeCheck) {
                                    bingeCheck = !bingeCheck; prefs.bingeCheckEnabled = bingeCheck
                                }
                            }
                        }
                    }
                    3 -> item {
                        SettingsCard(label("Preferred subtitle language", "لغة الترجمة المفضلة"),
                            "") {
                            SettingChoices(listOf("auto" to label("Automatic", "تلقائي"), "ar" to label("Arabic", "عربي"),
                                "en" to label("English", "إنكليزي"), "off" to label("Off", "إيقاف")), subtitle, firstFocus = firstRightFocus, backFocus = categoryFocus[selected]) {
                                subtitle = it; prefs.preferredSubtitleLanguage = it
                                if (it != "auto") prefs.subtitleLabel = ""
                            }
                        }
                    }
                    4 -> {
                        item {
                            SettingsCard(label("Home sections", "أقسام الصفحة الرئيسية"),
                                "") {
                                SettingToggle(label("Continue Watching row", "قسم متابعة المشاهدة"), vm.showContinueRow, firstFocus = firstRightFocus, backFocus = categoryFocus[selected]) {
                                    vm.updateHomeSections(continueRow = !vm.showContinueRow)
                                }
                                SettingToggle(label("My List row", "قسم قائمتي"), vm.showMyListRow) {
                                    vm.updateHomeSections(listRow = !vm.showMyListRow)
                                }
                                SettingToggle(label("Hide watched from discovery", "إخفاء المشاهد من الاستكشاف"), vm.hideWatchedDiscovery) {
                                    vm.updateHomeSections(hideWatched = !vm.hideWatchedDiscovery)
                                }
                            }
                        }
                        item {
                            SettingsCard(label("Android TV launcher", "واجهة Android TV"),
                                "") {
                                SettingToggle(label("Show Watch Next", "إظهار متابعة المشاهدة"), tvHome) {
                                    tvHome = !tvHome; prefs.tvHomeEnabled = tvHome
                                    if (!tvHome) TvHomeIntegration.enqueueRemoveAll(ctx)
                                }
                            }
                        }
                    }
                    5 -> item {
                        SettingsCard(label("Download preferences", "تفضيلات التنزيل"),
                            "") {
                            SettingToggle(label("Unmetered networks only", "شبكات غير محدودة فقط"), unmetered, firstFocus = firstRightFocus, backFocus = categoryFocus[selected]) {
                                unmetered = !unmetered; prefs.downloadUnmeteredOnly = unmetered
                            }
                        }
                    }
                    6 -> {
                        item {
                            val storage by produceState<StorageDiagnostics.Snapshot?>(null, ctx, storageRefresh) {
                                value = withContext(Dispatchers.IO) { StorageDiagnostics.snapshot(ctx) }
                            }
                            SettingsCard(label("Storage overview", "معلومات التخزين"),
                                label("Cleaning preloaded data does not remove your downloads or watch history.",
                                    "تنظيف الملفات المؤقتة ما يمسح التنزيلات أو سجل المشاهدة.")) {
                                if (storage == null) Text(label("Checking storage…", "جارٍ فحص التخزين…"), color = C.Dim)
                                else {
                                    val st = storage!!
                                    listOf(
                                        label("Available", "المساحة المتاحة") to StorageDiagnostics.readable(st.available),
                                        label("Artwork", "الصور المؤقتة") to StorageDiagnostics.readable(st.artwork),
                                        label("Preloaded videos", "الفيديو المؤقت") to StorageDiagnostics.readable(st.prebuffer),
                                        label("Catalog cache", "فهرس المحتوى") to StorageDiagnostics.readable(st.apiCache),
                                        label("Downloads", "التنزيلات") to st.downloadCount.toString(),
                                        label("Failed", "الفاشلة") to st.failedCount.toString(),
                                    ).forEach { (name, value) ->
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(name, color = C.Dim, fontSize = 14.sp)
                                            Text(value, color = Color.White, fontSize = 14.sp)
                                        }
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    AppButton(label("Refresh", "تحديث"), Modifier.focusRequester(firstRightFocus).focusProperties { left = categoryFocus[selected] }) { storageRefresh++ }
                                    AppButton(label("Clear preloaded buffer", "مسح الفيديو المؤقت")) {
                                        scope.launch {
                                            withContext(Dispatchers.IO) { NextEpisodePreloader.clear(ctx) }
                                            storageRefresh++
                                        }
                                    }
                                }
                            }
                        }
                    }
                    7 -> item {
                        SettingsCard(label("Connection diagnostics", "فحص الاتصال"),
                            label("Check catalog access and the current video host independently.",
                                "افحص الوصول إلى الفهرس وخادم الفيديو بشكل منفصل.")) {
                            AppButton(if (diagnosing) label("Checking…", "جارٍ الفحص…")
                                else label("Run connection test", "افحص الاتصال"), Modifier.focusRequester(firstRightFocus).focusProperties { left = categoryFocus[selected] }) {
                                if (!diagnosing) scope.launch {
                                    diagnosing = true
                                    diagnostic = label("Checking the available routes…", "جارٍ فحص الاتصال…")
                                    try {
                                        val id = prefs.recent().firstOrNull()?.id
                                            ?: vm.homeCache[0]?.rows.orEmpty().flatMap { it.items }
                                                .firstOrNull { it.kind == "1" && it.id.isNotBlank() }?.id
                                        diagnostic = Services.repo.networkReport(ctx, id)
                                    } catch (e: CancellationException) { throw e }
                                      catch (e: Exception) { diagnostic = "Error: ${e.javaClass.simpleName}" }
                                    finally { diagnosing = false }
                                }
                            }
                            if (diagnostic.isNotBlank()) Text(diagnostic, color = C.Dim, fontSize = 13.sp)
                            AppButton(label("Last player error", "آخر خطأ في المشغل")) {
                                errorReport = app.cinemanatv.util.CrashReports.last(ctx)
                                    ?: label("No player error has been recorded.", "لم يتم تسجيل خطأ في المشغل.")
                            }
                        }
                        SettingsCard(label("Catalogue provider", "مصدر الفهرس"),
                            label("Movies, series, episodes and playback are loaded directly from the CEE-backed service.",
                                "يتم تحميل الأفلام والمسلسلات والحلقات والتشغيل مباشرة من خدمة CEE.")) {
                            Text("Cee TV · Movies, series and episodes", color = C.Dim)
                        }
                    }
                    8 -> item {
                        SettingsCard("Cee TV · "+app.cinemanatv.BuildConfig.VERSION_NAME,
                            label("Updates, community and app information.","التحديثات والمجتمع ومعلومات التطبيق.")) {
                            AppButton(if(updateBusy) label("Checking…","جارٍ الفحص…") else label("Check for updates","البحث عن تحديثات"),
                                Modifier.focusRequester(firstRightFocus).focusProperties { left=categoryFocus[selected] }) {
                                if(!updateBusy)scope.launch {
                                    updateBusy=true
                                    try {
                                        val status=app.cinemanatv.util.AppUpdateChecker.checkStatus(app.cinemanatv.BuildConfig.UPDATE_FEED_URL,
                                            app.cinemanatv.BuildConfig.VERSION_CODE.toLong())
                                        manualUpdate=status.second
                                        updateMessage=when {
                                            !status.first -> label("Update service could not be reached. Try again later.","تعذّر الوصول إلى خدمة التحديث. حاول لاحقاً.")
                                            status.second!=null -> label("New version: ","إصدار جديد: ")+status.second!!.versionName
                                            else -> label("No newer version is available.","لا يتوفر إصدار أحدث.")
                                        }
                                    }finally{updateBusy=false}
                                }
                            }
                            if(updateMessage.isNotBlank())Text(updateMessage,color=C.Dim,fontSize=13.sp)
                            manualUpdate?.let { candidate -> AppButton("Download update",primary=true){openWeb(candidate.downloadUrl)} }
                            AppButton(label("Telegram · @CinemanaHub","تيليگرام · @CinemanaHub")){openWeb("https://t.me/CinemanaHub")}
                            SettingToggle(label("Show Telegram invitation at startup","إظهار دعوة تيليگرام عند التشغيل"),showInvitation){
                                showInvitation=!showInvitation
                                prefs.hideTelegramInvitation=!showInvitation
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(title: String, description: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(C.Panel, RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF26382C), RoundedCornerShape(18.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
        if (description.isNotBlank()) Text(description, fontSize = 13.sp, color = C.Dim)
        content()
    }
}

@Composable
private fun SettingChoices(options: List<Pair<String, String>>, value: String,
                           firstFocus: FocusRequester? = null, backFocus: FocusRequester? = null,
                           onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        options.chunked(3).forEachIndexed { groupIndex, group ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                group.forEachIndexed { optionIndex, (key, name) ->
                    AppButton((if (key == value) "✓  " else "") + name,
                        modifier = if (groupIndex == 0 && optionIndex == 0 && firstFocus != null)
                            Modifier.focusRequester(firstFocus).then(
                                if (backFocus != null) Modifier.focusProperties { left = backFocus } else Modifier
                            ) else Modifier,
                        primary = key == value, showFocusChevron = true) { onSelect(key) }
                }
            }
        }
    }
}

@Composable
private fun SettingToggle(text: String, checked: Boolean, firstFocus: FocusRequester? = null,
                          backFocus: FocusRequester? = null, onToggle: () -> Unit) {
    AppButton((if (checked) "✓  " else "○  ") + text,
        modifier = if (firstFocus != null) Modifier.focusRequester(firstFocus).then(
            if (backFocus != null) Modifier.focusProperties { left = backFocus } else Modifier
        ) else Modifier,
        primary = checked, showFocusChevron = true, onClick = onToggle)
}
