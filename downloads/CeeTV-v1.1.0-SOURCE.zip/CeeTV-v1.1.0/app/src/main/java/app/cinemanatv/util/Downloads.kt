package app.cinemanatv.util

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.platform.LocalContext
import app.cinemanatv.data.displayTitle
import app.cinemanatv.Services
import app.cinemanatv.data.QualityOption
import app.cinemanatv.data.Video
import app.cinemanatv.data.userAgent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Legacy direct-file downloads plus Media3 adaptive playlist downloads. */
object Downloads {
    enum class State { NONE, QUEUED, RUNNING, PAUSED, FAILED, DONE }
    data class Status(
        val state: State,
        val percent: Int = 0,
        val bytes: Long = 0L,
        val total: Long = 0L,
        val reason: Int = 0,
    )
    data class Location(val slot: Int, val name: String, val free: Long)

    private fun dm(ctx: Context) = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /** Android app-scoped movie folders; external drive options appear only when actually mounted. */
    fun locations(ctx: Context): List<Location> = ctx.getExternalFilesDirs(Environment.DIRECTORY_MOVIES)
        .mapIndexedNotNull { index, root ->
            root?.takeIf { it.exists() || it.mkdirs() }?.let {
                Location(index, if (index == 0) "Device storage" else "External storage $index", it.usableSpace)
            }
        }

    fun file(ctx: Context, id: String): File? {
        val slot = Services.prefs.downloadSlot(id)
        val root = ctx.getExternalFilesDirs(Environment.DIRECTORY_MOVIES).getOrNull(slot)
            ?: if (slot == 0) ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) else null
        // Preserve the existing filename for seamless upgrades from v2.9.7.
        val safeId = id.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        return root?.let { File(it, "cinemana_$safeId.mp4") }
    }

    /** Completed local MP4, or null if unavailable. The device may have removed an SD card. */
    fun offlineMedia(ctx: Context, id: String): androidx.media3.common.MediaItem? =
        if (Services.prefs.downloadKind(id) == "adaptive") AdaptiveOffline.completed(ctx, id) else null

    fun local(ctx: Context, id: String): File? =
        file(ctx, id)?.takeIf { Services.prefs.downloadDone(id) && it.isFile && it.length() > 0L }

    fun status(ctx: Context, id: String): Status {
        val prefs = Services.prefs
        if (prefs.downloadKind(id) == "adaptive") {
            val entry = AdaptiveOffline.entry(ctx, id)
                ?: return if (prefs.downloads().any { it.id == id }) Status(State.QUEUED) else Status(State.NONE)
            val state = when (entry.state) {
                androidx.media3.exoplayer.offline.Download.STATE_COMPLETED -> State.DONE
                androidx.media3.exoplayer.offline.Download.STATE_FAILED -> State.FAILED
                androidx.media3.exoplayer.offline.Download.STATE_STOPPED -> State.PAUSED
                androidx.media3.exoplayer.offline.Download.STATE_QUEUED -> State.QUEUED
                androidx.media3.exoplayer.offline.Download.STATE_REMOVING,
                androidx.media3.exoplayer.offline.Download.STATE_RESTARTING -> State.QUEUED
                else -> State.RUNNING
            }
            return Status(state, entry.percentDownloaded.toInt().coerceIn(0, 100),
                entry.bytesDownloaded, entry.contentLength, entry.failureReason)
        }
        if (local(ctx, id) != null) return Status(State.DONE)
        val dlId = prefs.downloadId(id)
        if (dlId <= 0L) return Status(State.NONE)
        val cursor = runCatching { dm(ctx).query(DownloadManager.Query().setFilterById(dlId)) }.getOrNull()
            ?: return Status(State.FAILED)
        return cursor.use { c ->
            if (!c.moveToFirst()) return@use Status(State.FAILED)
            val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
            val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
            val reason = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
            val percent = if (total > 0L) ((got * 100L) / total).toInt().coerceIn(0, 99) else 0
            when (c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))) {
                DownloadManager.STATUS_SUCCESSFUL -> {
                    val f = file(ctx, id)
                    if (f != null && f.isFile && f.length() > 0L) {
                        prefs.setDownloadDone(id, true)
                        Status(State.DONE, 100, f.length(), f.length())
                    } else Status(State.FAILED, reason = reason)
                }
                DownloadManager.STATUS_FAILED -> Status(State.FAILED, percent, got, total, reason)
                DownloadManager.STATUS_PAUSED -> Status(State.PAUSED, percent, got, total, reason)
                DownloadManager.STATUS_PENDING -> Status(State.QUEUED, percent, got, total)
                else -> Status(State.RUNNING, percent, got, total)
            }
        }
    }

    /** Only provider-supplied numerical options; HLS/DASH and MP4 are both supported. */
    suspend fun choices(video: Video): List<QualityOption> = withContext(Dispatchers.IO) {
        val source = Services.repo.loadSources(video.id)
        if (source.vkPlayerUrl != null) throw java.io.IOException("VK Video uses its own player; offline download is unavailable.")
        numberedDownloadOptions(source.qualities)
    }

    /** Starts or retries a direct file download. Returns an error text, or null if queued. */
    suspend fun start(ctx: Context, v: Video, choice: QualityOption, slot: Int, unmeteredOnly: Boolean): String? {
        if (!(choice.url.startsWith("https://") || choice.url.startsWith("http://")))
            return "This stream cannot be downloaded."
        if (choice.adaptive) {
            if (slot != 0) return "HLS/DASH downloads use internal device storage. Choose Device storage."
            if (status(ctx, v.id).state in listOf(State.QUEUED, State.RUNNING, State.PAUSED, State.DONE)) return null
            val failure = AdaptiveOffline.queue(ctx, v.id, choice, unmeteredOnly)
            if (failure == null) {
                Services.prefs.setDownloadKind(v.id, "adaptive")
                Services.prefs.setDownloadQuality(v.id, downloadQualityLabel(choice))
                Services.prefs.addDownload(v)
                Services.prefs.downloadUnmeteredOnly = unmeteredOnly
                Services.prefs.downloadLocation = 0
            }
            return failure
        }
        val prefs = Services.prefs
        if (status(ctx, v.id).state in listOf(State.QUEUED, State.RUNNING, State.PAUSED, State.DONE)) return null
        if (locations(ctx).none { it.slot == slot }) return "That storage device is unavailable."
        return try {
            val previous = prefs.downloadId(v.id)
            if (previous > 0L) dm(ctx).remove(previous)
            file(ctx, v.id)?.delete()
            prefs.setDownloadSlot(v.id, slot)
            val dest = file(ctx, v.id) ?: return "Storage is unavailable."
            dest.parentFile?.mkdirs()
            dest.delete()
            val request = DownloadManager.Request(Uri.parse(choice.url))
                .setTitle(v.displayTitle)
                .setDescription("Cee · ${choice.height}p")
                .setDestinationUri(Uri.fromFile(dest))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .addRequestHeader("User-Agent", userAgent())
                .setAllowedOverMetered(!unmeteredOnly)
                .setAllowedOverRoaming(!unmeteredOnly)
            val id = dm(ctx).enqueue(request)
            prefs.setDownloadKind(v.id, "direct")
            prefs.setDownloadDone(v.id, false)
            prefs.setDownloadId(v.id, id)
            prefs.setDownloadQuality(v.id, downloadQualityLabel(choice))
            prefs.addDownload(v)
            prefs.downloadLocation = slot
            prefs.downloadUnmeteredOnly = unmeteredOnly
            null
        } catch (_: Exception) { "Couldn't start the download. Check storage space or network access." }
    }

    /** Cancel active download, or remove finished media; never delete unrelated user files. */
    fun remove(ctx: Context, id: String) {
        val prefs = Services.prefs
        if (prefs.downloadKind(id) == "adaptive") {
            AdaptiveOffline.remove(ctx, id)
            prefs.setDownloadKind(id, "direct")
            prefs.setDownloadQuality(id, "")
            prefs.removeDownload(id)
            return
        }
        val dlId = prefs.downloadId(id)
        if (dlId > 0L) runCatching { dm(ctx).remove(dlId) }
        file(ctx, id)?.delete()
        prefs.setDownloadId(id, 0L)
        prefs.setDownloadDone(id, false)
        prefs.setDownloadQuality(id, "")
        prefs.removeDownload(id)
    }
}

@Composable
fun rememberDownloadStatus(id: String): State<Downloads.Status> {
    val ctx = LocalContext.current
    return produceState(Downloads.Status(Downloads.State.NONE), id) {
        while (true) {
            value = withContext(Dispatchers.IO) { Downloads.status(ctx, id) }
            delay(1_000L)
        }
    }
}
