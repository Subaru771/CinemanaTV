# Cee TV 1.3.0 / native preview 0.2.0

Shared: responsive phone browsing, TV rail/D-pad navigation, pointer controls, player settings/quality menus, local history/list/downloads, chronological episodes/recent resume, Telegram/update notices, signing guards, locale-specific catalogue caching and shared initial loads.

Website flavor: existing verified website catalogue/player resolver and same stable update feed/package.
Native flavor: recovered native guest API groups/search/seasons/details/files/subtitles and separate preview package; no silent cross-provider fallback.

Correctness follow-up: exact numbered offline track selection, manual resolution retention after URL refresh, unsupported-track indicators, native URL/height pairs, series certification, cancellation-safe timed preparation and bounded native catalogue requests.

Unverified externally: physical hardware playback/focus/buffering and live native API/media delivery. Provider outages and source-limited resolutions remain outside app-only fixes. Account sync, licence/device signatures, casting and App Cloner options remain outside this independent guest integration.
