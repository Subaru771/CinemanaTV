@echo off
setlocal
cd /d "%~dp0"
set "ADB=adb"
where adb >nul 2>&1
if errorlevel 1 if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
"%ADB%" devices
if errorlevel 1 (
 echo ADB is unavailable or cannot connect.
 pause
 exit /b 1
)
"%ADB%" shell dumpsys package app.cinemanatv.cee | findstr /i "versionName versionCode"
echo Expected Cee TV: 1.3.0 / code 12
"%ADB%" shell dumpsys package app.cinemanatv.cee.nativepreview | findstr /i "versionName versionCode"
echo Expected native preview: 0.2.0-native-preview / code 2
pause
