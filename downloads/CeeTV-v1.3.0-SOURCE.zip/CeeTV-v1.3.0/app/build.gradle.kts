import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

fun cfg(name: String): String =
    localProps.getProperty(name)
        ?: (project.findProperty(name) as String?)
        ?: System.getenv(name.replace('.', '_').uppercase())
        ?: ""

fun signingValue(property:String,environment:String):String = localProps.getProperty(property)
    ?: (project.findProperty(property) as String?) ?: System.getenv(environment) ?: ""
val ceeSigning=mapOf(
    "storeFile" to signingValue("cee.signing.storeFile","CEE_SIGNING_STORE_FILE"),
    "storePassword" to signingValue("cee.signing.storePassword","CEE_SIGNING_STORE_PASSWORD"),
    "keyAlias" to signingValue("cee.signing.keyAlias","CEE_SIGNING_KEY_ALIAS"),
    "keyPassword" to signingValue("cee.signing.keyPassword","CEE_SIGNING_KEY_PASSWORD"),
)
val hasCeeSigning=ceeSigning.values.all{it.isNotBlank()}
if(ceeSigning.values.any{it.isNotBlank()} && !hasCeeSigning)
    throw GradleException("Provide all four cee.signing.* values; partial signing configuration is not allowed.")
if(cfg("cee.productionRelease").equals("true",true) && !hasCeeSigning)
    throw GradleException("A production release requires an explicit CEE signing key.")

android {
    namespace = "app.cinemanatv"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.cinemanatv.cee"
        minSdk = 26
        targetSdk = 34
    }
    flavorDimensions += "provider"
    productFlavors {
        create("website") {
            dimension = "provider"
            versionCode = 12
            versionName = "1.3.0"
            buildConfigField("boolean", "NATIVE_PROVIDER", "false")
            val updateFeed=cfg("cinemana.updateFeedUrl").ifBlank { "https://raw.githubusercontent.com/Subaru771/CinemanaTV/main/downloads/CeeTV-updates.json" }
                .replace("\\", "\\\\").replace("\"", "\\\"")
            buildConfigField("String", "UPDATE_FEED_URL", "\"$updateFeed\"")
            resValue("string", "app_name", "Cee TV")
            manifestPlaceholders["ceeCleartext"]="false"
        }
        create("nativeApi") {
            dimension = "provider"
            applicationIdSuffix = ".nativepreview"
            versionCode = 2
            versionName = "0.2.0-native-preview"
            buildConfigField("boolean", "NATIVE_PROVIDER", "true")
            buildConfigField("String", "UPDATE_FEED_URL", "\"\"")
            resValue("string", "app_name", "Cee TV Native")
            manifestPlaceholders["ceeCleartext"]="true"
        }
    }

    if(hasCeeSigning)signingConfigs.create("ceeRelease") {
        storeFile=rootProject.file(ceeSigning.getValue("storeFile"))
        storePassword=ceeSigning.getValue("storePassword")
        keyAlias=ceeSigning.getValue("keyAlias")
        keyPassword=ceeSigning.getValue("keyPassword")
    }
    buildTypes {
        release {
            // Optimized for sideload testing, but signed using this computer's debug key.
            // This is NOT a distributable production-signed release. It can update only
            // installations signed by the exact same key.
            isMinifyEnabled = true
            isShrinkResources = true
            isDebuggable = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName(if(hasCeeSigning)"ceeRelease" else "debug")
        }
    }

    lint {
        // Lint on release builds adds minutes and can fail a sideload build for unrelated reasons.
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    testOptions { unitTests.isIncludeAndroidResources = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.tv:tv-material:1.0.0")

    implementation("androidx.tvprovider:tvprovider:1.1.0")
    implementation("androidx.media3:media3-exoplayer:1.8.1")
    implementation("androidx.media3:media3-ui:1.8.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.8.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.8.1")
    implementation("androidx.media3:media3-database:1.8.1")
    implementation("androidx.media3:media3-datasource-okhttp:1.8.1")
    // Installs the Baseline Profiles embedded in Compose / Media3 on first launch (faster cold start).
    implementation("androidx.profileinstaller:profileinstaller:1.4.1")

    implementation("io.coil-kt:coil-compose:2.7.0")

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jsoup:jsoup:1.18.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    testImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}

// Native Robolectric/Compose state must not carry between test classes or screen configurations.
tasks.withType<org.gradle.api.tasks.testing.Test>().configureEach {
    forkEvery = 1L
    maxParallelForks = 2
}
