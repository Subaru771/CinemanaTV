# Version 1.4: automatic fallback

Original playback failures now trigger one automatic alternative-source lookup.
This covers failed source lookup, no returned streams, terminal playback errors,
and errors raised after the existing bounded retry/stall handling. There is no
attempt while offline, while the manual picker is open, while content filtering
is active, or when the selected source is already an alternative.

The match must be unique and have an exact normalized title and release year.
Episode matches additionally require exact season/episode coordinates and the
series release year. The matcher handles the provider's Arabic movie labels and
numeric Arabic/English episode labels; it does not guess missing metadata or
translate titles. Remakes, sequels, missing years and ambiguous duplicate posts
stay on the manual-selection path. The automatic lookup has an 18-second coroutine
deadline (a blocking HTTP call can take up to its configured 20-second timeout to
unwind cancellation). A successful lookup resolves streams before switching and
passes them through the existing single-use in-memory prefetch cache.

A toast announces a source switch. The alternative keeps its own saved playback
position and metadata, so timestamps from a different cut are not transferred.
Version 1.4 verification: all 152 tests passed, including seven automatic-match tests and the live media smoke test. The APK signature and versionCode 122 were verified. Full TV playback and automatic fallback UI behavior still need on-device testing.

---

# Cinemana TV 1.3 — optional native alternative source

This adds a separate provider based on the public website linked from CEE's entry
page. It does not change the original Cinemana API, subscriber status or network
authorization. No browser or CEE app is needed for this integration.

## Use

- On a title page, select **Find alternative source**.
- On a playback-error screen, select **Find alternative source**.
- On a catalog-error screen, select **Browse alternative source**.
- Without a working Cinemana catalog, open **Settings > Diagnostics > Browse
  alternative source**.
- Search by title, or enter an exact `https://cinamana.cc/watch=123/` episode/movie
  page URL. Blank search lists titles from the provider's front page.
- Select the exact result and confirm **Play selected title**. Check the year and
  season/episode in the provider's title. The app never automatically substitutes
  a similarly named result.

Playback uses the existing Media3 player and quality selection. Retry resolves
fresh stream URLs. The provider's IDs use the `cee_` prefix: viewing history,
downloads and progress stay separate from original-provider titles. The resolver
does not persist signed stream URLs or attach them to the original title's identity;
an explicitly requested download still uses the app's existing download manager.

Alternative results do not supply verified age classifications, Cinemana subtitles,
intro timestamps or scene-skip markers. No original IMDb metadata or episode queue
is copied onto them. Alternative browsing is unavailable while title filtering is
enabled. Episode selection is manual; there is no cross-provider automatic next
episode or full catalog synchronization. Direct MP4 is the only format live-tested;
the URL validator also recognizes HLS and DASH, but neither was live-tested.

## How it works

`CeeAlternativeSource.kt` searches the provider's public HTML pages. For an
explicitly selected post it submits the same player-resolution request used by the
website, extracts the MP4Plus embed address, and parses the player's declared media
sources. It does not run website JavaScript, load advertising scripts or bypass
DRM. HTML requests use an isolated HTTP client without original-provider account
tokens, shared cookies or persistent cache. Each redirect is checked against the
page-host allowlist before it is requested. Responses are size-bounded.

Currently supported page hosts: `cinamana.cc`, `mp4plus.org`. Currently supported
media hosts: subdomains of `cdnz.quest`, using HTTPS and MP4/HLS/DASH paths. Other
hosts and changed player layouts fail with an error rather than silently opening
a browser or executing site scripts. These are provider-specific rules, not a
general arbitrary-URL extractor.

## Evidence and practical limits

CEE's uploaded APK exceeded the transfer tool's 32 MiB limit. Inspection used a
public APKPure split distribution with package `com.erthlink1.tv`, version 30.1.0,
versionCode 400060. Its identity against the uploaded file was not established.

Its application strings included `https://cdnbitly.com/com.erthlink1.tv/all`.
Following that entry's public non-Earthlink navigation led through Soft31 and
`cinemana.mov` to `cinamana.cc`. The tested sample page was post 3216134. Its
player returned progressive MP4 choices at 480p and 320p on a `cdnz.quest` host.
Small HTTP range requests returned 206, `video/mp4` and an MP4 `ftyp` header, using
the app's TV User-Agent and no cookies or Referer.

That establishes a usable sample delivery route from the development environment,
not which path the installed CEE app uses in every case, full playback on a TV,
or access on every ISP. This third-party site can change or become unavailable.
No signed media URLs or account credentials are included in this source.

## Build and verification

Build using JDK 17, Android SDK platform 35 and the Gradle wrapper:

```sh
bash gradlew testDebugUnitTest assembleDebug
```

Pure parser/routing tests run without live services. An optional live smoke test
can be enabled with `CEE_LIVE_TEST=1`; it resolves the sample page and reads only
a small MP4 header. It does not play or download an entire video. Test reports are
under `app/build/reports/tests/testDebugUnitTest/`.

Application ID remains `app.cinemanatv`; version is 1.3, versionCode 121. APK
upgrades require the same signing certificate as the installed app. A build made
on a new machine with a new debug key cannot replace an older differently signed
installation. Windows builders and the GitHub Actions artifact names are updated
to version 1.3; the APK's version is set in `app/build.gradle.kts`.

TV validation still required: D-pad and Back behavior, English/Arabic labels,
search and exact-episode selection, full playback, seeking, quality switching,
expired-link retry, and operation on the intended Wi-Fi/mobile networks.

### Verification in this session

`testDebugUnitTest assembleDebug` completed successfully with JDK 17 and SDK 35.
All 145 tests passed (zero failures, errors or skipped tests), including the live
resolver smoke test. The live test resolved two qualities on
`aflm-s6-qsj.cdnz.quest` and verified an HTTP 206 response with an MP4 header.
`apksigner verify` passed; `aapt dump badging` confirmed package `app.cinemanatv`,
versionName 1.3, versionCode 121. This APK is debug/test signed with a new local
key, not the signing key of an existing installation. No TV/emulator UI or full
playback test was performed.
