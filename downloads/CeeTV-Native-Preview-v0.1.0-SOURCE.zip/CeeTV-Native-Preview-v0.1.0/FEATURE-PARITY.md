# Native preview scope

Implemented: native CEE API groups/banners, paginated provider collections, search encoding, details, seasons, related items, supplied file qualities and detail-based subtitles. Shared Cee TV player/touch/local-library behavior is retained. Native series IDs and API page sizes are preserved. Optional controlled signing has explicit production enforcement.

Unverified: live native API JSON, full-movie delivery, real device decoding/focus/buffering and older Android updates with rotated keys. Not included: Claude's unavailable refactor/portrait edits, provider account sync/licence/device-signature logic, DLNA or App Cloner behavior. The stable Cee TV app/feed is not promoted to this preview.
