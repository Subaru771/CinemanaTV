package app.cinemanatv.data

import android.os.Build
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.Base64
import java.util.concurrent.TimeUnit

/** Protocol facts recovered from the supplied Leanback APK, implemented independently. */
object CeeNativeProtocol {
    const val BASE="https://cee.buzz/api/android/"
    const val PREFIX="cee_api_"
    fun owns(id:String)=id.startsWith(PREFIX)
    fun id(raw:String):String=PREFIX+raw.also{require(it.matches(Regex("[0-9]{1,12}")) && it.toLong()>0){"Invalid CEE API title identity."}}
    fun raw(id:String):String {
        require(owns(id)){"This title does not belong to the native CEE catalogue."}
        return id.removePrefix(PREFIX).also{require(it.matches(Regex("[0-9]{1,12}")) && it.toLong()>0){"Invalid CEE API title identity."}}
    }
    fun groups(language:String,kind:Int)="videoGroups/lang/${if(language=="en")"en" else "ar"}/kindGroup/$kind"
    fun banner(level:Int)="banner/level/$level"
    fun info(id:String)="allVideoInfo/id/${raw(id)}"
    fun files(id:String)="transcoddedfiles/id/${raw(id)}"
    fun episodes(id:String)="videoSeason/id/${raw(id)}"
    fun related(id:String,kind:Int)="relatedVideos/id/${raw(id)}/kind/$kind"
    fun group(id:String,page:Int,size:Int=12):String {
        require(id.matches(Regex("[A-Za-z0-9_-]{1,80}")) && page in 0..10000 && size in 1..120)
        return "videoGroups/groupID/$id/page/$page/itemsPerPage/$size"
    }
    fun listing(kind:Int,sort:String,page:Int,size:Int=20):String {
        require(kind in 1..2 && page in 0..10000 && size in 1..120)
        require(sort in setOf("desc","asc","stars_desc","views_desc","r_desc","en_title_asc","ar_title_asc"))
        return "video/videoKind/$kind/categoryNb/0/langNb/0/sortParam/$sort/itemsPerPage/$size/searchTextValue/-/pageNumber/$page"
    }
    private fun uriEncode(text:String):String=buildString {
        for(b in text.toByteArray(Charsets.UTF_8)) {
            val v=b.toInt() and 255;val c=v.toChar()
            if(c.isLetterOrDigit() && v<128 || c in "_-!.~'()*")append(c)
            else append("%%%02X".format(java.util.Locale.US,v))
        }
    }
    /** APK search performs Uri.encode(Base64(NO_WRAP)) before Retrofit's normal @Path escaping. */
    fun searchSegments(query:String,kind:Int):List<String> {
        require(kind in 1..2)
        val encoded=uriEncode(Base64.getEncoder().encodeToString(query.toByteArray(Charsets.UTF_8))).replace("=","_")
        return listOf("video","V","2","videoKind",kind.toString(),"itemsPerPage","20","video_title_search",encoded)
    }
    fun userAgent():String {
        val device="${Build.MANUFACTURER} ${Build.MODEL}".filter{it.code in 32..126}.take(100)
        return "Android-TV ${Build.VERSION.RELEASE};40504;$device CeeTV-Native/0.1.0"
    }
}

class CeeApiException(val statusCode:Int?,message:String):IOException(message)

/** API transport never turns an HTML 200, failed lookup or login page into an empty catalogue. */
class CeeNativeHttp(
    private val base:HttpUrl=CeeNativeProtocol.BASE.toHttpUrl(),
    private val agent:()->String=CeeNativeProtocol::userAgent,
    private val client:OkHttpClient=OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
        .connectTimeout(10,TimeUnit.SECONDS).readTimeout(10,TimeUnit.SECONDS).callTimeout(15,TimeUnit.SECONDS).build(),
) {
    suspend fun get(path:String,noStore:Boolean=false):JsonElement {
        require(!path.startsWith('/') && !path.contains("://") && path.split('/').none{it==".."})
        return read(base.newBuilder().addPathSegments(path).build(),noStore)
    }
    suspend fun search(query:String,kind:Int):JsonElement {
        val url=base.newBuilder().apply{CeeNativeProtocol.searchSegments(query.trim().take(250),kind).forEach{addPathSegment(it)}}.build()
        return read(url,false)
    }
    private suspend fun read(initial:HttpUrl,noStore:Boolean):JsonElement=withContext(Dispatchers.IO) {
        var address=initial
        repeat(5) {
            var redirect:HttpUrl?=null
            val parsed=CancellableHttp.read(client,Request.Builder().url(address).header("User-Agent",agent())
                .header("Accept","application/json").apply{if(noStore)header("Cache-Control","no-store")}.build()) { response ->
                if(response.code in listOf(301,302,303,307,308)) {
                    val next=response.header("Location")?.let(address::resolve)
                    if(next==null || next.scheme!=base.scheme || next.host!=base.host || next.port!=base.port || !next.encodedPath.startsWith(base.encodedPath))
                        throw CeeApiException(response.code,"CEE API returned an unsupported redirect.")
                    redirect=next;null
                } else {
                    if(!response.isSuccessful)throw CeeApiException(response.code,"CEE API is unavailable (HTTP ${response.code}). Please retry when the service is reachable.")
                    val source=response.body?.source() ?: throw CeeApiException(response.code,"CEE API returned an empty response.")
                    if(source.request(2_000_001))throw CeeApiException(response.code,"CEE API response exceeded the supported size.")
                    val text=source.readUtf8().trimStart('\uFEFF',' ','\n','\r','\t')
                    if(text.startsWith('<') || response.header("Content-Type").orEmpty().contains("text/html",true))
                        throw CeeApiException(response.code,"CEE returned a website page instead of API data.")
                    val json=try{JsonParser.parseString(text)}catch(_:RuntimeException){throw CeeApiException(response.code,"CEE API returned invalid JSON.")}
                    if(!json.isJsonArray && !json.isJsonObject)throw CeeApiException(response.code,"CEE API returned an unexpected response.")
                    json
                }
            }
            if(redirect==null)return@withContext parsed ?: throw CeeApiException(null,"CEE API returned no data.")
            address=redirect!!
        }
        throw CeeApiException(null,"CEE API redirected too many times.")
    }
}
