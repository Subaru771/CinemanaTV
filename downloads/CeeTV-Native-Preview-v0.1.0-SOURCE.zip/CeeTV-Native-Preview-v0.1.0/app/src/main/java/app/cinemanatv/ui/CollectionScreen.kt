package app.cinemanatv.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.CatalogSection
import app.cinemanatv.data.Video
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class CollectionUiState {
    var videos by mutableStateOf<List<Video>>(emptyList())
    var page by mutableIntStateOf(1)
    var loadedPage by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var finished by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var attempt by mutableIntStateOf(0)
    val grid=LazyGridState()
}

@Composable
fun CollectionScreen(section:CatalogSection,vm:AppViewModel,onBack:()->Unit,onOpen:(Video)->Unit) {
    val state=remember(section.key){vm.collectionState(section.key)}
    LaunchedEffect(section.key,state.page,state.attempt) {
        if(state.loadedPage==state.page && state.error==null)return@LaunchedEffect
        state.loading=true;state.error=null
        try {
            val batch=Services.repo.browse(section,state.page)
            val normalized=batch.map { if(it.kind=="2" && !app.cinemanatv.data.CeeNativeProtocol.owns(it.id)) app.cinemanatv.data.CeeCatalogParser.parent(it) else it }
            state.videos=(state.videos+normalized).distinctBy { it.id }
            val pageSize=section.pageSize.takeIf{it in 1..120} ?: 24
            state.finished=batch.size<pageSize || (section.totalPosts>0 && state.page*pageSize>=section.totalPosts)
            state.loadedPage=state.page
        } catch(c:CancellationException){throw c}
          catch(_:Exception){state.error="This collection could not be loaded. Please retry."}
        finally {state.loading=false}
    }
    LaunchedEffect(state.videos,vm.contentFilterMode){vm.resolveMaturity(state.videos)}
    val visible=vm.visible(state.videos)
    Column(Modifier.fillMaxSize().padding(horizontal=40.dp,vertical=24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(18.dp)) {
            AppButton("Back",onClick=onBack)
            Column {
                Text(t(section.title),fontSize=28.sp,fontWeight=FontWeight.Bold)
                Text("${visible.size} "+t("titles"),color=C.Dim,fontSize=13.sp)
            }
        }
        LazyVerticalGrid(columns=GridCells.Adaptive(152.dp),state=state.grid,modifier=Modifier.weight(1f),
            horizontalArrangement=Arrangement.spacedBy(20.dp),verticalArrangement=Arrangement.spacedBy(20.dp)) {
            items(visible,key={it.id}) { v -> PosterCard(v,vm=vm,onClick={onOpen(v)}) }
            item(span={GridItemSpan(maxLineSpan)}) {
                Column(verticalArrangement=Arrangement.spacedBy(10.dp)) {
                    state.error?.let {Text(t(it),color=C.Dim)}
                    if(state.loading)Text(t("Loading…"),color=C.Accent)
                    else if(state.error!=null)AppButton("Retry",primary=true){state.attempt++}
                    else if(!state.finished)AppButton("Load more",primary=true){state.page++}
                    else Text(t("End of collection"),color=C.Dim)
                }
            }
        }
    }
}
