package app.cinemanatv.data

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** Native provider records keep their real IDs; website post IDs and title hashes never enter this adapter. */
internal object CeeNativeParser {
    private fun text(o:JsonObject,key:String)=o.get(key)?.takeIf{it.isJsonPrimitive}?.asString?.trim()
    fun envelope(root:JsonElement):JsonElement {
        var current=root
        repeat(4) {
            if(current.isJsonObject) {
                val obj=current.asJsonObject
                val next=listOf("data","result").firstNotNullOfOrNull{obj.get(it)?.takeIf{value->value.isJsonArray || value.isJsonObject}}
                if(next!=null)current=next else return current
            } else return current
        }
        return current
    }
    fun native(video:Video):Video {
        val root=video.rootSeries?.takeIf{it!="0" && it.isNotBlank()}
        return video.copy(nb=if(CeeNativeProtocol.owns(video.id))video.id else CeeNativeProtocol.id(video.id),
            rootSeries=root?.let{if(CeeNativeProtocol.owns(it))it else CeeNativeProtocol.id(it)},
            providerPageId=null,rootSeriesInfo=video.rootSeriesInfo?.let(::native))
    }
    fun raw(video:Video)=video.copy(nb=CeeNativeProtocol.raw(video.id),
        rootSeries=video.rootSeries?.let{if(CeeNativeProtocol.owns(it))CeeNativeProtocol.raw(it) else it},
        rootSeriesInfo=null)
    fun videos(root:JsonElement,kind:Int?=null):List<Video> = Payloads.videos(envelope(root),500).mapNotNull { video ->
        runCatching { native(video.copy(kind=video.kind ?: kind?.toString())) }.getOrNull()
    }
    fun detail(root:JsonElement,fallback:Video):Video {
        val json=envelope(root)
        val video=Payloads.detail(json,raw(fallback))
        val record=when {
            json.isJsonObject->json.asJsonObject
            json.isJsonArray->json.asJsonArray.firstOrNull{it.isJsonObject && text(it.asJsonObject,"nb")==video.id}?.asJsonObject
            else->null
        }?.takeIf{text(it,"nb")==null || text(it,"nb")==CeeNativeProtocol.raw(fallback.id)}
        val rating=if(video.kind=="2")record?.let{text(it,"seriesRating")} else null
        val intro=record?.get("introSkipping")?.takeIf{it.isJsonArray}?.asJsonArray?.firstOrNull{it.isJsonObject}?.asJsonObject
        return native(video.copy(filmRating=video.filmRating?.takeIf{it.isNotBlank()} ?: rating,
            introStart=video.introStart ?: intro?.let{text(it,"start")},introEnd=video.introEnd ?: intro?.let{text(it,"end")}))
    }
    fun groups(root:JsonElement,kind:Int?):List<ContentRow> {
        val body=envelope(root)
        val groups=body.takeIf{it.isJsonObject}?.asJsonObject?.get("groups")?.takeIf{it.isJsonArray}?.asJsonArray
            ?: throw CeeApiException(null,"CEE API returned an unrecognized catalogue format.")
        return groups.take(40).mapNotNull { element ->
            if(!element.isJsonObject)return@mapNotNull null
            val obj=element.asJsonObject
            val title=text(obj,"title")?.takeIf{it.isNotBlank()} ?: return@mapNotNull null
            val content=obj.get("content") ?: return@mapNotNull null
            val videos=videos(content,kind).filter{kind==null || it.kind==kind.toString()}
            val id=text(obj,"groupsID")?.takeIf{it.matches(Regex("[A-Za-z0-9_-]{1,80}"))}
            if(videos.isEmpty())null else ContentRow(title,videos,id?.let{
                CatalogSection("cee_api_group_$it",title,kind,pageSize=12,nativeGroupId=it)
            })
        }
    }
    /** The reference player reads resolution + videoUrl, never synthesizes URLs from names. */
    fun files(root:JsonElement):List<QualityOption> {
        val body=envelope(root)
        val entries=when {
            body.isJsonArray->body.asJsonArray.toList()
            body.isJsonObject->body.asJsonObject.get("transcodedFiles")?.takeIf{it.isJsonArray}?.asJsonArray?.toList().orEmpty()
            else->emptyList()
        }
        return entries.take(100).mapNotNull { item ->
            if(!item.isJsonObject)return@mapNotNull null
            val obj=item.asJsonObject
            val url=text(obj,"videoUrl")?.toHttpUrlOrNull()?.takeIf{
                it.scheme in setOf("http","https") && it.username.isEmpty() && it.password.isEmpty() &&
                    !Regex("\\.(?:png|jpe?g|webp|gif|svg)$",RegexOption.IGNORE_CASE).containsMatchIn(it.encodedPath)
            } ?: return@mapNotNull null
            val label=text(obj,"resolution").orEmpty()
            val height=Regex("[0-9]{3,4}").findAll(label).lastOrNull()?.value?.toIntOrNull()?.takeIf{it in 144..8640} ?: 0
            val container=text(obj,"container").orEmpty().lowercase()
            val mime=when {
                url.encodedPath.endsWith(".m3u8",true) || container in setOf("hls","m3u8")->"application/x-mpegURL"
                url.encodedPath.endsWith(".mpd",true) || container in setOf("dash","mpd")->"application/dash+xml"
                container=="mp4" || url.encodedPath.endsWith(".mp4",true)->"video/mp4"
                else->null
            }
            QualityOption(height,url.toString(),label.takeIf{it.isNotBlank()} ?: "Original file",mime)
        }.distinctBy{it.url}.sortedByDescending{it.height}
    }
    fun subtitles(root:JsonElement):List<SubtitleOption> {
        val body=envelope(root)
        val result=Payloads.subtitles(body).toMutableList()
        val translations=body.takeIf{it.isJsonObject}?.asJsonObject?.get("translations")?.takeIf{it.isJsonArray}?.asJsonArray
        translations?.take(50)?.forEach { item ->
            if(item.isJsonObject) {
                val obj=item.asJsonObject
                val ext=text(obj,"extention")?.lowercase()
                val url=text(obj,"file")?.toHttpUrlOrNull()?.takeIf{it.username.isEmpty() && it.password.isEmpty()}
                if(ext in setOf("srt","vtt") && url!=null) {
                    result.removeAll{it.url==url.toString()}
                    val label=when(text(obj,"name")?.lowercase()){"arabic"->"العربية";"english"->"English";else->text(obj,"name") ?: "Subtitle"}
                    result.add(SubtitleOption(label,url.toString(),if(ext=="vtt")"text/vtt" else "application/x-subrip"))
                }
            }
        }
        return result.distinctBy{it.url}
    }
}

/** Independent native CEE API implementation; failures never trigger a website substitution. */
class CeeNativeCatalog(
    private val http:CeeNativeHttp=CeeNativeHttp(),
    private val language:()->String={"ar"},
) : CeeCatalog {
    private val metadata=ConcurrentHashMap<String,Pair<Long,JsonElement>>()
    private suspend fun infoJson(id:String):JsonElement {
        metadata[id]?.takeIf{System.currentTimeMillis()-it.first in 0..30_000}?.let{return it.second}
        return http.get(CeeNativeProtocol.info(id),true).also {
            metadata[id]=System.currentTimeMillis() to it
            if(metadata.size>64)metadata.keys.firstOrNull{it!=id}?.let(metadata::remove)
        }
    }
    override suspend fun home(kind:Int?):HomeData=coroutineScope {
        require(kind==null || kind in 1..2)
        val banner=async { try{CeeNativeParser.videos(http.get(CeeNativeProtocol.banner(1)),kind)}
            catch(c:CancellationException){throw c}catch(_:IOException){emptyList()} }
        var first:IOException?=null
        var rows=try { CeeNativeParser.groups(http.get(CeeNativeProtocol.groups(language(),kind ?: 0)),kind) }
            catch(c:CancellationException){throw c}catch(e:IOException){first=e;emptyList()}
        if(rows.isEmpty() && kind==null)rows=listOf(1,2).map { type->async {
            try{CeeNativeParser.groups(http.get(CeeNativeProtocol.groups(language(),type)),type)}
            catch(c:CancellationException){throw c}catch(_:IOException){emptyList()}
        }}.awaitAll().flatten()
        if(rows.isEmpty())throw first ?: CeeApiException(null,"CEE API returned no catalogue titles.")
        val hero=banner.await().filter{kind==null || it.kind==kind.toString()}.ifEmpty{rows.flatMap{it.items}}.distinctBy{it.id}.take(6)
        HomeData(hero,rows)
    }
    override suspend fun browse(section:CatalogSection,page:Int):List<Video> {
        require(page>=1)
        val path=section.nativeGroupId?.let{CeeNativeProtocol.group(it,page-1,section.pageSize)}
            ?: CeeNativeProtocol.listing(section.kind ?: 1,section.nativeSort ?: "desc",page-1,section.pageSize)
        return CeeNativeParser.videos(http.get(path),section.kind)
    }
    override suspend fun search(query:String):List<Video> = coroutineScope {
        require(query.trim().isNotEmpty())
        val results=listOf(1,2).map { kind->async {
            try{Result.success(CeeNativeParser.videos(http.search(query,kind),kind))}
            catch(c:CancellationException){throw c}catch(e:IOException){Result.failure<List<Video>>(e)}
        }}.awaitAll()
        if(results.all{it.isFailure})throw (results.first().exceptionOrNull() ?: IOException("CEE search unavailable."))
        results.flatMap{it.getOrDefault(emptyList())}.distinctBy{it.id}
    }
    override suspend fun detail(video:Video):Video=CeeNativeParser.detail(infoJson(video.id),video)
    override suspend fun episodes(video:Video):List<Video> {
        if(video.kind=="1")return emptyList()
        val parent=if(video.episodeNumber>0)video.rootSeries?.takeIf(CeeNativeProtocol::owns)
            ?: throw IOException("CEE episode is missing its parent series identity.") else video.id
        val root=if(parent==video.id)video else video.rootSeriesInfo ?: Video(nb=parent,kind="2")
        return chronologicalEpisodes(CeeNativeParser.videos(http.get(CeeNativeProtocol.episodes(parent)),2).filter {
            it.kind=="2" && it.episodeNumber>0 && (it.rootSeries==null || it.rootSeries==parent)
        }.map {
            it.copy(rootSeries=parent,rootSeriesInfo=root)
        })
    }
    override suspend fun related(video:Video):List<Video> = CeeNativeParser.videos(
        http.get(CeeNativeProtocol.related(video.id,if(video.kind=="2")2 else 1)),video.kind?.toIntOrNull()).filter{it.id!=video.id}
    override suspend fun sources(id:String):PlaySources {
        val qualities=CeeNativeParser.files(http.get(CeeNativeProtocol.files(id),true))
        if(qualities.isEmpty())throw CeeApiException(null,"CEE API returned no video files for this title.")
        return PlaySources(qualities,emptyList())
    }
    override suspend fun subtitles(id:String)=CeeNativeParser.subtitles(infoJson(id))
}
