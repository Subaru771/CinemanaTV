package app.cinemanatv.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import coil.request.ImageRequest
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.R
import app.cinemanatv.data.ContentRow
import app.cinemanatv.data.displayTitle
import app.cinemanatv.data.Video
import app.cinemanatv.data.MediaContentFilter
import app.cinemanatv.util.NetworkResilience
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import coil.compose.AsyncImage

private const val CONTINUE = "Continue Watching"

@Composable
fun MainShell(vm:AppViewModel) {
    CeeScaffold(vm) {
        when(vm.tab) {
            0->HomeScreen(null,vm)
            1->HomeScreen(2,vm)
            2->HomeScreen(1,vm)
            3->SearchScreen(vm)
            4->HistoryScreen(vm)
            5->WatchlistScreen(vm)
            6->DownloadsScreen(vm)
            7->SettingsScreen(vm)
        }
    }
}

@Composable
fun HomeScreen(kind: Int?, vm: AppViewModel) {

    val key = kind ?: 0
    var data by remember(key) { mutableStateOf(vm.homeCache[key]) }
    var error by remember(key) { mutableStateOf<String?>(null) }
    var generation by remember(key) { mutableIntStateOf(0) }
    var diagnostic by remember(key) { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(key, context) {
        var previous = NetworkResilience.link(context)
        NetworkResilience.watch(context).collect { current ->
            if (error != null && current.connected && previous.routeId != current.routeId) {
                diagnostic = null
                generation++
            }
            previous = current
        }
    }

    LaunchedEffect(key, generation) {
        // 1) Paint last session's catalog right away if this tab has none in memory yet.
        if (data == null) {
            Services.repo.cachedHome(kind)?.let { vm.homeCache[key] = it; data = it }
        }
        // 2) Refresh behind it (stale-while-revalidate). A failed refresh never replaces
        //    good content with an error screen.
        if (data == null || generation > 0 || !vm.isHomeFresh(key)) {
            if (data == null) error = null
            try {
                val loaded = Services.repo.loadHome(kind)
                if (loaded.rows.isEmpty()) {
                    if (data == null) error = "CEE answered, but no titles were recognised."
                } else {
                    vm.homeCache[key] = loaded
                    vm.markHomeFresh(key)
                    error = null
                    if (loaded != data) data = loaded
                }
            } catch (c: CancellationException) { throw c }
              catch (e: Exception) {
                  if (data == null) error = if(e is app.cinemanatv.data.CeeApiException)e.message else NetworkResilience.diagnose(context, e).message
              }
        }
    }

    val d = data
    if (d == null) {
        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text(t("DISCOVER"), color = C.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(t(error ?: "Finding movies and series…"), fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
            if (error != null) {
                Text(t("Connection: ${NetworkResilience.link(context).type}"), color = C.Dim, fontSize = 14.sp)
                if (diagnostic != null) Text(diagnostic.orEmpty(), color = C.Dim, fontSize = 14.sp)
            }
            if (error == null) {
                repeat(2) { row ->
                    Text(t(if (row == 0) "Trending" else "Recently added"), color = C.Dim, fontSize = 16.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        repeat(6) {
                            Box(Modifier.width(112.dp).height(166.dp).clip(RoundedCornerShape(12.dp))
                                .background(C.Panel))
                        }
                    }
                }
            }
            if (error != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    AppButton("Retry", primary = true) { diagnostic = null; generation++ }
                    AppButton("Check source") {
                        scope.launch { diagnostic = Services.repo.probe() }
                    }
                    AppButton("Downloads") { vm.tab = 6 }
                }

            }
        }
        return
    }

    // "Continue Watching" works for guests too: it comes from this device.
    val mode = vm.contentFilterMode
    LaunchedEffect(d, mode) {
        if (mode != app.cinemanatv.data.ContentFilterMode.OFF)
            vm.resolveMaturity(d.hero + d.rows.flatMap { it.items } +
                Services.prefs.recent() + Services.prefs.watchlist())
    }
    // Recomputing this on every recomposition (it used to run on EVERY focus move) re-filtered the
    // whole catalog on each D-pad press. It only depends on the data, the filter and the row toggles.
    val showContinue = vm.showContinueRow
    val showMyList = vm.showMyListRow
    val hideWatched = vm.hideWatchedDiscovery
    val maturityBusy = vm.maturityBusy
    val rows = remember(d, mode, showContinue, showMyList, hideWatched, maturityBusy) {
        val recent = if (kind == null && showContinue) vm.visible(Services.prefs.recent()) else emptyList()
        val saved = if (kind == null && showMyList) vm.visible(Services.prefs.watchlist()) else emptyList()
        val hiddenWatchedIds = if (hideWatched) Services.prefs.history().mapTo(hashSetOf()) { it.id }
            else emptySet()
        val pinned = buildList {
            if (recent.isNotEmpty()) add(ContentRow(CONTINUE, recent))
            if (saved.isNotEmpty()) add(ContentRow("My List", saved))
        }
        pinned + d.rows.mapNotNull { row ->
            if (pinned.any { it.title == row.title }) null
            else vm.visible(row.items).filterNot { it.id in hiddenWatchedIds }
                .takeIf { it.isNotEmpty() }?.let { ContentRow(row.title, it, row.section) }
        }
    }
    if (rows.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 30.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (vm.maturityBusy) Text(t("Checking age ratings…"), color = C.Dim)
            else {
                Text(t("No titles match your content restrictions."), color = C.Dim)
                AppButton("Content settings", primary = true) { vm.tab = 7 }
            }
        }
        return
    }

    val colState = remember(key) { vm.colState(key) }
    val restore = remember(key) { vm.homeFocus[key] }
    val targetRow = restore?.first?.takeIf { t -> rows.any { it.title == t } } ?: rows.first().title
    val targetCol = if (restore != null && restore.first == targetRow) restore.second.coerceIn(0,rows.first{it.title==targetRow}.items.lastIndex) else 0
    val target = remember(key) { FocusRequester() }
    val initialFocus=remember(key){booleanArrayOf(true)}
    val navigationFocused by rememberUpdatedState(LocalNavigationRailFocused.current)
    val inputGeneration by rememberUpdatedState(LocalChromeInputGeneration.current)

    // Focus is tracked as state that is NOT read during composition: moving the D-pad must not
    // recompose the whole page. Only Hero observes the (debounced) preview.
    val focused = remember(key) { mutableStateOf<Video?>(null) }
    val preview = remember(key) { mutableStateOf<Video?>(null) }
    LaunchedEffect(key) {
        snapshotFlow { focused.value?.id }.distinctUntilChanged().collectLatest {
            delay(500) // Never decode a fullscreen backdrop during rapid D-pad navigation.
            preview.value = focused.value
        }
    }
    val fallback = vm.visible(d.hero).firstOrNull() ?: rows.first().items.firstOrNull() ?: return

    // Coming back from a title: restore the scroll position and put focus on the card we left.
    // Keyed by tab, not by data: a silent background refresh must never move the user's focus.
    LaunchedEffect(key) {
        val interaction=inputGeneration
        val ri = rows.indexOfFirst { it.title == targetRow }
        withFrameNanos{}
        if(ri>=0 && restore!=null) {
            val item=ri+1+(if(rows.any{it.section!=null})1 else 0)
            if(colState.layoutInfo.visibleItemsInfo.none{it.index==item})colState.scrollToItem(item)
            withFrameNanos{}
            val horizontal=vm.rowState(key,targetRow)
            if(horizontal.layoutInfo.visibleItemsInfo.none{it.index==targetCol})horizontal.scrollToItem(targetCol)
        }
        delay(60)
        if(initialFocus[0] && inputGeneration==interaction && (restore!=null || !navigationFocused))runCatching { target.requestFocus() }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = colState,
            contentPadding = PaddingValues(top = 4.dp, bottom = 40.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key="hero") { Hero(preview, fallback,onFocused={initialFocus[0]=false},onResume={vm.push(Screen.Play(listOf(it),0))}) { vm.push(Screen.Detail(it)) } }
            if(rows.any{it.section!=null})item(key="collections") {
                LazyRow(contentPadding=PaddingValues(horizontal=32.dp,vertical=2.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    val sections=rows.mapNotNull{it.section}.distinctBy{it.key}
                    itemsIndexed(sections,key={_,section->section.key}) { _,section ->
                        AppButton(section.title,showFocusChevron=true,onFocused={initialFocus[0]=false}) {vm.push(Screen.Collection(section))}
                    }
                }
            }
            itemsIndexed(rows, key = { _, r -> r.title }) { _, row ->
                Column {
                    Row(Modifier.fillMaxWidth().padding(start=32.dp,end=32.dp,bottom=8.dp),
                        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.width(3.dp).height(20.dp).clip(RoundedCornerShape(2.dp)).background(C.Accent))
                            Text(t(row.title),fontSize=20.sp,fontWeight=FontWeight.SemiBold)
                        }
                        row.section?.let { section -> AppButton("Browse all",showFocusChevron=false,onFocused={initialFocus[0]=false}) { vm.push(Screen.Collection(section)) } }
                    }
                    LazyRow(
                        state = vm.rowState(key, row.title),
                        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(row.items, key = { _, v -> v.id }) { ci, v ->
                            PosterCard(
                                v,
                                vm = vm,
                                modifier = if (row.title == targetRow && ci == targetCol) Modifier.focusRequester(target) else Modifier,
                                onFocus = { focused.value = v; vm.homeFocus[key] = row.title to ci },
                                onClick = { vm.push(Screen.Detail(v)) },
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Artwork stays bounded for TV memory; text and focus controls sit over a solid gradient. */
@Composable
private fun Hero(focused: State<Video?>, fallback: Video,onFocused:()->Unit,onResume:(Video)->Unit,onOpen:(Video)->Unit) {
    val v=focused.value ?: fallback
    val context=LocalContext.current
    val artwork=remember(v.poster,context){ImageRequest.Builder(context).data(v.poster).size(500,750).crossfade(false).build()}
    Box(Modifier.fillMaxWidth().height(228.dp).padding(horizontal=32.dp,vertical=6.dp)
        .clip(RoundedCornerShape(20.dp)).background(C.Panel)) {
        AsyncImage(model=artwork,contentDescription=null,contentScale=ContentScale.Crop,
            alignment=Alignment.TopCenter,modifier=Modifier.align(Alignment.CenterEnd).fillMaxWidth(0.6f).fillMaxHeight().blur(20.dp).alpha(0.18f))
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to C.Panel,0.4f to C.Panel,1f to Color.Transparent)))
        AsyncImage(model=artwork,contentDescription=null,contentScale=ContentScale.Crop,
            modifier=Modifier.align(Alignment.CenterEnd).padding(end=24.dp).width(124.dp).height(186.dp).clip(RoundedCornerShape(12.dp)))
        Column(Modifier.align(Alignment.CenterStart).padding(start=24.dp,end=208.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Text(t("IN THE SPOTLIGHT"),fontSize=10.sp,fontWeight=FontWeight.Bold,color=C.Accent,letterSpacing=2.sp)
                Text(t(if(v.kind=="2") "Series" else "Movies"),Modifier.clip(RoundedCornerShape(5.dp)).background(Color(0xFF2B4130))
                    .padding(horizontal=8.dp,vertical=3.dp),fontSize=10.sp,color=Color.White)
            }
            Text(v.displayTitle,fontSize=30.sp,fontWeight=FontWeight.Bold,maxLines=2,lineHeight=34.sp,overflow=TextOverflow.Ellipsis)
            val metadata=listOfNotNull(v.year,v.rating,v.filmRating).plus(v.genres.take(2)).joinToString("  ·  ")
            if(metadata.isNotBlank())Text(metadata,fontSize=13.sp,color=C.Dim)
            if(v.description.isNotBlank())Text(v.description,maxLines=1,fontSize=13.sp,lineHeight=19.sp,color=C.Dim,overflow=TextOverflow.Ellipsis)
            val resumable=v.kind!="2" && Services.prefs.resume(v.id)>10_000L
            var saved by remember(v.id){mutableStateOf(Services.prefs.isWatchlisted(v.id))}
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                AppButton(if(resumable) "Resume" else if(v.kind=="2") "Explore series" else "View movie",icon=Icons.Default.PlayArrow,
                    primary=true,showFocusChevron=false,onFocused=onFocused){if(resumable)onResume(v) else onOpen(v)}
                AppButton(if(saved) "In My List" else "Add to My List",icon=if(saved)Icons.Default.Check else Icons.Default.Add,
                    showFocusChevron=false,onFocused=onFocused){saved=Services.prefs.toggleWatchlist(v)}
            }
        }
    }
}
