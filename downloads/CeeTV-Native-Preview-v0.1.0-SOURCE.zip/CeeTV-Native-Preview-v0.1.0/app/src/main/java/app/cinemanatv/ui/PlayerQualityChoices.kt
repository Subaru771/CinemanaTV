package app.cinemanatv.ui

import app.cinemanatv.data.QualityOption

/** Decoder metadata supplements the provider inventory; one current track must not replace it. */
internal fun playerQualityChoices(
    sources: List<QualityOption>,
    discovered: List<QualityOption>,
    current: QualityOption?,
    trackHeights: List<Int>,
): List<QualityOption> {
    val declared = (sources + discovered).filter { it.height > 0 }
        .sortedByDescending { it.url == current?.url }
    val native = if (current == null) emptyList() else trackHeights.filter { it > 0 }.map {
        current.copy(height = it, name = "${it}p")
    }
    return (declared + native).distinctBy { it.height }.sortedByDescending { it.height }
}
