package app.cinemanatv.data

import com.google.gson.JsonParser
import org.junit.Assert.*
import org.junit.Test

class CeeNativeParserTest {
    private fun json(s:String)=JsonParser.parseString(s)
    @Test fun qualitiesUseTheirReturnedUrlsAndResolutions() {
        val files=CeeNativeParser.files(json("""[{"resolution":"360p","container":"mp4","videoUrl":"https://cdn.example/low"},{"resolution":"1080p","container":"mp4","videoUrl":"https://cdn.example/full?signature=sample"}]"""))
        assertEquals(listOf(1080,360),files.map{it.height})
        assertEquals("https://cdn.example/full?signature=sample",files.first().url)
        assertEquals("video/mp4",files.first().mimeType)
    }
    @Test fun namesWithoutUrlsNeverBecomeInventedStreams() {
        assertTrue(CeeNativeParser.files(json("""[{"resolution":"720p","name":"movie.mp4","transcoddedFileName":"720.mp4"},{"resolution":"1080p","videoUrl":"https://cdn.example/poster.jpg"},{"videoUrl":"file:///tmp/movie.mp4"},{"videoUrl":"https://user:pass@cdn.example/movie.mp4"}]""")).isEmpty())
    }
    @Test fun anUnnumberedFileRemainsAnOriginalFile() {
        val file=CeeNativeParser.files(json("""[{"container":"mp4","videoUrl":"https://cdn.example/original"}]""")).single()
        assertEquals(0,file.height);assertEquals("Original file",file.label)
        assertEquals(listOf(file),app.cinemanatv.util.numberedDownloadOptions(listOf(file)))
    }
    @Test fun nativeSeriesIdentityNeverUsesAWebsiteTitleHash() {
        val video=CeeNativeParser.videos(json("""[{"nb":"101","kind":"2","rootSeries":"100","season":"1","episodeNummer":"2","en_title":"Episode"}]""")).single()
        assertEquals("cee_api_101",video.id);assertEquals("cee_api_100",video.rootSeries);assertNull(video.providerPageId)
    }
    @Test fun metadataFromADifferentTitleCannotOverwriteTheRequestedTitle() {
        val fallback=Video(nb="cee_api_101",kind="2",enTitle="Requested")
        val detail=CeeNativeParser.detail(json("""{"nb":"102","en_title":"Wrong","seriesRating":"PG","introSkipping":[{"start":10,"end":60}]}"""),fallback)
        assertEquals(fallback,detail)
    }
    @Test fun seriesCertificationAndPublishedIntroSecondsAreRetained() {
        val detail=CeeNativeParser.detail(json("""{"nb":"101","kind":"2","seriesRating":"TV-MA","introSkipping":[{"start":11.5,"end":45}]}"""),Video(nb="cee_api_101",kind="2",enTitle="Episode"))
        assertEquals("TV-MA",detail.filmRating);assertEquals(11_500L until 45_000L,detail.introWindow)
    }
    @Test fun subtitleMimeCanComeFromTheApiWhenTheSignedUrlHasNoExtension() {
        val subtitles=CeeNativeParser.subtitles(json("""{"translations":[{"name":"english","extention":"vtt","file":"https://cdn.example/sub?token=sample"},{"name":"arabic","extention":"srt","file":"https://cdn.example/ar.srt"}]}"""))
        assertEquals("text/vtt",subtitles.first{it.label=="English"}.mime)
        assertEquals("application/x-subrip",subtitles.first{it.label=="العربية"}.mime)
    }
    @Test fun unsupportedGroupsAreDifferentFromAnExplicitlyEmptyList() {
        assertTrue(CeeNativeParser.groups(json("""{"groups":[]}"""),null).isEmpty())
        try{CeeNativeParser.groups(json("""{"page":"landing"}"""),null);fail()}catch(_:CeeApiException){}
    }
}
