package app.cinemanatv.data

import com.google.gson.JsonParser
import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.*
import org.junit.Assert.*
import java.util.concurrent.CopyOnWriteArrayList

class CeeNativeApiTest {
    private lateinit var server:MockWebServer
    private lateinit var http:CeeNativeHttp
    private val requests=CopyOnWriteArrayList<RecordedRequest>()
    private val responses=mutableMapOf<String,Pair<Int,String>>()
    @Before fun setup(){
        server=MockWebServer()
        server.dispatcher=object:Dispatcher(){override fun dispatch(request:RecordedRequest):MockResponse {
            requests.add(request)
            val response=synchronized(responses){responses[request.path]}
            return MockResponse().setResponseCode(response?.first ?: 404).setHeader("Content-Type","application/json").setBody(response?.second ?: "{}")
        }}
        server.start();http=CeeNativeHttp(server.url("/api/android/"),{"CeeTV-Contract-Test"})
    }
    @After fun close(){server.shutdown()}
    private fun respond(path:String,body:String,code:Int=200){synchronized(responses){responses["/api/android/$path"]=code to body}}
    private fun movie(id:Int=101)="""{"nb":"$id","kind":"1","en_title":"Example $id"}"""
    @Test fun homeUsesTheApkGroupContractAndNativeIdentities() = runBlocking {
        respond("videoGroups/lang/en/kindGroup/0","""{"groups":[{"groupsID":"42","title":"Popular","content":[${movie()}]}]}""")
        respond("banner/level/1","[${movie()}]")
        val home=CeeNativeCatalog(http,{"en"}).home(null)
        assertEquals("cee_api_101",home.hero.single().id)
        assertEquals("42",home.rows.single().section?.nativeGroupId)
        assertEquals(12,home.rows.single().section?.pageSize)
        assertEquals(2,requests.size)
        assertTrue(requests.all{it.getHeader("Authorization")==null && it.getHeader("Cookie")==null})
    }
    @Test fun theFirstCollectionPageUsesTheApksZeroBasedPaging() = runBlocking {
        respond("videoGroups/groupID/42/page/0/itemsPerPage/12","[${movie()}]")
        val result=CeeNativeCatalog(http).browse(CatalogSection("native","Popular",1,pageSize=12,nativeGroupId="42"),1)
        assertEquals("cee_api_101",result.single().id)
        assertEquals("/api/android/videoGroups/groupID/42/page/0/itemsPerPage/12",requests.single().path)
    }
    @Test fun fileLookupIsExactCaseFreshAndSuppliesTheNativeQualityUrls() = runBlocking {
        respond("transcoddedfiles/id/101","""[{"resolution":"720p","container":"mp4","videoUrl":"https://cdn.example/720.mp4"}]""")
        val result=CeeNativeCatalog(http).sources("cee_api_101")
        assertEquals(720,result.qualities.single().height)
        assertEquals("no-store",requests.single().getHeader("Cache-Control"))
        assertEquals("CeeTV-Contract-Test",requests.single().getHeader("User-Agent"))
    }
    @Test fun searchMatchesTheApksUriThenRetrofitEncodingAndKeepsPartialSuccess() = runBlocking {
        respond("video/V/2/videoKind/1/itemsPerPage/20/video_title_search/YQ%253D%253D","[${movie()}]")
        respond("video/V/2/videoKind/2/itemsPerPage/20/video_title_search/YQ%253D%253D","{}",503)
        assertEquals("cee_api_101",CeeNativeCatalog(http).search("a").single().id)
        assertTrue(requests.all{it.path!!.endsWith("/YQ%253D%253D")})
    }
    @Test fun episodesKeepTheRealParentAndChronologicalOrder() = runBlocking {
        respond("videoSeason/id/100","""[{"nb":"103","kind":"2","en_title":"Third","season":"1","episodeNummer":"3","rootSeries":"100"},{"nb":"102","kind":"2","en_title":"Second","season":"1","episodeNummer":"2","rootSeries":"100"},{"nb":"104","kind":"2","en_title":"Wrong series","season":"1","episodeNummer":"1","rootSeries":"999"}]""")
        val result=CeeNativeCatalog(http).episodes(Video(nb="cee_api_103",kind="2",rootSeries="cee_api_100",season="1",episodeNummer="3"))
        assertEquals(listOf(2,3),result.map{it.episodeNumber})
        assertTrue(result.all{it.rootSeries=="cee_api_100"})
    }
    @Test fun playbackDoesNotWaitForAnOptionalSubtitleLookup() = runBlocking {
        respond("transcoddedfiles/id/101","""[{"resolution":"480p","container":"mp4","videoUrl":"https://cdn.example/movie.mp4"}]""")
        assertEquals(480,CeeNativeCatalog(http).sources("cee_api_101").qualities.single().height)
        assertEquals(1,requests.size)
    }
    @Test fun landingHtmlWithHttp200IsAnError() = runBlocking {
        respond("banner/level/1","<!doctype html><title>Download CEE</title>")
        try{http.get("banner/level/1");fail()}catch(e:CeeApiException){assertTrue(e.message!!.contains("website page"))}
    }
    @Test fun anUnavailableNativeServiceNeverBecomesWebsiteCatalogueData() = runBlocking {
        respond("videoGroups/lang/ar/kindGroup/0","{}",503)
        respond("banner/level/1","{}",503)
        try{CeeNativeCatalog(http).home(null);fail()}catch(e:CeeApiException){assertEquals(503,e.statusCode)}
        assertTrue(requests.isNotEmpty());assertTrue(requests.all{it.path!!.startsWith("/api/android/")})
    }
    @Test fun JSONPrimitivesAreNotMistakenForAnEmptySuccessfulResponse() = runBlocking {
        respond("banner/level/1","\"not a catalogue\"")
        try{http.get("banner/level/1");fail()}catch(e:CeeApiException){assertTrue(e.message!!.contains("unexpected response"))}
    }
    @Test fun namespaceAndRoutesCannotAcceptWebsiteIdsOrPathInjection() {
        assertEquals("transcoddedfiles/id/101",CeeNativeProtocol.files("cee_api_101"))
        for(id in listOf("cee_101","cee_api_0","cee_api_../1"))try{CeeNativeProtocol.raw(id);fail(id)}catch(_:IllegalArgumentException){}
        try{CeeNativeProtocol.group("../42",0);fail()}catch(_:IllegalArgumentException){}
    }
}
