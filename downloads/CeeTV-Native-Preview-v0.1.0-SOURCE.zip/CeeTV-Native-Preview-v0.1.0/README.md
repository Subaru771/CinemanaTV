# Cee TV Native Preview 0.1.0

An independent implementation of the native CEE catalogue/playback protocol recovered from the supplied CEE Leanback APK. Kotlin, Compose and Media3 code is written for this app; no decompiled application code, native blob, App Cloner payload or reference signing key is included.

Package: `app.cinemanatv.cee.nativepreview`. Launcher: **Cee TV Native**. This installs alongside Cee TV 1.2.2. It uses a separate cache/library and has no default update feed. The stable Cee TV package and update feed are not changed.

## What is different

The default repository uses `https://cee.buzz/api/android/` for provider groups, banners, paged collections, search, details, related items, seasons, and resolution/URL video-file lists. It never silently substitutes a website catalogue. Native IDs are namespaced separately from old website post IDs. Numbered video qualities come directly from the returned files; downloads use those same options.

The Soft31 landing page at cee.buzz.iraq.soft31.com embeds cee.buzz/home through /2.html. Its API-looking paths currently return the landing HTML with HTTP 200; this is rejected as non-API data. Both the actual CEE origin and native API returned connection-timeout HTTP 503 responses here. The preview therefore has contract/UI test coverage but is **not verified for live catalogue/media playback**. It is for testing on a network where the reference APK works.

The reference API's compatibility protocol version is retained in the User-Agent with actual device fields and Cee TV identification. No serial, MAC, device fingerprint, account token, licence signature, analytics SDK or identity-spoofing setting is copied. The guest read paths do not send account credentials. Native API access stays HTTPS with certificate verification. Media/artwork URLs retain HTTP/HTTPS as supplied by that API, matching legacy-media support.

See REVERSE-ENGINEERING-MAP.md for the traced protocol, SECOND-OPINION.md for the review, and VERIFICATION.md for test limits.

## Build and signing

Use JDK 17 and Android SDK 35. Run `bash gradlew testDebugUnitTest assembleDebug` for development. Release-type previews use `bash gradlew assembleRelease` and default to the development key; this is not production signing.

Optional controlled signing accepts all four properties in local.properties or Gradle -P, or the corresponding environment variables:

| Property | Environment |
| --- | --- |
| cee.signing.storeFile | CEE_SIGNING_STORE_FILE |
| cee.signing.storePassword | CEE_SIGNING_STORE_PASSWORD |
| cee.signing.keyAlias | CEE_SIGNING_KEY_ALIAS |
| cee.signing.keyPassword | CEE_SIGNING_KEY_PASSWORD |

Partial configuration fails. Set `-Pcee.productionRelease=true` for a production build: it refuses to proceed without an explicit key. Keep keys/passwords out of Git, source ZIPs and build logs. Environment variables or a private local properties file avoid putting passwords into shell history.

For the existing stable package, securely back up the exact current keystore and check its certificate fingerprint. Generating another debug keystore, even with the same alias/password, creates a different signing identity and breaks in-place updates. Plan any rotation against the supported Android versions and verify it on devices. The preview's separate package can adopt a controlled release key before a production rollout. Never reuse the reference APK's public Android test key.

## Interface and scope

The existing green TV UI, touch controls, player options, local history/list/downloads, episode sorting and resume behavior are retained. Native collection page sizes and provider series IDs are preserved. Provider failures remain visible and the local download/library controls remain reachable.

This preview retains the tested landscape TV layout. Claude's edited portrait/refactor source was not supplied. A responsive phone pass should keep shared state/navigation while adapting compact navigation and every major screen, with 360/412dp portrait and landscape pointer/rotation tests. Real TV remote, hardware decoder, buffering, HDR/audio and phone testing are still required.

Account sync, licence/device-signature calls, DLNA/Cling, Firebase and App Cloner ScreenOff behavior are outside this native guest adapter. The HTML adapter remains in the source for old tests/reference but is not selected by the preview application.
