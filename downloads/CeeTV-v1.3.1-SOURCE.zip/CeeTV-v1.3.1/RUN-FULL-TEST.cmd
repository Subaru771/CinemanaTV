@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat --no-daemon --max-workers=2 testWebsiteDebugUnitTest testNativeApiDebugUnitTest assembleWebsiteDebug assembleNativeApiDebug
if errorlevel 1 exit /b 1
echo Both provider variants tested and built.
pause
