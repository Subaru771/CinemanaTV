# Cee TV 1.3.1 / Native Preview 0.3.0

The responsive phone/TV interface, pointer and D-pad controls, local history/lists/downloads, chronological episodes, recent resume, Telegram/update notices, signing guards and shared quality discovery remain from 1.3.0.

Website mode has two explicit transport choices using the same website title IDs: direct on-device parsing or an optional hosted website API. Native guest API mode remains a separate installation with separate native identities; there is no guessed title matching or hidden cross-provider substitution.

Hosted website mode implements home, search/watch-page lookup, category browsing, details, episode pagination, related cards, supported subtitle declarations and source/rejected-route lookup. Published HLS audio/subtitle groups stay in the master playlist. An unavailable subtitle declaration produces an empty list rather than invented captions.

The server centralizes a bounded catalogue cache and parser repair. It tries three known server slots and multiple approved embeds, preserves URL/height pairs and fresh playback lookups, and applies request deadlines, response limits, cancellation and access/rate gates. The Android adapter independently checks HLS reachability from its own network.

Remaining external limits: an actual HTTPS deployment is needed to enable hosted mode. Website markup and media hosts remain external dependencies; it is not a video relay or an all-network guarantee. Native live service availability and physical TV/phone decoder/focus/buffering behavior are not established by local fixtures. Account sync, licence/device signatures, casting and App Cloner behavior remain outside the independent guest integration.
