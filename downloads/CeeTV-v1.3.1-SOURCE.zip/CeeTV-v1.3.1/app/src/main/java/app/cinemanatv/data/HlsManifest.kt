package app.cinemanatv.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.BufferedSource
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

object HlsManifest {
    internal data class Variant(val height: Int, val url: String)
    internal data class Playlist(val url: String, val text: String)
    private val http by lazy { OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
        .callTimeout(6,TimeUnit.SECONDS).connectTimeout(4,TimeUnit.SECONDS)
        .readTimeout(4,TimeUnit.SECONDS).build() }

    private fun safe(url:HttpUrl)=url.scheme=="https" && url.username.isEmpty() && url.password.isEmpty()

    internal fun variants(master:String,text:String,deduplicate:Boolean=true):List<Variant> {
        if(!text.trimStart().startsWith("#EXTM3U"))return emptyList()
        val base=master.toHttpUrlOrNull() ?: return emptyList()
        var height:Int?=null
        val parsed=buildList {
            text.lineSequence().take(8000).forEach { raw ->
                val line=raw.trim()
                if(line.startsWith("#EXT-X-STREAM-INF:")) {
                    height=Regex("""(?:[:,])\s*RESOLUTION\s*=\s*[0-9]+x([0-9]+)(?:,|$)""",RegexOption.IGNORE_CASE)
                        .find(line)?.groupValues?.get(1)?.toIntOrNull()?.takeIf{it in 144..8640}
                } else if(line.isNotBlank() && !line.startsWith("#")) {
                    val target=base.resolve(line)
                    if(height!=null && target!=null && safe(target))add(Variant(height!!,target.toString()))
                    height=null
                }
            }
        }.distinctBy{it.url}.sortedByDescending{it.height}
        return if(deduplicate)parsed.distinctBy{it.height} else parsed
    }

    internal fun playlistPrefix(source:BufferedSource):String {
        val truncated=source.request(65_537L)
        val text=source.readUtf8(minOf(source.buffer.size,65_536L))
        return (if(truncated)text.substringBeforeLast('\n',"") else text)
            .takeIf{it.trimStart().startsWith("#EXTM3U")}
            ?: throw IOException("The provider did not return a playlist.")
    }

    private suspend fun <T> get(address:String,range:Boolean=false,consume:(okhttp3.Response)->T):T {
        var url=address.toHttpUrlOrNull()?.takeIf(::safe) ?: throw IOException("Invalid media address.")
        repeat(6) {
            coroutineContext.ensureActive()
            var next:HttpUrl?=null
            val result=CancellableHttp.read(http,Request.Builder().url(url).header("User-Agent",userAgent())
                .apply{if(range)header("Range","bytes=0-511").header("Accept-Encoding","identity")}.build()) { response ->
                if(response.code in listOf(301,302,303,307,308)) {
                    next=response.header("Location")?.let(url::resolve)?.takeIf(::safe)
                        ?: throw IOException("Unsupported media redirect.")
                    null
                } else consume(response)
            }
            if(next==null)return result ?: throw IOException("Empty media response.")
            url=next!!
        }
        throw IOException("Too many media redirects.")
    }

    private val pages=LinkedHashMap<String,Pair<Long,Playlist>>()
    private suspend fun read(address:String,refresh:Boolean=false):Playlist {
        if(!refresh)synchronized(pages){pages[address]?.takeIf{System.currentTimeMillis()-it.first in 0..20_000}}?.let{return it.second}
        val page=get(address) { response ->
            if(!response.isSuccessful)throw IOException("Playlist HTTP ${response.code}.")
            val source=response.body?.source() ?: throw IOException("Empty playlist.")
            Playlist(response.request.url.toString(),playlistPrefix(source))
        }
        synchronized(pages){pages[address]=System.currentTimeMillis() to page;while(pages.size>24)pages.remove(pages.keys.first())}
        return page
    }

    /** Try another rendition if one is broken; resolve URIs at a redirected playlist's final URL. */
    internal suspend fun readable(address:String,playlist:suspend (String)->Playlist={read(it)},
                                   segment:suspend (String)->Boolean=::segmentReadable):Boolean {
        val master=try{playlist(address)}catch(_:IOException){return false}
        if(!master.text.trimStart().startsWith("#EXTM3U"))return false
        val isMaster=master.text.lineSequence().any{it.trim().startsWith("#EXT-X-STREAM-INF:")}
        val declared=variants(master.url,master.text,deduplicate=false)
        val targets=if(!isMaster)listOf(master.url) else declared.asReversed().map{it.url}.ifEmpty {
            master.text.lineSequence().map(String::trim).filter{it.isNotEmpty() && !it.startsWith("#")}
                .mapNotNull{master.url.toHttpUrlOrNull()?.resolve(it)?.takeIf(::safe)?.toString()}.toList()
        }
        for(target in targets.distinct().take(6)) {
            coroutineContext.ensureActive()
            try {
                val media=if(!isMaster)master else playlist(target)
                if(!media.text.trimStart().startsWith("#EXTM3U") || media.text.contains("#EXT-X-STREAM-INF:"))continue
                val first=media.text.lineSequence().map(String::trim).firstOrNull{it.isNotEmpty() && !it.startsWith("#")}
                val url=first?.let{media.url.toHttpUrlOrNull()?.resolve(it)}?.takeIf(::safe) ?: continue
                if(segment(url.toString()))return true
            }catch(_:IOException){ /* An unavailable rendition does not invalidate the others. */ }
        }
        return false
    }

    private suspend fun segmentReadable(address:String):Boolean {
        suspend fun sample(range:Boolean):Pair<Int,Boolean> = get(address,range) { response ->
            val type=response.header("Content-Type").orEmpty()
            val source=response.body?.source()
            val readable=response.isSuccessful && !type.contains("text/html",true) && !type.contains("json",true) &&
                source!=null && source.request(16) && source.readByteArray(16).let {
                    val text=String(it,Charsets.UTF_8).trimStart()
                    !text.startsWith("<") && !text.startsWith("#EXTM3U") && !text.startsWith("{")
                }
            response.code to readable
        }
        val first=sample(true)
        return if(first.first in listOf(400,405,416))sample(false).second else first.second
    }

    suspend fun heights(option:QualityOption,refresh:Boolean=false):List<Int> = withContext(Dispatchers.IO) {
        if(!option.adaptive || option.mimeType.equals("application/dash+xml",true) || option.url.substringBefore('?').endsWith(".mpd",true))return@withContext emptyList()
        repeat(2){attempt ->
            try{val page=read(option.url,refresh || attempt>0);return@withContext variants(page.url,page.text).map{it.height}}
            catch(c:kotlinx.coroutines.CancellationException){throw c}catch(_:IOException){if(attempt==0)kotlinx.coroutines.delay(250)}
        }
        emptyList()
    }

    suspend fun downloadOptions(options:List<QualityOption>,findHeights:suspend (QualityOption)->List<Int> = {heights(it)}):List<QualityOption> = withContext(Dispatchers.IO) {
        QualityInventory.expand(options,findHeights)
    }
}
