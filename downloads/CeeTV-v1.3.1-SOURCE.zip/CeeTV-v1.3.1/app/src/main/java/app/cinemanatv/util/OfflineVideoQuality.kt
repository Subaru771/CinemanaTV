@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package app.cinemanatv.util

import androidx.media3.common.C
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import java.io.IOException

internal class OfflineQualityUnavailable(height:Int):IOException("${height}p is not available for offline playback on this device. Choose another quality.")

/** A numbered download must select that video track; a height ceiling can silently choose another. */
internal fun offlineVideoQuality(tracks:Tracks,height:Int):TrackSelectionOverride? {
    if(height<=0)return null
    val groups=tracks.groups.filter{it.type==C.TRACK_TYPE_VIDEO}
    if(groups.isEmpty())return null // An audio-only period keeps its audio selection.
    val found=groups.flatMap { group ->
        (0 until group.length).filter{group.isTrackSupported(it) && group.getTrackFormat(it).height==height}
            .map{group to it}
    }.maxByOrNull{(group,index)->group.getTrackFormat(index).bitrate}
        ?: throw OfflineQualityUnavailable(height)
    return TrackSelectionOverride(found.first.mediaTrackGroup,found.second)
}
