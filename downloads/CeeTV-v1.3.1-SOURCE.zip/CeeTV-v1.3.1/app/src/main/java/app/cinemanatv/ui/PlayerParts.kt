@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.ui

import app.cinemanatv.data.displayTitle

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import app.cinemanatv.BuildConfig
import app.cinemanatv.util.PlaybackReport
import androidx.compose.foundation.horizontalScroll
import android.content.Intent
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent as AndroidKeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C as MediaC
import androidx.media3.common.PlaybackException
import app.cinemanatv.util.SmartQuality
import app.cinemanatv.util.preferredSubtitleLabel
import app.cinemanatv.util.NextEpisodePreloader
import app.cinemanatv.util.TvHomeIntegration
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import app.cinemanatv.ui.TouchSurface as Surface
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.PlaySources
import app.cinemanatv.data.QualityOption
import app.cinemanatv.data.Video
import app.cinemanatv.data.MatureAction
import app.cinemanatv.data.SceneSkipping
import app.cinemanatv.data.SceneRange
import app.cinemanatv.data.ExternalSceneMarker
import app.cinemanatv.data.ExternalSceneMarkers
import app.cinemanatv.data.RemoteSceneMetadata
import app.cinemanatv.data.MatureSceneLookup
import app.cinemanatv.data.EpisodeSceneMarkers
import app.cinemanatv.data.MatureSceneLookupStatus
import app.cinemanatv.data.supportsPublicMatureMarkers
import app.cinemanatv.data.SkipOffer
import app.cinemanatv.data.SkipPlanner
import app.cinemanatv.util.Capabilities
import app.cinemanatv.util.Downloads
import app.cinemanatv.util.NetworkResilience
import app.cinemanatv.util.TimedCaption
import app.cinemanatv.util.parseTimedSubtitles
import app.cinemanatv.util.activeCaptions
import app.cinemanatv.data.userAgent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.URL
import app.cinemanatv.util.FailureType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.withTimeoutOrNull
import java.text.DateFormat
import java.util.Locale

// All interaction goes through focusable TV surfaces, never touchscreen-only overlays.
/** Compose state for clocks and menus must not re-bind the underlying video surface. */
@Composable
internal fun CinemaVideoSurface(
    player: Player, mode: ScreenMode, subtitleScale: Float,
    manualCues: List<Cue>?, style: Int, placement: Int,
) {
    val currentManual by rememberUpdatedState(manualCues)
    AndroidView(
        factory = { ctx -> PlayerView(ctx).apply {
            useController = false
            setKeepContentOnPlayerReset(true)
            this.player = player
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            subtitleView?.apply {
                // Retain simultaneous cues and original subtitle timing/positioning.
                setApplyEmbeddedStyles(true)
                // Readable on any scene: white text, dark outline, and a size the viewer controls
                // (never the tiny font sizes some subtitle files embed).
                setApplyEmbeddedFontSizes(false)
                setStyle(CaptionStyleCompat(
                    android.graphics.Color.WHITE,
                    android.graphics.Color.TRANSPARENT,
                    android.graphics.Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                    android.graphics.Color.BLACK,
                    null
                ))
                setBottomPaddingFraction(0.06f)
            }
            // PlayerView already dispatches the full CueGroup. Register after its
            // listener so unpositioned simultaneous cues can be stacked instead
            // of painted on top of one another; do not drop the other cues.
            val boundView = this
            val cueListener = object : Player.Listener {
                override fun onCues(cueGroup: CueGroup) {
                    if (currentManual == null) {
                        boundView.subtitleView?.setCues(layoutSimultaneousSubtitleCues(cueGroup.cues))
                    }
                }
            }
            player.addListener(cueListener)
            setTag(app.cinemanatv.R.id.cinemana_multi_cue_listener, cueListener)
            subtitleView?.setCues(layoutSimultaneousSubtitleCues(player.currentCues.cues))
        } },
        update = { view ->
            val resize = when (mode) {
                ScreenMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                ScreenMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                ScreenMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            }
            if (view.resizeMode != resize) view.resizeMode = resize
            view.subtitleView?.apply {
                setFractionalTextSize(0.0533f * subtitleScale)
                setBottomPaddingFraction(when (placement) { 0 -> 0.025f; 2 -> 0.18f; else -> 0.06f })
                setStyle(when (style) {
                    1 -> CaptionStyleCompat(android.graphics.Color.YELLOW,
                        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null)
                    2 -> CaptionStyleCompat(android.graphics.Color.WHITE,
                        android.graphics.Color.BLACK, android.graphics.Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_NONE, android.graphics.Color.BLACK, null)
                    else -> CaptionStyleCompat(android.graphics.Color.WHITE,
                        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null)
                })
                setCues(layoutSimultaneousSubtitleCues(manualCues ?: player.currentCues.cues))
            }
        },
        modifier = Modifier.fillMaxSize(),
        onRelease = { view ->
            (view.getTag(app.cinemanatv.R.id.cinemana_multi_cue_listener) as? Player.Listener)
                ?.let { player.removeListener(it) }
            view.setTag(app.cinemanatv.R.id.cinemana_multi_cue_listener, null)
            // Do not leave the ExoPlayer attached to a disposed AndroidView.
            view.player = null
        }
    )
}

internal enum class NightGlyph { PREVIOUS, REWIND, PLAY, PAUSE, FORWARD, NEXT, CAPTIONS, SETTINGS }

/** All icons are vector-drawn, so they render consistently without icon-font dependencies. */
@Composable
internal fun NightControl(
    label: String,
    glyph: NightGlyph,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    onFocused: () -> Unit = {},
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val translatedLabel = t(label)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.width(if (primary) 76.dp else 56.dp)
    ) {
        Surface(
            onClick = onClick,
            modifier = modifier.size(if (primary) 62.dp else 46.dp)
                .onFocusChanged {
                    if (focused != it.isFocused) {
                        focused = it.isFocused
                        if (it.isFocused) onFocused()
                    }
                }
                .semantics { contentDescription = translatedLabel },
            shape = ClickableSurfaceDefaults.shape(CircleShape),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.055f),
            border = ClickableSurfaceDefaults.border(
                focusedBorder = Border(
                    androidx.compose.foundation.BorderStroke(2.dp, if (primary) Focus else Accent),
                    shape = CircleShape
                )
            ),
            colors = ClickableSurfaceDefaults.colors(
                containerColor = if (primary) Accent else Color(0x1AFFFFFF),
                contentColor = if (primary) Ink else Color.White,
                focusedContainerColor = if (primary) Focus else Color(0xFF204A33),
                focusedContentColor = if (primary) Ink else Accent
            )
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                NightVector(glyph, color = if (primary) Ink else if (focused) Accent else Color.White)
            }
        }
        // Reserve stable height so focus changes never cause the controls to jump.
        val helper = when (glyph) {
            NightGlyph.REWIND -> "−10"
            NightGlyph.FORWARD -> "+10"
            NightGlyph.PREVIOUS -> if (focused) "Previous" else " "
            NightGlyph.NEXT -> if (focused) "Next" else " "
            NightGlyph.PLAY -> if (focused) "Play" else " "
            NightGlyph.PAUSE -> if (focused) "Pause" else " "
            NightGlyph.CAPTIONS -> if (focused) "Captions" else " "
            NightGlyph.SETTINGS -> if (focused) "Settings" else " "
        }
        Text(t(helper), maxLines = 1,
            modifier = Modifier.padding(top = 5.dp),
            fontSize = 9.sp, color = if (focused) Accent else Muted)
    }
}

@Composable
internal fun NightVector(glyph: NightGlyph, color: Color) {
    if (glyph == NightGlyph.CAPTIONS) {
        Text(t("CC"), fontSize = 13.sp, color = color, fontWeight = FontWeight.Bold)
        return
    }
    Canvas(Modifier.size(if (glyph == NightGlyph.PLAY || glyph == NightGlyph.PAUSE) 27.dp else 23.dp)) {
        val w = size.width
        val h = size.height
        val line = 2.3.dp.toPx()
        fun triangle(right: Boolean, left: Float, top: Float, width: Float, height: Float) {
            val p = Path().apply {
                if (right) {
                    moveTo(left, top); lineTo(left + width, top + height / 2f)
                    lineTo(left, top + height)
                } else {
                    moveTo(left + width, top); lineTo(left, top + height / 2f)
                    lineTo(left + width, top + height)
                }
                close()
            }
            drawPath(p, color)
        }
        when (glyph) {
            NightGlyph.PLAY -> triangle(true, w * .32f, h * .18f, w * .44f, h * .64f)
            NightGlyph.PAUSE -> {
                drawRoundRect(color, topLeft = Offset(w * .27f, h * .2f),
                    size = Size(w * .16f, h * .6f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(line / 2))
                drawRoundRect(color, topLeft = Offset(w * .57f, h * .2f),
                    size = Size(w * .16f, h * .6f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(line / 2))
            }
            NightGlyph.PREVIOUS, NightGlyph.REWIND -> {
                triangle(false, w * .15f, h * .25f, w * .35f, h * .5f)
                triangle(false, w * .5f, h * .25f, w * .35f, h * .5f)
                if (glyph == NightGlyph.PREVIOUS)
                    drawLine(color, Offset(w * .1f, h * .18f), Offset(w * .1f, h * .82f), strokeWidth = line)
            }
            NightGlyph.NEXT, NightGlyph.FORWARD -> {
                triangle(true, w * .15f, h * .25f, w * .35f, h * .5f)
                triangle(true, w * .5f, h * .25f, w * .35f, h * .5f)
                if (glyph == NightGlyph.NEXT)
                    drawLine(color, Offset(w * .90f, h * .18f), Offset(w * .90f, h * .82f), strokeWidth = line)
            }
            NightGlyph.SETTINGS -> {
                drawCircle(color, radius = w * .29f, style = Stroke(line))
                drawCircle(color, radius = w * .105f, style = Stroke(line))
                for (n in 0 until 8) {
                    val a = n * Math.PI / 4.0
                    val cx = w / 2f
                    val cy = h / 2f
                    drawLine(color,
                        Offset(cx + kotlin.math.cos(a).toFloat() * w * .35f,
                            cy + kotlin.math.sin(a).toFloat() * w * .35f),
                        Offset(cx + kotlin.math.cos(a).toFloat() * w * .46f,
                            cy + kotlin.math.sin(a).toFloat() * w * .46f),
                        strokeWidth = line, cap = StrokeCap.Round)
                }
            }
            NightGlyph.CAPTIONS -> Unit
        }
    }
}

/** The Skip Intro / Undo button: a compact pill that lights up clearly under the D-pad. */
@Composable
internal fun SkipChip(
    label: String,
    hint: String?,
    primary: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(14.dp)
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(shape),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
        border = ClickableSurfaceDefaults.border(
            border = Border(androidx.compose.foundation.BorderStroke(1.dp,
                if (primary) Accent else Color(0x66FFFFFF)), shape = shape),
            focusedBorder = Border(androidx.compose.foundation.BorderStroke(2.dp, Focus), shape = shape)
        ),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (primary) Color(0xEE0F2A1A) else Color(0xE6111817),
            contentColor = if(primary) Ink else Color.White,
            focusedContainerColor = Focus,
            focusedContentColor = Ink
        )
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(t(label), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            if (hint != null) {
                Text(hint, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Accent,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0x33FFFFFF))
                        .padding(horizontal = 7.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
internal fun PlayerPill(label: String) {
    Text(t(label), modifier = Modifier.clip(RoundedCornerShape(16.dp))
        .background(Color(0xA51A2B20)).border(1.dp, Color(0x654A7E57), RoundedCornerShape(16.dp))
        .padding(horizontal = 12.dp, vertical = 6.dp), color = Color(0xFFE6F7EA),
        fontSize = 11.sp, fontWeight = FontWeight.Medium)
}

/** Focusable TV tiles visibly illuminate when the D-pad lands on them. */
@Composable
internal fun PlayerTile(
    label: String,
    symbol: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(13.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.055f),
        border = ClickableSurfaceDefaults.border(
            focusedBorder = Border(androidx.compose.foundation.BorderStroke(2.dp, Focus), shape = RoundedCornerShape(13.dp))
        ),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (primary) Accent else Color(0xD81A2920),
            contentColor = if(primary) Ink else Color.White,
            focusedContainerColor = Focus,
            focusedContentColor = Ink
        )
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(symbol, fontSize = if (symbol == "CC") 14.sp else 20.sp, fontWeight = FontWeight.Bold)
            Text(t(label), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
internal fun PlayerOption(
    label: String,
    detail: String,
    symbol: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(13.dp)),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.012f),
        border = ClickableSurfaceDefaults.border(
            focusedBorder = Border(androidx.compose.foundation.BorderStroke(2.dp, Focus), shape = RoundedCornerShape(13.dp))
        ),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (selected) Color(0xFF183825) else Color(0xFF18221D),
            contentColor = Color.White,
            focusedContainerColor = Color(0xFF294737),
            focusedContentColor = Color.White
        )
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if(symbol.isNotBlank())Text(symbol, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(27.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(t(label), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                if (detail.isNotEmpty()) Text(t(detail), fontSize = 11.sp, maxLines = 1)
            }
            if (selected) Text(t("✓"), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            else Text(t("›"), fontSize = 18.sp)
        }
    }
}

@Composable
internal fun DetailLine(name: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(t(name), color = Accent, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
        Text(t(value), fontSize = 16.sp, color = Color.White)
    }
}

@Composable
internal fun CinemaTimeline(
    progress: Float,
    buffered: Float,
    seekable: Boolean,
    instant: Boolean,
    requester: FocusRequester,
    onFocus: (Boolean) -> Unit,
    onStep: (Long, Int) -> Unit,
    onJump: (Float) -> Unit,
    onUp: () -> Unit = {}
) {
    var focused by remember { mutableStateOf(false) }
    var width by remember { mutableIntStateOf(1) }
    var dragFraction by remember{mutableStateOf<Float?>(null)}
    val target = progress.coerceIn(0f, 1f)
    // Position is sampled twice a second; gliding between samples makes the bar move
    // continuously. Big jumps (seeks) snap, small steps glide.
    val last = remember { FloatArray(1) { target } }
    val jumped = kotlin.math.abs(target - last[0]) > 0.01f
    SideEffect { last[0] = target }
    val fill = animateFloatAsState(
        targetValue = target,
        animationSpec = if (instant || jumped) snap() else tween(480, easing = LinearEasing),
        label = "timeline"
    )
    val bufferedFraction = buffered.coerceIn(0f, 1f)
    Box(
        Modifier.fillMaxWidth().height(44.dp).semantics{contentDescription="Playback timeline"}
            .focusRequester(requester)
            .onFocusChanged { focused = it.isFocused; onFocus(it.isFocused) }
            .onSizeChanged { width = it.width.coerceAtLeast(1) }
            .pointerInput(seekable, width) { detectTapGestures { offset ->
                if (seekable) onJump((offset.x / width).coerceIn(0f, 1f))
            } }
            .pointerInput(seekable,width){if(seekable)detectDragGestures(
                onDragStart={dragFraction=(it.x/width).coerceIn(0f,1f)},
                onDragEnd={dragFraction?.let(onJump);dragFraction=null},onDragCancel={dragFraction=null},
                onDrag={change,_->change.consume();dragFraction=(change.position.x/width).coerceIn(0f,1f)})}
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) false else when (event.key) {
                    Key.DirectionLeft -> {
                        if (seekable) onStep(-10_000L, event.nativeKeyEvent.repeatCount)
                        true
                    }
                    Key.DirectionRight -> {
                        if (seekable) onStep(10_000L, event.nativeKeyEvent.repeatCount)
                        true
                    }
                    // Nothing sits above the timeline: Up dismisses the HUD.
                    Key.DirectionUp -> { onUp(); true }
                    else -> false
                }
            }
            .focusable(),
        contentAlignment = Alignment.CenterStart
    ) {
        // One canvas: the animated value is read in the draw phase only, so the glide
        // costs a redraw per frame, not a recomposition per frame.
        Canvas(Modifier.fillMaxSize()) {
            val trackHeight = (if (focused) 7.dp else 3.dp).toPx()
            val cy = size.height / 2f
            val top = cy - trackHeight / 2f
            val corner = androidx.compose.ui.geometry.CornerRadius(trackHeight / 2f)
            drawRoundRect(Color(0xAA515B55), Offset(0f, top), Size(size.width, trackHeight), corner)
            if (bufferedFraction > 0f) {
                drawRoundRect(Color(0xFF899C90), Offset(0f, top), Size(size.width * bufferedFraction, trackHeight), corner)
            }
            val p = (dragFraction ?: fill.value).coerceIn(0f, 1f)
            if (p > 0f) {
                drawRoundRect(Accent, Offset(0f, top), Size(size.width * p, trackHeight), corner)
            }
            val thumb = (if (focused) 8.dp else 6.dp).toPx()
            val cx = (size.width * p).coerceIn(thumb, (size.width - thumb).coerceAtLeast(thumb))
            drawCircle(Color(0xFFDEFBE5), thumb, Offset(cx, cy))
            drawCircle(Accent, thumb - 2.dp.toPx(), Offset(cx, cy))
        }
    }
}

@Composable
internal fun CinemaSpinner() {
    val spin = rememberInfiniteTransition(label = "buffering")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(850, easing = LinearEasing)), label = "spin")
    Canvas(Modifier.size(34.dp)) {
        val stroke = 3.5.dp.toPx()
        drawArc(Color(0x665D6574), 0f, 360f, false, topLeft = Offset(stroke, stroke),
            size = Size(size.width - 2f * stroke, size.height - 2f * stroke),
            style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = StrokeCap.Round))
        drawArc(Accent, angle, 105f, false, topLeft = Offset(stroke, stroke),
            size = Size(size.width - 2f * stroke, size.height - 2f * stroke),
            style = androidx.compose.ui.graphics.drawscope.Stroke(stroke, cap = StrokeCap.Round))
    }
}
