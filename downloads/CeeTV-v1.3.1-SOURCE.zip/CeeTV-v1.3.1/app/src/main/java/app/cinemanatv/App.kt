package app.cinemanatv

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import app.cinemanatv.data.Prefs
import app.cinemanatv.data.Repository
import app.cinemanatv.data.CeeNativeCatalog
import app.cinemanatv.data.CeeApiCatalog
import app.cinemanatv.data.CeeHtmlCatalog
import app.cinemanatv.util.Capabilities

/** Tiny service locator – enough for an app this size. */
object Services {
    lateinit var prefs: Prefs
    lateinit var repo: Repository
}

class App : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.12).build() }
        .diskCache {
            DiskCache.Builder()
                .directory(cacheDir.resolve("artwork"))
                .maxSizeBytes(160L * 1024L * 1024L)
                .build()
        }
        .crossfade(false)
        // Artwork URLs often ship no-cache headers; we still want them on disk between launches.
        .respectCacheHeaders(false)
        // Posters are small and opaque: RGB565 halves bitmap memory and speeds up decode.
        .allowRgb565(true)
        .build()

    override fun onCreate() {
        super.onCreate()
        app.cinemanatv.util.CrashReports.install(this)
        app.cinemanatv.util.PerformanceMetrics.appStarted()
        Services.prefs = Prefs(this)
        reloadRepository(this)
        Thread({ runCatching { Capabilities.maxDecodableHeight() } }, "caps-warmup").start()
    }
    companion object {
    fun reloadRepository(context:android.content.Context) {
        val server=Services.prefs.websiteServerUrl
        val namespace=if(server.isBlank())"home" else "hosted-"+java.security.MessageDigest.getInstance("SHA-256").digest(server.toByteArray()).take(8).joinToString(""){"%02x".format(it)}
        Services.repo = Repository(
            if(BuildConfig.NATIVE_PROVIDER) CeeNativeCatalog(language={Services.prefs.interfaceLanguage}) else if(server.isNotBlank()) CeeApiCatalog(server,Services.prefs.websiteServerKey) else CeeHtmlCatalog(),
            context.cacheDir.resolve(if(BuildConfig.NATIVE_PROVIDER) "cee-native-api-home" else namespace),
            cacheNamespace={Services.prefs.interfaceLanguage},
        )
    }
    }
}
