package app.cinemanatv.ui

import app.cinemanatv.data.QualityOption

/** Decoder metadata supplements the provider inventory; one current track must not replace it. */
internal fun playerQualityChoices(
    sources: List<QualityOption>,
    discovered: List<QualityOption>,
    current: QualityOption?,
    trackHeights: List<Int>,
): List<QualityOption> {
    val declared = (sources + discovered).filter { it.height > 0 }
        .sortedByDescending { it.url == current?.url }
    val native = if (current == null) emptyList() else trackHeights.filter { it > 0 }.map {
        current.copy(height = it, name = "${it}p")
    }
    return (declared + native).distinctBy { it.height }.sortedByDescending { it.height }
}

/** Signed URLs and list positions may change on refresh; a manual choice belongs to a resolution. */
internal fun refreshedQualityIndex(previous:QualityOption?,manual:Boolean,options:List<QualityOption>,fallback:Int):Int {
    if(options.isEmpty())return -1
    if(manual && previous!=null) {
        if(previous.height>0) {
            options.indexOfFirst{it.height==previous.height}.takeIf{it>=0}?.let{return it}
            options.withIndex().filter{it.value.height in 1..previous.height}.maxByOrNull{it.value.height}?.let{return it.index}
        } else options.indexOfFirst{it.url==previous.url}.takeIf{it>=0}?.let{return it}
    }
    return fallback.coerceIn(options.indices)
}
