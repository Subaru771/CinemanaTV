package app.cinemanatv.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable internal fun compactLayout():Boolean {
    val config=LocalConfiguration.current
    return config.screenWidthDp<600 && config.uiMode and Configuration.UI_MODE_TYPE_MASK!=Configuration.UI_MODE_TYPE_TELEVISION
}
@Composable internal fun screenGutter()=if(compactLayout())16.dp else 48.dp

internal fun desiredOrientation(smallestWidth:Int,television:Boolean,playing:Boolean):Int =
    if(television || smallestWidth>=600 || playing)ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

private tailrec fun Context.activity():Activity?=when(this){
    is Activity->this
    is ContextWrapper->if(baseContext!==this)baseContext.activity() else null
    else->null
}

/** Browse follows the phone's rotation; playback and TV layouts stay landscape. */
@Composable internal fun PlaybackOrientation(playing:Boolean) {
    val activity=LocalContext.current.activity()
    val config=LocalConfiguration.current
    val orientation=desiredOrientation(config.smallestScreenWidthDp,
        config.uiMode and Configuration.UI_MODE_TYPE_MASK==Configuration.UI_MODE_TYPE_TELEVISION,playing)
    DisposableEffect(activity,orientation) {
        val previous=activity?.requestedOrientation
        if(activity!=null && previous!=orientation)activity.requestedOrientation=orientation
        onDispose {if(activity!=null && previous!=null && activity.requestedOrientation==orientation)activity.requestedOrientation=previous}
    }
}
