package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import app.cinemanatv.Services
import app.cinemanatv.data.CeeApiCatalog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable internal fun HostedProviderSettings() {
    val context=LocalContext.current
    val prefs=Services.prefs
    val scope=rememberCoroutineScope()
    var url by remember{mutableStateOf(prefs.websiteServerUrl)}
    var key by remember{mutableStateOf(prefs.websiteServerKey)}
    var busy by remember{mutableStateOf(false)}
    var status by remember{mutableStateOf("")}
    val ar=LocalInterfaceLanguage.current=="ar"
    fun t(en:String,arabic:String)=if(ar)arabic else en
    fun restart() {
        app.cinemanatv.App.reloadRepository(context)
        context.startActivity(android.content.Intent.makeRestartActivityTask(android.content.ComponentName(context,app.cinemanatv.MainActivity::class.java)))
    }
    Text(if(prefs.websiteServerUrl.isBlank())t("Active: direct website", "الحالي: الموقع مباشرة") else t("Active: hosted website server", "الحالي: خادم الموقع"),color=Color(0xFFB8E986))
    Text(t("Optional HTTPS server. Videos still play from the provider's media hosts. Applying a provider restarts browsing.","خادم HTTPS اختياري. يستمر تشغيل الفيديو من خوادم المصدر. يؤدي تطبيق المصدر إلى إعادة فتح التصفح."),fontSize=14.sp,color=Color.LightGray)
    Text(t("Server URL", "عنوان الخادم"),color=Color.White)
    BasicTextField(url,{url=it},Modifier.fillMaxWidth().testTag("hosted-server-url").background(Color(0xFF13251E),RoundedCornerShape(8.dp)).border(1.dp,Color(0xFF80B96F),RoundedCornerShape(8.dp)).padding(12.dp),textStyle=TextStyle(color=Color.White,fontSize=16.sp),singleLine=true,enabled=!busy)
    Text(t("Server access key", "مفتاح الخادم"),color=Color.White)
    BasicTextField(key,{key=it},Modifier.fillMaxWidth().testTag("hosted-server-key").background(Color(0xFF13251E),RoundedCornerShape(8.dp)).border(1.dp,Color(0xFF80B96F),RoundedCornerShape(8.dp)).padding(12.dp),textStyle=TextStyle(color=Color.White,fontSize=16.sp),singleLine=true,visualTransformation=PasswordVisualTransformation(),enabled=!busy)
    AppButton(if(busy)t("Checking…","جارٍ الفحص…") else t("Test and use server","افحص واستخدم الخادم")) {
        if(!busy)scope.launch {
            busy=true
            try {
                val candidate=url.trim().trimEnd('/')+"/"
                val testedKey=key
                CeeApiCatalog(candidate,testedKey).checkHealth()
                prefs.websiteServerUrl=candidate;prefs.websiteServerKey=testedKey
                restart()
            } catch(c:CancellationException){throw c}
              catch(e:Exception){status=if(e is IllegalArgumentException)t("Enter a valid HTTPS server URL.","أدخل عنوان خادم HTTPS صالحاً.") else e.message ?: t("Server check failed.","فشل فحص الخادم.")}
            finally{busy=false}
        }
    }
    AppButton(t("Use direct website","استخدم الموقع مباشرة")) {
        if(!busy){prefs.websiteServerUrl="";prefs.websiteServerKey="";restart()}
    }
    if(status.isNotBlank())Text(status,color=Color(0xFFFFCC88),fontSize=14.sp)
}
