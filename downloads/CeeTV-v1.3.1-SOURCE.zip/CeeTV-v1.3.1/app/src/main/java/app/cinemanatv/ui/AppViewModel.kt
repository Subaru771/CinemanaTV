package app.cinemanatv.ui

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import android.os.SystemClock
import android.content.Context
import kotlinx.coroutines.delay
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import app.cinemanatv.Services
import app.cinemanatv.data.HomeData
import app.cinemanatv.data.Video
import app.cinemanatv.data.ContentFilterMode
import app.cinemanatv.data.MediaContentFilter
import app.cinemanatv.data.MaturityQueue
import app.cinemanatv.data.SearchFilterState
import app.cinemanatv.data.SearchFacet
import app.cinemanatv.data.MatureSkipAvailability
import app.cinemanatv.data.MatureSkipStatus
import app.cinemanatv.data.EpisodeSceneMarkers
import app.cinemanatv.data.MatureSceneLookupStatus
import app.cinemanatv.data.ExternalSceneMarkers
import app.cinemanatv.data.supportsPublicMatureMarkers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.runtime.mutableStateMapOf
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonParser
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed interface Screen {
    data object Main : Screen
    data class Collection(val section: app.cinemanatv.data.CatalogSection) : Screen
    /** [queue]/[index] are set when the title is one episode picked from a series page. */
    data class Detail(val video: Video, val queue: List<Video>? = null, val index: Int = 0) : Screen
    data class Play(val queue: List<Video>, val index: Int) : Screen
}

class AppViewModel : ViewModel() {
    /** Startup loads the same real HomeData consumed by HomeScreen; no fake assets. */
    var initialCatalogReady by mutableStateOf(false)
        private set

    // Splash has a ~0.65-second minimum and a 1.9-second maximum. Catalog loading
    // continues on the Home screen if the source is slow or unavailable.
    var splashFinished by mutableStateOf(false)
        private set

    var interfaceLanguage by mutableStateOf(Services.prefs.interfaceLanguage)
        private set
    private var catalogueWarmup:kotlinx.coroutines.Job?=null

    fun changeInterfaceLanguage(language: String) {
        val normalized = if (language == "ar") "ar" else "en"
        if(interfaceLanguage==normalized)return
        catalogueWarmup?.cancel()
        val pendingHomes=homeRequests.values.toList();homeRequests.clear()
        pendingHomes.forEach{it.cancel()}
        homeCache.clear();homeFreshAt.clear();collectionStates.clear()
        homeFocus.clear();colStates.clear();rowStates.clear()
        searchResults=null;searchDone=""
        Services.prefs.interfaceLanguage = normalized
        interfaceLanguage = normalized
    }

    var contentFilterMode by mutableStateOf(ContentFilterMode.OFF)
        private set
    var matureAction by mutableStateOf(Services.prefs.matureAction)
        private set

    fun changeMatureAction(value: app.cinemanatv.data.MatureAction, context: Context) {
        if (matureAction == value) return
        matureAction = value
        Services.prefs.matureAction = value
        contentFilterMode = Services.prefs.contentFilterMode
        // Clear launcher recommendations previously published under a different filter.
        app.cinemanatv.util.TvHomeIntegration.enqueueRemoveAll(context.applicationContext)
        if (stack.size > 1) { stack.clear(); stack.add(Screen.Main) }
    }

    fun changeContentFilterMode(value: ContentFilterMode, context: Context) {
        if (contentFilterMode == value) return
        contentFilterMode = value
        Services.prefs.contentFilterMode = value
        // External launcher cards may contain old restricted titles. Remove stale cards.
        app.cinemanatv.util.TvHomeIntegration.enqueueRemoveAll(context.applicationContext)
        if (stack.size > 1) { stack.clear(); stack.add(Screen.Main) }
    }

    var showContinueRow by mutableStateOf(Services.prefs.showContinueRow)
    var showMyListRow by mutableStateOf(Services.prefs.showMyListRow)
    var hideWatchedDiscovery by mutableStateOf(Services.prefs.hideWatchedDiscovery)
    fun updateHomeSections(continueRow: Boolean = showContinueRow, listRow: Boolean = showMyListRow,
                           hideWatched: Boolean = hideWatchedDiscovery) {
        showContinueRow = continueRow; showMyListRow = listRow; hideWatchedDiscovery = hideWatched
        Services.prefs.showContinueRow = continueRow
        Services.prefs.showMyListRow = listRow
        Services.prefs.hideWatchedDiscovery = hideWatched
    }

    // Preserve the Settings category across search opens and page transitions.
    var settingsCategory by androidx.compose.runtime.mutableIntStateOf(0)

    var tab by mutableStateOf(0)
    /** The tab that was showing before the search panel dropped down over it. */
    var lastTab = 0

    // ---- Optional mature-scene marker BADGES (distinct from age/content restrictions) ----
    // These are catalogue indications only. Playback revalidates the stream runtime before skip.
    private val matureSkipStates = mutableStateMapOf<String, MatureSkipStatus>()
    private val matureSkipExpires = mutableMapOf<String, Long>()
    private val matureSkipReasons = mutableStateMapOf<String, String>()
    private val skipLookupSlots = Semaphore(3) // Never flood third-party databases on a TV.
    var skipSearchBusy by mutableStateOf(false)
    /** Identifies the newest search scan so a cancelled older scan can't clear the busy flag. */
    var skipScanToken = 0

    fun skipStatus(video: Video): MatureSkipStatus {
        if (Services.prefs.hasSceneRanges(video.id))
            return MatureSkipStatus.LISTED
        return matureSkipStates[video.id] ?: MatureSkipStatus.UNKNOWN
    }

    fun skipDiagnostic(video: Video): String = matureSkipReasons[video.id] ?: "Mature skip status unknown"

    suspend fun ensureMatureSkip(video: Video) {
        val id = video.id
        if (id.isBlank()) return
        if (Services.prefs.hasSceneRanges(id)) {
            matureSkipStates[id] = MatureSkipStatus.LISTED
            return
        }
        val now = SystemClock.elapsedRealtime()
        if ((matureSkipExpires[id] ?: 0L) > now || matureSkipStates[id] == MatureSkipStatus.CHECKING) return
        skipLookupSlots.withPermit {
            if ((matureSkipExpires[id] ?: 0L) > SystemClock.elapsedRealtime() ||
                matureSkipStates[id] == MatureSkipStatus.CHECKING) return@withPermit
            // The existing mature marker sources are movie-only. Treat series/episode results
            // as unknown instead of inferring a status from the parent title.
            if (video.episodeNumber == 0 && !video.supportsPublicMatureMarkers) {
                matureSkipReasons[id] = "Choose an episode to check mature markers"
                matureSkipStates[id] = MatureSkipStatus.UNKNOWN
                matureSkipExpires[id] = SystemClock.elapsedRealtime() + 30 * 60_000L
                return@withPermit
            }
            matureSkipStates[id] = MatureSkipStatus.CHECKING
            try {
                val details = withTimeoutOrNull(12_000L) { Services.repo.infoOrNull(video,
                    refresh = matureSkipReasons.containsKey(id)) }
                var lookupDetails = details
                var imdb = ExternalSceneMarkers.imdbID(video.imdbRef) ?: ExternalSceneMarkers.imdbID(details?.imdbRef)
                if (video.episodeNumber > 0) {
                    imdb = EpisodeSceneMarkers.seriesImdb(video, details)
                    if (imdb == null) {
                        val root = details?.rootSeries ?: video.rootSeries
                        if (!root.isNullOrBlank() && root != "0") {
                            val parent = Services.repo.infoOrNull(Video(nb = root))
                            lookupDetails = (details ?: video).copy(rootSeriesInfo = parent)
                            imdb = EpisodeSceneMarkers.seriesImdb(video, lookupDetails)
                        }
                    }
                }
                val status = if (imdb == null) MatureSkipStatus.UNKNOWN else if (video.episodeNumber > 0) {
                    val result = withTimeoutOrNull(40_000L) {
                        EpisodeSceneMarkers.load(imdb, video.seasonNumber, video.episodeNumber, 21_600_000L,
                            EpisodeSceneMarkers.seriesTitle(video, lookupDetails))
                    }
                    when (result?.status) {
                        MatureSceneLookupStatus.READY -> MatureSkipStatus.LISTED
                        MatureSceneLookupStatus.NO_MARKERS -> MatureSkipStatus.NOT_LISTED
                        else -> MatureSkipStatus.UNKNOWN
                    }
                } else withTimeoutOrNull(45_000L) {
                    val primary = MatureSkipAvailability.check(imdb)
                    if (primary == MatureSkipStatus.LISTED) primary else {
                        val fallback = EpisodeSceneMarkers.load(imdb, 0, 0, 21_600_000L, video.title)
                        when (fallback.status) {
                            MatureSceneLookupStatus.READY -> MatureSkipStatus.LISTED
                            MatureSceneLookupStatus.NO_MARKERS -> if (primary == MatureSkipStatus.NOT_LISTED)
                                MatureSkipStatus.NOT_LISTED else MatureSkipStatus.UNKNOWN
                            else -> MatureSkipStatus.UNKNOWN
                        }
                    }
                } ?: MatureSkipStatus.UNKNOWN
                matureSkipReasons[id] = when {
                    imdb == null -> "Mature skip unavailable · IMDb ID missing; retrying"
                    status == MatureSkipStatus.UNKNOWN -> "Mature marker service unreachable · retrying"
                    else -> "Mature skip status unknown"
                }
                matureSkipStates[id] = status
                matureSkipExpires[id] = SystemClock.elapsedRealtime() + when (status) {
                    MatureSkipStatus.LISTED -> 45 * 60_000L
                    MatureSkipStatus.NOT_LISTED -> 10 * 60_000L
                    else -> 30_000L
                }
            } catch (c: CancellationException) {
                matureSkipStates.remove(id)
                throw c
            } catch (_: Exception) {
                matureSkipStates[id] = MatureSkipStatus.UNKNOWN
                matureSkipReasons[id] = "Mature marker service unreachable · retrying"
                matureSkipExpires[id] = SystemClock.elapsedRealtime() + 30_000L
            }
        }
    }

    suspend fun checkSearchMatureSkip(items: List<Video>) = coroutineScope {
        // The Search filter checks the FULL returned list. Unchecked rows must not be
        // misrepresented as negative results while this progressive scan runs.
        for (group in items.distinctBy { it.id }.chunked(3)) {
            coroutineScope { group.map { video -> async { ensureMatureSkip(video) } }.awaitAll() }
        }
    }

    // ---- Mature-content filter -------------------------------------------------------------
    // Catalog list payloads usually carry no age certificate or genre tags, so a filter that
    // only looks at list items lets everything through. Titles are therefore resolved once via
    // their detail record (cached on disk) and hidden until that check finishes.
    private val maturityMeta = mutableStateMapOf<String, Video>()
    private val gson = Gson()

    private fun hasMeta(v: Video) = v.filmRating != null || v.categories != null || v.adult != null

    private fun loadStoredMeta(id: String): Video? = runCatching {
        val o = JsonParser.parseString(Services.prefs.maturityCached(id) ?: return null).asJsonObject
        Video(
            nb = id,
            filmRating = o.get("r")?.takeIf { it.isJsonPrimitive }?.asString,
            categories = o.get("c")?.takeIf { !it.isJsonNull },
            adult = o.get("a")?.takeIf { !it.isJsonNull },
        )
    }.getOrNull()

    private fun storeMeta(v: Video) {
        val o = com.google.gson.JsonObject()
        v.filmRating?.let { o.addProperty("r", it) }
        v.categories?.let { o.add("c", it) }
        v.adult?.let { o.add("a", it) }
        Services.prefs.maturityStore(v.id, gson.toJson(o))
    }

    /** The video with any resolved certificate / genre / adult metadata merged in. */
    fun resolve(v: Video): Video {
        val m = maturityMeta[v.id] ?: return v
        return v.copy(
            filmRating = v.filmRating ?: m.filmRating,
            categories = v.categories ?: m.categories,
            adult = v.adult ?: m.adult,
        )
    }

    /** Applies the content setting. Unchecked titles stay hidden until resolveMaturity() has run. */
    fun visible(items: List<Video>, parent: Video? = null): List<Video> {
        if (contentFilterMode == ContentFilterMode.OFF) return items
        return items.map(::resolve).filter { isVerifiedAllowed(it, parent) }
    }

    private fun isVerifiedAllowed(video: Video, parent: Video? = null): Boolean {
        if (contentFilterMode == ContentFilterMode.OFF) return true
        val resolved = resolve(video)
        val inherited = parent ?: resolved.rootSeriesInfo
        val hasCertificateOrTags = hasMeta(resolved) ||
            maturityMeta.containsKey(resolved.id) || (inherited != null && hasMeta(inherited))
        return hasCertificateOrTags && MediaContentFilter.allowed(resolved, contentFilterMode, parent)
    }

    var maturityBusy by mutableStateOf(false)
        private set

    // Search, Home and Downloads can ask for ratings at the same time.
    // Serialize lookups and skip IDs resolved by earlier callers.
    private val maturityLookupMutex = Mutex()

    suspend fun resolveMaturity(items: List<Video>) {
        if (contentFilterMode == ContentFilterMode.OFF || items.isEmpty()) return
        maturityLookupMutex.withLock {
            if (contentFilterMode == ContentFilterMode.OFF) return@withLock
            // No 160-title cap. Keep the user's complete currently loaded list eligible for
            // classification; process in small batches so TV UIs stay responsive.
            val todo = MaturityQueue.pending(items, { it.id }, { hasMeta(it) }) {
                maturityMeta.containsKey(it)
            }
            if (todo.isEmpty()) return@withLock
            maturityBusy = true
            try {
                val missing = ArrayList<Video>()
                todo.forEach { v ->
                    val cached = loadStoredMeta(v.id)
                    if (cached != null) maturityMeta[v.id] = cached else missing.add(v)
                }
                var consecutiveFailedBatches = 0
                for (chunk in missing.chunked(4)) {
                    if (contentFilterMode == ContentFilterMode.OFF) break
                    val resolved = coroutineScope {
                        chunk.map { v -> async {
                            // infoOrNull distinguishes a failed network request from a valid
                            // detail response with no certificate. Cancellation is propagated.
                            v to withTimeoutOrNull(9_000L) { Services.repo.infoOrNull(v) }
                        } }.awaitAll()
                    }
                    var successes = 0
                    resolved.forEach { (v, info) ->
                        if (info == null) return@forEach // fail closed; retry on a future visit
                        successes++
                        val meta = Video(nb = v.id, filmRating = info.filmRating,
                            categories = info.categories, adult = info.adult)
                        if (hasMeta(meta)) storeMeta(meta)
                        maturityMeta[v.id] = meta
                    }
                    // Don't hammer the provider through a large catalog if it has gone down.
                    // Unresolved titles remain hidden and can be retried later.
                    consecutiveFailedBatches = if (successes == 0) consecutiveFailedBatches + 1 else 0
                    if (consecutiveFailedBatches >= 2) break
                }
            } finally {
                maturityBusy = false
            }
        }
    }
    val stack = mutableStateListOf<Screen>(Screen.Main)
    val homeCache = mutableMapOf<Int, HomeData>() // key: 0 = all, 1 = movies, 2 = series
    private val homeRequests=mutableMapOf<Int,kotlinx.coroutines.Deferred<HomeData>>()
    /** Splash warm-up and Home share one request owned by the ViewModel. */
    suspend fun loadHome(kind:Int?,force:Boolean=false):HomeData = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main.immediate) {
        val key=kind ?: 0
        if(!force)homeCache[key]?.takeIf{isHomeFresh(key)}?.let{return@withContext it}
        val language=interfaceLanguage
        val deferred=homeRequests[key]?.takeUnless{it.isCompleted} ?: viewModelScope.async(start=kotlinx.coroutines.CoroutineStart.LAZY) {
            Services.repo.loadHome(kind).also { data ->
                if(language==interfaceLanguage){homeCache[key]=data;markHomeFresh(key)}
            }
        }.also{homeRequests[key]=it}
        try{deferred.await()}finally{if(deferred.isCompleted && homeRequests[key]===deferred)homeRequests.remove(key)}
    }
    /** When each cached catalog was last confirmed by the network (elapsed ms), by key. */
    val homeFreshAt = mutableMapOf<Int, Long>()
    fun isHomeFresh(key: Int): Boolean =
        homeFreshAt[key]?.let { android.os.SystemClock.elapsedRealtime() - it < 10 * 60_000L } == true
    fun markHomeFresh(key: Int) { homeFreshAt[key] = android.os.SystemClock.elapsedRealtime() }

    init {
        viewModelScope.launch {
            val startedAt = SystemClock.elapsedRealtime()
            while (!initialCatalogReady && SystemClock.elapsedRealtime() - startedAt < 1_900L) {
                delay(50L)
            }
            val remaining = 1_100L - (SystemClock.elapsedRealtime() - startedAt)
            if (remaining > 0) delay(remaining)
            splashFinished = true
        }
        catalogueWarmup=viewModelScope.launch {
            try {
                // 1) Last session's catalog is on disk: show it immediately. HomeScreen then
                //    refreshes it in the background (stale-while-revalidate).
                val cached = Services.repo.cachedHome(null)
                if (cached != null) {
                    homeCache[0] = cached
                    initialCatalogReady = true
                } else {
                    // 2) First run: try to warm data, but never hold the splash over 2 seconds.
                    withTimeoutOrNull(1_900L) {
                        val result = loadHome(null)
                        if (result.rows.isNotEmpty()) { homeCache[0] = result; markHomeFresh(0) }
                    }
                }
            } catch (c: CancellationException) { throw c }
              catch (_: Exception) { /* Home screen owns retry and diagnostics */ }
            finally {
                initialCatalogReady = true
                app.cinemanatv.util.PerformanceMetrics.catalogReady()
            }
        }
    }


    // UI state that must survive opening a title and coming back (scroll position, focus, search).
    val homeFocus = mutableMapOf<Int, Pair<String, Int>>() // key -> (row title, column)
    private val colStates = mutableMapOf<Int, LazyListState>()
    private val rowStates = mutableMapOf<String, LazyListState>()
    fun colState(key: Int) = colStates.getOrPut(key) { LazyListState() }
    fun rowState(key: Int, row: String) = rowStates.getOrPut("$key:$row") { LazyListState() }
    var searchQuery by mutableStateOf("")
    var searchDone by mutableStateOf("")           // the query `searchResults` belongs to
    var searchResults by mutableStateOf<List<Video>?>(null)
    val searchGrid = LazyGridState()
    private val collectionStates=mutableMapOf<String,CollectionUiState>()
    fun collectionState(key:String)=collectionStates.getOrPut(key){CollectionUiState()}
    // Kept in ViewModel so filters survive opening a title and pressing Back.
    var searchFilters by mutableStateOf(SearchFilterState())
    var searchFiltersOpen by mutableStateOf(false)
    var searchFacet by mutableStateOf<SearchFacet?>(null)

    fun push(s: Screen) {
        when (s) {
            Screen.Main -> stack.add(s)
            is Screen.Collection -> stack.add(s)
            is Screen.Detail -> if (isVerifiedAllowed(s.video)) stack.add(s)
            is Screen.Play -> {
                val selected = s.queue.getOrNull(s.index) ?: return
                if (!isVerifiedAllowed(selected)) return
                val allowedQueue = s.queue.map(::resolve).filter { isVerifiedAllowed(it) }
                val nextIndex = allowedQueue.indexOfFirst { it.id == selected.id }
                if (nextIndex >= 0) stack.add(Screen.Play(allowedQueue, nextIndex))
            }
        }
    }
    fun pop(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.lastIndex); return true
    }
}
