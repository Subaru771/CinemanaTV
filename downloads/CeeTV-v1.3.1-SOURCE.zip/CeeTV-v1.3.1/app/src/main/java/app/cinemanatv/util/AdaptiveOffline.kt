@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package app.cinemanatv.util

import android.app.Notification
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.NoOpCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.offline.Download
import androidx.media3.exoplayer.offline.DefaultDownloadIndex
import androidx.media3.exoplayer.offline.DownloadHelper
import androidx.media3.exoplayer.offline.DownloadManager
import androidx.media3.exoplayer.offline.DownloadNotificationHelper
import androidx.media3.exoplayer.offline.DownloadService
import androidx.media3.exoplayer.scheduler.Scheduler
import androidx.media3.exoplayer.offline.DownloadRequest
import androidx.media3.exoplayer.offline.DownloadHelper.Callback
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.DataSource
import app.cinemanatv.R
import app.cinemanatv.data.QualityOption
import app.cinemanatv.data.userAgent
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.Executor
import kotlin.coroutines.resume

/** Singleton cache + download index. Segmented HLS/DASH data stays in private device storage. */
object AdaptiveOffline {
    @Volatile private var cached: SimpleCache? = null
    @Volatile private var managed: DownloadManager? = null
    private val guard = Any()
    private val upstream = DefaultHttpDataSource.Factory().setUserAgent(userAgent())
    @Volatile private var database: StandaloneDatabaseProvider? = null
    private fun db(ctx: Context): StandaloneDatabaseProvider = synchronized(guard) {
        database ?: StandaloneDatabaseProvider(ctx.applicationContext).also { database = it }
    }

    fun cache(ctx: Context): SimpleCache = synchronized(guard) {
        cached ?: SimpleCache(File(ctx.applicationContext.filesDir, "offline_segments"),
            NoOpCacheEvictor(), db(ctx)).also { cached = it }
    }

    fun manager(ctx: Context): DownloadManager = synchronized(guard) {
        managed ?: DownloadManager(ctx.applicationContext,
            db(ctx), cache(ctx), upstream,
            Executor { work -> work.run() }).also {
                it.maxParallelDownloads = 2
                it.requirements = androidx.media3.exoplayer.scheduler.Requirements(
                    if (app.cinemanatv.Services.prefs.downloadUnmeteredOnly)
                        androidx.media3.exoplayer.scheduler.Requirements.NETWORK_UNMETERED
                    else androidx.media3.exoplayer.scheduler.Requirements.NETWORK
                )
                managed = it
            }
    }

    fun entry(ctx: Context, id: String): Download? = runCatching {
        DefaultDownloadIndex(db(ctx)).getDownload(id)
    }.getOrNull()

    fun completed(ctx: Context, id: String): MediaItem? = entry(ctx, id)
        ?.takeIf { it.state == Download.STATE_COMPLETED }
        ?.request?.toMediaItem()

    fun playbackSource(ctx: Context): DataSource.Factory = CacheDataSource.Factory()
        .setCache(cache(ctx))
        .setUpstreamDataSourceFactory(upstream)
        .setCacheWriteDataSinkFactory(null)

    fun remove(ctx: Context, id: String) {
        DownloadService.sendRemoveDownload(ctx, CinemanaDownloadService::class.java, id, false)
    }

    fun setUnmetered(ctx: Context, enabled: Boolean) {
        // Media3 requirements apply to all adaptive downloads managed by the app.
        val requirements = androidx.media3.exoplayer.scheduler.Requirements(
            if (enabled) androidx.media3.exoplayer.scheduler.Requirements.NETWORK_UNMETERED
            else androidx.media3.exoplayer.scheduler.Requirements.NETWORK
        )
        manager(ctx).requirements = requirements
    }

    suspend fun queue(ctx: Context, id: String, quality: QualityOption, unmeteredOnly: Boolean): String? {
        if (!quality.adaptive) return "Not a supported HLS/DASH playlist."
        val mime = quality.mimeType ?: if (quality.url.substringBefore('?').endsWith(".mpd", true))
            MimeTypes.APPLICATION_MPD else MimeTypes.APPLICATION_M3U8
        return try { withTimeoutOrNull(20_000L) { withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { continuation ->
            val item = MediaItem.Builder().setMediaId(id).setUri(Uri.parse(quality.url)).setMimeType(mime).build()
            val helper = DownloadHelper.Factory()
                .setRenderersFactory(DefaultRenderersFactory(ctx))
                .setDataSourceFactory(upstream)
                .create(item)
            val released=AtomicBoolean(false)
            fun releaseHelper(){
                if(released.compareAndSet(false,true)) {
                    if(Looper.myLooper()==Looper.getMainLooper())helper.release()
                    else Handler(Looper.getMainLooper()).post{helper.release()}
                }
            }
            continuation.invokeOnCancellation { releaseHelper() }
            try {
                helper.prepare(object : Callback {
                    override fun onPrepared(prepared: DownloadHelper, tracksInfoAvailable: Boolean) {
                        if(!continuation.isActive){releaseHelper();return}
                        try {
                            // Media3 1.8.1 exposes whether preparation yielded track information.
                            // Never apply resolution selections if tracks are unavailable.
                            if (!tracksInfoAvailable) {
                                if (continuation.isActive) continuation.resume(
                                    "The provider did not return downloadable track information.")
                                return
                            }
                            // Cap the selected video track at the requested provider resolution.
                            val params = TrackSelectionParameters.Builder(ctx)
                                .setMaxVideoSize(Int.MAX_VALUE, quality.height.takeIf { it > 0 } ?:
                                    app.cinemanatv.Services.prefs.maxQuality.takeIf { it > 0 } ?: 1080)
                                .setForceHighestSupportedBitrate(true).build()
                            for (period in 0 until prepared.periodCount) {
                                val exact=offlineVideoQuality(prepared.getTracks(period),quality.height)
                                prepared.replaceTrackSelections(period,if(exact==null)params else params.buildUpon().setOverrideForType(exact).build())
                            }
                            val request: DownloadRequest = prepared.getDownloadRequest(id, null)
                            if(!continuation.isActive)return
                            setUnmetered(ctx, unmeteredOnly)
                            DownloadService.sendAddDownload(ctx, CinemanaDownloadService::class.java, request, true)
                            if (continuation.isActive) continuation.resume(null)
                        } catch (e: Exception) {
                            if (continuation.isActive) continuation.resume(
                                    if(e is OfflineQualityUnavailable)e.message else "Could not prepare offline playlist: ${e.javaClass.simpleName}")
                        } finally { releaseHelper() }
                    }
                    override fun onPrepareError(prepared: DownloadHelper, error: IOException) {
                        releaseHelper()
                        if (continuation.isActive) continuation.resume(
                            "The provider playlist could not be prepared for offline download.")
                    }
                })
            } catch (e: Exception) {
                releaseHelper()
                if (continuation.isActive) continuation.resume("Could not start playlist download.")
            }
            }
        }} ?: "Preparing the download timed out. Please retry."
        }catch(cancel:CancellationException){throw cancel}
         catch(_:Exception){"Could not prepare this stream for offline download."}
         catch(_:LinkageError){"Offline playback is unavailable on this device."}
    }
}

/** Media3 downloads continue while the viewer browses or the app is backgrounded. */
class CinemanaDownloadService : DownloadService(
    1102,
    DEFAULT_FOREGROUND_NOTIFICATION_UPDATE_INTERVAL,
    "cinemana_offline",
    R.string.app_name,
    0,
) {
    private val notifier by lazy { DownloadNotificationHelper(this, "cinemana_offline") }
    override fun getDownloadManager(): DownloadManager = AdaptiveOffline.manager(this)
    override fun getScheduler(): Scheduler? = null
    override fun getForegroundNotification(downloads: MutableList<Download>, notMetRequirements: Int): Notification =
        notifier.buildProgressNotification(this, R.drawable.ic_launcher_foreground, null,
            "Cee TV offline downloads", downloads, notMetRequirements)
}
