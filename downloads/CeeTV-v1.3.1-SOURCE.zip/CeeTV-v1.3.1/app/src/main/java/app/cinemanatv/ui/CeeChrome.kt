package app.cinemanatv.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.type
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.tv.material3.*
import app.cinemanatv.ui.TouchSurface as Surface
import app.cinemanatv.R

internal val LocalNavigationRailFocused=compositionLocalOf{false}
internal val LocalChromeFocusGeneration=compositionLocalOf{0}
internal val LocalChromeInputGeneration=compositionLocalOf{0}
private data class Destination(val tab:Int,val title:String,val icon:ImageVector)
private val destinations=listOf(
    Destination(0,"Home",Icons.Default.Home),Destination(1,"Series",Icons.Default.List),
    Destination(2,"Movies",Icons.Default.PlayArrow),Destination(3,"Search",Icons.Default.Search),
    Destination(4,"History",Icons.Default.DateRange),Destination(5,"My List",Icons.Default.Favorite),
    Destination(6,"Downloads",Icons.Default.KeyboardArrowDown),Destination(7,"Settings",Icons.Default.Settings),
)

/** Fixed-width rail: navigation never pushes the content around or covers another focus target. */
@Composable
internal fun CeeScaffold(vm:AppViewModel,content:@Composable ()->Unit) {
    if(compactLayout()){CompactScaffold(vm,content);return}
    var navigationFocused by remember{mutableStateOf(false)}
    var focusGeneration by remember{mutableIntStateOf(0)}
    var inputGeneration by remember{mutableIntStateOf(0)}
    Row(Modifier.fillMaxSize().onPreviewKeyEvent{if(it.type==KeyEventType.KeyDown)inputGeneration++;false}) {
        Column(Modifier.width(92.dp).fillMaxHeight().background(Color(0xFF101B15))
            .onFocusChanged{navigationFocused=it.hasFocus}.focusGroup()
            .verticalScroll(rememberScrollState()).padding(horizontal=8.dp,vertical=14.dp),
            horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(5.dp)) {
            Image(painterResource(R.drawable.cee_mark),contentDescription="Cee TV",modifier=Modifier.size(34.dp))
            Text("Cee TV",fontSize=12.sp,fontWeight=FontWeight.Bold,color=C.Accent)
            Spacer(Modifier.height(10.dp))
            destinations.forEach { destination ->
                if(destination.tab==4 || destination.tab==7)Spacer(Modifier.height(8.dp))
                val selected=vm.tab==destination.tab
                var entryFocused by remember(destination.tab){mutableStateOf(false)}
                Surface(onClick={
                    if(destination.tab==3){if(vm.tab==3)vm.tab=vm.lastTab else{vm.lastTab=vm.tab;vm.tab=3}}
                    else vm.tab=destination.tab
                },modifier=Modifier.fillMaxWidth().height(54.dp).onFocusChanged{
                        if(entryFocused!=it.hasFocus){entryFocused=it.hasFocus;if(it.hasFocus)focusGeneration++}
                    },
                    shape=ClickableSurfaceDefaults.shape(RoundedCornerShape(13.dp)),
                    colors=ClickableSurfaceDefaults.colors(
                        containerColor=if(selected)C.Accent else Color.Transparent,
                        contentColor=if(selected)Color(0xFF10200C) else C.Dim,
                        focusedContainerColor=if(selected)C.Accent else Color(0xFF2C4431),
                        focusedContentColor=if(selected)Color(0xFF10200C) else Color.White),
                    scale=ClickableSurfaceDefaults.scale(focusedScale=1f),
                    border=ClickableSurfaceDefaults.border(focusedBorder=Border(BorderStroke(1.5.dp,C.Accent),shape=RoundedCornerShape(13.dp)))) {
                    Column(Modifier.fillMaxSize().padding(vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                        Icon(destination.icon,contentDescription=null,modifier=Modifier.size(21.dp))
                        Spacer(Modifier.height(3.dp))
                        Text(t(destination.title),fontSize=11.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().height(60.dp).padding(horizontal=32.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                Text(t(if(vm.tab==0)"Discover" else destinations.firstOrNull{it.tab==vm.tab}?.title ?: "Home"),fontSize=23.sp,fontWeight=FontWeight.Bold)
                AppButton(if(vm.tab==3)"Close" else "Search",icon=if(vm.tab==3)Icons.Default.Close else Icons.Default.Search,onFocused={focusGeneration++}) {
                    if(vm.tab==3)vm.tab=vm.lastTab else{vm.lastTab=vm.tab;vm.tab=3}
                }
            }
            CompositionLocalProvider(LocalNavigationRailFocused provides navigationFocused,LocalChromeFocusGeneration provides focusGeneration,LocalChromeInputGeneration provides inputGeneration) {
                Box(Modifier.weight(1f).fillMaxWidth()){content()}
            }
        }
    }
}

@Composable private fun CompactScaffold(vm:AppViewModel,content:@Composable ()->Unit) {
    var navigationFocused by remember{mutableStateOf(false)}
    var focusGeneration by remember{mutableIntStateOf(0)}
    var inputGeneration by remember{mutableIntStateOf(0)}
    val navigation=rememberLazyListState()
    LaunchedEffect(vm.tab) {
        val selected=destinations.indexOfFirst{it.tab==vm.tab}
        if(selected>=0 && navigation.layoutInfo.visibleItemsInfo.none{it.index==selected})navigation.animateScrollToItem(selected)
    }
    fun select(tab:Int) {
        if(tab==3){if(vm.tab==3)vm.tab=vm.lastTab else{vm.lastTab=vm.tab;vm.tab=3}}else vm.tab=tab
    }
    Column(Modifier.fillMaxSize().onPreviewKeyEvent{if(it.type==KeyEventType.KeyDown)inputGeneration++;false}) {
        Row(Modifier.fillMaxWidth().heightIn(min=58.dp).padding(horizontal=16.dp,vertical=7.dp),
            verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            Image(painterResource(R.drawable.cee_mark),contentDescription="Cee TV",modifier=Modifier.size(28.dp))
            Text(t(if(vm.tab==0)"Discover" else destinations.firstOrNull{it.tab==vm.tab}?.title ?: "Home"),
                modifier=Modifier.weight(1f),fontSize=20.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
            AppButton(if(vm.tab==3)"Close" else "Search",showFocusChevron=false){select(3)}
        }
        CompositionLocalProvider(LocalNavigationRailFocused provides navigationFocused,
            LocalChromeFocusGeneration provides focusGeneration,LocalChromeInputGeneration provides inputGeneration) {
            Box(Modifier.weight(1f).fillMaxWidth()){content()}
        }
        LazyRow(Modifier.fillMaxWidth().testTag("phone-navigation").background(Color(0xFF101B15)).onFocusChanged{navigationFocused=it.hasFocus}.focusGroup(),
            state=navigation,contentPadding=PaddingValues(8.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            items(destinations,key={it.tab}){destination ->
                val selected=vm.tab==destination.tab
                Surface(onClick={select(destination.tab)},modifier=Modifier.width(82.dp).height(56.dp).onFocusChanged{if(it.hasFocus)focusGeneration++},
                    shape=ClickableSurfaceDefaults.shape(RoundedCornerShape(12.dp)),scale=ClickableSurfaceDefaults.scale(focusedScale=1f),
                    colors=ClickableSurfaceDefaults.colors(containerColor=if(selected)C.Accent else Color.Transparent,
                        contentColor=if(selected)Color(0xFF10200C) else C.Dim,
                        focusedContainerColor=if(selected)C.Accent else Color(0xFF2C4431),
                        focusedContentColor=if(selected)Color(0xFF10200C) else Color.White)) {
                    Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
                        Icon(destination.icon,contentDescription=null,modifier=Modifier.size(21.dp))
                        Text(t(destination.title),fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
