package app.cinemanatv.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/** Keep every declared quality, including qualities offered by a different server. */
internal object QualityInventory {
    suspend fun expand(
        options: List<QualityOption>,
        findHeights: suspend (QualityOption) -> List<Int>,
        onOptions: suspend (List<QualityOption>) -> Unit = {},
    ): List<QualityOption> = coroutineScope {
        val found = options.toMutableList()
        val lock = Mutex()
        onOptions(found.toList())
        options.filter { it.adaptive && it.height == 0 }.distinctBy { it.url }.take(3).map { option ->
            async {
                val heights = try {
                    withTimeoutOrNull(14_000) { findHeights(option) }.orEmpty()
                } catch (cancel: CancellationException) { throw cancel }
                  catch (_: Exception) { emptyList() }
                if (heights.isNotEmpty()) lock.withLock {
                    // Retain the master URL: a child playlist may omit separate audio/subtitles.
                    found.addAll(heights.filter { it in 144..8640 }.distinct().map {
                        option.copy(height = it, name = "${it}p")
                    })
                    onOptions(found.distinctBy { it.url to it.height })
                }
            }
        }.awaitAll()
        found.distinctBy { it.url to it.height }
    }
}
