package app.cinemanatv.data

import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Hosted website adapter. Website IDs are preserved; native API IDs never enter this path. */
class CeeApiCatalog(baseUrl:String, private val apiKey:String?=null, allowLocalHttp:Boolean=false) : CeeCatalog {
    private val base=baseUrl.toHttpUrl().also {
        require(it.username.isEmpty() && it.password.isEmpty() && it.query==null && it.fragment==null &&
            (it.scheme=="https" || (allowLocalHttp && it.host in setOf("localhost","127.0.0.1","::1")))) { "Use an HTTPS server URL without credentials, query or fragment." }
    }
    private val gson=Gson()
    private val client=OkHttpClient.Builder().followRedirects(false).followSslRedirects(false)
        .connectTimeout(10,TimeUnit.SECONDS).readTimeout(35,TimeUnit.SECONDS).callTimeout(38,TimeUnit.SECONDS).build()
    private suspend fun get(path:String,params:Map<String,String> = emptyMap(),body:Any?=null):String {
        val url=base.newBuilder().addPathSegments(path.trimStart('/')).apply {params.forEach{(k,v)->addQueryParameter(k,v)}}.build()
        val request=Request.Builder().url(url).header("Accept","application/json").apply {
            if(!apiKey.isNullOrBlank())header("x-api-key",apiKey)
            if(body!=null)post(gson.toJson(body).toRequestBody("application/json".toMediaType()))
        }.build()
        return CancellableHttp.read(client,request) { response ->
            val source=response.body?.source() ?: throw IOException("Server returned an empty response.")
            if(source.request(2_000_001))throw IOException("Server response exceeded the size limit.")
            val text=source.readUtf8()
            if(!response.isSuccessful)throw IOException(when(response.code){401->"The server rejected its access key.";429->"Server request limit reached. Retry shortly.";else->"Catalogue server unavailable (HTTP ${response.code})."})
            val json=runCatching{JsonParser.parseString(text)}.getOrNull()
            if(json==null || !json.isJsonObject)throw IOException("The server did not return catalogue JSON.")
            text
        }
    }
    suspend fun checkHealth() {
        val root=JsonParser.parseString(get("api/health")).asJsonObject
        if(root.get("schema")?.asInt!=1 || root.get("provider")?.asString!="cee-website" || root.get("ok")?.asBoolean!=true)
            throw IOException("This address is not a compatible Cee TV website server.")
    }
    private fun postId(v:Video)=CeeCatalogParser.postId(v)
    private fun identity(id:String):String=id.removePrefix("cee_").also{require(it.matches(Regex("[0-9]{1,12}"))){"Invalid website title ID."}}
    private data class Home(val featured:List<Video> = emptyList(),val rows:List<ContentRow> = emptyList())
    private data class Results(val results:List<Video> = emptyList())
    private data class Episodes(val episodes:List<Video> = emptyList(),val cursors:List<EpisodeCursor> = emptyList())
    private data class Sources(val qualities:List<QualityOption> = emptyList(),val vkPlayerUrl:String?=null)
    private data class Subs(val subtitles:List<SubtitleOption> = emptyList())
    override suspend fun home(kind:Int?):HomeData {
        val data=gson.fromJson(get("api/home",kind?.let{mapOf("kind" to it.toString())} ?: emptyMap()),Home::class.java)
        if(data.rows.isEmpty())throw IOException("The server returned no catalogue rows.")
        return HomeData(data.featured,data.rows)
    }
    override suspend fun browse(section:CatalogSection,page:Int):List<Video> {
        require(page in 1..10000 && section.categoryId!=null)
        return gson.fromJson(get("api/browse",buildMap{put("category",section.categoryId.toString());put("page",page.toString());section.kind?.let{put("kind",it.toString())}}),Results::class.java).results
    }
    override suspend fun search(query:String)=gson.fromJson(get("api/search",mapOf("q" to query.take(250))),Results::class.java).results
    override suspend fun detail(video:Video):Video {
        val result=gson.fromJson(get("api/detail/${postId(video)}",mapOf("title" to video.title,"kind" to (video.kind ?: "1"))),Video::class.java)
        return video.copy(nb=video.id,
            kind=result.kind ?: video.kind,
            enTitle=result.enTitle?.takeIf{it.isNotBlank()} ?: video.enTitle, arTitle=result.arTitle ?: video.arTitle,
            enContent=result.enContent?.takeIf{it.isNotBlank()} ?: video.enContent, arContent=result.arContent ?: video.arContent,
            year=result.year ?: video.year, stars=result.stars ?: video.stars, filmRating=result.filmRating ?: video.filmRating,
            img=result.img ?: video.img, imgObjUrl=result.imgObjUrl ?: video.imgObjUrl,
            imgThumbObjUrl=result.imgThumbObjUrl ?: video.imgThumbObjUrl,
            imgMediumThumbObjUrl=result.imgMediumThumbObjUrl ?: video.imgMediumThumbObjUrl,
            categories=result.categories ?: video.categories, imdbRef=result.imdbRef ?: video.imdbRef,
            adult=result.adult ?: video.adult,
            introStart=result.introStart ?: video.introStart,introEnd=result.introEnd ?: video.introEnd,
            introStartMs=result.introStartMs ?: video.introStartMs,introEndMs=result.introEndMs ?: video.introEndMs,
            season=result.season ?: video.season, episodeNummer=result.episodeNummer ?: video.episodeNummer,
            providerPageId=result.providerPageId ?: video.providerPageId,
            rootSeries=video.rootSeries ?: result.rootSeries,rootSeriesInfo=video.rootSeriesInfo ?: result.rootSeriesInfo)
    }
    override suspend fun episodes(video:Video)=episodePage(video).videos
    override suspend fun episodePage(video:Video,cursors:List<EpisodeCursor>?):EpisodeBatch = withTimeout(38_000L) {
        if(cursors==null) {
            val result=gson.fromJson(get("api/episodes/${postId(video)}",mapOf("title" to video.title)),Episodes::class.java)
            EpisodeBatch(chronologicalEpisodes(result.episodes.map{it.copy(rootSeries=video.id,rootSeriesInfo=video)}),result.cursors)
        } else coroutineScope {
            val slots=Semaphore(3)
            val chunks=cursors.take(40).map{cursor->async{slots.withPermit {
                val data=gson.fromJson(get("api/episodes/${postId(video)}/more",mapOf("seasonId" to cursor.seasonId,"page" to cursor.page.toString(),"currentPostId" to cursor.currentPostId,"season" to cursor.season.toString(),"title" to video.title)),Episodes::class.java)
                data.episodes.map{it.copy(rootSeries=video.id,rootSeriesInfo=video)} to cursor.takeIf{data.episodes.isNotEmpty() && it.page<1000}?.copy(page=cursor.page+1)
            }}}.awaitAll()
            EpisodeBatch(chronologicalEpisodes(chunks.flatMap{it.first}.distinctBy{it.id}),chunks.mapNotNull{it.second})
        }
    }
    override suspend fun related(video:Video)=gson.fromJson(get("api/related/${postId(video)}"),Results::class.java).results.filter{it.id!=video.id}
    override suspend fun sources(id:String)=sources(id,emptySet())
    override suspend fun sources(id:String,rejected:Set<String>):PlaySources {
        val result=gson.fromJson(get("api/sources/${identity(id)}",body=mapOf("rejected" to rejected.take(24))),Sources::class.java)
        val accepted=result.qualities.filter{q->q.url !in rejected && q.height in 0..8640 && q.url.toHttpUrlOrNull()?.let{CeeAlternativeSource.allowedMedia(it)}==true}.distinctBy{it.url to it.height}
        val valid=accepted.filter{q->!q.adaptive || q.mimeType.equals("application/dash+xml",true) || q.url.substringBefore('?').endsWith(".mpd",true) || HlsManifest.readable(q.url)}
        val vk=result.vkPlayerUrl?.takeIf(CeeAlternativeSource::isVkPlayer)
        if(valid.isEmpty() && vk==null)throw IOException("No reachable provider stream was returned. Try another title or route.")
        return PlaySources(valid,emptyList(),if(valid.isEmpty())vk else null)
    }
    override suspend fun subtitles(id:String)=gson.fromJson(get("api/subtitles/${identity(id)}"),Subs::class.java).subtitles.filter {
        it.url.toHttpUrlOrNull()?.let{u->u.scheme=="https" && u.username.isEmpty() && u.password.isEmpty()}==true && it.mime in setOf("text/vtt","application/x-subrip")
    }
}
