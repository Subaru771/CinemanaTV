package app.cinemanatv.ui

import android.content.pm.ActivityInfo
import org.junit.Assert.*
import org.junit.Test

class OrientationPolicyTest {
    @Test fun phonesFollowRotationWhileBrowsing(){assertEquals(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED,desiredOrientation(360,false,false))}
    @Test fun playbackRequestsLandscape(){assertEquals(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,desiredOrientation(360,false,true))}
    @Test fun televisionAndTabletLayoutsStayLandscape(){assertEquals(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,desiredOrientation(360,true,false));assertEquals(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,desiredOrientation(720,false,false))}
}
