package app.cinemanatv.util

import org.junit.Assert.*
import org.junit.Test

class UpdatePackageIdentityTest {
    private val feed="""{"schema":1,"tv":{"enabled":true,"applicationId":"app.cinemanatv.cee.nativepreview","versionCode":3,"version":"0.3.0","downloadUrl":"https://example.com/native.apk"}}"""
    @Test fun nativeUpdatesAreMatchedToTheNativePackage() {
        assertNotNull(AppUpdateChecker.parseManifest(feed,2,"app.cinemanatv.cee.nativepreview",true))
        assertNull(AppUpdateChecker.parseManifest(feed,2,"app.cinemanatv.cee",true))
    }
    @Test fun runtimePackageChecksRequireAnExplicitIdentity() {
        val missing=feed.replace("\"applicationId\":\"app.cinemanatv.cee.nativepreview\",","")
        assertNull(AppUpdateChecker.parseManifest(missing,2,"app.cinemanatv.cee.nativepreview",true))
    }
}
