package app.cinemanatv.ui

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import app.cinemanatv.Services
import app.cinemanatv.data.Prefs
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="sw360dp-w360dp-h800dp-port-mdpi")
class HostedProviderSettingsTest {
    @get:Rule val compose=createComposeRule()
    @Test fun invalidServerCannotReplaceTheSavedWorkingConfiguration() {
        Services.prefs=Prefs(RuntimeEnvironment.getApplication())
        Services.prefs.websiteServerUrl="https://saved.example/";Services.prefs.websiteServerKey="saved-key"
        compose.setContent{CinemanaTheme{androidx.compose.foundation.layout.Column{HostedProviderSettings()}}}
        compose.onNodeWithTag("hosted-server-url").performTextClearance()
        compose.onNodeWithTag("hosted-server-url").performTextInput("http://insecure.example/")
        compose.onNodeWithText("Test and use server").performClick()
        compose.waitForIdle()
        compose.onNodeWithText("Enter a valid HTTPS server URL.").assertExists()
        assertEquals("https://saved.example/",Services.prefs.websiteServerUrl)
        assertEquals("saved-key",Services.prefs.websiteServerKey)
    }
}
