@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package app.cinemanatv.ui
import androidx.media3.common.*
import androidx.media3.common.C as MediaConstants
import org.junit.Assert.*
import org.junit.Test
@org.junit.runner.RunWith(org.robolectric.RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk=[28],application=android.app.Application::class)
class AdaptiveVideoTracksTest {
    @Test fun showsOnlyActualSupportedHeightsAndDeduplicatesThem() {
        fun format(height:Int)=Format.Builder().setSampleMimeType(MimeTypes.VIDEO_H264).setWidth(height*16/9).setHeight(height).build()
        val group=TrackGroup("video",format(1080),format(720),format(720),format(480))
        val tracks=Tracks(listOf(Tracks.Group(group,true,intArrayOf(MediaConstants.FORMAT_HANDLED,MediaConstants.FORMAT_HANDLED,MediaConstants.FORMAT_HANDLED,MediaConstants.FORMAT_UNSUPPORTED_TYPE),booleanArrayOf(false,true,false,false))))
        assertEquals(listOf(1080,720),videoRenditions(tracks).map{it.height})
        assertEquals(setOf(480),unsupportedVideoHeights(tracks))
        assertEquals(listOf(1080,720),app.cinemanatv.util.QualityDiscovery.trackHeights(tracks))
        val choice=videoRenditions(tracks).first{it.height==720}
        assertEquals(group,choice.group)
        assertEquals(720,choice.group.getFormat(choice.index).height)
    }
    @Test fun unknownTrackHeightsDoNotBecomeInventedQualities(){assertTrue(videoRenditions(Tracks.EMPTY).isEmpty());assertTrue(unsupportedVideoHeights(Tracks.EMPTY).isEmpty())}
}
