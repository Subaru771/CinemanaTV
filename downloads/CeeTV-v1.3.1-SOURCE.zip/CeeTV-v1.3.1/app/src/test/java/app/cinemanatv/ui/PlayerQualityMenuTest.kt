package app.cinemanatv.ui

import android.app.Application
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import app.cinemanatv.Services
import app.cinemanatv.data.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w1280dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PlayerQualityMenuTest {
    @get:Rule val compose=createComposeRule()
    @Test fun actualPlayerMenuShowsNumberedHlsChoicesAndOpensTheChosenAsset() {
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cinemana_tv",0).edit().clear().commit()
        app.getSharedPreferences("cinemana_library",0).edit().clear().commit()
        Services.prefs=Prefs(app)
        val choices=listOf(1080,720,480).map{QualityOption(it,"https://media.example/$it/master.m3u8")}
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=PlaySources(choices,emptyList())})
        val opened=mutableListOf<QualityOption>()
        compose.setContent{CinemanaTheme{CompositionLocalProvider(LocalPlayerEngineFactory provides {context ->
            object:CinemaPlaybackEngine(context){
                override fun open(id:String,quality:QualityOption,subtitles:List<SubtitleOption>,at:Long,play:Boolean,maxVideoHeight:Int){
                    opened.add(quality)
                    throw IllegalStateException("Fixture decoder unavailable")
                }
            }
        }){PlayerScreen(listOf(Video(nb="cee_1",kind="1",enTitle="Example")),0,onExit={},onRegisterBack={})}}}
        compose.onNode(hasText("Video quality") and hasClickAction()).performTouchInput{click()}
        for(height in listOf(1080,720,480))compose.onNode(hasText("${height}p") and hasClickAction()).assertIsDisplayed()
        compose.onNode(hasText("720p") and hasClickAction()).performTouchInput{click()}
        compose.runOnIdle{assertEquals(choices[1],opened.last())}
    }
}
