package app.cinemanatv.ui

import app.cinemanatv.data.QualityOption
import org.junit.Assert.*
import org.junit.Test

class QualityRefreshTest {
    @Test fun manualResolutionSurvivesExpiredUrlsAndReorderedSources() {
        val previous=QualityOption(720,"https://media.example/old720.mp4")
        val refreshed=listOf(QualityOption(360,"https://media.example/360.mp4"),QualityOption(720,"https://media.example/new720.mp4"))
        assertEquals(1,refreshedQualityIndex(previous,true,refreshed,0))
    }
    @Test fun anUnavailableManualResolutionUsesTheClosestAvailableLowerOne() {
        val refreshed=listOf(QualityOption(1080,"https://media.example/1080.mp4"),QualityOption(480,"https://media.example/480.mp4"))
        assertEquals(1,refreshedQualityIndex(QualityOption(720,"old"),true,refreshed,0))
    }
    @Test fun automaticSelectionUsesTheNewBandwidthChoice() {
        val options=listOf(QualityOption(1080,"one"),QualityOption(480,"two"))
        assertEquals(1,refreshedQualityIndex(options.first(),false,options,1))
    }
}
