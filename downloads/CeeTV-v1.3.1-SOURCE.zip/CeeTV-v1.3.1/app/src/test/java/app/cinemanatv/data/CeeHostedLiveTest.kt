package app.cinemanatv.data

import app.cinemanatv.util.numberedDownloadOptions
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test

/** Optional end-to-end check against an explicitly configured running server; no credentials in fixtures. */
class CeeHostedLiveTest {
    @Test fun realServerCatalogueAndHlsInventoryReachTheAndroidAdapter()=runBlocking {
        val url=System.getenv("CEE_HOSTED_TEST_URL")
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1" && !url.isNullOrBlank())
        val api=CeeApiCatalog(url!!,System.getenv("CEE_HOSTED_TEST_KEY"),allowLocalHttp=true)
        api.checkHealth()
        val home=api.home(1);assertTrue(home.rows.any{it.items.isNotEmpty()})
        val source=api.sources("cee_2148687");assertTrue(source.qualities.isNotEmpty())
        val options=HlsManifest.downloadOptions(source.qualities)
        val heights=numberedDownloadOptions(options).filter{it.height>0}.map{it.height}.distinct().sortedDescending()
        assertTrue("No HLS resolutions were discoverable",heights.isNotEmpty())
        val viewing=app.cinemanatv.ui.playerQualityChoices(source.qualities,options,source.qualities.first(),emptyList())
        assertEquals(heights,viewing.map{it.height})
        println("Live hosted adapter: ${home.rows.size} catalogue rows; ${heights.size} matching viewing/download resolutions; media playlist and segment probes passed.")
    }
}
