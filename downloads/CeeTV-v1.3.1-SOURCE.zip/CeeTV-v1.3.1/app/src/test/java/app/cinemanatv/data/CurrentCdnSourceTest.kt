package app.cinemanatv.data

import app.cinemanatv.util.numberedDownloadOptions
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.junit.Assert.*
import org.junit.Test

class CurrentCdnSourceTest {
    @Test fun currentWebsiteDirectMp4MasterIsARealFileChoice() {
        val url="https://s203d1.downet.net/movies/Example.2026.mp4"
        val options=CeeAlternativeSource.qualities("""<script>const masterUrl="$url";</script>""")
        assertEquals(1,options.size)
        assertEquals(url,options.single().url)
        assertFalse(options.single().adaptive)
        assertEquals("video/mp4",options.single().mimeType)
        assertEquals(options,numberedDownloadOptions(options))
        assertEquals(0,options.single().height)
    }
    @Test fun theCdnHlsMasterRetainsItsRelayAlternative() {
        val url="https://s203d1.downet.net/movie/master.m3u8"
        val options=CeeAlternativeSource.qualities("""<script>const masterUrl="$url";</script>""")
        assertEquals(2,options.size)
        assertTrue(options.all{it.adaptive})
        assertEquals(url,options.first().url)
        assertEquals(url,options.last().url.toHttpUrl().queryParameter("url"))
    }
    @Test fun directDashMasterIsNotMislabeledAsHls() {
        val options=CeeAlternativeSource.qualities("""<script>const masterUrl="https://s203d1.downet.net/movie/manifest.mpd";</script>""")
        assertEquals("application/dash+xml",options.single().mimeType)
    }
    @Test fun lookalikeDomainsAndUnapprovedPathsAreRejected() {
        for(url in listOf("https://s203d1.downet.net.evil.example/movie.mp4","http://s203d1.downet.net/movie.mp4",
            "https://user@s203d1.downet.net/movie.mp4","https://s203d1.downet.net:444/movie.mp4","https://s203d1.downet.net/run.php")) {
            assertTrue(url,CeeAlternativeSource.qualities("""<script>const masterUrl="$url";</script>""").isEmpty())
        }
    }
}
