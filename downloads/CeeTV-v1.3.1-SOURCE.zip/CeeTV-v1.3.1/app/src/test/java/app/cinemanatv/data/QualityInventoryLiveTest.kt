package app.cinemanatv.data

import app.cinemanatv.util.numberedDownloadOptions
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test

class QualityInventoryLiveTest {
    @Test fun viewingAndDownloadsGetTheSamePublishedHlsResolutions() = runBlocking {
        assumeTrue(System.getenv("CEE_LIVE_TEST")=="1")
        val source=CeeAlternativeSource.resolve("cee_2148687")
        val selected=source.qualities.first()
        val sizes=HlsManifest.heights(selected)
        assertTrue("No declared HLS resolutions",sizes.isNotEmpty())
        val expanded=HlsManifest.downloadOptions(source.qualities)
        val viewing=app.cinemanatv.ui.playerQualityChoices(source.qualities,expanded,selected,listOf(sizes.last()))
        val downloads=numberedDownloadOptions(expanded)
        assertEquals(sizes,downloads.filter{it.height>0}.map{it.height})
        assertEquals(downloads.filter{it.height>0}.map{it.height},viewing.map{it.height})
        println("Live quality inventory: ${sizes.size} source-declared resolutions match between viewing and download choices")
    }
}
