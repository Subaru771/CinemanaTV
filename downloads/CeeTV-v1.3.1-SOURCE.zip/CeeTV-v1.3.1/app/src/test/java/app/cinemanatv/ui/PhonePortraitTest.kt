package app.cinemanatv.ui

import android.app.Application
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.junit4.AndroidComposeTestRule
import androidx.compose.ui.unit.Density
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.viewModelScope
import app.cinemanatv.Services
import app.cinemanatv.data.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.util.concurrent.atomic.AtomicInteger
import java.io.File

abstract class PortraitBehavior {
    @Test fun changingLanguageCancelsPendingTabsAndClearsOldResults() {
        val ready=CompletableDeferred<HomeData>();val calls=AtomicInteger()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?):HomeData{calls.incrementAndGet();return ready.await()}})
        val vm=model();content{androidx.tv.material3.Text("Locale fixture")}
        compose.runOnIdle {
            vm.viewModelScope.launch{vm.loadHome(1)}
            vm.viewModelScope.launch{vm.loadHome(2)}
            vm.searchResults=listOf(movie);vm.searchDone="Old query"
        }
        compose.waitUntil(5000){calls.get()>=3}
        compose.runOnIdle {
            vm.changeInterfaceLanguage("ar")
            assertTrue(vm.homeCache.isEmpty());assertNull(vm.searchResults)
            assertEquals("ar",vm.interfaceLanguage)
        }
    }
    @Test fun anUnsupportedQualityCannotBeActivatedByTouch() {
        var activated=false
        content{PlayerOption("2160p","Not supported on this device","",enabled=false){activated=true}}
        compose.onNode(hasText("2160p") and hasClickAction()).assertIsNotEnabled().performTouchInput{click()}
        compose.runOnIdle{assertFalse(activated)}
    }
    @get:Rule val compose=createComposeRule()
    private val models=ViewModelStore()
    protected open val fontScale=1f
    private val artwork=System.getenv("CEE_PREVIEW_DATA")?.let{File(it).listFiles()?.firstOrNull{file->file.extension=="jpg"}?.toURI()?.toString()}
    private val movie=Video(nb="cee_api_101",kind="1",enTitle="A long example movie title for phone testing",year="2026",imgObjUrl=artwork)
    private val data=HomeData(listOf(movie),listOf(ContentRow("Latest movies",listOf(movie))))
    @Before fun setup(){
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cinemana_tv",0).edit().clear().commit()
        app.getSharedPreferences("cinemana_library",0).edit().clear().commit()
        Services.prefs=Prefs(app)
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?)=data;override suspend fun search(query:String)=listOf(movie)})
    }
    @After fun cleanup(){models.clear()}
    private fun model()=AppViewModel().also{models.put("phone",it)}
    private fun content(block:@androidx.compose.runtime.Composable ()->Unit) {
        compose.setContent{CompositionLocalProvider(LocalDensity provides Density(1f,fontScale)){CinemanaTheme{block()}}}
    }
    private fun snapshot(name:String) {
        val directory=System.getenv("CEE_PREVIEW_DIR") ?: return
        val activity=(compose as? AndroidComposeTestRule<*,*>)?.activity ?: return
        compose.runOnIdle {
            val view=activity.window.decorView
            if(view.width>0 && view.height>0) {
                val bitmap=android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888)
                view.draw(android.graphics.Canvas(bitmap))
                val file=File(directory,"${javaClass.simpleName}-$name.png");file.parentFile.mkdirs()
                file.outputStream().use{bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it)}
                bitmap.recycle()
            }
        }
    }
    @Test fun bottomNavigationOpensEveryLibraryDestinationWithRealTaps() {
        val vm=model();content{MainShell(vm)}
        snapshot("home")
        val tabs=listOf(0 to "Home",1 to "Series",2 to "Movies",4 to "History",5 to "My List",6 to "Downloads",7 to "Settings")
        for((tab,title)in tabs) {
            compose.onNodeWithTag("phone-navigation").performScrollToIndex(tab)
            compose.onNode(hasText(title) and hasClickAction() and hasAnyAncestor(hasTestTag("phone-navigation"))).performTouchInput{click()}
            compose.runOnIdle{assertEquals(tab,vm.tab)}
        }
    }
    @Test fun searchHasAFullWidthEditableFieldAndReachableClearAction() {
        val vm=model();vm.tab=3;content{MainShell(vm)}
        val field=compose.onNode(hasSetTextAction())
        val bounds=field.getBoundsInRoot()
        assertTrue(bounds.right.value-bounds.left.value>=280f)
        field.performTextInput("Example")
        compose.onNode(hasText("Clear") and hasClickAction()).performTouchInput{click()}
        compose.runOnIdle{assertEquals("",vm.searchQuery)}
    }
    @Test fun portraitSettingsCanChooseAndPersistPlaybackQuality() {
        val vm=model();vm.tab=7;content{MainShell(vm)}
        compose.onNodeWithTag("settings-categories").performScrollToIndex(2)
        compose.onNode(hasText("Playback") and hasClickAction()).performTouchInput{click()}
        compose.onNode(hasText("720p",substring=true) and hasClickAction()).performScrollTo().performTouchInput{click()}
        compose.runOnIdle{assertEquals(720,Services.prefs.maxQuality)}
        snapshot("settings")
    }
    @Test fun detailActionsUseThePhoneWidthAndCanStartPlayback() {
        var played=false
        content{DetailScreen(movie,onPlay={_,_->played=true},onOpen={},onBack={})}
        val title=compose.onNodeWithText(movie.enTitle!!).getBoundsInRoot()
        assertTrue(title.left.value>=15f)
        snapshot("detail")
        compose.onNode(hasText("Play") and hasClickAction()).performScrollTo().performTouchInput{click()}
        compose.runOnIdle{assertTrue(played)}
    }
    @Test fun splashWarmupAndHomeShareOnePendingCatalogueRequest() {
        val ready=CompletableDeferred<HomeData>();val calls=AtomicInteger()
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?):HomeData{calls.incrementAndGet();return ready.await()}})
        val vm=model();content{HomeScreen(null,vm)}
        compose.waitUntil(5000){calls.get()==1}
        compose.runOnIdle{ready.complete(data)}
        compose.waitUntil(5000){compose.runOnIdle{vm.homeCache[0]!=null}}
        compose.runOnIdle{assertEquals(1,calls.get())}
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="sw360dp-w360dp-h800dp-port-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PhonePortrait360Test:PortraitBehavior()

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="sw412dp-w412dp-h915dp-port-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PhonePortrait412Test:PortraitBehavior(){override val fontScale=1.3f}
