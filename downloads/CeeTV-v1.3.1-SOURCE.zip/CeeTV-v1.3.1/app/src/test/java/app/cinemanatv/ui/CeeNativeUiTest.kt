package app.cinemanatv.ui

import android.app.Application
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.lifecycle.ViewModelStore
import app.cinemanatv.Services
import app.cinemanatv.data.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class,qualifiers="w1280dp-h720dp-land-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class CeeNativeUiTest {
    @get:Rule val compose=createComposeRule()
    private val models=ViewModelStore()
    @Before fun setup(){
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("cinemana_tv",0).edit().clear().commit()
        app.getSharedPreferences("cinemana_library",0).edit().clear().commit()
        Services.prefs=Prefs(app)
    }
    @After fun release(){models.clear()}
    private fun model()=AppViewModel().also{models.put("native-test",it)}
    @Test fun nativeSeriesCardsRetainTheirProviderIdentityAndTwelveItemPagination() {
        val videos=(1..12).map{Video(nb="cee_api_$it",enTitle="Series $it",kind="2")}
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun browse(section:CatalogSection,page:Int)=videos})
        val vm=model();var opened:Video?=null
        val section=CatalogSection("native-42","Native series",2,pageSize=12,nativeGroupId="42")
        compose.setContent{CinemanaTheme{CollectionScreen(section,vm,onBack={},onOpen={opened=it})}}
        compose.onNode(hasContentDescription("Series 1") and hasClickAction()).performTouchInput{click()}
        compose.runOnIdle {
            assertEquals("cee_api_1",opened?.id)
            assertFalse(vm.collectionState(section.key).finished)
            assertEquals(videos,vm.collectionState(section.key).videos)
        }
    }
    @Test fun theNativeApiFailureIsVisibleAndTheLibraryRemainsReachable() {
        Services.repo=Repository(object:StubCeeCatalog(){override suspend fun home(kind:Int?):HomeData {
            throw CeeApiException(503,"CEE API is unavailable (HTTP 503). Please retry when the service is reachable.")
        }})
        val vm=model()
        compose.setContent{CinemanaTheme{HomeScreen(null,vm)}}
        compose.onNodeWithText("CEE API is unavailable (HTTP 503). Please retry when the service is reachable.").assertIsDisplayed()
        compose.onNode(hasText("Downloads") and hasClickAction()).performTouchInput{click()}
        compose.runOnIdle{assertEquals(6,vm.tab)}
    }
}
