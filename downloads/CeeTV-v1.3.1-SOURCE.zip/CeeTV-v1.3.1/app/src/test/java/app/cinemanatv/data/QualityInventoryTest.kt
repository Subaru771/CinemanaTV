package app.cinemanatv.data

import java.io.IOException
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class QualityInventoryTest {
    private val first=QualityOption(0,"https://media.example/first.m3u8")
    private val second=QualityOption(0,"https://media.example/second.m3u8")

    @Test fun laterServersAddQualitiesEvenWhenTheFirstServerWorks() = runBlocking {
        val result=QualityInventory.expand(listOf(first,second),{if(it==first)listOf(1080) else listOf(720,480)})
        assertEquals(listOf(1080,720,480),result.filter{it.height>0}.map{it.height})
        assertEquals(listOf(first.url,second.url,second.url),result.filter{it.height>0}.map{it.url})
        assertTrue(result.contains(first));assertTrue(result.contains(second))
    }
    @Test fun aBrokenServerDoesNotEraseOtherQualities() = runBlocking {
        val result=QualityInventory.expand(listOf(first,second),{if(it==first)throw IOException("HTTP 403") else listOf(720)})
        assertEquals(listOf(720),result.filter{it.height>0}.map{it.height})
    }
    @Test fun aSlowServerDoesNotBlockPublishingReadyChoices() = runBlocking {
        val waiting=CompletableDeferred<Unit>();val published=CompletableDeferred<List<QualityOption>>()
        val task=async { QualityInventory.expand(listOf(first,second),{
            if(it==second)waiting.await()
            if(it==first)listOf(1080) else listOf(480)
        },{options->if(options.any{it.height==1080})published.complete(options)}) }
        val partial=withTimeout(1000){published.await()}
        assertTrue(partial.any{it.height==1080});assertFalse(partial.any{it.height==480})
        waiting.complete(Unit)
        assertEquals(setOf(1080,480),task.await().filter{it.height>0}.map{it.height}.toSet())
    }
    @Test fun qualitiesKeepTheMasterForItsSeparateAudioAndSubtitles() = runBlocking {
        val result=QualityInventory.expand(listOf(first),{listOf(1080,720)})
        assertTrue(result.all{it.url==first.url && it.adaptive})
    }
    @Test fun cancellationStopsDiscoveryInsteadOfBecomingAnEmptySuccess() = runBlocking {
        try {
            QualityInventory.expand(listOf(first),{throw CancellationException("Leaving player")})
            fail("Cancellation was swallowed")
        } catch(expected:CancellationException) { assertEquals("Leaving player",expected.message) }
    }
    @Test fun repeatedAndInvalidHeightsDoNotBecomeMenuOptions() = runBlocking {
        val result=QualityInventory.expand(listOf(first,first),{listOf(0,-1,720,720,99999)})
        assertEquals(listOf(720),result.filter{it.height>0}.map{it.height})
    }
}
