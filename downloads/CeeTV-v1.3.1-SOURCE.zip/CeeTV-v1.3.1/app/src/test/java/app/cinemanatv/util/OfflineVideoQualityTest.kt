@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package app.cinemanatv.util

import android.app.Application
import androidx.media3.common.*
import androidx.media3.common.C as MediaC
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],application=Application::class)
class OfflineVideoQualityTest {
    private fun tracks():Tracks {
        fun format(h:Int)=Format.Builder().setSampleMimeType(MimeTypes.VIDEO_H264).setHeight(h).build()
        val video=TrackGroup("video",format(1080),format(720),format(480))
        val audio=TrackGroup("audio",Format.Builder().setSampleMimeType(MimeTypes.AUDIO_AAC).build())
        return Tracks(listOf(Tracks.Group(video,true,intArrayOf(MediaC.FORMAT_UNSUPPORTED_TYPE,MediaC.FORMAT_HANDLED,MediaC.FORMAT_HANDLED),booleanArrayOf(false,true,false)),
            Tracks.Group(audio,false,intArrayOf(MediaC.FORMAT_HANDLED),booleanArrayOf(true))))
    }
    @Test fun numberedDownloadsSelectTheRequestedVideoTrack() {
        val selected=offlineVideoQuality(tracks(),720)!!
        assertEquals(MediaC.TRACK_TYPE_VIDEO,selected.type)
        assertEquals(listOf(1),selected.trackIndices)
        assertEquals(720,selected.mediaTrackGroup.getFormat(selected.trackIndices.single()).height)
    }
    @Test fun unsupportedResolutionsFailInsteadOfSilentlyDownloadingLower() {
        try{offlineVideoQuality(tracks(),1080);fail()}catch(e:OfflineQualityUnavailable){assertTrue(e.message!!.contains("1080p"))}
    }
    @Test fun automaticDownloadsDoNotForceANumberedTrack(){assertNull(offlineVideoQuality(tracks(),0))}
    @Test fun audioOnlyPeriodsRemainUntouched(){assertNull(offlineVideoQuality(Tracks(listOf(tracks().groups.last())),720))}
}
