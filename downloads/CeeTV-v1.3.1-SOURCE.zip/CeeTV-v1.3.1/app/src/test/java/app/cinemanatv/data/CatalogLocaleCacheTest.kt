package app.cinemanatv.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class CatalogLocaleCacheTest {
    @get:Rule val folder=TemporaryFolder()
    @Test fun languageSpecificCacheNeverReturnsLabelsFromAnotherLanguage() = runBlocking {
        var language="en"
        val backend=object:StubCeeCatalog(){override suspend fun home(kind:Int?)=HomeData(emptyList(),listOf(ContentRow(language,listOf(Video(nb="cee_api_1",enTitle="Example"))))) }
        val repo=Repository(backend,folder.newFolder(),{language})
        repo.loadHome(null)
        language="ar"
        assertNull(repo.cachedHome(null))
        repo.loadHome(null)
        assertEquals("ar",repo.cachedHome(null)!!.rows.single().title)
        language="en"
        assertEquals("en",repo.cachedHome(null)!!.rows.single().title)
    }
}
