package app.cinemanatv.data

import kotlinx.coroutines.*
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.*
import org.junit.Assert.*
import java.util.concurrent.TimeUnit

class CeeApiCatalogTest {
    private val server=MockWebServer()
    @Before fun start(){server.start()}
    @After fun stop(){server.shutdown()}
    private fun api(prefix:String="/")=CeeApiCatalog(server.url(prefix).toString(),"fixture-key",allowLocalHttp=true)
    private fun fixture(name:String)=javaClass.getResource("/hosted-api/$name.json")!!.readText()
    private fun enqueue(name:String){server.enqueue(MockResponse().setHeader("Content-Type","application/json").setBody(fixture(name)))}
    @Test fun serverFixturesDeserializeAcrossEveryCatalogueRead()=runBlocking {
        val api=api();enqueue("home");val home=api.home(1);assertEquals("cee_123",home.hero.first().id)
        enqueue("search");assertEquals(home.hero.first().id,api.search("Example & عربي").first().id)
        val video=home.hero.first();enqueue("detail");assertEquals(video.id,api.detail(video).id)
        enqueue("browse");assertEquals(video.id,api.browse(CatalogSection("category_1","Example",1,1),2).first().id)
        enqueue("episodes");val episodes=api.episodePage(video);assertEquals(2,episodes.videos.first().episodeNumber);assertEquals(video.id,episodes.videos.first().rootSeries)
        enqueue("related");assertTrue(api.related(Video(nb="cee_999",providerPageId="999")).isNotEmpty())
        enqueue("subtitles");assertEquals("text/vtt",api.subtitles("cee_123").first().mime)
        enqueue("sources");assertEquals(720,api.sources("cee_123").qualities.first().height)
    }
    @Test fun preservesDeploymentPrefixAndEncodesSearchWithoutLeakingKeyIntoUrl()=runBlocking {
        enqueue("search");api("/cee/").search("عربي & movie")
        val request=server.takeRequest();assertTrue(request.path!!.startsWith("/cee/api/search?"));assertEquals("عربي & movie",request.requestUrl!!.queryParameter("q"))
        assertEquals("fixture-key",request.getHeader("x-api-key"));assertFalse(request.path!!.contains("fixture-key"))
    }
    @Test fun healthRequiresCompatibleProviderContract()=runBlocking {
        enqueue("health");api().checkHealth()
        server.enqueue(MockResponse().setBody("{\"schema\":1,\"provider\":\"other\",\"ok\":true}"))
        assertTrue(runCatching{api().checkHealth()}.exceptionOrNull() is java.io.IOException)
    }
    @Test fun rejectsInsecureOrCredentialBearingConfiguration() {
        for(url in listOf("http://example.com/","https://user:pass@example.com/","https://example.com/?token=x","https://example.com/#fragment"))assertTrue(runCatching{CeeApiCatalog(url)}.isFailure)
    }
    @Test fun refusesRedirectsAndDoesNotForwardServerKey()=runBlocking {
        MockWebServer().use { destination -> destination.start()
            server.enqueue(MockResponse().setResponseCode(302).setHeader("Location",destination.url("/collect")))
            assertTrue(runCatching{api().checkHealth()}.exceptionOrNull() is java.io.IOException)
            assertNull(destination.takeRequest(150,TimeUnit.MILLISECONDS))
        }
    }
    @Test fun cancellationInterruptsStalledHttpRequest()=runBlocking {
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
        val task=launch(Dispatchers.Default){api().home(null)}
        assertNotNull(server.takeRequest(3,TimeUnit.SECONDS))
        withTimeout(2000){task.cancelAndJoin()};assertTrue(task.isCancelled)
    }
    @Test fun failedUrlsAreSentForServerRecoveryAndNeverReturned()=runBlocking {
        enqueue("sources");val q=api().sources("cee_123").qualities.first();server.takeRequest()
        enqueue("sources");assertTrue(runCatching{api().sources("cee_123",setOf(q.url))}.isFailure)
        val request=server.takeRequest();assertEquals("POST",request.method);assertTrue(request.body.readUtf8().contains(q.url))
    }
    @Test fun boundsResponseAndDoesNotExposeUpstreamErrorBody()=runBlocking {
        server.enqueue(MockResponse().setBody("x".repeat(2_000_001)))
        assertTrue(runCatching{api().home(null)}.exceptionOrNull()?.message?.contains("size limit")==true)
        server.enqueue(MockResponse().setResponseCode(502).setBody("secret signed media token"))
        val error=runCatching{api().home(null)}.exceptionOrNull()!!
        assertFalse(error.message!!.contains("secret"))
    }
    @Test fun partialDetailResponsePreservesExistingCatalogueMetadata()=runBlocking {
        val video=Video(nb="cee_123",providerPageId="123",kind="1",enTitle="Old title",year="2026",stars="8.2",filmRating="PG-13",imgObjUrl="https://images.example/poster.jpg",introStart="12",introEnd="20")
        server.enqueue(MockResponse().setBody("""{"id":"cee_123","title":"Updated title","description":"Updated plot","imdbId":"tt1234567"}"""))
        val detail=api().detail(video)
        assertEquals("Updated title",detail.title);assertEquals("Updated plot",detail.description)
        assertEquals("tt1234567",detail.imdbRef);assertEquals(video.poster,detail.poster);assertEquals(video.year,detail.year);assertEquals(video.stars,detail.stars)
        assertEquals(video.filmRating,detail.filmRating);assertEquals(video.introWindow,detail.introWindow)
    }
}
