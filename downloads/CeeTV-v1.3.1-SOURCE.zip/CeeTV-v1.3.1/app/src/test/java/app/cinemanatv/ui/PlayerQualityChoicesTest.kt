package app.cinemanatv.ui

import app.cinemanatv.data.QualityOption
import org.junit.Assert.*
import org.junit.Test

class PlayerQualityChoicesTest {
    private val master=QualityOption(0,"https://media.example/master.m3u8")
    @Test fun oneSelectedTrackDoesNotEraseTheCompleteProviderInventory() {
        val declared=listOf(1080,720,480).map{master.copy(height=it)}
        val menu=playerQualityChoices(listOf(master),declared,master,listOf(480))
        assertEquals(listOf(1080,720,480),menu.map{it.height})
    }
    @Test fun nativeMetadataCompletesAPartialProviderInventory() {
        val menu=playerQualityChoices(listOf(master),listOf(master.copy(height=720)),master,listOf(1080,720,480))
        assertEquals(listOf(1080,720,480),menu.map{it.height})
    }
    @Test fun explicitlyNumberedHlsSourcesAppearAsResolutions() {
        val sources=listOf(master.copy(height=1080),master.copy(height=720,url="https://media.example/backup.m3u8"))
        assertEquals(sources,playerQualityChoices(sources,emptyList(),sources.first(),emptyList()))
    }
    @Test fun selectingAQualityKeepsItsOriginatingServer() {
        val backup=master.copy(height=1080,url="https://other.example/master.m3u8")
        val menu=playerQualityChoices(listOf(master),listOf(backup),master,listOf(480))
        assertEquals(backup,menu.first())
    }
    @Test fun duplicateHeightsPreferTheCurrentServerWithoutLosingOtherResolutions() {
        val backup=master.copy(url="https://other.example/master.m3u8")
        val menu=playerQualityChoices(listOf(master,backup),listOf(master.copy(height=720),backup.copy(height=720)),backup,listOf(480))
        assertEquals(backup.url,menu.first().url)
        assertEquals(listOf(720,480),menu.map{it.height})
    }
    @Test fun unknownMetadataDoesNotInventQualities() {
        assertTrue(playerQualityChoices(listOf(master),emptyList(),master,emptyList()).isEmpty())
    }
}
