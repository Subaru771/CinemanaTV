const {test}=require('node:test');
const assert=require('node:assert/strict');
const {qualitiesFromPlayerHtml,stripComments,allowedMedia}=require('../src/sources');
const {fetchWithTimeout}=require('../src/ceeClient');
test('keeps all declared heights for one master, including quoted reordered objects',()=>{
 const u='https://v.brqz.online/movie.m3u8';
 const q=qualitiesFromPlayerHtml(`<script>sources=[{'file':'${u}','label':'1080p'},{"label":"720p","file":"${u}"}]</script>`);
 assert.deepEqual(q.filter(v=>v.height>0).map(v=>v.height),[1080,720]);
});
test('handles escaped query characters and ignores commented source objects',()=>{
 const q=qualitiesFromPlayerHtml(`<script>// file:'https://v.brqz.online/fake.m3u8'\nsources=[{'label':'480p','file':'https:\\/\\/v.brqz.online/movie.mp4?a=1\\u0026b=2'}];</script>`);
 assert.equal(q.length,1);assert.equal(q[0].height,480);assert.equal(new URL(q[0].url).searchParams.get('b'),'2');
 assert.ok(stripComments('let x="https://a/b//c"; // comment').includes('https://a/b//c'));
});
test('rejects private and unapproved media addresses',()=>{
 for(const u of ['http://v.brqz.online/a.mp4','https://127.0.0.1/a.mp4','https://evil.example/a.mp4','https://user:pass@v.brqz.online/a.mp4'])assert.equal(allowedMedia(new URL(u)),false);
});
test('bounds response while reading, rather than buffering an oversized body',async()=>{
 let reads=0;
 const body=new ReadableStream({pull(c){reads++;c.enqueue(new Uint8Array(1000000));}});
 await assert.rejects(fetchWithTimeout('https://cinamana.cc/',{},async()=>{},async()=>new Response(body)),/too large/);
 assert.ok(reads<=5);
});
test('validates every redirect and stops before fetching a rejected destination',async()=>{
 let calls=0;
 await assert.rejects(fetchWithTimeout('https://cinamana.cc/',{},async u=>{if(u.includes('127.0.0.1'))throw Error('blocked');},async()=>{calls++;return new Response(null,{status:302,headers:{location:'https://127.0.0.1/'}});}),/blocked/);
 assert.equal(calls,1);
});

test('shares simultaneous catalogue lookups, caches successes and retries failures',async()=>{
 const {createPageCache}=require('../src/ceeClient'); let calls=0, finish;
 const cache=createPageCache(()=>{calls++;return new Promise(r=>{finish=r;});});
 const a=cache.page('https://cinamana.cc/movies/'),b=cache.page('https://cinamana.cc/movies/');
 assert.equal(calls,1);finish('fixture');assert.deepEqual(await Promise.all([a,b]),['fixture','fixture']);
 assert.equal(await cache.page('https://cinamana.cc/movies/'),'fixture');assert.equal(calls,1);
 let failures=0;const retry=createPageCache(async()=>{failures++;throw Error('upstream');});
 await assert.rejects(retry.page('https://cinamana.cc/'));await assert.rejects(retry.page('https://cinamana.cc/'));assert.equal(failures,2);
});

test('resolution parsing ignores codec digits and accepts dimensions and Arabic digits',()=>{
 const q=qualitiesFromPlayerHtml(`<script>sources=[{file:'https://v.brqz.online/a.mp4',label:'H264 720p'},{file:'https://v.brqz.online/b.mp4',label:'1920x1080'},{file:'https://v.brqz.online/c.mp4',label:'٤٨٠p'}]</script>`);
 assert.deepEqual(q.map(v=>v.height),[1080,720,480]);
});

test('matches current downet media hosts and direct MP4 master declarations',()=>{
 const q=qualitiesFromPlayerHtml(`<script>const masterUrl='https://edge.downet.net/movie.mp4';</script>`);
 assert.equal(q.length,1);assert.equal(q[0].mimeType,'video/mp4');assert.equal(q[0].name,'CEE · Original file');
 assert.equal(allowedMedia(new URL('https://edge.downet.net:8443/movie.mp4')),false);
});
test('falls back to the watch page and ignores unrelated iframes before applying the route cap',async()=>{
 const {resolve}=require('../src/sources');let slots=0;
 const result=await resolve('123',[],async url=>url.includes('watch=') ? '<iframe src="https://ads.example/a"></iframe>'.repeat(12)+'<iframe src="https://cdnplus.sbs/embed-123.html"></iframe>' : `<script>const masterUrl='https://edge.downet.net/movie.mp4';</script>`,async()=>{slots++;throw Error('slot unavailable');});
 assert.equal(slots,3);assert.equal(result.qualities[0].mimeType,'video/mp4');
});
