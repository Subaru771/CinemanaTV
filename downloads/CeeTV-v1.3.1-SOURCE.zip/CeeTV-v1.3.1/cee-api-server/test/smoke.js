// Dependency-free smoke test for the parsing layer, run with: node test/smoke.js
// Does NOT hit the network — feeds static HTML fixtures to the same parse.js used by server.js.
const assert = require('assert');
const P = require('../src/parse');

const listingHtml = `
<html><body>
  <a href="https://cinamana.cc/watch=1234567/" class="item">
    <img data-src="https://img.example/poster1.jpg">
    <h2>فيلم تجريبي 2023</h2>
  </a>
  <a href="https://cinamana.cc/watch=7654321/" class="item">
    <img src="https://img.example/poster2.jpg">
    <h3>مسلسل تجريبي الموسم الثاني الحلقة 5</h3>
  </a>
  <a href="https://cinamana.cc/watch=999/" class="cn-mega-item">
    <h2>Should be skipped (ad slot)</h2>
  </a>
</body></html>`;

const cards = P.cards(listingHtml);
assert.strictEqual(cards.length, 2, `expected 2 cards, got ${cards.length}`);
assert.strictEqual(cards[0].id, 'cee_1234567');
assert.strictEqual(cards[0].kind, '1');
assert.strictEqual(cards[0].year, '2023');
assert.strictEqual(cards[1].kind, '2');
assert.strictEqual(cards[1].season, '2');
assert.strictEqual(cards[1].episode, '5');
console.log('cards(): OK —', JSON.stringify(cards, null, 2));

const detailHtml = `
<html><body>
  <h1>فيلم تجريبي 2023</h1>
  <meta property="og:image" content="https://img.example/big.jpg">
  <div class="story">قصة الفيلم هنا.</div>
  <a href="https://www.imdb.com/title/tt1234567/">IMDb</a>
</body></html>`;
const d = P.detail(detailHtml, { id: 'cee_1234567', title: 'fallback title', kind: '1', providerPageId: '1234567' });
assert.strictEqual(d.imdbId, 'tt1234567');
assert.ok(d.description.includes('قصة'));
console.log('detail(): OK —', JSON.stringify(d, null, 2));

const episodesHtml = `
<html><body>
  <div id="s1" class="season-wrapper">
    <button class="season-trigger" data-target="s1">الموسم الاول</button>
    <div class="episodes-grid">
      <a href="https://cinamana.cc/watch=111/" title="الحلقة 2"><span>2</span></a>
      <a href="https://cinamana.cc/watch=112/" title="الحلقة 1"><span>1</span></a>
    </div>
  </div>
</body></html>`;
const parent = { id: 'cee_series_abc', title: 'مسلسل تجريبي', poster: null, year: '2023' };
const eps = P.episodesFromHtml(episodesHtml, parent);
assert.strictEqual(eps.length, 2);
assert.strictEqual(eps[0].episode, '1'); // sorted chronologically
assert.strictEqual(eps[1].episode, '2');
console.log('episodesFromHtml(): OK —', JSON.stringify(eps, null, 2));

console.log('\nALL SMOKE TESTS PASSED');
