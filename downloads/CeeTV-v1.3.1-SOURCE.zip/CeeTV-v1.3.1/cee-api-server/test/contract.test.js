const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const client = require('../src/ceeClient');
const html = `<a href="/watch=123/" class="item"><h2>Example film 2026</h2></a>`;
let categoryRecords = [];
const requested = [];
const player = `<script>sources=[{'label':'720p','file':'https://v.brqz.online/movie.mp4'}]</script>`;
client.page = async url => {
  requested.push(url);
  if (url.includes('wp/v2/categories')) return JSON.stringify(categoryRecords);
  if (url.includes('wp/v2/posts')) return JSON.stringify([{id:123,title:{rendered:'Example film 2026'}}]);
  if (url.includes('embed-')) return player;
  if (url.includes('watch=')) return html+`<h1>Example film 2026</h1><track src="https://v.brqz.online/en.vtt" label="English"><button class="season-trigger" data-target="s1">Season 1</button><div id="s1" class="season-wrapper"><div class="episodes-grid"><a href="/watch=124/" title="episode 2">2</a></div></div>`;
  return html;
};
client.post = async () => '<iframe src="https://cdnplus.sbs/embed-Abc.html"></iframe>';
const app = require('../src/server');
let server, base;
before(async () => { server = app.listen(0,'127.0.0.1'); await new Promise(r=>server.once('listening',r)); base=`http://127.0.0.1:${server.address().port}`; });
after(() => server.close());
const fixtureDir=fs.existsSync(path.resolve(__dirname,'../../app/build.gradle.kts')) ? path.resolve(__dirname,'../../app/src/test/resources/hosted-api') : path.resolve(__dirname,'fixtures/generated');
fs.mkdirSync(fixtureDir,{recursive:true});
async function response(route,name,init) {
  const res=await fetch(base+route,init); assert.equal(res.status,200); const data=await res.json();
  if (name) fs.writeFileSync(path.join(fixtureDir,name+'.json'),JSON.stringify(data,null,2)+'\n');
  return data;
}
test('HTTP catalogue, detail, episodes, browse, subtitles and files match the Android contract',async()=>{
  assert.equal((await response('/api/health','health')).schema,1);
  const home=await response('/api/home?kind=1','home');assert.equal(home.featured[0].id,'cee_123');assert.equal(home.rows[0].items[0].title,'Example film 2026');
  assert.equal((await response('/api/search?q=Example','search')).results[0].id,'cee_123');
  assert.equal((await response('/api/detail/123','detail')).id,'cee_123');
  const eps=await response('/api/episodes/123?title=Example','episodes');assert.equal(eps.episodes[0].episode,'2');assert.ok(eps.episodes[0].rootSeries.startsWith('cee_series_'));
  assert.equal((await response('/api/browse?category=1&page=2','browse')).results[0].id,'cee_123');
  assert.equal((await response('/api/subtitles/123','subtitles')).subtitles[0].mime,'text/vtt');
  await response('/api/related/999','related');
  const sources=await response('/api/sources/123','sources',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rejected:[]})});
  assert.equal(sources.qualities[0].height,720);assert.equal(sources.qualities[0].name,'CEE · 720p');
});
test('validates IDs, pages and kinds without calling upstream',async()=>{
  for(const route of ['/api/detail/not-a-post','/api/browse?category=1&page=0','/api/home?kind=3','/api/episodes/123/more?seasonId=1&currentPostId=123&page=-1'])assert.equal((await fetch(base+route)).status,400);
});
test('configured API key is required, and responses are not cached by HTTP clients',async()=>{
  process.env.CEE_API_KEY='test-key';
  try {
    assert.equal((await fetch(base+'/api/health')).status,401);
    const res=await fetch(base+'/api/health',{headers:{'x-api-key':'test-key'}});assert.equal(res.status,200);assert.equal(res.headers.get('cache-control'),'no-store');
  } finally {delete process.env.CEE_API_KEY;}
});

test('movie sections do not mislabel series categories and deep-link search keeps page identity',async()=>{
 categoryRecords=[{id:10,name:'أفلام أجنبي',count:1},{id:20,name:'مسلسلات عربية',count:1}];requested.length=0;
 try {
  const data=await response('/api/home?kind=1');
  assert.ok(data.rows.some(r=>r.section?.categoryId===10));assert.ok(!data.rows.some(r=>r.section?.categoryId===20));
  assert.ok(!requested.some(u=>u.includes('categories=20')));
  const result=await response('/api/search?q='+encodeURIComponent('https://cinamana.cc/watch=123/'));assert.equal(result.results[0].id,'cee_123');
 } finally {categoryRecords=[];}
});
