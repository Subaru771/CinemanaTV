const express = require('express');
const { page, post, absolute, requestScope } = require('./ceeClient');
const P = require('./parse');
const sources = require('./sources');

const app = express();
app.disable('x-powered-by');
const hops = Number(process.env.TRUST_PROXY_HOPS || 0);
if (Number.isInteger(hops) && hops > 0 && hops <= 2) app.set('trust proxy', hops);
app.use(require('express-rate-limit').rateLimit({ windowMs: 60000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.json({ limit: '128kb', inflate: false }));
let active = 0;
app.use((req, res, next) => {
  if (active >= 16) return res.status(503).json({ error: 'SERVER_BUSY' });
  active++;
  const controller = new AbortController();
  const timer = setTimeout(() => { controller.abort(); if (!res.headersSent) res.status(504).json({ error: 'UPSTREAM_TIMEOUT' }); }, 35000);
  res.once('close', () => { clearTimeout(timer); active--; if (!res.writableFinished) controller.abort(); });
  requestScope.run(controller.signal, next);
});
app.use((req, res, next) => {
  res.set('Cache-Control', 'no-store'); next();
});

// Simple API-key gate so randoms can't run your server as a free open proxy. Optional: if
// CEE_API_KEY isn't set, the check is skipped (fine for local dev, not for a public deployment).
app.use((req, res, next) => {
  const required = process.env.CEE_API_KEY;
  if (!required) return next();
  if (req.get('x-api-key') === required) return next();
  res.status(401).json({ error: 'Missing or invalid x-api-key.' });
});

function asyncRoute(fn) {
  return (req, res) => {
    fn(req, res).catch((err) => {
      if (!res.headersSent && !res.destroyed) res.status(502).json({ error: 'UPSTREAM_FAILURE', message: 'The provider could not supply this resource.' });
    });
  };
}

app.get(['/health', '/api/health'], (_req, res) => res.json({ ok: true, schema: 1, provider: 'cee-website', version: '1.1.0' }));
app.param('id', (req, res, next, id) => /^(?:cee_)?[0-9]{1,12}$/.test(id) ? next() : res.status(400).json({ error: 'Invalid post id.' }));

/** GET /api/home?kind=1|2 (omit kind for both). Mirrors CeeHtmlCatalog.home(). */
app.get('/api/home', asyncRoute(async (req, res) => {
  const kind = req.query.kind ? Number(req.query.kind) : null;
  if (kind !== null && ![1,2].includes(kind)) return res.status(400).json({ error: 'Invalid kind.' });

  const listing = async (path, expectedKind) => {
    try {
      return P.cards(await page(absolute(path)), expectedKind);
    } catch {
      return [];
    }
  };
  const categoriesRaw = await (async () => {
    try {
      const html = await page(absolute('wp-json/wp/v2/categories?per_page=100&hide_empty=true'));
      return JSON.parse(html);
    } catch {
      return [];
    }
  })();

  const [movies, episodes] = await Promise.all([
    kind !== 2 ? listing('movies/', '1') : Promise.resolve([]),
    kind !== 1 ? listing('series/', '2') : Promise.resolve([]),
  ]);

  const rows = [];
  if (movies.length) rows.push({ title: 'Latest movies', items: movies });
  const series = episodes.map(P.parentOf).filter((v, i, arr) => arr.findIndex((o) => o.id === v.id) === i);
  if (series.length) rows.push({ title: 'Recently updated series', items: series });

  const premieres = episodes.filter((v) => v.episode === '1').map(P.parentOf)
    .filter((v, i, arr) => arr.findIndex((o) => o.id === v.id) === i);
  if (premieres.length) rows.push({ title: 'Season premieres', items: premieres });
  if (episodes.length) rows.push({ title: 'Latest episodes', items: episodes });

  const known = {
    'أفلام أجنبي': ['International movies', 1], 'أفلام هندي': ['Indian cinema', 1],
    'مسلسلات عربية': ['Arabic series', 2], 'مسلسلات تركية': ['Turkish series', 2],
    'مسلسلات أجنبي': ['International series', 2], 'مسلسلات آسيوية': ['Asian series', 2], 'أنمي': ['Anime', null]
  };
  const categories = (Array.isArray(categoriesRaw) ? categoriesRaw : []).map(c => {
    const entry = known[require('cheerio').load(c.name || '').text().trim()];
    return entry && Number.isInteger(c.id) && c.id > 0 ? { ...c, title: entry[0], kind: entry[1] } : null;
  }).filter(c => c && (kind === null || c.kind === null || c.kind === kind)).slice(0, 12);
  const categoryRows = await Promise.all(categories.map(async c => {
    try {
      const items = (await collection(c.id, 1, c.kind)).filter(v => kind === null || v.kind === String(kind));
      return items.length ? { title: c.title, items,
        section: { key: `category_${c.id}`, title: c.title, kind: c.kind, categoryId: c.id, totalPosts: c.count || 0 } } : null;
    } catch { return null; }
  }));
  rows.push(...categoryRows.filter(Boolean));
  if (!rows.length) return res.status(502).json({ error: 'CEE_LAYOUT_MISMATCH', message: 'No recognizable catalogue rows were returned.' });
  const featured = movies.length ? movies : series.length ? series : rows.flatMap(r => r.items);
  res.json({ featured: featured.slice(0, 6), rows, categoriesSeen: categories.length });
}));

/** GET /api/search?q=... */
app.get('/api/search', asyncRoute(async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 250);
  if (q.startsWith('https://')) {
    let target; try { target = new URL(q); } catch { return res.status(400).json({ error: 'Invalid watch page.' }); }
    const id = P.pageId(q);
    if (!id || target.origin !== new URL(P.BASE).origin || target.username || target.password) return res.status(400).json({ error: 'Use a provider watch-page URL.' });
    return res.json({ results: [P.detail(await page(absolute(`watch=${id}/`)), { id: `cee_${id}`, providerPageId: id, title: '' })] });
  }
  const url = q ? `${P.BASE}?s=${encodeURIComponent(q)}` : `${P.BASE}main`;
  const results = P.cards(await page(url)).map((v) => (v.kind === '2' ? P.parentOf(v) : v));
  const seen = new Set();
  res.json({ results: results.filter((v) => (seen.has(v.id) ? false : seen.add(v.id))) });
}));

/** GET /api/detail/:id  (id = numeric CEE post id, or cee_<id>) */
app.get('/api/detail/:id', asyncRoute(async (req, res) => {
  const raw = req.params.id.replace(/^cee_/, '');
  const fallback = { id: `cee_${raw}`, title: req.query.title || '', kind: req.query.kind || '1', providerPageId: raw };
  const html = await page(absolute(`watch=${raw}/`));
  res.json(P.detail(html, fallback));
}));

/** GET /api/episodes/:id — first page + pagination cursors for remaining seasons. */
app.get('/api/episodes/:id', asyncRoute(async (req, res) => {
  const raw = req.params.id.replace(/^cee_/, '').replace(/^series_/, '');
  const fallbackTitle = req.query.title || '';
  const html = await page(absolute(`watch=${raw}/`));
  const parent = P.parentOf(P.detail(html, { id: `cee_${raw}`, title: fallbackTitle, kind: '2', providerPageId: raw }));
  res.json({ episodes: P.episodesFromHtml(html, parent), cursors: P.episodeCursors(html, { id: `cee_${raw}`, providerPageId: raw }) });
}));

/** GET /api/episodes/:id/more?seasonId=&page=&currentPostId=&season= — one pagination chunk. */
app.get('/api/episodes/:id/more', asyncRoute(async (req, res) => {
  const { seasonId, page: pageNum, currentPostId, season: seasonNumber, title } = req.query;
  if (!Number.isInteger(Number(pageNum)) || Number(pageNum) < 1 || Number(pageNum) > 1000 || !/^[0-9]{1,12}$/.test(String(seasonId)) || !/^[0-9]{1,12}$/.test(String(currentPostId))) {
    return res.status(400).json({ error: 'Invalid seasonId/currentPostId.' });
  }
  const html = await post(absolute('wp-admin/admin-ajax.php'),
    { action: 'load_more_episodes', season_id: seasonId, page: pageNum, current_post_id: currentPostId },
    absolute(`watch=${currentPostId}/`));
  const parent = P.parentOf({ id: `cee_${currentPostId}`, title: title || '', poster: null, year: null, providerPageId: String(currentPostId) });
  res.json({ episodes: P.episodeChunk(html, parent, Number(seasonNumber) || 1) });
}));

/** GET /api/sources/:id — resolved playable qualities for a single title/episode. */
app.all('/api/sources/:id', asyncRoute(async (req, res) => {
  const raw = req.params.id.replace(/^cee_/, '');
  if (!['GET','POST'].includes(req.method)) return res.sendStatus(405);
  const rejected = req.body?.rejected || [];
  if (!Array.isArray(rejected) || rejected.length > 24 || rejected.some(v => typeof v !== 'string' || v.length > 4096)) return res.status(400).json({ error: 'Invalid exclusions.' });
  res.json(await sources.resolve(raw, rejected));
}));

async function collection(category, pageNumber, kind) {
  const url = absolute(`wp-json/wp/v2/posts?per_page=24&page=${pageNumber}&categories=${category}&_embed=wp:featuredmedia`);
  const records = JSON.parse(await page(url));
  if (!Array.isArray(records)) throw new Error('Invalid provider collection.');
  return records.filter(v => /^[0-9]{1,12}$/.test(String(v.id))).map(v => {
    const $ = require('cheerio');
    const item = P.card(String(v.id), $.load(v.title?.rendered || '').text(), v._embedded?.['wp:featuredmedia']?.[0]?.source_url || null, kind ? String(kind) : undefined);
    return item.kind === '2' ? P.parentOf(item) : item;
  });
}
app.get('/api/browse', asyncRoute(async (req, res) => {
  const category = Number(req.query.category), number = Number(req.query.page || 1), kind = req.query.kind ? Number(req.query.kind) : null;
  if (!Number.isSafeInteger(category) || category < 1 || !Number.isInteger(number) || number < 1 || number > 10000 || (kind !== null && ![1,2].includes(kind))) return res.status(400).json({ error: 'Invalid collection.' });
  res.json({ results: await collection(category, number, kind) });
}));
app.get('/api/related/:id', asyncRoute(async (req, res) => {
  const id = req.params.id.replace(/^cee_/, '');
  res.json({ results: P.cards(await page(absolute(`watch=${id}/`))).filter(v => v.id !== `cee_${id}`).map(v => v.kind === '2' ? P.parentOf(v) : v) });
}));
app.get('/api/subtitles/:id', asyncRoute(async (req, res) => {
  const html = await page(absolute(`watch=${req.params.id.replace(/^cee_/, '')}/`), true);
  const $ = require('cheerio').load(html);
  const subtitles = [];
  $('track[src]').each((_, el) => {
    try {
      const u = new URL($(el).attr('src'), absolute('/'));
      if (u.protocol !== 'https:' || u.username || u.password || !/\.(vtt|srt)$/i.test(u.pathname)) return;
      subtitles.push({ label: $(el).attr('label') || $(el).attr('srclang') || 'Subtitle', url: u.toString(), mime: u.pathname.toLowerCase().endsWith('.vtt') ? 'text/vtt' : 'application/x-subrip' });
    } catch {}
  });
  res.json({ subtitles });
}));
const port = process.env.PORT || 8787;
if (require.main === module) {
  if (process.env.NODE_ENV === 'production' && (!process.env.CEE_API_KEY || process.env.CEE_API_KEY.length < 24)) throw new Error('Production needs a CEE_API_KEY of at least 24 characters.');
  const server = app.listen(port, process.env.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1', () => console.log(`cee-api-server listening on :${port}`));
  server.requestTimeout = 40000; server.headersTimeout = 10000;
}
module.exports = app;
