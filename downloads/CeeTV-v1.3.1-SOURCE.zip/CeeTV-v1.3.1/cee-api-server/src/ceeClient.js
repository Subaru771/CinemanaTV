const { LRUCache } = require('lru-cache');
const { BASE } = require('./parse');
const { lookup } = require('node:dns/promises');
const ipaddr = require('ipaddr.js');
const hosts = new Set([new URL(BASE).hostname, 'cinamana.cc', 'mp4plus.org', 'cdnplus.sbs']);
const { AsyncLocalStorage } = require('node:async_hooks');
const requestScope = new AsyncLocalStorage();
async function validateTarget(raw) {
  const u = new URL(raw);
  if (u.protocol !== 'https:' || u.username || u.password || (u.port && u.port !== '443') || !hosts.has(u.hostname)) throw new Error('Unsupported upstream address.');
  const addresses = await lookup(u.hostname, { all: true });
  if (!addresses.length || addresses.some(a => ipaddr.process(a.address).range() !== 'unicast')) throw new Error('Upstream address is not public.');
  return u;
}
async function fetchWithTimeout(raw, init = {}, validator = validateTarget, fetcher = fetch) {
  const parent = requestScope.getStore();
  const signal = parent ? AbortSignal.any([parent, AbortSignal.timeout(15000)]) : AbortSignal.timeout(15000); let url = raw;
  for (let redirects = 0; redirects <= 4; redirects++) {
    await validator(url);
    const res = await fetcher(url, { ...init, signal, redirect: 'manual' });
    if ([301,302,303,307,308].includes(res.status)) {
      const location = res.headers.get('location'); await res.body?.cancel();
      if (!location || redirects === 4) throw new Error('Invalid upstream redirect.');
      url = new URL(location, url).toString(); continue;
    }
    if (!res.ok) { await res.body?.cancel(); throw new Error(`CEE source HTTP ${res.status}.`); }
    let size = 0; const chunks = [];
    for await (const chunk of res.body) { size += chunk.length; if (size > 2000000) throw new Error('CEE source page is too large.'); chunks.push(chunk); }
    return Buffer.concat(chunks).toString('utf8');
  }
}
function createPageCache(fetcher = fetchWithTimeout) {
  const localCache = new LRUCache({ max: 300, maxSize: 32 * 1024 * 1024, sizeCalculation: v => Buffer.byteLength(v), ttl: 120000 });
  const localPending = new Map();
  async function cachedPage(url, fresh = false) {
    if (!fresh && localCache.has(url)) return localCache.get(url);
    if (localPending.has(url)) return localPending.get(url);
    if (localPending.size >= 64) throw new Error('Upstream lookup capacity reached.');
    const task = fetcher(url, { headers: { 'User-Agent': 'Mozilla/5.0 (CeeTV-server)', Referer: BASE } })
      .then(body => { if (!fresh) localCache.set(url, body); return body; }).finally(() => localPending.delete(url));
    localPending.set(url, task); return task;
  }
  return { page: cachedPage, pageCache: localCache };
}
const { page, pageCache } = createPageCache();

async function post(url, form, referer) {
  return fetchWithTimeout(url, { method: 'POST', body: new URLSearchParams(form), headers: {
    'User-Agent': 'Mozilla/5.0 (CeeTV-server)', 'Content-Type': 'application/x-www-form-urlencoded', ...(referer ? { Referer: referer } : {}) } });
}
function absolute(path) { return new URL(path, BASE).toString(); }
module.exports = { page, post, absolute, pageCache, validateTarget, requestScope, fetchWithTimeout, createPageCache };
