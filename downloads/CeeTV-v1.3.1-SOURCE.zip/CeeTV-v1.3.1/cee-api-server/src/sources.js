const cheerio = require('cheerio');
const { page, post, absolute } = require('./ceeClient');

const SOURCE_PATTERN = /\{\s*file\s*:\s*["']([^"']+)["']\s*,\s*label\s*:\s*["']([^"']*)["']\s*\}/g;
const MASTER_PATTERN = /\b(?:const|let|var)\s+masterUrl\s*=\s*["']([^"']+)["']/;
const DECLARED_U_PATTERN = /\b(?:const|let|var)\s+u\s*=\s*["']([^"']+)["']/;
const FILE_PATTERN = /\bfile\s*:\s*["']([^"']+)["']/g;

function allowedRelayTarget(u) {
  return u.protocol === 'https:' && (!u.port || u.port === '443') && !u.username && !u.password && (u.hostname.endsWith('.scdns.io') || u.hostname.endsWith('.downet.net')) &&
    u.pathname.toLowerCase().endsWith('.m3u8');
}

/** Same allow-list as the Android app's CeeAlternativeSource.allowedMedia(). Keep both in sync:
 *  this is what stops the server (and, until the app switches over, the app) from handing the
 *  player an arbitrary URL pulled out of page script. */
function allowedMedia(u) {
  if (u.protocol !== 'https:' || (u.port && u.port !== '443') || u.username || u.password) return false;
  if (allowedRelayTarget(u)) return true;
  if (u.hostname === 'stream.cinemana.cc' && u.pathname === '/cinema-stream') {
    const inner = u.searchParams.get('url');
    if (!inner) return false;
    try { return allowedRelayTarget(new URL(inner)); } catch { return false; }
  }
  const okHost = u.hostname.endsWith('.cdnz.quest') || u.hostname.endsWith('.brqz.online') || u.hostname.endsWith('.downet.net') || u.hostname === 'fvideo6d.ddns.me';
  if (!okHost) return false;
  const p = u.pathname.toLowerCase();
  return p.endsWith('.mp4') || p.endsWith('.m3u8') || p.endsWith('.mpd');
}

function tryUrl(raw) {
  try { return new URL(raw.replace(/\\\//g, '/')); } catch { return null; }
}

/** Decodes the common "eval(function(p,a,c,k,e,d)...)" packer's string dictionary.
 *  Only ever substitutes plain tokens back into a string — this NEVER calls eval() or runs
 *  any of the page's JavaScript. */
function unpack(html) {
  const marker = html.indexOf("}('");
  if (marker < 0) return html;
  let cursor = marker + 2;
  function quoted() {
    if (html[cursor++] !== "'") return null;
    let out = '';
    while (cursor < html.length) {
      const ch = html[cursor++];
      if (ch === "'") return out;
      if (ch === '\\' && cursor < html.length) {
        const next = html[cursor++];
        if (next !== "'" && next !== '\\') out += '\\';
        out += next;
      } else out += ch;
    }
    return null;
  }
  function commaNumber() {
    if (html[cursor++] !== ',') return null;
    const start = cursor;
    while (/[0-9]/.test(html[cursor] || '')) cursor++;
    const s = html.slice(start, cursor);
    return s ? parseInt(s, 10) : null;
  }
  let payload = quoted();
  if (payload == null) return html;
  const radix = commaNumber();
  if (!(radix >= 2 && radix <= 36)) return html;
  const count = commaNumber();
  if (!(count >= 1 && count <= 2000)) return html;
  if (html[cursor++] !== ',') return html;
  const wordsRaw = quoted();
  if (wordsRaw == null) return html;
  if (!html.startsWith(".split('|')", cursor)) return html;
  const words = wordsRaw.split('|');
  if (words.length !== count) return html;
  for (let index = count - 1; index >= 0; index--) {
    if (words[index]) {
      const token = new RegExp(`\\b${index.toString(radix)}\\b`, 'g');
      payload = payload.replace(token, words[index]);
      if (payload.length > 2_000_000) return html;
    }
  }
  return payload;
}

function stripComments(js) {
  let out = '', quote = null;
  for (let i = 0; i < js.length; i++) {
    const c = js[i], next = js[i + 1];
    if (quote) { out += c; if (c === '\\') out += js[++i] || ''; else if (c === quote) quote = null; }
    else if (c === '"' || c === "'" || c === '`') { quote = c; out += c; }
    else if (c === '/' && next === '/') { while (i < js.length && js[i] !== '\n') i++; out += '\n'; }
    else if (c === '/' && next === '*') { i += 2; while (i < js.length && !(js[i] === '*' && js[i + 1] === '/')) i++; i++; out += ' '; }
    else out += c;
  }
  return out;
}
function sourceObjects(js) {
  const out = [];
  for (const object of js.matchAll(/\{[^{}]{1,8192}\}/g)) {
    const fields = {};
    for (const m of object[0].matchAll(/["']?(file|label)["']?\s*:\s*(["'])((?:\\.|(?!\2)[^\\])*?)\2/g)) {
      fields[m[1]] = m[3].replace(/\\u([0-9a-f]{4})/gi, (_, n) => String.fromCharCode(parseInt(n, 16))).replace(/\\x([0-9a-f]{2})/gi, (_, n) => String.fromCharCode(parseInt(n, 16))).replace(/\\([\\/"'])/g, '$1');
    }
    if (fields.file) out.push([null, fields.file, fields.label || '']);
  }
  return out;
}

function qualitiesFromPlayerHtml(html) {
  const unpacked = unpack(html);
  const $ = cheerio.load(unpacked);
  const scripts = $('script:not([src])');
  const scriptText = scripts.length ? scripts.map((_, el) => $(el).html()).get().join('\n') : unpacked;
  const decoded = stripComments(scriptText);

  const out = [];
  const seenUrls = new Set();
  const push = (url, label, mime) => {
    const s = url.toString();
    if (seenUrls.has(s + ":0")) return;
    seenUrls.add(s + ":0");
    out.push({ height: 0, url: s, name: label, mimeType: mime || null });
  };

  const declaredM = DECLARED_U_PATTERN.exec(decoded);
  if (declaredM) {
    const u = tryUrl(declaredM[1]);
    if (u && allowedMedia(u) && u.pathname.toLowerCase().endsWith('.m3u8') && /\.loadSource\(\s*u\s*\)/.test(decoded)) {
      push(u, 'CEE · Auto (HLS)', 'application/x-mpegURL');
    }
  }

  for (const m of decoded.matchAll(FILE_PATTERN)) {
    const u = tryUrl(m[1]);
    if (u && allowedMedia(u) && u.pathname.toLowerCase().endsWith('.m3u8')) push(u, 'CEE · Auto (HLS)', 'application/x-mpegURL');
  }

  for (const m of sourceObjects(decoded)) {
    const u = tryUrl(m[1]);
    if (!u || !allowedMedia(u)) continue;
    const labelText = require('./textParse').digits(m[2] || '');
    const heightMatch = /\b[0-9]{2,5}[x×]([0-9]{2,5})\b/i.exec(labelText) || /\b([0-9]{3,4})\s*p\b/i.exec(labelText) || /\b([0-9]{3,4})(?=\s|$)/.exec(labelText);
    const declaredHeight = heightMatch ? parseInt(heightMatch[1], 10) : 0;
    const height = declaredHeight >= 144 && declaredHeight <= 8640 ? declaredHeight : 0;
    const label = height > 0 ? `CEE · ${height}p` : 'CEE · Auto';
    const mime = (u.hostname === 'stream.cinemana.cc' || allowedRelayTarget(u)) ? 'application/x-mpegURL' : null;
    const key = u.toString() + ":" + height;
    if (seenUrls.has(key)) continue;
    seenUrls.add(key);
    out.push({ height, url: u.toString(), name: label, mimeType: mime });
  }

  const masterM = MASTER_PATTERN.exec(decoded);
  if (masterM) {
    const u = tryUrl(masterM[1]);
    if (u && allowedMedia(u)) {
      const path = u.pathname.toLowerCase();
      push(u, path.endsWith('.mp4') ? 'CEE · Original file' : path.endsWith('.mpd') ? 'CEE · Auto (DASH)' : 'CEE · Direct HLS',
        path.endsWith('.mp4') ? 'video/mp4' : path.endsWith('.mpd') ? 'application/dash+xml' : 'application/x-mpegURL');
      if (allowedRelayTarget(u)) {
        const relay = new URL('https://stream.cinemana.cc/cinema-stream');
        relay.searchParams.set('url', u.toString());
        push(relay, 'CEE · Auto (HLS)', 'application/x-mpegURL');
      }
    }
  }

  out.sort((a, b) => b.height - a.height);
  return out;
}

const ALLOWED_PAGE_HOSTS = new Set(['cinamana.cc', 'mp4plus.org', 'cdnplus.sbs']);

function isVkPlayer(u) {
  return u.protocol === 'https:' && !u.username && !u.password &&
    (u.hostname === 'vkvideo.ru' || u.hostname === 'vk.com') && u.pathname === '/video_ext.php' &&
    /^-?[0-9]{1,20}$/.test(u.searchParams.get('oid') || '') && /^[0-9]{1,20}$/.test(u.searchParams.get('id') || '');
}

/** Resolves a CEE watch page (postId) to a list of playable qualities. */
async function resolve(postId, rejected = [], fetchPage = page, fetchPost = post) {
  if (!/^[0-9]{1,12}$/.test(postId)) throw new Error('Invalid CEE post id.');
  const watch = fetchPage(absolute(`watch=${postId}/`), true).catch(() => '');
  const slots = await Promise.allSettled([0, 1, 2].map(server => fetchPost(
    absolute('wp-content/themes/EEE/Inc/Ajax/Single/Server.php'), { post_id: postId, server }, absolute(`watch=${postId}/`))));
  const slotHtml = slots.filter(v => v.status === 'fulfilled').map(v => v.value).join('\n');
  const watchHtml = slotHtml + '\n' + await watch;
  const $ = cheerio.load(watchHtml);
  const candidates = $('iframe[src]').map((_, el) => $(el).attr('src')).get();
  $('a[href]').each((_, el) => { const href = $(el).attr('href'); if (href && href.includes('/embed-')) candidates.push(href); });
  const collected = qualitiesFromPlayerHtml(slotHtml); let vk = null;
  const approved = [...new Set(candidates)].map(raw => {
    let embed = tryUrl(new URL(raw, absolute('/')).toString());
    if (embed?.hostname === 'cinamana.cc' && embed.pathname === '/acm.php') embed = tryUrl(embed.searchParams.get('url') || '');
    if (embed && isVkPlayer(embed)) return embed;
    return embed && embed.protocol === 'https:' && !embed.port && !embed.username && !embed.password && ALLOWED_PAGE_HOSTS.has(embed.hostname) && /\/embed-[A-Za-z0-9]+\.html$/.test(embed.pathname) ? embed : null;
  }).filter(Boolean).slice(0, 8);
  for (const embed of approved) {
    if (isVkPlayer(embed)) { vk ||= embed.toString(); continue; }
    try { collected.push(...qualitiesFromPlayerHtml(await fetchPage(embed.toString(), true))); } catch { /* try remaining provider routes */ }
  }
  const seen = new Set();
  const qualities = collected.filter(q => { const key = `${q.url}:${q.height}`; if (rejected.includes(q.url) || seen.has(key)) return false; seen.add(key); return true; });
  if (!qualities.length && !vk) throw new Error('No usable provider source was found.');
  return { vkPlayerUrl: qualities.length ? null : vk, qualities };
}
module.exports = { resolve, unpack, qualitiesFromPlayerHtml, allowedMedia, stripComments };
