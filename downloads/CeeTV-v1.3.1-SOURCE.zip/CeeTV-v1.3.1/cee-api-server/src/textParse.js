// Ported from the Android app's data/CeeCatalog.kt (CeeCatalogParser). Logic kept in lockstep
// with that file on purpose — if you change season/episode parsing here, check it there too
// (or, once this server is live, remove the on-device parser and let the app trust this JSON).

const YEAR = /\b(?:19|20)[0-9]{2}\b/g;
const EPISODE_PATTERN = /(?:الحلقة|حلقة|episode|ep)\s*[-:]?\s*([0-9]+)|\bS[0-9]+E([0-9]+)\b/i;
const SEASON_PATTERN = /(?:الموسم|موسم|season)\s*([^\s–—:]+)|\bS([0-9]+)E[0-9]+\b/i;

const ORDINALS = {
  'الاول': 1, 'الأول': 1, 'الأولى': 1, 'الاولى': 1, 'الثاني': 2,
  'الثالث': 3, 'الرابع': 4, 'الخامس': 5, 'السادس': 6, 'السابع': 7, 'الثامن': 8, 'التاسع': 9, 'العاشر': 10,
};

/** Arabic-Indic and Extended Arabic-Indic digits -> ASCII. */
function digits(s) {
  return [...s].map((ch) => {
    const cp = ch.codePointAt(0);
    if (cp >= 0x0660 && cp <= 0x0669) return String(cp - 0x0660);
    if (cp >= 0x06f0 && cp <= 0x06f9) return String(cp - 0x06f0);
    return ch;
  }).join('');
}

function number(s) {
  const n = parseInt(digits(s).trim(), 10);
  if (!Number.isNaN(n)) return n;
  return ORDINALS[s.trim()] ?? null;
}

function season(raw) {
  const text = digits(raw).trim();
  const plain = parseInt(text, 10);
  if (!Number.isNaN(plain) && plain > 0) return plain;

  const m = /(?:الموسم|موسم|season)\s*[:#-]?\s*(.+)/i.exec(text);
  if (m) {
    const leading = /^[0-9]+/.exec(m[1]);
    if (leading) {
      const v = parseInt(leading[0], 10);
      if (v > 0) return v;
    }
    const normalized = m[1]
      .replace(/[أإآ]/g, 'ا')
      .replace(/[\u064B-\u065F\u0670]/g, '');
    const units = ['الاول', 'الثاني', 'الثالث', 'الرابع', 'الخامس', 'السادس', 'السابع', 'الثامن', 'التاسع'];
    const names = new Map();
    for (let n = 3; n <= 9; n++) names.set(units[n - 1] + ' عشر', 10 + n);
    const tens = ['العشرون', 'الثلاثون', 'الاربعون', 'الخمسون', 'الستون', 'السبعون', 'الثمانون', 'التسعون'];
    tens.forEach((t, i) => {
      names.set(t, (i + 2) * 10);
      names.set(t.replace('ون', 'ين'), (i + 2) * 10);
      for (let n = 1; n <= 9; n++) {
        const unit = n === 1 ? 'الحادي' : units[n - 1];
        names.set(unit + ' و' + t, (i + 2) * 10 + n);
        names.set(unit + ' و' + t.replace('ون', 'ين'), (i + 2) * 10 + n);
      }
    });
    const compact = normalized.replace(/\s/g, '');
    const sorted = [...names.entries()].sort((a, b) => b[0].length - a[0].length);
    for (const [key, value] of sorted) {
      if (compact.startsWith(key.replace(/\s/g, ''))) return value;
    }
  }
  const sm = SEASON_PATTERN.exec(text);
  if (sm) {
    const candidate = sm[1] ?? sm[2];
    if (candidate) {
      const v = number(candidate);
      if (v != null) return v;
    }
  }
  return 1;
}

function episode(raw) {
  const text = digits(raw);
  const m = EPISODE_PATTERN.exec(text);
  if (!m) return 0;
  const v = parseInt(m[1] ?? m[2] ?? '', 10);
  return Number.isNaN(v) ? 0 : v;
}

function seriesTitle(raw) {
  const markers = ['الموسم', 'الحلقة', 'حلقة', 'season', 'episode'];
  let at = raw.length;
  for (const marker of markers) {
    const idx = raw.toLowerCase().indexOf(marker.toLowerCase());
    if (idx >= 0 && idx < at) at = idx;
  }
  return raw.slice(0, at).trim().replace(/^[-–—:\s]+|[-–—:\s]+$/g, '')
    .replace(/^مسلسل\s*/, '').replace(/^انمي\s*/, '').replace(/^أنمي\s*/, '').trim();
}

function latestYear(title) {
  const matches = [...digits(title).matchAll(YEAR)];
  return matches.length ? matches[matches.length - 1][0] : null;
}

module.exports = { digits, number, season, episode, seriesTitle, latestYear };
