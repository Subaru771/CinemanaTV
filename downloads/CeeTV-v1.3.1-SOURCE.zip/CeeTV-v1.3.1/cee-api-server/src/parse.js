const cheerio = require('cheerio');
const { season, episode, seriesTitle, latestYear } = require('./textParse');

const BASE = process.env.CEE_BASE_URL || 'https://cinamana.cc/';

function pageId(href) {
  try {
    const u = new URL(href, BASE);
    const m = /^\/watch=([0-9]{1,12})\/?$/.exec(u.pathname);
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

function safeHttpsUrl(raw) {
  if (!raw) return null;
  try {
    const u = new URL(raw, BASE);
    if (u.protocol !== 'https:' || u.username || u.password) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function posterFor($, el) {
  const img = $(el).find('img[data-src], img[src]').first();
  if (img.length) {
    const raw = img.attr('data-src') || img.attr('src');
    const url = safeHttpsUrl(raw);
    if (url) return url;
  }
  const bg = $(el).find('[style*="background-image"]').first().attr('style') || '';
  const m = /url\((['"]?)(.*?)\1\)/.exec(bg);
  return m ? safeHttpsUrl(m[2]) : null;
}

/** One catalogue card -> the same shape the Android app's `Video` model expects on the wire. */
function card(id, title, image, expectedKind) {
  const ep = episode(title);
  const isSeries = expectedKind === '2' ||
    (expectedKind !== '1' && (ep > 0 || title.includes('مسلسل') || title.includes('الموسم')));
  return {
    id: `cee_${id}`,
    kind: isSeries ? '2' : '1',
    title,
    year: latestYear(title),
    poster: image,
    season: isSeries && ep > 0 ? String(season(title)) : null,
    episode: isSeries && ep > 0 ? String(ep) : null,
    providerPageId: id,
  };
}

/** Parses a listing/search/home page into cards. Mirrors CeeCatalogParser.cards(). */
function cards(html, expectedKind) {
  const $ = cheerio.load(html, { baseURI: BASE });
  const seen = new Set();
  const out = [];
  $('a[href]').each((_, el) => {
    if ($(el).hasClass('cn-mega-item')) return;
    const href = $(el).attr('href');
    const id = pageId(href);
    if (!id) return;
    const title = $(el).find('h2,h3').first().text().trim();
    if (!title) return;
    const c = card(id, title, posterFor($, el), expectedKind);
    if (seen.has(c.id)) return;
    seen.add(c.id);
    out.push(c);
    if (out.length >= 180) return false;
  });
  return out;
}

function parentOf(video) {
  const name = seriesTitle(video.title);
  // Stable id for a series derived from its title/year, same recipe as the Kotlin side
  // (sha256(name|year) truncated), so ids line up if both parsers ever run side by side.
  const crypto = require('crypto');
  const key = crypto.createHash('sha256').update(`${name.toLowerCase()}|${video.year || ''}`).digest('hex').slice(0, 16);
  return { ...video, id: `cee_series_${key}`, kind: '2', title: name, season: null, episode: null };
}

function postId(video) {
  const raw = video.providerPageId || video.id.replace(/^cee_/, '');
  if (!/^[0-9]{1,12}$/.test(raw)) throw new Error('CEE title is missing its source page identity.');
  return raw;
}

function detail(html, fallback) {
  const $ = cheerio.load(html, { baseURI: BASE });
  const heading = $('h1').first().text().trim() || fallback.title;
  const image = safeHttpsUrl($('#watch-later-btn').attr('data-poster')) ||
    safeHttpsUrl($('meta[property="og:image"]').attr('content')) || fallback.poster;
  const parsed = card(postId(fallback), heading, image, fallback.kind);

  const description = $('[itemprop=description], .story, .StoryArea, .post-story').first().text().trim() ||
    $('meta[property="og:description"]').attr('content') || null;

  const imdb = new Set();
  $('a[href*="imdb.com/title/"]').each((_, el) => {
    const m = /title\/(tt[0-9]+)/.exec($(el).attr('href') || '');
    if (m) imdb.add(m[1]);
  });
  const imdbId = imdb.size === 1 ? [...imdb][0] : null;

  let tags = [];
  $('script:not([src])').each((_, el) => {
    const text = $(el).html() || '';
    if (!text.includes('const postData =')) return;
    const m = /genres\s*:\s*(\[[^\]]*\])/.exec(text);
    if (!m) return;
    try {
      tags = JSON.parse(m[1]).map((t) => decodeURIComponent(String(t)).replace(/-/g, ' ')).filter(Boolean);
    } catch { /* leave tags empty on malformed JSON; never let one bad page fail the whole response */ }
  });

  const providerPlot = $('h4').filter((_, el) => $(el).text().trim() === 'القصة').first().next().text().trim() || null;
  const scoreMatches = [];
  $('span').each((_, el) => {
    const m = /^IMDb\s*([0-9]+(?:\.[0-9]+)?)$/.exec($(el).text().trim());
    if (m && Number(m[1]) >= 0 && Number(m[1]) <= 10) scoreMatches.push(m[1]);
  });
  const score = new Set(scoreMatches).size === 1 ? scoreMatches[0] : null;

  const result = {
    ...parsed,
    description: (providerPlot || description || '').slice(0, 2000) || fallback.description || null,
    imdbId: imdbId || fallback.imdbId || null,
    year: parsed.year || fallback.year || null,
    categories: tags.length ? tags : fallback.categories || [],
    rating: fallback.rating || null,
    stars: score || fallback.stars || null,
    season: parsed.season || fallback.season || null,
    episode: parsed.episode || fallback.episode || null,
  };
  if (String(fallback.id).startsWith('cee_series_')) {
    return { ...parentOf(result), id: fallback.id, title: fallback.title };
  }
  return { ...result, id: fallback.id, rootSeries: fallback.rootSeries || null };
}

function episodeCursors(html, video) {
  const $ = cheerio.load(html, { baseURI: BASE });
  const labels = {};
  $('.season-trigger[data-target]').each((_, el) => {
    labels[$(el).attr('data-target')] = $(el).text();
  });
  const out = [];
  const seen = new Set();
  $('.load-more-episodes[data-season][data-page]').each((_, el) => {
    const seasonId = $(el).attr('data-season');
    const page = parseInt($(el).attr('data-page'), 10);
    const current = $(el).attr('data-current') || postId(video);
    if (!/^[0-9]{1,12}$/.test(seasonId) || !(page >= 1 && page <= 1000) || !/^[0-9]{1,12}$/.test(current)) return;
    if (seen.has(seasonId)) return;
    seen.add(seasonId);
    const sectionId = $(el).closest('.season-wrapper').attr('id') || '';
    out.push({ season: season(labels[sectionId] || ''), seasonId, currentPostId: current, page });
  });
  return out;
}

function episodesFromHtml(html, parent) {
  const $ = cheerio.load(html, { baseURI: BASE });
  const labels = {};
  $('.season-trigger[data-target]').each((_, el) => {
    labels[$(el).attr('data-target')] = $(el).text();
  });
  const out = [];
  const seen = new Set();
  $('.season-wrapper').each((_, section) => {
    const s = season(labels[$(section).attr('id')] || '');
    $(section).find('.episodes-grid a[href]').each((_, link) => {
      const id = pageId($(link).attr('href'));
      if (!id) return;
      let ep = null;
      for (const attr of ['data-episode', 'data-episode-number']) {
        const raw = $(link).attr(attr);
        if (raw != null) {
          const n = parseInt(require('./textParse').digits(raw), 10);
          if (n > 0) { ep = n; break; }
        }
      }
      if (ep == null) ep = episode($(link).attr('title') || '') || null;
      if (!ep) ep = episode($(link).text() || '') || null;
      if (!ep) {
        $(link).find('span').each((_, span) => {
          const n = parseInt(require('./textParse').digits($(span).text()), 10);
          if (n > 0) ep = n;
        });
      }
      if (!ep) {
        const n = parseInt(require('./textParse').digits($(link).text()).trim(), 10);
        if (n > 0) ep = n;
      }
      if (!ep || ep <= 0) return;
      const vid = `cee_${id}`;
      if (seen.has(vid)) return;
      seen.add(vid);
      out.push({
        id: vid, kind: '2', title: `${parent.title} · S${s} E${ep}`,
        poster: parent.poster, year: parent.year, season: String(s), episode: String(ep),
        rootSeries: parent.id, rootSeriesInfo: parent, providerPageId: id,
      });
    });
  });
  out.sort((a, b) => (Number(a.season) - Number(b.season)) || (Number(a.episode) - Number(b.episode)));
  return out;
}

function episodeChunk(html, parent, seasonNumber) {
  const wrapped = `<button class="season-trigger" data-target="chunk">موسم ${seasonNumber}</button>` +
    `<div id="chunk" class="season-wrapper"><div class="episodes-grid">${html}</div></div>`;
  return episodesFromHtml(wrapped, parent);
}

module.exports = {
  BASE, pageId, cards, card, parentOf, postId, detail, episodeCursors, episodesFromHtml, episodeChunk,
};
