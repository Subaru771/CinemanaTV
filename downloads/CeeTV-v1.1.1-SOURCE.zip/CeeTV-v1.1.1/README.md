# Cee TV 1.1.1

Fixes native quality selection for adaptive streams: real decoder-supported Media3 video tracks are listed after preparation. Selecting a resolution sets a video-track override; Auto clears it and restores the normal cap. Numbered MP4 source choices remain available. A visible Quality button is reachable from the timeline and from the playback error pane. Preferred limits are labelled as maximums, not advertised as actual renditions.

Recovery refreshes URLs and excludes a failed route for that playback session, with two automatic refresh attempts. Network changes/manual retry clear those exclusions. Server lookup failures no longer stop mirror fallback immediately. A source-declared direct HLS candidate is considered only after relay failure and after a bounded master/variant check passes; a master responding HTTP 200 alone does not qualify. Failed direct checks remain briefly in memory, never in persistent preferences.

The uploaded Cinemana TV v1.4.17 source was reviewed as reference. Its cee.buzz API returned HTTP 503 for the three checked routes, and its own documentation says JSON response bodies/native compatibility were not verified. That backend was not substituted for the current CEE catalogue. Existing explicit MIME typing, marker seek handling, library, downloads, logo, channel and update features are retained.

UI changes include an explicit player Quality action, consistent green accents and contrast, simpler rendition rows, clean player titles and a layered featured-art layout. No universal video-availability claim is made. VK's official player keeps its own controls. A source with only one real quality does not gain invented resolutions.

Package app.cinemanatv.cee; versionCode 7; Android 8+. Build with JDK 17 / SDK 35: bash gradlew testDebugUnitTest assembleRelease. Optional provider checks use CEE_LIVE_TEST=1.
