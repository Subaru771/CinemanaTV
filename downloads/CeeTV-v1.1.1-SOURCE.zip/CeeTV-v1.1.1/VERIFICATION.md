# Verification

New regression checks cover supported resolution enumeration/deduplication, manual video overrides and return to Auto, source URL exclusion, HTTP-error mirror continuation, and refusing a direct master whose variant is unreadable. Existing player/download/catalogue/navigation tests are retained.

Live investigation: the declared HLS master and relay master responded HTTP 200; a direct child playlist returned HTTP 403, including with the public site headers. Therefore direct playback is not claimed to be verified for that title, and the app gates that fallback with a real variant check. The three checked cee.buzz API routes from the supplied reference returned HTTP 503. Provider availability remains a separate issue from the fixed quality chooser.

No physical TV testing was performed. The user did not yet identify a particular failing title in the installed build, so not all failures can be reproduced. Final deterministic results and signed artifact checks are recorded before publishing.

Final build: testDebugUnitTest and assembleRelease succeeded. 185 deterministic tests passed; seven optional provider tests were skipped. Manual live observations above remain failures where noted, not passing playback checks. Native ICU validation passed. Signed package/version and published file hashes are verified before delivery.
