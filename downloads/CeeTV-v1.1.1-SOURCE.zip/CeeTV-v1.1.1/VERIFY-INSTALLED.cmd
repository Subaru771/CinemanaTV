@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ADB=adb"
where adb >nul 2>&1
if errorlevel 1 if exist "%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe" set "ADB=%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"
"%ADB%" devices
if errorlevel 1 (
 echo ADB not found or cannot connect to TV.
 pause
 exit /b 1
)
echo.
echo Checking installed CinemanaTV package...
"%ADB%" shell dumpsys package app.cinemanatv.cee | findstr /i "versionName versionCode"
echo Expected versionName: 1.1.1
pause
