package app.cinemanatv.data

import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class CeeServerFallbackTest {
    private val vk = CeeAlternativeSource.NoPlayableStream("This CEE title uses VK Video, which is not supported by the native player.")

    @Test fun firstServerWinsWithoutTryingOthers() {
        val tried = mutableListOf<Int>()
        val result = CeeAlternativeSource.firstPlayable(4) { tried += it; "ok$it" }
        assertEquals("ok0", result)
        assertEquals(listOf(0), tried)
    }

    @Test fun vkOnDefaultServerFallsThroughToNextSlot() {
        val tried = mutableListOf<Int>()
        val result = CeeAlternativeSource.firstPlayable(4) { server ->
            tried += server
            if (server < 2) throw vk else "ok$server"
        }
        assertEquals("ok2", result)
        assertEquals(listOf(0, 1, 2), tried)
    }

    @Test fun whenNoSlotWorksTheDefaultServersErrorIsReported() {
        try {
            CeeAlternativeSource.firstPlayable<String>(3) { server ->
                throw if (server == 0) vk else CeeAlternativeSource.NoPlayableStream("other $server")
            }
            fail("expected failure")
        } catch (e: IOException) { assertTrue(e.message.orEmpty().contains("VK Video")) }
    }

    @Test fun failedServerDoesNotPreventTryingTheNextMirror() {
        val tried=mutableListOf<Int>()
        val result=CeeAlternativeSource.firstPlayable(4){server->
            tried+=server
            if(server==0)throw IOException("CEE source HTTP 503")
            "working"
        }
        assertEquals("working",result)
        assertEquals(listOf(0,1),tried)
    }

    @Test fun unsupportedEmbedFailuresRemainRetryable() {
        try {
            CeeAlternativeSource.embed("""<iframe src="https://unknown.example/player"></iframe>""")
            fail()
        } catch (e: CeeAlternativeSource.NoPlayableStream) { }
    }
}
