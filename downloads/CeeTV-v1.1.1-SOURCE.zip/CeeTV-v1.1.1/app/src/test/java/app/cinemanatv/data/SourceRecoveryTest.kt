package app.cinemanatv.data
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.Assert.*
class SourceRecoveryTest {
    @Test fun refreshCanExcludeTheFailedUrlWhileKeepingOtherSuppliedSources()=runBlocking {
        val first=QualityOption(720,"https://media.example/failed.mp4")
        val second=QualityOption(480,"https://media.example/working.mp4")
        val repo=Repository(object:StubCeeCatalog(){override suspend fun sources(id:String)=PlaySources(listOf(first,second),emptyList())})
        assertEquals(listOf(second),repo.loadSources("cee_123",setOf(first.url)).qualities)
        assertEquals(listOf(first,second),repo.loadSources("cee_123").qualities)
    }
}
