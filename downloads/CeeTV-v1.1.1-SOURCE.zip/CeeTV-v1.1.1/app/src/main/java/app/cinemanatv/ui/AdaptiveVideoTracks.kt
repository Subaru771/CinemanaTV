@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package app.cinemanatv.ui

import androidx.media3.common.C
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks

internal data class VideoRendition(val height:Int,val group:TrackGroup,val index:Int)

/** Only decoder-supported, source-declared video tracks. No invented resolutions. */
internal fun videoRenditions(tracks:Tracks):List<VideoRendition> {
    val groups=tracks.groups.filter { it.type==C.TRACK_TYPE_VIDEO }.sortedByDescending { it.isSelected }
    return groups.flatMap { group ->
        (0 until group.length).filter { group.isTrackSupported(it) && group.getTrackFormat(it).height>0 }
            .sortedByDescending { group.getTrackFormat(it).bitrate }
            .map { VideoRendition(group.getTrackFormat(it).height,group.mediaTrackGroup,it) }
    }.distinctBy{it.height}.sortedByDescending{it.height}
}
