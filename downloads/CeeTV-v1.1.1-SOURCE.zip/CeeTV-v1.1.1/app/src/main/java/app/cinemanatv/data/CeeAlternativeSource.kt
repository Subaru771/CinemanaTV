package app.cinemanatv.data

import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.IOException
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/** Resolves the public CEE player route for the native catalogue. */
object CeeAlternativeSource {
    const val BASE = "https://cinamana.cc/"
    /** Server slots tried in order (0 = the site's default). Bounded so a dead title fails fast. */
    internal const val MAX_SERVERS = 4

    /** The page answered, but this slot offers nothing the native player can use.
     *  This and other IO failures may advance to another bounded server slot. */
    internal class NoPlayableStream(message: String) : IOException(message)
    private val client by lazy { OkHttpClient.Builder()
        .followRedirects(false).followSslRedirects(false)
        .connectTimeout(12, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS).build() }
    // Keep identity checks safe to use during UI composition.
    // Keep it independent of HTTP/TLS setup and Android's native regex compiler.
    private val postId by lazy { Regex("[0-9]{1,12}") }
    private val watchPath by lazy { Regex("/watch=([0-9]{1,12})/?") }
    // ICU (Android) rejects the unescaped closing brace that the JDK accepts.
    internal const val SOURCE_PATTERN = """\{\s*file\s*:\s*["']([^"']+)["']\s*,\s*label\s*:\s*["']([^"']*)["']\s*\}"""
    internal const val MASTER_PATTERN = """\b(?:const|let|var)\s+masterUrl\s*=\s*["']([^"']+)["']"""
    private val source by lazy { Regex(SOURCE_PATTERN) }
    private val master by lazy { Regex(MASTER_PATTERN) }

    fun owns(id: String): Boolean = id.startsWith("cee_")

    internal fun pageId(url: String): String? {
        val parsed = url.toHttpUrlOrNull() ?: return null
        if (parsed.scheme != "https" || parsed.host != "cinamana.cc" || parsed.port != 443 ||
            parsed.username.isNotEmpty() || parsed.password.isNotEmpty()) return null
        return watchPath.matchEntire(parsed.encodedPath)?.groupValues?.get(1)
    }

    internal fun catalog(html: String): List<Video> = Jsoup.parse(html, BASE)
        .select("a[href]").asSequence().filterNot { it.hasClass("cn-mega-item") }
        .mapNotNull { anchor ->
            val id = pageId(anchor.absUrl("href")) ?: return@mapNotNull null
            val title = anchor.selectFirst("h2, h3")?.text()?.trim()
                ?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            // Do not inherit IMDb IDs, ratings, timestamps or season queues from another cut.
            Video(nb = "cee_$id", enTitle = title,
                year = Regex("\\b(?:19|20)[0-9]{2}\\b").findAll(title).lastOrNull()?.value,
                enContent = "CEE source · $BASE" )
        }.distinctBy { it.id }.take(40).toList()

    internal fun embed(html: String): HttpUrl {
        val raw = Jsoup.parse(html, BASE).selectFirst("iframe[src]")?.absUrl("src")
            ?.toHttpUrlOrNull() ?: throw NoPlayableStream("CEE source returned no supported player.")
        val target = if (raw.host == "cinamana.cc" && raw.encodedPath == "/acm.php") {
            raw.queryParameter("url")?.toHttpUrlOrNull()
        } else raw
        if (target != null && isVkPlayer(target.toString())) return target
        if (target == null || !allowedPage(target) || target.host !in setOf("mp4plus.org", "cdnplus.sbs") ||
            !Regex("/embed-[A-Za-z0-9]+\\.html").matches(target.encodedPath))
            throw NoPlayableStream("CEE source uses an unsupported player host.")
        return target
    }

    internal fun isVkPlayer(address: String): Boolean {
        val url = address.toHttpUrlOrNull() ?: return false
        return url.scheme == "https" && url.port == 443 && url.username.isEmpty() && url.password.isEmpty() &&
            url.host in setOf("vkvideo.ru", "vk.com") && url.encodedPath == "/video_ext.php" &&
            url.queryParameter("oid")?.matches(Regex("-?[0-9]{1,20}")) == true &&
            url.queryParameter("id")?.matches(Regex("[0-9]{1,20}")) == true
    }

    /** Decode the player's bounded string dictionary; never evaluate its JavaScript. */
    private fun unpack(html: String): String {
        var cursor = html.indexOf("}('").takeIf { it >= 0 }?.plus(2) ?: return html
        fun quoted(): String? {
            if (html.getOrNull(cursor++) != '\'') return null
            val out = StringBuilder()
            while (cursor < html.length) {
                val ch = html[cursor++]
                if (ch == '\'') return out.toString()
                if (ch == '\\' && cursor < html.length) {
                    val next = html[cursor++]
                    if (next != '\'' && next != '\\') out.append('\\')
                    out.append(next)
                } else out.append(ch)
            }
            return null
        }
        fun commaNumber(): Int? {
            if (html.getOrNull(cursor++) != ',') return null
            val start = cursor
            while (html.getOrNull(cursor)?.let { it in '0'..'9' } == true) cursor++
            return html.substring(start, cursor).toIntOrNull()
        }
        var payload = quoted() ?: return html
        val radix = commaNumber()?.takeIf { it in 2..36 } ?: return html
        val count = commaNumber()?.takeIf { it in 1..2000 } ?: return html
        if (html.getOrNull(cursor++) != ',') return html
        val words = (quoted() ?: return html).split('|')
        if (!html.startsWith(".split('|')", cursor) || words.size != count) return html
        for (index in count - 1 downTo 0) {
            if (words[index].isNotEmpty()) {
                val token = Regex("\\b" + index.toString(radix) + "\\b")
                payload = token.replace(payload) { words[index] }
                if (payload.length > 2_000_000) return html
            }
        }
        return payload
    }

    internal fun qualities(html: String): List<QualityOption> {
        val decoded = unpack(html)
        // Some CEE pages declare an Hls.js URL as `const u`; commented legacy iframes are ignored.
        val document = Jsoup.parse(decoded)
        val script = document.select("script:not([src])").joinToString("\n") { it.data() }
        val declared = Regex("""\b(?:const|let|var)\s+u\s*=\s*["']([^"']+)["']""").find(script)
            ?.groupValues?.get(1)?.replace("\\/", "/")?.toHttpUrlOrNull()
        val declaredHls = declared?.takeIf { allowedMedia(it) && it.encodedPath.endsWith(".m3u8", true) &&
            Regex("""\.loadSource\(\s*u\s*\)""").containsMatchIn(script) }?.let {
            QualityOption(0, it.toString(), "CEE · Auto (HLS)", "application/x-mpegURL")
        }

        val adaptive = Regex("""\bfile\s*:\s*["']([^"']+)["']""").findAll(decoded).mapNotNull {
            val url = it.groupValues[1].replace("\\/", "/").toHttpUrlOrNull() ?: return@mapNotNull null
            if (!allowedMedia(url) || !url.encodedPath.endsWith(".m3u8", true)) return@mapNotNull null
            QualityOption(0, url.toString(), "CEE · Auto (HLS)", "application/x-mpegURL")
        }.toList()

        val direct = source.findAll(decoded).mapNotNull { match ->
        val url = match.groupValues[1].replace("\\/", "/").toHttpUrlOrNull()
            ?: return@mapNotNull null
        if (!allowedMedia(url)) return@mapNotNull null
        val height = Regex("[0-9]{3,4}").find(match.groupValues[2])?.value?.toIntOrNull() ?: 0
        QualityOption(height, url.toString(), if (height > 0) "CEE · ${height}p" else "CEE · Auto",
            if (url.host == "stream.cinemana.cc" || allowedRelayTarget(url)) "application/x-mpegURL" else null)
        }.distinctBy { it.url }.sortedByDescending { it.height }.toList()
        val originalMaster = master.find(decoded)?.groupValues?.get(1)?.replace("\\/", "/")?.toHttpUrlOrNull()
        val relay = originalMaster?.takeIf(::allowedRelayTarget)?.let { target ->
            "https://stream.cinemana.cc/cinema-stream".toHttpUrlOrNull()!!.newBuilder()
                .addQueryParameter("url", target.toString()).build()
        }
        val nativeMaster=originalMaster?.takeIf(::allowedRelayTarget)?.let { QualityOption(0,it.toString(),"CEE · Direct HLS","application/x-mpegURL") }
        return (direct + adaptive + listOfNotNull(nativeMaster) + listOfNotNull(declaredHls) + listOfNotNull(relay?.let {
            QualityOption(0, it.toString(), "CEE · Auto (HLS)", "application/x-mpegURL")
        })).distinctBy { it.url }
    }

    private fun allowedRelayTarget(url: HttpUrl): Boolean = url.scheme == "https" && url.port == 443 &&
        url.username.isEmpty() && url.password.isEmpty() && url.host.endsWith(".scdns.io") &&
        url.encodedPath.endsWith(".m3u8", true)

    internal fun allowedMedia(url: HttpUrl): Boolean {
        if (url.scheme != "https" || url.port != 443 || url.username.isNotEmpty() || url.password.isNotEmpty()) return false
        if (allowedRelayTarget(url)) return true
        if (url.host == "stream.cinemana.cc" && url.encodedPath == "/cinema-stream")
            return url.queryParameter("url")?.toHttpUrlOrNull()?.let(::allowedRelayTarget) == true
        return (url.host.endsWith(".cdnz.quest") || url.host.endsWith(".brqz.online") || url.host == "fvideo6d.ddns.me") &&
            listOf(".mp4", ".m3u8", ".mpd").any { url.encodedPath.lowercase().endsWith(it) }
    }

    private fun allowedPage(url: HttpUrl): Boolean = url.scheme == "https" && url.port == 443 &&
        url.username.isEmpty() && url.password.isEmpty() && url.host in setOf("cinamana.cc", "mp4plus.org", "cdnplus.sbs")

    /** Bounded HTTP fetch; validate each redirect before sending a request to its destination. */
    private fun fetch(initial: Request): String {
        var request = initial
        repeat(6) {
            if (!allowedPage(request.url)) throw IOException("Unsupported CEE source address.")
            client.newCall(request).execute().use { response ->
                if (response.code in listOf(301, 302, 303, 307, 308)) {
                    val next = response.header("Location")?.let(request.url::resolve)
                        ?: throw IOException("CEE source returned an invalid redirect.")
                    request = if (response.code in listOf(301, 302, 303))
                        request.newBuilder().url(next).get().build()
                    else request.newBuilder().url(next).build()
                } else {
                    if (!response.isSuccessful) throw IOException("CEE source HTTP ${response.code}.")
                    val body = response.body ?: throw IOException("CEE source returned no page.")
                    val bytes = body.byteStream().use { input ->
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(8192)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            if (output.size() + count > 2_000_000)
                                throw IOException("CEE source page is too large.")
                            output.write(buffer, 0, count)
                        }
                        output.toByteArray()
                    }
                    return String(bytes, Charsets.UTF_8)
                }
            }
        }
        throw IOException("CEE source redirected too many times.")
    }

    private fun request(url: HttpUrl): Request.Builder = Request.Builder().url(url)
        .header("User-Agent", "Mozilla/5.0")

    internal suspend fun document(url: String): String = withContext(Dispatchers.IO) {
        val parsed = url.toHttpUrlOrNull() ?: throw IOException("Invalid CEE catalogue address.")
        fetch(request(parsed).build())
    }

    internal suspend fun episodeDocument(cursor:EpisodeCursor):String = withContext(Dispatchers.IO) {
        require(cursor.seasonId.matches(Regex("[0-9]{1,12}")) && cursor.currentPostId.matches(Regex("[0-9]{1,12}")) && cursor.page in 1..1000)
        val endpoint=(BASE+"wp-admin/admin-ajax.php").toHttpUrlOrNull()!!
        fetch(request(endpoint).header("Referer",BASE+"watch="+cursor.currentPostId+"/")
            .post(FormBody.Builder().add("action","load_more_episodes").add("season_id",cursor.seasonId)
                .add("page",cursor.page.toString()).add("current_post_id",cursor.currentPostId).build()).build())
    }

    suspend fun search(query: String): List<Video> = withContext(Dispatchers.IO) {
        val trimmed = query.trim().take(250)
        // A precise episode page can be selected when the website's search lacks episode results.
        if (trimmed.startsWith("https://")) {
            val id = pageId(trimmed) ?: throw IOException("Enter a cinamana.cc/watch=… page URL.")
            val html = fetch(request("${BASE}watch=$id/".toHttpUrlOrNull()!!).build())
            val title = Jsoup.parse(html).selectFirst("h1")?.text()?.trim()
                ?.takeIf { it.isNotBlank() } ?: throw IOException("The selected page has no title.")
            return@withContext listOf(Video(nb = "cee_$id", enTitle = title,
                enContent = "CEE source · $BASE"))
        }
        val url = if (trimmed.isBlank()) "${BASE}main".toHttpUrlOrNull()!!
            else BASE.toHttpUrlOrNull()!!.newBuilder().addQueryParameter("s", trimmed).build()
        catalog(fetch(request(url).build()))
    }

    internal fun usableRoutes(options:List<QualityOption>,rejected:Set<String>,verifyDirect:(String)->Boolean):List<QualityOption> {
        val remaining=options.filterNot{it.url in rejected}
        val relayAvailable=remaining.any{it.url.toHttpUrlOrNull()?.host=="stream.cinemana.cc"}
        return remaining.filter { option ->
            val direct=option.url.toHttpUrlOrNull()?.let(::allowedRelayTarget)==true
            !direct || (!relayAvailable && verifyDirect(option.url))
        }
    }
    private val directChecks=LinkedHashMap<String,Pair<Long,Boolean>>()
    private val probeClient by lazy { client.newBuilder().callTimeout(6,TimeUnit.SECONDS).readTimeout(5,TimeUnit.SECONDS).build() }
    private fun directReadable(address:String):Boolean {
        synchronized(directChecks){directChecks[address]?.takeIf{System.currentTimeMillis()-it.first<30_000}}?.let{return it.second}
        fun playlist(url:HttpUrl):String? {
            if(!allowedRelayTarget(url))return null
            return probeClient.newCall(Request.Builder().url(url).header("User-Agent",userAgent()).build()).execute().use { response ->
                if(!response.isSuccessful)return@use null
                val bytes=response.body?.byteStream()?.use { input ->
                    val output=ByteArrayOutputStream();val buffer=ByteArray(4096)
                    while(output.size()<65_537){
                        val count=input.read(buffer,0,minOf(buffer.size,65_537-output.size()))
                        if(count<0)break
                        output.write(buffer,0,count)
                    }
                    output.toByteArray()
                } ?: return@use null
                if(bytes.size>65_536)return@use null
                String(bytes,Charsets.UTF_8).takeIf{it.trimStart().startsWith("#EXTM3U")}
            }
        }
        val readable=runCatching {
            val masterUrl=address.toHttpUrlOrNull() ?: return@runCatching false
            val master=playlist(masterUrl) ?: return@runCatching false
            val next=master.lineSequence().map{it.trim()}.firstOrNull{it.isNotEmpty() && !it.startsWith("#")} ?: return@runCatching false
            val variant=masterUrl.resolve(next) ?: return@runCatching false
            playlist(variant)!=null
        }.getOrDefault(false)
        synchronized(directChecks){directChecks[address]=System.currentTimeMillis() to readable;while(directChecks.size>16)directChecks.remove(directChecks.keys.first())}
        return readable
    }

    /** Runs [attempt] for server slots 0 until [servers]; moves on after a slot-specific IO failure.
     *  If every slot fails that way, the first slot's error is reported (it is the site's default). */
    internal inline fun <T> firstPlayable(servers: Int, attempt: (Int) -> T): T {
        var first: IOException? = null
        for (server in 0 until servers) {
            try { return attempt(server) } catch (e: IOException) { if (first == null) first = e }
        }
        throw first ?: NoPlayableStream("No server slot was tried.")
    }

    suspend fun resolve(id: String,rejected:Set<String> = emptySet()): PlaySources = withContext(Dispatchers.IO) {
        val number = id.removePrefix("cee_")
        if (!owns(id) || !postId.matches(number)) throw IOException("Invalid alternative title ID.")
        // Resolve again on retry; signed stream URLs never enter persistent preferences.
        kotlinx.coroutines.withTimeoutOrNull(30_000L) {
            firstPlayable(MAX_SERVERS) { server ->
                coroutineContext.ensureActive()
                resolveServer(number,server,rejected)
            }
        } ?: throw IOException("Provider lookup timed out. Please retry.")
    }

    private fun resolveServer(number: String, server: Int,rejected:Set<String>): PlaySources {
        val endpoint = "${BASE}wp-content/themes/EEE/Inc/Ajax/Single/Server.php".toHttpUrlOrNull()!!
        val response = fetch(request(endpoint).header("Referer", "${BASE}watch=$number/")
            .post(FormBody.Builder().add("post_id", number).add("server", server.toString()).build()).build())
        val declaredInline=qualities(response)
        val inline = usableRoutes(declaredInline,rejected,::directReadable)
        if (inline.isNotEmpty()) return PlaySources(inline, emptyList())
        if(declaredInline.isNotEmpty())throw NoPlayableStream("No working stream remains for this title. Try again later or choose another title.")
        val player = embed(response)
        if (isVkPlayer(player.toString())) return PlaySources(emptyList(), emptyList(), player.toString())
        val streams = usableRoutes(qualities(fetch(request(player).header("Referer", BASE).build())),rejected,::directReadable)
        if (streams.isEmpty()) throw NoPlayableStream("No supported MP4, HLS or DASH streams were returned. Try another title.")
        return PlaySources(streams, emptyList())
    }

}
