# Cinemana CEE TV 1.0 verification

Reference inspection and implementation: 2026-11-12.

- Separate package `app.cinemanatv.cee`, versionName 1.0/versionCode 1, minSdk 26.
- CEE-backed home, search, detail and season/episode adapters replace the previous provider's API and authentication. No source switch or title matching is involved.
- Live catalogue check: three rows; Avengers Infinity War search returned one title; sample series page returned 13 episode links.
- Live MP4 check: two qualities resolved, first media request returned HTTP 206 and a valid MP4 `ftyp` header.
- Live HLS check: the movie player returned an explicit HLS source whose relay served an `#EXTM3U` master playlist.
- Final build: testDebugUnitTest and assembleRelease succeeded; 158 tests, zero failures/errors/skips.
- Unit and Robolectric tests cover native player startup, provider parsing, routing, queues, resume-related models and error handling. Optional live tests require CEE_LIVE_TEST=1.
- Native ICU check reproduces the old unescaped-brace failure and accepts the provider's production patterns.

These checks do not establish support on every ISP or hardware decoder. A real TV playback/remote test is still required. The Leanback reference's protected backend was not recovered; the implemented provider is the public route traced from the mobile CEE reference.

On TV: install this separate app, open a movie, press Play; then open a series, choose a season/episode and test Auto Next. Disable the network temporarily and verify a failed request produces an error rather than closing the app. Existing Cinemana TV installations remain separate.
