package app.cinemanatv.data

import okhttp3.HttpUrl.Companion.toHttpUrl
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class CeeAlternativeSourceTest {
    @Test fun literalObjectBracesAreEscapedForAndroidIcu() {
        assertTrue(CeeAlternativeSource.SOURCE_PATTERN.startsWith("\\{"))
        assertTrue(CeeAlternativeSource.SOURCE_PATTERN.endsWith("\\}"))
        assertTrue(CeeAlternativeSource.owns("cee_123"))
        assertFalse(CeeAlternativeSource.owns("123"))
    }
    @Test fun catalogKeepsProviderIdentityAndExcludesPinnedAndForeignLinks() {
        val html = """
            <a class="cn-mega-item" href="/watch=9/"><h3>Pinned advertisement</h3></a>
            <a href="/watch=123/"><h3>The Matrix 1999</h3></a>
            <a href="/watch=123/"><h3>Duplicate</h3></a>
            <a href="https://other.example/watch=124/"><h3>Foreign</h3></a>
            <a href="/watch=125/"><h3>Season 2 Episode 3</h3></a>
            <a href="/watch=126/">Navigation without a title</a>
        """.trimIndent()
        val results = CeeAlternativeSource.catalog(html)
        assertEquals(listOf("cee_123", "cee_125"), results.map { it.id })
        assertEquals("The Matrix 1999", results.first().title)
        assertEquals("1999", results.first().year)
        assertTrue(results.all { it.imdbRef == null && it.introWindow == null && it.rootSeries == null })
    }

    @Test fun pageLinksRequireTheExactProviderHostAndNumericPost() {
        assertEquals("123", CeeAlternativeSource.pageId("https://cinamana.cc/watch=123/"))
        listOf("http://cinamana.cc/watch=123/", "https://cinamana.cc.evil.example/watch=123/",
            "https://user@cinamana.cc/watch=123/", "https://cinamana.cc:444/watch=123/",
            "https://cinamana.cc/watch=no/", "https://cinamana.cc/watch=123/other").forEach {
            assertNull(it, CeeAlternativeSource.pageId(it))
        }
    }

    @Test fun wrapperUnwrapsThePlayerInsteadOfExecutingItsScripts() {
        val player = CeeAlternativeSource.embed("""<iframe src="https://cinamana.cc/acm.php?url=https%3A%2F%2Fmp4plus.org%2Fembed-abc123.html"></iframe>""")
        assertEquals("https://mp4plus.org/embed-abc123.html", player.toString())
    }

    @Test(expected = IOException::class) fun unrelatedEmbedHostsAreRejected() {
        CeeAlternativeSource.embed("""<iframe src="https://other.example/embed-abc123.html"></iframe>""")
    }

    @Test fun playerParserAcceptsOnlySupportedHttpsMediaAndSortsQualities() {
        val html = """
            sources: [{file:"https://video.cdnz.quest/token-low/v.mp4",label:"320p"},
            {file:"https://video.cdnz.quest/token-high/v.mp4",label:"480p"},
            {file:"http://video.cdnz.quest/plain/v.mp4",label:"1080p"},
            {file:"https://ads.example/payload.mp4",label:"2160p"},
            {file:"https://video.cdnz.quest/not-media.html",label:"720p"}]
        """.trimIndent()
        val result = CeeAlternativeSource.qualities(html)
        assertEquals(listOf(480, 320), result.map { it.height })
        assertTrue(result.all { it.label.startsWith("CEE") })
        assertTrue(CeeAlternativeSource.qualities("<html>Maintenance</html>").isEmpty())
    }

    @Test fun mediaValidationRejectsLookalikeDomainsAndCredentials() {
        assertTrue(CeeAlternativeSource.allowedMedia("https://node.cdnz.quest/video.m3u8?expires=123".toHttpUrl()))
        listOf("https://node.cdnz.quest.evil.example/v.mp4", "https://user@node.cdnz.quest/v.mp4",
            "https://node.cdnz.quest:444/v.mp4", "https://cdnz.quest/v.mp4").forEach {
            assertFalse(it, CeeAlternativeSource.allowedMedia(it.toHttpUrl()))
        }
    }
}
