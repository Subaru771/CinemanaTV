# CinemanaTV Phone v1.6.6 touch hotfix

Cause: multiple interactive screens reused androidx.tv.material3 Surface and Button. Their TV focus/D-pad interaction does not guarantee pointer taps on a phone. The hotfix adds an actual Compose Foundation clickable to those components when LocalHandset is true, without altering TV focus navigation.

Affected: poster cards, episode thumbnails, AppButton (search, settings and action controls), announcement buttons, player transport controls, player sheet options.

Build: Android SDK 35, JDK 17; `./gradlew testDebugUnitTest assembleRelease`

Note: GitHub runner debug keystores differ between builds. Uninstall a previous test APK if Android says it cannot install an update; this clears app data. Production distribution requires a persistent private signing key.
