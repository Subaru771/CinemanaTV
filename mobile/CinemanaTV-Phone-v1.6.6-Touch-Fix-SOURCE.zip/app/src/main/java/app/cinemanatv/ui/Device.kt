package app.cinemanatv.ui

import androidx.compose.foundation.clickable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier

/** TV and phones share the repository, but pointer events must not rely on TV D-pad semantics. */
val LocalHandset = staticCompositionLocalOf { false }

/** TV Material Surface/Button uses D-pad and semantics onClick, not a handset pointer click target.
 * Append a genuine clickable to make it operate with a finger without changing TV focus paths. */
@Composable
fun Modifier.touchOnPhone(onClick: () -> Unit): Modifier =
    if (LocalHandset.current) this.clickable(onClick = onClick) else this
