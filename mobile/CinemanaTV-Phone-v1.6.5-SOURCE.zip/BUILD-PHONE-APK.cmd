@echo off
cd /d "%~dp0"
call gradlew.bat --no-daemon testDebugUnitTest assembleRelease
if errorlevel 1 (echo Build failed. Check error above. & pause & exit /b 1)
echo APK: app\build\outputs\apk\release\app-release.apk
pause
