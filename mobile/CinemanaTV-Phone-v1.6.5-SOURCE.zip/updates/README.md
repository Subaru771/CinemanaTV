# Cinemana TV — enabling update notifications

The app already contains the version comparison, a network check on each **fresh launch**, and a remote-friendly update dialog. The checker requires a publicly reachable JSON file to learn when a new APK exists.

## One-time setup (no server process required)

1. Upload `update.json` to an HTTPS static host (Cloudflare Pages, GitHub Pages, etc.). Start from `update.example.json`, but replace the example domain with a REAL APK download URL before publishing. Give the uploaded file a stable URL such as `https://your-existing-site.example/update.json`.
2. Before building the app, write the actual URL in the untracked `local.properties`:

   `cinemana.updateFeedUrl=https://YOUR-REAL-SITE/update.json`

   Or provide Gradle property `-Pcinemana.updateFeedUrl=https://YOUR-REAL-SITE/update.json`.
3. For the existing GitHub Actions build, add an Actions repository **variable** `CINEMANA_UPDATE_FEED_URL` containing the *published manifest* URL. The workflow passes it to Gradle.
4. Build and install the new app. For later releases, update the public `update.json` with the **newer versionCode**, version name and real HTTPS APK URL. Only newer builds trigger the notice.

## Manifest format

```json
{
  "versionCode": 61,
  "versionName": "1.6.6",
  "downloadUrl": "https://YOUR-REAL-SITE/CinemanaTV-v1.6.2.apk",
  "notes": "Optional short release summary",
  "notesAr": "ملخص اختياري للتحديث بالعربية"
}
```

The current app is **v1.6.5 / versionCode 60**. Version 60 or below will never trigger the update notification. The request uses HTTPS, 5-second timeouts, a 32-KB response cap and no background polling. Connection errors, invalid JSON or unavailable feeds produce no notice.

**Not a push-notification service:** it checks when viewers launch the app, rather than waking the device when the app is closed. **Not an auto-installer:** selecting Get update opens the provided HTTPS download URL. Android TV browsers/download managers vary; installation requires user approval. Keep your APK signing certificate identical for Android to accept an update without uninstalling the old version.

**Security:** only host the update feed and APK on a trusted server you control. The app intentionally does not sideload packages or install unknown binaries by itself.
