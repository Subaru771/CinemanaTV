package app.cinemanatv.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.tv.material3.Text

/** Touch-first navigation. All destinations are the original TV pages and view-model state. */
@Composable
fun MobileShell(vm: AppViewModel) {
    var showMore by remember { mutableStateOf(false) }
    val isSearching = vm.tab == 3
    Column(
        Modifier.fillMaxSize()
            .background(C.Bg)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        Row(
            Modifier.fillMaxWidth().height(54.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Cinemana", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("  "+t("MOBILE"), color = C.Red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier.clip(RoundedCornerShape(12.dp))
                    .background(C.Panel)
                    .clickable {
                        if (isSearching) vm.tab = vm.lastTab
                        else { vm.lastTab = vm.tab; vm.tab = 3 }
                    }.padding(horizontal = 16.dp, vertical = 10.dp)
            ) { Text(if (isSearching) "✕  "+t("Close") else "⌕  "+t("Search"), fontSize = 14.sp) }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (vm.tab) {
                0 -> HomeScreen(null, vm)
                1 -> HomeScreen(2, vm)
                2 -> HomeScreen(1, vm)
                3 -> SearchScreen(vm)
                4 -> HistoryScreen(vm)
                5 -> WatchlistScreen(vm)
                6 -> DownloadsScreen(vm)
                7 -> SettingsScreen(vm)
                else -> HomeScreen(null, vm)
            }
        }
        Row(
            Modifier.fillMaxWidth().height(65.dp)
                .background(Color(0xFF141923)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MobileTab("⌂", "Home", vm.tab == 0, Modifier.weight(1f)) { vm.tab = 0 }
            MobileTab("▤", "Series", vm.tab == 1, Modifier.weight(1f)) { vm.tab = 1 }
            MobileTab("▣", "Movies", vm.tab == 2, Modifier.weight(1f)) { vm.tab = 2 }
            MobileTab("♡", "My List", vm.tab == 5, Modifier.weight(1f)) { vm.tab = 5 }
            MobileTab("⋯", "More", vm.tab in listOf(4,6,7), Modifier.weight(1f)) { showMore = true }
        }
    }
    if (showMore) Dialog(onDismissRequest = { showMore = false }) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                .background(C.Panel).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(t("More"), fontWeight = FontWeight.Bold, fontSize = 22.sp)
            listOf(4 to "History", 6 to "Downloads", 7 to "Settings").forEach { (tab, name) ->
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(if (vm.tab == tab) Color(0xFF3B2631) else Color(0xFF232A38))
                    .clickable { vm.tab = tab; showMore = false }
                    .padding(16.dp)) {
                    Text(t(name), fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun MobileTab(icon: String, title: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val color = if (selected) C.Red else C.Dim
    Column(
        modifier.fillMaxHeight().clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = color, fontSize = 23.sp, lineHeight = 26.sp)
        Text(t(title), color = color, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
