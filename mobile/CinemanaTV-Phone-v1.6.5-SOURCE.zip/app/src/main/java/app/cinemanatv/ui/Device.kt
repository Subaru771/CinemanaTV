package app.cinemanatv.ui

import androidx.compose.runtime.staticCompositionLocalOf

/** The TV and phone apps share exactly the same playback, repositories and settings. */
val LocalHandset = staticCompositionLocalOf { false }
