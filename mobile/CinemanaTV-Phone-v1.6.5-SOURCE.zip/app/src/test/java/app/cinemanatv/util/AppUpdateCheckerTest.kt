package app.cinemanatv.util

import org.junit.Assert.*
import org.junit.Test

class AppUpdateCheckerTest {
    private val manifest = """{"versionCode":57,"versionName":"1.6.2","downloadUrl":"https://example.org/CinemanaTV.apk","notes":"New version"}"""

    @Test fun newerVersionTriggersNotice() {
        val update = AppUpdateChecker.parseManifest(manifest, 56)
        assertNotNull(update)
        assertEquals(57L, update!!.versionCode)
        assertEquals("1.6.2", update.versionName)
    }

    @Test fun sameAndOlderVersionsNeverTriggerNotice() {
        assertNull(AppUpdateChecker.parseManifest(manifest, 57))
        assertNull(AppUpdateChecker.parseManifest(manifest, 58))
    }

    @Test fun unsafeAndMalformedUrlsRejected() {
        assertNull(AppUpdateChecker.parseManifest(manifest.replace("https://", "http://"), 56))
        assertNull(AppUpdateChecker.parseManifest(manifest.replace("https://example.org/CinemanaTV.apk", "javascript:alert(1)"), 56))
        assertNull(AppUpdateChecker.parseManifest("{oops", 56))
    }

    @Test fun missingRequiredFieldsRejected() {
        assertNull(AppUpdateChecker.parseManifest("""{"versionCode":58,"versionName":"1.6.3"}""", 56))
    }
}
