# CinemanaTV Mobile — v1.6.5-phone.1

Native Android phone port of the full CinemanaTV v1.6.5 Kotlin/Jetpack Compose source.

## Mobile changes
- Portrait touch interface with bottom navigation, search and More menu.
- Compact mobile home rows, hero, details, search, downloads, lists and settings.
- Fullscreen landscape playback and touch gestures (tap controls; double-tap left/right seeks 10 seconds).
- Existing underlying catalog, playback, download, subtitle, next-episode, filter, and history features retained.
- Distinct `app.cinemanatv.mobile` application ID to coexist with Android TV build.
- Mobile-specific update feed config; TV update feed cannot replace this APK.
- TV recommendations disabled on handsets.

## Build
Unzip the project. Install Android Studio / Android SDK 35 and Java 17+.
Run `./gradlew :app:assembleRelease` (Windows: `gradlew.bat :app:assembleRelease`).
APK appears at `app/build/outputs/apk/release/app-release.apk`.

**Release signing:** Current Gradle source uses its debug signing key for the release build.
This is for testing only; create a durable production signing key before public distribution.

**Verification:** Source changes have been statically reviewed. A local Android build/test is not possible without SDK and Maven dependencies. Use the included GitHub Actions workflow to compile and run tests.
